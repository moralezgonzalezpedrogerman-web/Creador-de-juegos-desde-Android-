#include "importer.h"
#include "model.h"

#define CGLTF_IMPLEMENTATION
#include "cgltf.h"
#include "ufbx.h"

#include <algorithm>
#include <cmath>
#include <cstring>
#include <sstream>
#include <unordered_map>

namespace forge {

static std::string lower(std::string s) {
    for (auto& c : s) c = (char)tolower((unsigned char)c);
    return s;
}

static std::string extOf(const std::string& n) {
    size_t p = n.rfind('.');
    return p == std::string::npos ? "" : lower(n.substr(p + 1));
}

static std::string baseOf(const std::string& n) {
    std::string b = n;
    size_t p = b.rfind('.');
    if (p != std::string::npos) b = b.substr(0, p);
    for (auto& c : b) if (c == ' ' || c == '/' || c == '\\') c = '_';
    return b.empty() ? "modelo" : b;
}

bool isModelFile(const std::string& n) {
    std::string e = extOf(n);
    return e == "obj" || e == "glb" || e == "gltf" || e == "fbx";
}

// Triangulos sin indexar: 8 floats por vertice (pos, normal, uv). Normal (0,0,0) = sin normal.
struct Raw {
    std::vector<float> v;
    std::string tex;
    float color[3] = {1, 1, 1};
    void add(const float* p, const float* n, const float* uv) {
        v.insert(v.end(), {p[0], p[1], p[2], n[0], n[1], n[2], uv[0], uv[1]});
    }
};

// ---------------------------------------------------------------- OBJ
static bool parseObj(const std::string& text, Raw& raw, std::string& err) {
    std::vector<float> P, T, N;
    std::istringstream in(text);
    std::string line;
    while (std::getline(in, line)) {
        std::istringstream ls(line);
        std::string tag;
        ls >> tag;
        if (tag == "v") { float x = 0, y = 0, z = 0; ls >> x >> y >> z; P.insert(P.end(), {x, y, z}); }
        else if (tag == "vt") { float u = 0, v = 0; ls >> u >> v; T.insert(T.end(), {u, v}); }
        else if (tag == "vn") { float x = 0, y = 0, z = 0; ls >> x >> y >> z; N.insert(N.end(), {x, y, z}); }
        else if (tag == "f") {
            struct Ref { int p = -1, t = -1, n = -1; };
            std::vector<Ref> face;
            std::string tok;
            while (ls >> tok) {
                Ref r;
                int idx[3] = {0, 0, 0}, k = 0;
                bool has[3] = {false, false, false};
                size_t i = 0;
                while (i <= tok.size() && k < 3) {
                    size_t j = tok.find('/', i);
                    std::string part = tok.substr(i, j == std::string::npos ? std::string::npos : j - i);
                    if (!part.empty()) { idx[k] = atoi(part.c_str()); has[k] = true; }
                    k++;
                    if (j == std::string::npos) break;
                    i = j + 1;
                }
                auto res = [](int v, size_t count) { return v > 0 ? v - 1 : (int)count + v; };
                if (has[0]) r.p = res(idx[0], P.size() / 3);
                if (has[1]) r.t = res(idx[1], T.size() / 2);
                if (has[2]) r.n = res(idx[2], N.size() / 3);
                if (r.p < 0 || (size_t)r.p >= P.size() / 3) { err = "OBJ con indices invalidos"; return false; }
                if (r.t >= 0 && (size_t)r.t >= T.size() / 2) r.t = -1;
                if (r.n >= 0 && (size_t)r.n >= N.size() / 3) r.n = -1;
                face.push_back(r);
            }
            for (size_t i = 1; i + 1 < face.size(); i++) {
                const Ref* t3[3] = {&face[0], &face[i], &face[i + 1]};
                for (auto* r : t3) {
                    float uv[2] = {0, 0}, n[3] = {0, 0, 0};
                    if (r->t >= 0) { uv[0] = T[r->t * 2]; uv[1] = T[r->t * 2 + 1]; }
                    if (r->n >= 0) { n[0] = N[r->n * 3]; n[1] = N[r->n * 3 + 1]; n[2] = N[r->n * 3 + 2]; }
                    raw.add(&P[r->p * 3], n, uv);
                }
            }
        }
    }
    return true;
}

// ---------------------------------------------------------------- glTF / GLB
static bool parseGltf(const std::vector<uint8_t>& data, const std::string& base, Raw& raw, Files& assets,
                      std::string& err) {
    cgltf_options opt;
    memset(&opt, 0, sizeof opt);
    cgltf_data* d = nullptr;
    if (cgltf_parse(&opt, data.data(), data.size(), &d) != cgltf_result_success) {
        err = "archivo glTF/GLB invalido";
        return false;
    }
    struct Free { cgltf_data* d; ~Free() { cgltf_free(d); } } guard{d};
    if (cgltf_load_buffers(&opt, d, nullptr) != cgltf_result_success) {
        err = "el glTF usa archivos externos (.bin): usa un .glb o exportalo con todo incrustado";
        return false;
    }
    bool gotMat = false;
    for (size_t ni = 0; ni < d->nodes_count; ni++) {
        cgltf_node* node = &d->nodes[ni];
        if (!node->mesh) continue;
        float M[16];
        cgltf_node_transform_world(node, M);
        for (size_t pi = 0; pi < node->mesh->primitives_count; pi++) {
            cgltf_primitive* pr = &node->mesh->primitives[pi];
            if (pr->type != cgltf_primitive_type_triangles) continue;
            cgltf_accessor *ap = nullptr, *an = nullptr, *at = nullptr;
            for (size_t a = 0; a < pr->attributes_count; a++) {
                cgltf_attribute& at_ = pr->attributes[a];
                if (at_.type == cgltf_attribute_type_position && at_.index == 0) ap = at_.data;
                if (at_.type == cgltf_attribute_type_normal && at_.index == 0) an = at_.data;
                if (at_.type == cgltf_attribute_type_texcoord && at_.index == 0) at = at_.data;
            }
            if (!ap) continue;
            if (!gotMat && pr->material) {
                gotMat = true;
                cgltf_material* m = pr->material;
                if (m->has_pbr_metallic_roughness) {
                    for (int k = 0; k < 3; k++) raw.color[k] = m->pbr_metallic_roughness.base_color_factor[k];
                    cgltf_texture* tx = m->pbr_metallic_roughness.base_color_texture.texture;
                    if (tx && tx->image && tx->image->buffer_view) {
                        cgltf_buffer_view* bv = tx->image->buffer_view;
                        const uint8_t* src = (const uint8_t*)bv->buffer->data + bv->offset;
                        bool jpg = tx->image->mime_type && strstr(tx->image->mime_type, "jpeg");
                        std::string tn = base + (jpg ? "_tex.jpg" : "_tex.png");
                        assets[tn].assign(src, src + bv->size);
                        raw.tex = tn;
                    }
                }
            }
            size_t count = pr->indices ? pr->indices->count : ap->count;
            for (size_t k = 0; k + 2 < count + 0 && k + 3 <= count; k += 3) {
                for (int c = 0; c < 3; c++) {
                    size_t vi = pr->indices ? cgltf_accessor_read_index(pr->indices, k + c) : k + c;
                    float p[3] = {0, 0, 0}, n[3] = {0, 0, 0}, uv[2] = {0, 0};
                    cgltf_accessor_read_float(ap, vi, p, 3);
                    if (an) cgltf_accessor_read_float(an, vi, n, 3);
                    if (at) { cgltf_accessor_read_float(at, vi, uv, 2); uv[1] = 1.f - uv[1]; }
                    float wp[3] = {M[0] * p[0] + M[4] * p[1] + M[8] * p[2] + M[12],
                                   M[1] * p[0] + M[5] * p[1] + M[9] * p[2] + M[13],
                                   M[2] * p[0] + M[6] * p[1] + M[10] * p[2] + M[14]};
                    float wn[3] = {M[0] * n[0] + M[4] * n[1] + M[8] * n[2], M[1] * n[0] + M[5] * n[1] + M[9] * n[2],
                                   M[2] * n[0] + M[6] * n[1] + M[10] * n[2]};
                    raw.add(wp, wn, uv);
                }
            }
        }
    }
    return true;
}

// ---------------------------------------------------------------- FBX
static bool parseFbx(const std::vector<uint8_t>& data, Raw& raw, std::string& err) {
    ufbx_load_opts opts;
    memset(&opts, 0, sizeof opts);
    opts.target_axes = ufbx_axes_right_handed_y_up;
    opts.target_unit_meters = 1.0f;
    ufbx_error uerr;
    ufbx_scene* sc = ufbx_load_memory(data.data(), data.size(), &opts, &uerr);
    if (!sc) {
        err = std::string("FBX invalido: ") + uerr.description.data;
        return false;
    }
    for (size_t ni = 0; ni < sc->nodes.count; ni++) {
        ufbx_node* node = sc->nodes.data[ni];
        ufbx_mesh* mesh = node->mesh;
        if (!mesh) continue;
        ufbx_matrix gm = node->geometry_to_world;
        std::vector<uint32_t> tris(mesh->max_face_triangles * 3);
        for (size_t fi = 0; fi < mesh->faces.count; fi++) {
            size_t nt = ufbx_triangulate_face(tris.data(), tris.size(), mesh, mesh->faces.data[fi]);
            for (size_t j = 0; j < nt * 3; j++) {
                uint32_t ix = tris[j];
                ufbx_vec3 p = ufbx_transform_position(&gm, ufbx_get_vertex_vec3(&mesh->vertex_position, ix));
                ufbx_vec3 n = {0, 0, 0};
                if (mesh->vertex_normal.exists) n = ufbx_transform_direction(&gm, ufbx_get_vertex_vec3(&mesh->vertex_normal, ix));
                ufbx_vec2 uv = {0, 0};
                if (mesh->vertex_uv.exists) uv = ufbx_get_vertex_vec2(&mesh->vertex_uv, ix);
                float pf[3] = {(float)p.x, (float)p.y, (float)p.z}, nf[3] = {(float)n.x, (float)n.y, (float)n.z},
                      uf[2] = {(float)uv.x, (float)uv.y};
                raw.add(pf, nf, uf);
            }
        }
    }
    ufbx_free_scene(sc);
    return true;
}

// ---------------------------------------------------------------- normalizar y compactar
struct Key {
    uint32_t k[8];
    bool operator==(const Key& o) const { return memcmp(k, o.k, sizeof k) == 0; }
};
struct KeyHash {
    size_t operator()(const Key& a) const {
        size_t h = 1469598103934665603ull;
        for (uint32_t x : a.k) { h ^= x; h *= 1099511628211ull; }
        return h;
    }
};

static bool finalize(Raw& raw, ModelData& out, std::string& err) {
    size_t nv = raw.v.size() / 8;
    if (nv < 3) { err = "el modelo no tiene triangulos"; return false; }
    if (nv > 6000000) { err = "el modelo es demasiado grande"; return false; }
    float mn[3] = {1e30f, 1e30f, 1e30f}, mx[3] = {-1e30f, -1e30f, -1e30f};
    for (size_t i = 0; i < nv; i++)
        for (int c = 0; c < 3; c++) {
            mn[c] = std::min(mn[c], raw.v[i * 8 + c]);
            mx[c] = std::max(mx[c], raw.v[i * 8 + c]);
        }
    float ext = std::max(mx[0] - mn[0], std::max(mx[1] - mn[1], mx[2] - mn[2]));
    if (!(ext > 1e-9f)) { err = "el modelo no tiene volumen"; return false; }
    float s = 1.f / ext, ce[3] = {(mn[0] + mx[0]) * .5f, (mn[1] + mx[1]) * .5f, (mn[2] + mx[2]) * .5f};
    for (size_t i = 0; i < nv; i++) {
        float* v = &raw.v[i * 8];
        for (int c = 0; c < 3; c++) v[c] = (v[c] - ce[c]) * s;
    }
    // Normales planas donde falten.
    for (size_t t = 0; t + 2 < nv; t += 3) {
        float* a = &raw.v[t * 8];
        float* b = a + 8;
        float* c = b + 8;
        float e1[3] = {b[0] - a[0], b[1] - a[1], b[2] - a[2]}, e2[3] = {c[0] - a[0], c[1] - a[1], c[2] - a[2]};
        float n[3] = {e1[1] * e2[2] - e1[2] * e2[1], e1[2] * e2[0] - e1[0] * e2[2], e1[0] * e2[1] - e1[1] * e2[0]};
        float l = std::sqrt(n[0] * n[0] + n[1] * n[1] + n[2] * n[2]);
        if (l > 1e-12f) { n[0] /= l; n[1] /= l; n[2] /= l; } else { n[0] = 0; n[1] = 1; n[2] = 0; }
        for (float* v : {a, b, c}) {
            float vl = std::sqrt(v[3] * v[3] + v[4] * v[4] + v[5] * v[5]);
            if (vl < 1e-6f) { v[3] = n[0]; v[4] = n[1]; v[5] = n[2]; }
            else { v[3] /= vl; v[4] /= vl; v[5] /= vl; }
        }
    }
    // Quitar vertices repetidos (indexar): baja mucho la memoria.
    std::unordered_map<Key, uint32_t, KeyHash> seen;
    seen.reserve(nv / 2);
    out.v.clear();
    out.idx.clear();
    for (size_t i = 0; i < nv; i++) {
        Key k;
        memcpy(k.k, &raw.v[i * 8], 32);
        auto it = seen.find(k);
        if (it == seen.end()) {
            it = seen.emplace(k, (uint32_t)(out.v.size() / 8)).first;
            out.v.insert(out.v.end(), raw.v.begin() + i * 8, raw.v.begin() + i * 8 + 8);
        }
        out.idx.push_back(it->second);
    }
    out.tex = raw.tex;
    for (int c = 0; c < 3; c++) out.color[c] = raw.color[c];
    return true;
}

bool importModel(const std::string& fileName, const std::vector<uint8_t>& data, Files& assets,
                 std::string& modelAssetName, std::string& err) {
    std::string e = extOf(fileName), base = baseOf(fileName);
    Raw raw;
    bool ok = false;
    if (e == "obj") ok = parseObj(std::string(data.begin(), data.end()), raw, err);
    else if (e == "glb" || e == "gltf") ok = parseGltf(data, base, raw, assets, err);
    else if (e == "fbx") ok = parseFbx(data, raw, err);
    else { err = "formato de modelo no compatible (usa obj, glb, gltf o fbx)"; return false; }
    if (!ok) return false;

    ModelData md;
    if (!finalize(raw, md, err)) return false;
    std::vector<uint8_t> bytes;
    if (!modelWrite(md, bytes)) { err = "no se pudo convertir el modelo"; return false; }

    std::string name = base + ".fmdl";
    for (int i = 2; assets.count(name); i++) name = base + "_" + std::to_string(i) + ".fmdl";
    assets[name] = std::move(bytes);
    modelAssetName = name;
    return true;
}

}  // namespace forge
