#pragma once
#include "scene.h"
#include <string>
#include <vector>

namespace forge {

// Convierte un modelo 3D (obj, glb, gltf con todo incrustado, fbx) al formato compacto .fmdl
// y lo agrega a los assets. Si el modelo trae textura incrustada, tambien se agrega como asset.
bool importModel(const std::string& fileName, const std::vector<uint8_t>& data, Files& assets,
                 std::string& modelAssetName, std::string& err);

bool isModelFile(const std::string& fileName);

}  // namespace forge
