#pragma once
#include "audio.h"
#include "playview.h"
#include "renderer.h"
#include <functional>
#include <set>
#include <string>
#include <vector>

namespace forge {

// Servicios que la plataforma ofrece al editor.
struct EditorHost {
    std::string dataDir;  // carpeta privada: proyectos y exportaciones
    std::function<void()> pickFile;  // abre el selector; el archivo llega a Editor::onFile
    std::function<void(const std::string& displayName, const std::string& path)> saveOut;  // copiar a donde elija el usuario
    std::function<bool(std::vector<uint8_t>&)> loadRuntime;  // forge_runtime.exe (para exportar)
};

enum class Screen { Projects, Edit, Play };

class Editor {
public:
    explicit Editor(EditorHost h) : host_(std::move(h)) {}
    void init(Audio* audio);

    // Una vez por frame, con ImGui::NewFrame() ya llamado. r puede ser null (pruebas).
    void frame(Renderer* r, int w, int h, float dt);
    void onFile(const std::string& name, std::vector<uint8_t> data);  // archivo elegido por el usuario
    PlayControls& controls() { return play_.ctl; }

    // --- proyectos
    bool newProject(const std::string& name, bool demo);
    bool openProject(const std::string& name);
    bool saveProject();
    void closeProject();
    bool buildPack(std::vector<uint8_t>& out);
    bool buildExe(std::vector<uint8_t>& out, std::string& err);

    // --- edicion (tambien usados por las pruebas)
    void addObject(Kind k, const std::string& modelName = "");
    void addScene(bool is3d);
    void select(int i) { sel_ = i; }
    void startPlay();
    void stopPlay();
    Screen screen() const { return screen_; }
    Project& project() { return edit_.proj; }
    PlayView& play() { return play_; }
    int sceneIndex() const { return sceneIdx_; }
    void setScene(int i);
    int selected() const { return sel_; }
    const std::vector<std::string>& projectNames() const { return projList_; }
    bool dirty() const { return dirty_; }

    // Ventanas visibles (publico para poder activarlas desde pruebas).
    bool showObjs = true, showProps = true, showBlocks = false, showWorld = false, showHud = false, showAssets = false;

private:
    EditorHost host_;
    Audio* audio_ = nullptr;
    Screen screen_ = Screen::Projects;
    Game edit_;                 // el proyecto en edicion (edit_.proj)
    PlayView play_;
    std::string name_, newName_ = "mi_juego";
    std::vector<std::string> projList_;
    std::set<std::string> assetDirty_;
    int sceneIdx_ = 0, sel_ = -1;
    bool dirty_ = false;
    float snap_ = 0.25f;
    int w_ = 1, h_ = 1;

    // mensaje temporal
    std::string toast_;
    float toastT_ = 0;
    void toast(const std::string& t) { toast_ = t; toastT_ = 3.5f; }

    // camara del editor
    float yaw_ = 0.6f, pitch_ = 0.55f, dist_ = 14.f;
    V3 target_;
    float cx_ = 0, cy_ = 0, h2d_ = kView2DHeight;

    // gestos
    int prevN_ = 0;
    bool gestOk_ = false, dragObj_ = false;
    float lastX_ = 0, lastY_ = 0, lastDist_ = 0, moveAcc_ = 0;
    V3 grab_;

    // ayudantes
    Scene& scene() { return edit_.proj.scenes[sceneIdx_]; }
    bool hasScene() const { return sceneIdx_ >= 0 && sceneIdx_ < (int)edit_.proj.scenes.size(); }
    Obj* selObj();
    std::string uniqueName(const std::string& base);
    void listProjects();
    void resetView();
    EditorView view() const;
    void rayAt(float x, float y, const EditorView& ev, V3& o, V3& d) const;
    int pick(float x, float y, const EditorView& ev);
    void gestures();
    std::vector<std::string> assetsOf(int kind) const;  // 0 imagen, 1 audio, 2 modelo
    void doExportExe();
    void doExportPack();

    // pantallas y ventanas
    void projectsUI(Renderer* r);
    void editFrame(Renderer* r, float dt);
    void playFrame(Renderer* r, float dt);
    void menuBar();
    void objectsWin();
    void propsWin();
    void blocksWin();
    void worldWin();
    void hudWin(Renderer* r);
    void assetsWin();
    void blocksUI(std::vector<Block>& list, int depth);
    void addBlockMenu(std::vector<Block>& list);
    void toastUI();
    void markDirty() { dirty_ = true; }
};

}  // namespace forge
