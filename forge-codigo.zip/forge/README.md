# Forge

Creador de videojuegos para Android con **motor propio** en C++ (sin Unity/Godot/etc.). Editor 3D estilo
FPS Creator + bloques estilo Pocket Code, luces y sombras, y exportación a **APK** y a **.exe**
(el .exe se arma dentro de la app, sin compilador externo).

## Qué incluye
- **Editor táctil**: arrastra y coloca cubos, suelos, paredes, objetos, luces, modelos 3D y el punto de inicio del jugador.
  Cámara: 1 dedo orbita, 2 dedos zoom/desplazar; arrastrar un objeto seleccionado lo mueve (con rejilla).
- **Propiedades**: posición, tamaño, giro, color, textura, sólido/visible/girar; paredes destructibles o móviles con bloques.
- **Mundo**: color del cielo (arriba/abajo), sol (dirección y color, sombras), luz ambiente, niebla.
- **Bloques** (por objeto): eventos *Al empezar / Al tocar-interactuar / Al acercarse / Al recibir un disparo*;
  mover, deslizar, girar, tamaño, color, mostrar/ocultar, destruir, sonido, música, esperar, repetir, por siempre, si/si no,
  variables, cambiar de escena, decir texto.
- **Escenas 2D y 3D** mezcladas (menú 2D clásico, niveles 3D).
- **Controles por defecto** en 3D: joystick izquierdo, mirar a la derecha, botones **SALTAR** y **DISPARAR**.
  En *Botones y arma* puedes dejarlos por defecto, **editarlos** (posición, tamaño, color, texto, acción) o dejarlos **en blanco**.
- **Arma en primera persona** editable (sprite propio, tamaño, posición, cadencia, alcance) con destello y retroceso.
- **Importar**: imágenes png/jpg, audio mp3/wav/flac, modelos obj / glb / gltf (datos incrustados) / fbx.
  Los modelos se convierten a un formato compacto propio (`.fmdl`) para que el juego pese poco.
- **Exportar**: `.exe` (runtime + paquete) y `.pack` (para crear un APK del juego, ver abajo).

## Compilar (GitHub Actions)
Sube el repo a GitHub; el workflow `build` hace todo:
1. `tests`: pruebas del núcleo, importadores y editor (sin pantalla).
2. `windows-runtime`: compila `forge_runtime.exe` (estático, sin DLLs).
3. `android-apk`: mete el runtime en los assets y compila el APK de Forge → artefacto **forge-apk**.

## APK de un juego tuyo
Firmar APKs dentro del teléfono es muy pesado, así que se hace con el workflow:
1. En Forge: *Proyecto → Exportar paquete (.pack)* y guarda el archivo.
2. Súbelo al repo, p. ej. `games/mi_juego.pack`.
3. Actions → *build* → *Run workflow* → escribe esa ruta. Obtienes **game-apk**: un APK que solo ejecuta tu juego.

## Estructura
- `core/` motor (escena, juego, bloques, render GL ES 3 / GL 3.3, audio, HUD, controles, paquete).
- `editor/` editor ImGui e importadores. `platform/windows` runtime de PC. `android/` app (NativeActivity + un puente Java mínimo para el selector de archivos).
- `tests/` pruebas (`cmake -S tests -B b && cmake --build b && ctest --test-dir b`).

## Límites conocidos (honestos)
- **El código de Android/OpenGL/Windows aún no se ha ejecutado en un dispositivo**: lo verificado aquí es la lógica
  (núcleo, bloques, disparo, paquetes, importadores, editor sin pantalla). La primera compilación en Actions y la primera
  prueba en tu teléfono pueden destapar ajustes; avísame y se corrigen.
- Modelos: malla estática con una sola textura (sin animaciones/esqueletos). gltf debe traer los datos incrustados (usa .glb).
- Audio ogg no está soportado (usa mp3/wav/flac).
- Los archivos del proyecto se cargan enteros en RAM; mantén audios y texturas moderados.
- Los controles táctiles se ven solo en Android; en el .exe se juega con WASD, espacio, clic (disparar), E (interactuar), Esc salir.
