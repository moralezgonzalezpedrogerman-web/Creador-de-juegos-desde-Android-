// Prueba de importadores de modelos: OBJ (con caras de 4 vertices), GLB hecho a mano y,
// si se pasa la ruta de un .fbx como argumento, un FBX real.
#include <cstdio>
#include <cmath>
#include <cstring>
#include <fstream>
#include <iterator>

#include "importer.h"
#include "model.h"

using namespace forge;

#define CHECK(c) do { if (!(c)) { printf("FALLO linea %d: %s\n", __LINE__, #c); return 1; } } while (0)

static std::vector<uint8_t> makeGlb() {
    std::string json =
        R"({"asset":{"version":"2.0"},"scene":0,"scenes":[{"nodes":[0]}],"nodes":[{"mesh":0}],)"
        R"("meshes":[{"primitives":[{"attributes":{"POSITION":0,"TEXCOORD_0":1},"indices":2,"material":0}]}],)"
        R"("materials":[{"pbrMetallicRoughness":{"baseColorFactor":[1,0.5,0.25,1]}}],)"
        R"("accessors":[{"bufferView":0,"componentType":5126,"count":3,"type":"VEC3","min":[0,0,0],"max":[2,1,0]},)"
        R"({"bufferView":1,"componentType":5126,"count":3,"type":"VEC2"},)"
        R"({"bufferView":2,"componentType":5123,"count":3,"type":"SCALAR"}],)"
        R"("bufferViews":[{"buffer":0,"byteOffset":0,"byteLength":36},{"buffer":0,"byteOffset":36,"byteLength":24},)"
        R"({"buffer":0,"byteOffset":60,"byteLength":6}],"buffers":[{"byteLength":68}]})";
    while (json.size() % 4) json += ' ';
    float pos[9] = {0, 0, 0, 2, 0, 0, 0, 1, 0};
    float uv[6] = {0, 0, 1, 0, 0, 1};
    unsigned short idx[3] = {0, 1, 2};
    std::vector<uint8_t> bin(68, 0);
    memcpy(bin.data(), pos, 36);
    memcpy(bin.data() + 36, uv, 24);
    memcpy(bin.data() + 60, idx, 6);
    auto w32 = [](std::vector<uint8_t>& o, uint32_t v) { for (int i = 0; i < 4; i++) o.push_back((v >> (8 * i)) & 255); };
    std::vector<uint8_t> g;
    g.insert(g.end(), {'g', 'l', 'T', 'F'});
    w32(g, 2);
    w32(g, (uint32_t)(12 + 8 + json.size() + 8 + bin.size()));
    w32(g, (uint32_t)json.size());
    g.insert(g.end(), {'J', 'S', 'O', 'N'});
    g.insert(g.end(), json.begin(), json.end());
    w32(g, (uint32_t)bin.size());
    g.insert(g.end(), {'B', 'I', 'N', 0});
    g.insert(g.end(), bin.begin(), bin.end());
    return g;
}

static bool check(const Files& a, const std::string& name, size_t minTris, float* bboxMax = nullptr) {
    auto it = a.find(name);
    if (it == a.end()) return false;
    ModelData m;
    if (!modelRead(it->second.data(), it->second.size(), m)) return false;
    if (m.idx.size() / 3 < minTris) return false;
    float mx = 0;
    for (size_t i = 0; i < m.v.size(); i += 8)
        for (int c = 0; c < 3; c++) mx = std::max(mx, std::fabs(m.v[i + c]));
    if (bboxMax) *bboxMax = mx;
    return mx <= 0.5001f;  // normalizado a un cubo unitario centrado
}

int main(int argc, char** argv) {
    Files assets;
    std::string name, err;

    // OBJ: un cubo con 6 caras de 4 vertices -> 12 triangulos, 8 vertices unicos.
    std::string obj =
        "v -5 -5 -5\nv 5 -5 -5\nv 5 5 -5\nv -5 5 -5\nv -5 -5 5\nv 5 -5 5\nv 5 5 5\nv -5 5 5\n"
        "f 1 2 3 4\nf 5 8 7 6\nf 1 5 6 2\nf 2 6 7 3\nf 3 7 8 4\nf 4 8 5 1\n";
    CHECK(importModel("Mi Cubo.obj", std::vector<uint8_t>(obj.begin(), obj.end()), assets, name, err));
    CHECK(name == "Mi_Cubo.fmdl");
    ModelData m;
    CHECK(modelRead(assets[name].data(), assets[name].size(), m));
    CHECK(m.idx.size() == 36);
    CHECK(check(assets, name, 12));
    printf("OBJ ok: %zu triangulos, %zu vertices\n", m.idx.size() / 3, m.v.size() / 8);

    // El mismo nombre dos veces no pisa el anterior.
    CHECK(importModel("Mi Cubo.obj", std::vector<uint8_t>(obj.begin(), obj.end()), assets, name, err));
    CHECK(name == "Mi_Cubo_2.fmdl");

    // OBJ roto.
    std::string bad = "f 1 2 3\n";
    CHECK(!importModel("roto.obj", std::vector<uint8_t>(bad.begin(), bad.end()), assets, name, err));

    // GLB.
    auto glb = makeGlb();
    CHECK(importModel("tri.glb", glb, assets, name, err));
    ModelData g;
    CHECK(modelRead(assets[name].data(), assets[name].size(), g));
    CHECK(g.idx.size() == 3);
    CHECK(g.color[0] == 1.f && g.color[1] == 0.5f && g.color[2] == 0.25f);  // color del material
    CHECK(check(assets, name, 1));
    printf("GLB ok: %zu triangulos, color %.2f %.2f %.2f\n", g.idx.size() / 3, g.color[0], g.color[1], g.color[2]);

    // Formato no compatible.
    CHECK(!importModel("x.stl", {1, 2, 3}, assets, name, err));

    // FBX opcional.
    if (argc > 1) {
        std::ifstream f(argv[1], std::ios::binary);
        std::vector<uint8_t> fbx((std::istreambuf_iterator<char>(f)), std::istreambuf_iterator<char>());
        CHECK(!fbx.empty());
        CHECK(importModel("prueba.fbx", fbx, assets, name, err));
        ModelData fm;
        CHECK(modelRead(assets[name].data(), assets[name].size(), fm));
        CHECK(check(assets, name, 1));
        printf("FBX ok: %zu triangulos, %zu vertices\n", fm.idx.size() / 3, fm.v.size() / 8);
    }
    printf("OK\n");
    return 0;
}
