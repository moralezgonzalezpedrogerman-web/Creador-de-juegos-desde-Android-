// Prueba headless del editor: ImGui real sin backend, Renderer nulo.
#include "editor.h"
#include "fsutil.h"
#include "imgui.h"
#include <cstdio>
#include <cstdlib>
using namespace forge;

static int fails = 0;
#define CHECK(c) do { if (!(c)) { printf("FALLO %s:%d %s\n", __FILE__, __LINE__, #c); fails++; } } while (0)

static void frame(Editor& e, float mx = -1, float my = -1, bool down = false) {
    ImGuiIO& io = ImGui::GetIO();
    io.DisplaySize = ImVec2(1280, 720);
    io.DeltaTime = 1.f / 60;
    io.AddMousePosEvent(mx, my);
    io.AddMouseButtonEvent(0, down);
    ImGui::NewFrame();
    e.frame(nullptr, 1280, 720, 1.f / 60);
    ImGui::Render();
}

int main() {
    char tmpl[] = "/tmp/forge_edXXXXXX";
    std::string dir = mkdtemp(tmpl);
    ImGui::CreateContext();
    ImGuiIO& io = ImGui::GetIO();
    io.IniFilename = nullptr;
    unsigned char* px; int fw, fh;
    io.Fonts->GetTexDataAsRGBA32(&px, &fw, &fh);

    EditorHost h;
    h.dataDir = dir;
    h.loadRuntime = [](std::vector<uint8_t>& o) { o = {'M', 'Z', 1, 2, 3}; return true; };
    std::vector<std::string> saved;
    h.saveOut = [&](const std::string& n, const std::string&) { saved.push_back(n); };
    Audio audio; audio.init(true);
    Editor e(h);
    e.init(&audio);

    for (int i = 0; i < 5; i++) frame(e);
    CHECK(e.screen() == Screen::Projects);
    CHECK(e.newProject("prueba", true));
    CHECK(e.screen() == Screen::Edit);
    e.showObjs = e.showProps = e.showBlocks = e.showWorld = e.showHud = e.showAssets = true;
    for (int i = 0; i < 5; i++) frame(e);

    // anadir objetos de todos los tipos
    for (Kind k : {Kind::Cube, Kind::Floor, Kind::Wall, Kind::Item, Kind::Light, Kind::Player}) e.addObject(k);
    CHECK(!e.project().scenes.empty());
    e.select(0);
    for (int i = 0; i < 5; i++) frame(e);
    e.addScene(false);
    e.setScene(e.project().scenes.size() - 1);
    e.addObject(Kind::Cube);
    e.select(0);
    for (int i = 0; i < 5; i++) frame(e);
    e.setScene(0);

    // gestos: toque y arrastre
    frame(e, 600, 300, true);
    for (int i = 0; i < 5; i++) frame(e, 600 + i * 10, 300, true);
    frame(e, 650, 300, false);

    // importar un png minimo y audio falso
    std::vector<uint8_t> junk = {1, 2, 3};
    e.onFile("x.wav", junk);
    for (int i = 0; i < 3; i++) frame(e);

    CHECK(e.saveProject());
    std::vector<uint8_t> pk, exe; std::string err;
    CHECK(e.buildPack(pk));
    CHECK(e.buildExe(exe, err));
    CHECK(exe.size() > pk.size());

    // jugar
    e.startPlay();
    CHECK(e.screen() == Screen::Play);
    for (int i = 0; i < 30; i++) frame(e);
    e.stopPlay();
    CHECK(e.screen() == Screen::Edit);

    e.closeProject();
    frame(e);
    CHECK(e.screen() == Screen::Projects);
    CHECK(e.openProject("prueba"));
    for (int i = 0; i < 5; i++) frame(e);
    e.closeProject();
    for (int i = 0; i < 3; i++) frame(e);

    ImGui::DestroyContext();
    fs::removeTree(dir);
    printf(fails ? "editor_test: %d fallos\n" : "editor_test: OK\n", fails);
    return fails ? 1 : 0;
}
