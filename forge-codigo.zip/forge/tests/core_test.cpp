// Prueba del nucleo sin GPU: demo, bloques, fisica basica, paquete y exportacion a .exe.
#include <cstdio>
#include <cstdlib>

#include "game.h"
#include "pack.h"
#include "model.h"
#include "hud.h"
#include "controls.h"

using namespace forge;

#define CHECK(c) do { if (!(c)) { printf("FALLO linea %d: %s\n", __LINE__, #c); return 1; } } while (0)

static Obj* find(Game& g, const char* n) {
    for (auto& o : g.sc->objs) if (o.name == n) return &o;
    return nullptr;
}

int main() {
    Project p;
    CHECK(loadDemo(p));
    CHECK(p.scenes.size() == 2);

    // Paquete e exportacion.
    Files f;
    f["project.forge"] = {'a', 'b'};
    f["tex.png"] = {1, 2, 3};
    std::vector<uint8_t> pk, back, out;
    CHECK(packWrite(f, pk));
    Files g2;
    CHECK(packRead(pk.data(), pk.size(), g2) && g2.size() == 2 && g2["tex.png"].size() == 3);
    CHECK(exportExe({'M', 'Z', 0, 0}, pk, out));
    CHECK(!exportExe({1, 2}, pk, out));
    FILE* fp = fopen("fake.exe", "wb");
    CHECK(fp);
    fwrite(out.data(), 1, out.size(), fp);
    fclose(fp);
    CHECK(extractFromExe("fake.exe", back) && back == pk);

    // Juego: menu 2D -> nivel 3D -> puerta -> pasar.
    Game gm;
    gm.load(std::move(p));
    Input in;
    const float dt = 1.f / 60.f, asp = 16.f / 9.f;
    CHECK(gm.sc->name == "Menu" && !gm.sc->is3d);
    in.tap = true;
    gm.update(dt, in, asp);
    in.tap = false;
    gm.update(dt, in, asp);
    CHECK(gm.sc->name == "Nivel1" && gm.sc->is3d);

    for (int i = 0; i < 120; i++) gm.update(dt, in, asp);
    CHECK(gm.ground);
    in.moveY = 1;
    for (int i = 0; i < 200; i++) gm.update(dt, in, asp);
    in.moveY = 0;
    CHECK(gm.pos.z > -3.8f && gm.pos.z < -3.0f);  // la puerta cerrada bloquea

    Obj* door = find(gm, "Puerta");
    CHECK(door);
    float y0 = door->pos.y;
    in.tap = true;
    gm.update(dt, in, asp);
    in.tap = false;
    for (int i = 0; i < 90; i++) gm.update(dt, in, asp);
    CHECK(door->pos.y > y0 + 2.f);                // el bloque "repetir" la subio

    in.moveY = 1;
    for (int i = 0; i < 200; i++) gm.update(dt, in, asp);
    CHECK(gm.pos.z < -8.f);                       // ya pasa por debajo

    Obj* cube = find(gm, "Cubo_giratorio");
    CHECK(cube && cube->yaw > 100.f);             // "por siempre" gira cada frame

    // --- disparo: el evento "Al recibir un disparo" se ejecuta al apuntar a un objeto
    {
        Project q;
        q.name = "tiro";
        Scene sc; sc.name = "N"; sc.is3d = true;
        Obj floor; floor.name = "Suelo"; floor.kind = Kind::Floor; floor.pos = {0, -0.5f, 0}; floor.scale = {20, 1, 20};
        Obj tgt; tgt.name = "Blanco"; tgt.pos = {0, 1.0f, -5}; tgt.scale = {1, 2, 1};
        Script sct; sct.ev = Ev::Shot;
        Block b; b.op = Op::SetVar; b.s = "golpes"; b.a = 7; sct.blocks.push_back(b);
        tgt.scripts.push_back(sct);
        sc.objs.push_back(floor); sc.objs.push_back(tgt);
        q.scenes.push_back(sc);
        Game g;
        std::string snd;
        g.onSound = [&](const std::string& n) { snd = n; };
        g.load(std::move(q));
        Input si;
        for (int i = 0; i < 90; i++) g.update(dt, si, asp);
        si.shoot = true;
        for (int i = 0; i < 5; i++) g.update(dt, si, asp);
        CHECK(snd == "disparo");
        CHECK(g.vars["golpes"] == 7.f);
    }

    // --- botones por defecto (saltar y disparar) y propios
    {
        auto d = defaultHud();
        bool j = false, sh = false;
        for (auto& b : d) { j |= b.act == HudAct::Jump; sh |= b.act == HudAct::Shoot; }
        CHECK(j && sh);
        Project q;
        loadDemo(q);
        q.hudDefault = false;
        q.hud.clear();                         // "en blanco": sin botones
        q.weapon.rate = 0.4f; q.weapon.tex = "arma.png";
        HudBtn hb; hb.label = "BUM"; hb.act = HudAct::Shoot; hb.x = 0.3f; hb.y = 0.4f; q.hud.push_back(hb);
        std::string txt = writeProject(q);
        Files f; f["project.forge"] = std::vector<uint8_t>(txt.begin(), txt.end());
        Project r; std::string err;
        CHECK(loadProject(f, r, err));
        CHECK(!r.hudDefault && r.hud.size() == 1 && r.hud[0].label == "BUM" && r.hud[0].act == HudAct::Shoot);
        CHECK(r.weapon.tex == "arma.png" && r.weapon.rate > 0.39f && r.weapon.rate < 0.41f);
        CHECK(r.scenes.size() == q.scenes.size());
        CHECK(writeProject(r) == txt);        // estable: guardar y cargar no cambia nada
        Hud hud; hud.setup(r);
        CHECK(hud.btns.size() == 1);
        Hud hd; Project dd; loadDemo(dd); hd.setup(dd);
        CHECK(hd.btns.size() >= 2);
    }

    // --- toques: el boton de disparo del HUD dispara
    {
        Project q; loadDemo(q);
        Hud hud; hud.setup(q);
        PlayControls ctl; ctl.hud = &hud; ctl.w = 1600; ctl.h = 900; ctl.is3d = true;
        ctl.begin(0, 1600 * 0.88f, 900 * 0.68f, 0);
        Input i1 = ctl.consume();
        CHECK(i1.shoot);
        ctl.end(0, 50);
        Input i2 = ctl.consume();
        CHECK(!i2.shoot);
    }

    // --- modelo compacto
    {
        ModelData m; m.v = {0,0,0, 0,1,0, 0,0,  1,0,0, 0,1,0, 1,0,  0,0,1, 0,1,0, 0,1};
        m.idx = {0, 1, 2}; m.tex = "t.png"; m.color[0] = 0.5f;
        std::vector<uint8_t> bytes; ModelData r;
        CHECK(modelWrite(m, bytes) && modelRead(bytes.data(), bytes.size(), r));
        CHECK(r.v == m.v && r.idx == m.idx && r.tex == "t.png" && r.color[0] == 0.5f);
        CHECK(!modelRead(bytes.data(), 5, r));
    }
    printf("OK\n");
    return 0;
}
