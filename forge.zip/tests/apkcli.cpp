// Herramienta de prueba: crea un APK con la version C++ (la misma que usa el editor de Windows).
// uso: apkcli plantilla.apk salida.apk game.pack icono.png|- carpeta_claves etiqueta appid verName verCode orient
#include <cstdio>
#include <cstdlib>
#include <fstream>
#include <iterator>
#include "apkbuild.h"
using namespace forge;
static std::vector<uint8_t> rd(const std::string& p) { std::ifstream f(p, std::ios::binary); return std::vector<uint8_t>(std::istreambuf_iterator<char>(f), {}); }
int main(int c, char** a) {
    if (c < 11) return 2;
    ApkConfig cfg; cfg.label = a[6]; cfg.appId = a[7]; cfg.verName = a[8]; cfg.verCode = atoi(a[9]); cfg.orient = atoi(a[10]);
    std::map<std::string, std::vector<uint8_t>> extra;
    extra["assets/game.pack"] = rd(a[3]);
    extra["assets/standalone"] = {'1'};
    std::vector<uint8_t> icon;
    if (std::string(a[4]) != "-") icon = rd(a[4]);
    std::string kd = a[5], err;
    std::vector<uint8_t> out;
    bool ic = false;
    if (!apkBuild(rd(a[1]), extra, icon, cfg, rd(kd + "/apk_sign_key.pk8"), rd(kd + "/apk_sign_cert.der"), out, &ic, err)) { fprintf(stderr, "ERROR: %s\n", err.c_str()); return 1; }
    std::ofstream o(a[2], std::ios::binary);
    o.write((const char*)out.data(), out.size());
    printf("icon=%d\n", ic ? 1 : 0);
    return 0;
}
