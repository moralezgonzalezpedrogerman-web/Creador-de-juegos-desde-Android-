// Prueba del nucleo sin GPU: demo, bloques, fisica basica, paquete y exportacion a .exe.
#include <cstdio>
#include <cmath>
#include <cstdlib>

#include "game.h"
#include "pack.h"
#include "model.h"
#include "hud.h"
#include "controls.h"

using namespace forge;

#define CHECK(c) do { if (!(c)) { printf("FALLO linea %d: %s\n", __LINE__, #c); return 1; } } while (0)

static Obj* find(Game& g, const char* n) {
    for (auto& o : g.sc->objs) if (o.name == n) return &o;
    return nullptr;
}

int main() {
    Project p;
    CHECK(loadDemo(p));
    CHECK(p.scenes.size() == 2);

    // Paquete e exportacion.
    Files f;
    f["project.forge"] = {'a', 'b'};
    f["tex.png"] = {1, 2, 3};
    std::vector<uint8_t> pk, back, out;
    CHECK(packWrite(f, pk));
    Files g2;
    CHECK(packRead(pk.data(), pk.size(), g2) && g2.size() == 2 && g2["tex.png"].size() == 3);
    CHECK(exportExe({'M', 'Z', 0, 0}, pk, out));
    CHECK(!exportExe({1, 2}, pk, out));
    FILE* fp = fopen("fake.exe", "wb");
    CHECK(fp);
    fwrite(out.data(), 1, out.size(), fp);
    fclose(fp);
    CHECK(extractFromExe("fake.exe", back) && back == pk);

    // Juego: menu 2D -> nivel 3D -> puerta -> pasar.
    Game gm;
    gm.load(std::move(p));
    Input in;
    const float dt = 1.f / 60.f, asp = 16.f / 9.f;
    CHECK(gm.sc->name == "Menu" && !gm.sc->is3d);
    in.tap = true;
    gm.update(dt, in, asp);
    in.tap = false;
    gm.update(dt, in, asp);
    CHECK(gm.sc->name == "Nivel1" && gm.sc->is3d);

    for (int i = 0; i < 120; i++) gm.update(dt, in, asp);
    CHECK(gm.ground);
    in.moveY = 1;
    for (int i = 0; i < 200; i++) gm.update(dt, in, asp);
    in.moveY = 0;
    CHECK(gm.pos.z > -3.8f && gm.pos.z < -3.0f);  // la puerta cerrada bloquea

    Obj* door = find(gm, "Puerta");
    CHECK(door);
    float y0 = door->pos.y;
    in.tap = true;
    gm.update(dt, in, asp);
    in.tap = false;
    for (int i = 0; i < 90; i++) gm.update(dt, in, asp);
    CHECK(door->pos.y > y0 + 2.f);                // el bloque "repetir" la subio

    in.moveY = 1;
    for (int i = 0; i < 200; i++) gm.update(dt, in, asp);
    CHECK(gm.pos.z < -8.f);                       // ya pasa por debajo

    Obj* cube = find(gm, "Cubo_giratorio");
    CHECK(cube);
    float yawA = cube->yaw;
    gm.update(dt, in, asp);
    CHECK(cube->yaw != yawA);                     // "para siempre" gira cada frame

    // --- disparo: el evento "Al recibir un disparo" se ejecuta al apuntar a un objeto
    {
        Project q;
        q.name = "tiro";
        Scene sc; sc.name = "N"; sc.is3d = true;
        Obj floor; floor.name = "Suelo"; floor.kind = Kind::Floor; floor.pos = {0, -0.5f, 0}; floor.scale = {20, 1, 20};
        Obj tgt; tgt.name = "Blanco"; tgt.pos = {0, 1.0f, -5}; tgt.scale = {1, 2, 1};
        Block h; h.op = Op::WhenShot;
        Block b; b.op = Op::SetVar; b.t = "golpes"; b.f[0] = "3+4";
        tgt.blocks = {h, b};
        sc.objs.push_back(floor); sc.objs.push_back(tgt);
        q.scenes.push_back(sc);
        Game g;
        std::string snd;
        g.onSound = [&](const std::string& n) { snd = n; };
        g.load(std::move(q));
        Input si;
        for (int i = 0; i < 90; i++) g.update(dt, si, asp);
        si.shoot = true;
        for (int i = 0; i < 5; i++) g.update(dt, si, asp);
        CHECK(snd == "disparo");
        CHECK(g.vars["golpes"].num() == 7.0);
    }


    // --- bloques: formulas, si/de lo contrario, bucles, mensajes, deslizar
    {
        auto blk = [](Op op, const char* t = "", const char* f0 = "", const char* f1 = "", const char* f2 = "") {
            Block b; b.op = op; b.t = t; b.f[0] = f0; b.f[1] = f1; b.f[2] = f2; return b;
        };
        Project q;
        Scene sc; sc.name = "S"; sc.is3d = false;
        Obj a; a.name = "A"; a.scale = {100, 100, 1};
        a.blocks = {
            blk(Op::WhenStart),
            blk(Op::SetVar, "n", "0"),
            blk(Op::Repeat, "", "5"), blk(Op::ChangeVar, "n", "2"), blk(Op::LoopEnd),          // n = 10
            blk(Op::If, "", "n > 5 y n < 20"), blk(Op::SetX, "", "n * 3"),                      // x = 30
            blk(Op::Else), blk(Op::SetX, "", "-1"), blk(Op::EndIf),
            blk(Op::If, "", "n = 0"), blk(Op::SetY, "", "999"), blk(Op::Else), blk(Op::ChangeY, "", "7"), blk(Op::EndIf),
            blk(Op::Broadcast, "hola"),
            blk(Op::WhenReceive, "hola"), blk(Op::SetVar, "oido", "unir('si', 1)"),
        };
        Obj b; b.name = "B"; b.scale = {50, 50, 1};
        b.blocks = {
            blk(Op::WhenReceive, "hola"), blk(Op::GlideTo, "", "1", "200", "100"), blk(Op::SetVar, "fin", "1"),
        };
        Obj c; c.name = "C";
        c.blocks = {
            blk(Op::WhenStart), blk(Op::BroadcastWait, "hola"), blk(Op::SetVar, "listo", "posición x + 1"),
        };
        sc.objs = {a, b, c};
        q.scenes.push_back(sc);
        Game g;
        g.load(std::move(q));
        Input z;
        for (int i = 0; i < 20; i++) g.update(dt, z, asp);
        Obj& A = g.proj.scenes[0].objs[0];
        CHECK(g.vars["n"].num() == 10);
        CHECK(A.pos.x == 30 && A.pos.y == 7);          // "si" verdadero; el segundo "si" va por "de lo contrario"
        CHECK(g.vars["oido"].txt() == "si1");          // difundir mensaje + cuando recibo
        CHECK(g.vars.count("fin") == 0);               // B aun desliza (1 s)
        CHECK(g.vars.count("listo") == 0);             // C espera a que terminen los que recibieron
        for (int i = 0; i < 80; i++) g.update(dt, z, asp);
        Obj& Bo = g.proj.scenes[0].objs[1];
        CHECK(std::fabs(Bo.pos.x - 200) < 0.01f && std::fabs(Bo.pos.y - 100) < 0.01f);
        CHECK(g.vars["fin"].num() == 1);
        CHECK(g.vars["listo"].num() == 1);             // posición x de C (0) + 1
    }

    // --- fisica: una pelota cae por la gravedad, rebota y se detiene sobre el suelo
    {
        auto blk = [](Op op, const char* t = "", const char* f0 = "", const char* f1 = "", const char* f2 = "") {
            Block b; b.op = op; b.t = t; b.f[0] = f0; b.f[1] = f1; b.f[2] = f2; return b;
        };
        Project q;
        Scene sc; sc.name = "F"; sc.is3d = false;
        Obj ground; ground.name = "Suelo"; ground.pos = {0, -400, 0}; ground.scale = {2000, 100, 1}; ground.yaw = 90;
        ground.blocks = {blk(Op::WhenStart), blk(Op::PhysStatic)};
        Obj ball; ball.name = "Pelota"; ball.pos = {0, 200, 0}; ball.scale = {60, 60, 1}; ball.yaw = 90;
        ball.blocks = {blk(Op::WhenStart), blk(Op::PhysDynamic), blk(Op::SetBounce, "", "50")};
        sc.objs = {ground, ball};
        q.scenes.push_back(sc);
        Game g;
        g.load(std::move(q));
        Input z;
        for (int i = 0; i < 600; i++) g.update(dt, z, asp);
        Obj& P = g.proj.scenes[0].objs[1];
        CHECK(P.pos.y < 0 && P.pos.y > -400);          // cayó pero no atravesó el suelo
        CHECK(std::fabs(P.pos.y - (-400 + 50 + 30)) < 8.f);  // reposa sobre el suelo
    }

    // --- la colision gira con el objeto (3D): una pared larga en X girada 90 grados ocupa Z
    {
        Project q;
        Scene sc; sc.name = "R"; sc.is3d = true;
        Obj w; w.kind = Kind::Wall; w.name = "W"; w.pos = {0, 1, 0}; w.scale = {6, 2, 0.4f}; w.yaw = 90;
        Obj fl; fl.kind = Kind::Floor; fl.name = "F"; fl.pos = {0, -0.1f, 0}; fl.scale = {40, 0.2f, 40};
        sc.objs = {fl, w};
        q.scenes.push_back(sc);
        Game g;
        g.load(std::move(q));
        Input fw; fw.moveY = 1.f;
        g.pos = {2.5f, 0.05f, 5.f};
        for (int i = 0; i < 90; i++) g.update(dt, fw, asp);
        CHECK(g.pos.z < -1.f);             // a x=2.5 no hay pared: pasa
        g.pos = {0, 0.05f, 5.f};
        g.vel = V3();
        for (int i = 0; i < 90; i++) g.update(dt, fw, asp);
        CHECK(g.pos.z > 3.f);              // la pared girada (larga en Z) la detiene
    }

    // --- la colision de un modelo sigue su forma: un plano delgado dentro de una caja de 4 m solo choca en el plano
    {
        ModelData md;
        float vv[4][3] = {{-.5f, -.5f, 0}, {.5f, -.5f, 0}, {.5f, .5f, 0}, {-.5f, .5f, 0}};
        for (auto& p : vv) md.v.insert(md.v.end(), {p[0], p[1], p[2], 0, 0, 1, 0, 0});
        md.idx = {0, 1, 2, 0, 2, 3};
        std::vector<uint8_t> bytes;
        CHECK(modelWrite(md, bytes));
        Project q;
        q.assets["m.fmdl"] = bytes;
        Scene sc; sc.name = "M"; sc.is3d = true;
        Obj fl; fl.kind = Kind::Floor; fl.name = "F"; fl.pos = {0, -0.1f, 0}; fl.scale = {40, 0.2f, 40};
        Obj m; m.kind = Kind::Model; m.model = "m.fmdl"; m.name = "M"; m.pos = {0, 2, 0}; m.scale = {4, 4, 4};
        sc.objs = {fl, m};
        q.scenes.push_back(sc);
        Game g;
        g.load(std::move(q));
        Input fw; fw.moveY = 1.f;
        g.pos = {0, 0.05f, 5.f};
        for (int i = 0; i < 90; i++) g.update(dt, fw, asp);
        CHECK(g.pos.z < 1.0f && g.pos.z > 0.1f);   // pasa por el espacio vacio y se detiene en el plano
    }

    // --- el proyecto con bloques se guarda y se carga igual
    {
        Project q;
        loadDemo(q);
        std::string txt = writeProject(q);
        Files f; f["project.forge"] = std::vector<uint8_t>(txt.begin(), txt.end());
        Project r; std::string err;
        CHECK(loadProject(f, r, err));
        CHECK(writeProject(r) == txt);
        CHECK(r.scenes[1].objs[5].blocks.size() == q.scenes[1].objs[5].blocks.size());
        CHECK(r.scenes[1].objs[5].blocks[3].f[0] == q.scenes[1].objs[5].blocks[3].f[0]);
    }

    // --- botones por defecto (saltar y disparar) y propios
    {
        auto d = defaultHud();
        bool j = false, sh = false;
        for (auto& b : d) { j |= b.act == HudAct::Jump; sh |= b.act == HudAct::Shoot; }
        CHECK(j && sh);
        Project q;
        loadDemo(q);
        q.hudDefault = false;
        q.hud.clear();                         // "en blanco": sin botones
        q.weapon.rate = 0.4f; q.weapon.tex = "arma.png";
        HudBtn hb; hb.label = "BUM"; hb.act = HudAct::Shoot; hb.x = 0.3f; hb.y = 0.4f; q.hud.push_back(hb);
        std::string txt = writeProject(q);
        Files f; f["project.forge"] = std::vector<uint8_t>(txt.begin(), txt.end());
        Project r; std::string err;
        CHECK(loadProject(f, r, err));
        CHECK(!r.hudDefault && r.hud.size() == 1 && r.hud[0].label == "BUM" && r.hud[0].act == HudAct::Shoot);
        CHECK(r.weapon.tex == "arma.png" && r.weapon.rate > 0.39f && r.weapon.rate < 0.41f);
        CHECK(r.scenes.size() == q.scenes.size());
        CHECK(writeProject(r) == txt);        // estable: guardar y cargar no cambia nada
        Hud hud; hud.setup(r);
        CHECK(hud.btns.size() == 1);
        Hud hd; Project dd; loadDemo(dd); hd.setup(dd);
        CHECK(hd.btns.size() >= 2);
    }

    // --- toques: el boton de disparo del HUD dispara
    {
        Project q; loadDemo(q);
        Hud hud; hud.setup(q);
        PlayControls ctl; ctl.hud = &hud; ctl.w = 1600; ctl.h = 900; ctl.is3d = true;
        ctl.begin(0, 1600 * 0.88f, 900 * 0.68f, 0);
        Input i1 = ctl.consume();
        CHECK(i1.shoot);
        ctl.end(0, 50);
        Input i2 = ctl.consume();
        CHECK(!i2.shoot);
    }

    // --- modelo compacto
    {
        ModelData m; m.v = {0,0,0, 0,1,0, 0,0,  1,0,0, 0,1,0, 1,0,  0,0,1, 0,1,0, 0,1};
        m.idx = {0, 1, 2}; m.tex = "t.png"; m.color[0] = 0.5f;
        std::vector<uint8_t> bytes; ModelData r;
        CHECK(modelWrite(m, bytes) && modelRead(bytes.data(), bytes.size(), r));
        CHECK(r.v == m.v && r.idx == m.idx && r.tex == "t.png" && r.color[0] == 0.5f);
        CHECK(!modelRead(bytes.data(), 5, r));
    }
    printf("OK\n");
    return 0;
}
