// Prueba del nucleo sin GPU: demo, bloques, fisica basica, paquete y exportacion a .exe.
#include "defsounds.h"
#include <cstdio>
#include <cmath>
#include <cstdlib>

#include "game.h"
#include "video.h"
#include "pack.h"
#include "model.h"
#include "hud.h"
#include "controls.h"

using namespace forge;

#define CHECK(c) do { if (!(c)) { printf("FALLO linea %d: %s\n", __LINE__, #c); return 1; } } while (0)

static Obj* find(Game& g, const char* n) {
    for (auto& o : g.sc->objs) if (o.name == n) return &o;
    return nullptr;
}

int main() {
    Project p;
    CHECK(loadDemo(p));
    CHECK(p.scenes.size() == 2);

    // Paquete e exportacion.
    Files f;
    f["project.forge"] = {'a', 'b'};
    f["tex.png"] = {1, 2, 3};
    std::vector<uint8_t> pk, back, out;
    CHECK(packWrite(f, pk));
    Files g2;
    CHECK(packRead(pk.data(), pk.size(), g2) && g2.size() == 2 && g2["tex.png"].size() == 3);
    CHECK(exportExe({'M', 'Z', 0, 0}, pk, out));
    CHECK(!exportExe({1, 2}, pk, out));
    FILE* fp = fopen("fake.exe", "wb");
    CHECK(fp);
    fwrite(out.data(), 1, out.size(), fp);
    fclose(fp);
    CHECK(extractFromExe("fake.exe", back) && back == pk);

    // Juego: menu 2D -> nivel 3D -> puerta -> pasar.
    Game gm;
    gm.load(std::move(p));
    Input in;
    const float dt = 1.f / 60.f, asp = 16.f / 9.f;
    CHECK(gm.sc->name == "Menu" && !gm.sc->is3d);
    in.tap = true;
    gm.update(dt, in, asp);
    in.tap = false;
    gm.update(dt, in, asp);
    CHECK(gm.sc->name == "Nivel1" && gm.sc->is3d);

    for (int i = 0; i < 120; i++) gm.update(dt, in, asp);
    CHECK(gm.ground);
    in.moveY = 1;
    for (int i = 0; i < 200; i++) gm.update(dt, in, asp);
    in.moveY = 0;
    CHECK(gm.pos.z > -3.8f && gm.pos.z < -3.0f);  // la puerta cerrada bloquea

    Obj* door = find(gm, "Puerta");
    CHECK(door);
    float y0 = door->pos.y;
    in.tap = true;
    gm.update(dt, in, asp);
    in.tap = false;
    for (int i = 0; i < 90; i++) gm.update(dt, in, asp);
    CHECK(door->pos.y > y0 + 2.f);                // el bloque "repetir" la subio

    in.moveY = 1;
    for (int i = 0; i < 200; i++) gm.update(dt, in, asp);
    CHECK(gm.pos.z < -8.f);                       // ya pasa por debajo

    Obj* cube = find(gm, "Cubo_giratorio");
    CHECK(cube);
    float yawA = cube->yaw;
    gm.update(dt, in, asp);
    CHECK(cube->yaw != yawA);                     // "para siempre" gira cada frame

    // --- disparo: el evento "Al recibir un disparo" se ejecuta al apuntar a un objeto
    {
        Project q;
        q.name = "tiro";
        Scene sc; sc.name = "N"; sc.is3d = true;
        Obj floor; floor.name = "Suelo"; floor.kind = Kind::Floor; floor.pos = {0, -0.5f, 0}; floor.scale = {20, 1, 20};
        Obj tgt; tgt.name = "Blanco"; tgt.pos = {0, 1.0f, -5}; tgt.scale = {1, 2, 1};
        Block h; h.op = Op::WhenShot;
        Block b; b.op = Op::SetVar; b.t = "golpes"; b.f[0] = "3+4";
        tgt.blocks = {h, b};
        sc.objs.push_back(floor); sc.objs.push_back(tgt);
        q.scenes.push_back(sc);
        Game g;
        std::string snd;
        g.onSound = [&](const std::string& n) { snd = n; };
        g.load(std::move(q));
        Input si;
        for (int i = 0; i < 90; i++) g.update(dt, si, asp);
        si.shoot = true;
        for (int i = 0; i < 40; i++) g.update(dt, si, asp);
        CHECK(snd == "disparo");
        CHECK(g.vars["golpes"].num() == 7.0);
    }


    // --- bloques: formulas, si/de lo contrario, bucles, mensajes, deslizar
    {
        auto blk = [](Op op, const char* t = "", const char* f0 = "", const char* f1 = "", const char* f2 = "") {
            Block b; b.op = op; b.t = t; b.f[0] = f0; b.f[1] = f1; b.f[2] = f2; return b;
        };
        Project q;
        Scene sc; sc.name = "S"; sc.is3d = false;
        Obj a; a.name = "A"; a.scale = {100, 100, 1};
        a.blocks = {
            blk(Op::WhenStart),
            blk(Op::SetVar, "n", "0"),
            blk(Op::Repeat, "", "5"), blk(Op::ChangeVar, "n", "2"), blk(Op::LoopEnd),          // n = 10
            blk(Op::If, "", "n > 5 y n < 20"), blk(Op::SetX, "", "n * 3"),                      // x = 30
            blk(Op::Else), blk(Op::SetX, "", "-1"), blk(Op::EndIf),
            blk(Op::If, "", "n = 0"), blk(Op::SetY, "", "999"), blk(Op::Else), blk(Op::ChangeY, "", "7"), blk(Op::EndIf),
            blk(Op::Broadcast, "hola"),
            blk(Op::WhenReceive, "hola"), blk(Op::SetVar, "oido", "unir('si', 1)"),
        };
        Obj b; b.name = "B"; b.scale = {50, 50, 1};
        b.blocks = {
            blk(Op::WhenReceive, "hola"), blk(Op::GlideTo, "", "1", "200", "100"), blk(Op::SetVar, "fin", "1"),
        };
        Obj c; c.name = "C";
        c.blocks = {
            blk(Op::WhenStart), blk(Op::BroadcastWait, "hola"), blk(Op::SetVar, "listo", "posición x + 1"),
        };
        sc.objs = {a, b, c};
        q.scenes.push_back(sc);
        Game g;
        g.load(std::move(q));
        Input z;
        for (int i = 0; i < 20; i++) g.update(dt, z, asp);
        Obj& A = g.proj.scenes[0].objs[0];
        CHECK(g.vars["n"].num() == 10);
        CHECK(A.pos.x == 30 && A.pos.y == 7);          // "si" verdadero; el segundo "si" va por "de lo contrario"
        CHECK(g.vars["oido"].txt() == "si1");          // difundir mensaje + cuando recibo
        CHECK(g.vars.count("fin") == 0);               // B aun desliza (1 s)
        CHECK(g.vars.count("listo") == 0);             // C espera a que terminen los que recibieron
        for (int i = 0; i < 80; i++) g.update(dt, z, asp);
        Obj& Bo = g.proj.scenes[0].objs[1];
        CHECK(std::fabs(Bo.pos.x - 200) < 0.01f && std::fabs(Bo.pos.y - 100) < 0.01f);
        CHECK(g.vars["fin"].num() == 1);
        CHECK(g.vars["listo"].num() == 1);             // posición x de C (0) + 1
    }

    // --- fisica: una pelota cae por la gravedad, rebota y se detiene sobre el suelo
    {
        auto blk = [](Op op, const char* t = "", const char* f0 = "", const char* f1 = "", const char* f2 = "") {
            Block b; b.op = op; b.t = t; b.f[0] = f0; b.f[1] = f1; b.f[2] = f2; return b;
        };
        Project q;
        Scene sc; sc.name = "F"; sc.is3d = false;
        Obj ground; ground.name = "Suelo"; ground.pos = {0, -400, 0}; ground.scale = {2000, 100, 1}; ground.yaw = 90;
        ground.blocks = {blk(Op::WhenStart), blk(Op::PhysStatic)};
        Obj ball; ball.name = "Pelota"; ball.pos = {0, 200, 0}; ball.scale = {60, 60, 1}; ball.yaw = 90;
        ball.blocks = {blk(Op::WhenStart), blk(Op::PhysDynamic), blk(Op::SetBounce, "", "50")};
        sc.objs = {ground, ball};
        q.scenes.push_back(sc);
        Game g;
        g.load(std::move(q));
        Input z;
        for (int i = 0; i < 600; i++) g.update(dt, z, asp);
        Obj& P = g.proj.scenes[0].objs[1];
        CHECK(P.pos.y < 0 && P.pos.y > -400);          // cayó pero no atravesó el suelo
        CHECK(std::fabs(P.pos.y - (-400 + 50 + 30)) < 8.f);  // reposa sobre el suelo
    }

    // --- la colision gira con el objeto (3D): una pared larga en X girada 90 grados ocupa Z
    {
        Project q;
        Scene sc; sc.name = "R"; sc.is3d = true;
        Obj w; w.kind = Kind::Wall; w.name = "W"; w.pos = {0, 1, 0}; w.scale = {6, 2, 0.4f}; w.yaw = 90;
        Obj fl; fl.kind = Kind::Floor; fl.name = "F"; fl.pos = {0, -0.1f, 0}; fl.scale = {40, 0.2f, 40}; fl.solid = true;
        sc.objs = {fl, w};
        q.scenes.push_back(sc);
        Game g;
        g.load(std::move(q));
        Input fw; fw.moveY = 1.f;
        g.pos = {2.5f, 0.05f, 5.f};
        for (int i = 0; i < 90; i++) g.update(dt, fw, asp);
        CHECK(g.pos.z < -1.f);             // a x=2.5 no hay pared: pasa
        g.pos = {0, 0.05f, 5.f};
        g.vel = V3();
        for (int i = 0; i < 90; i++) g.update(dt, fw, asp);
        CHECK(g.pos.z > 3.f);              // la pared girada (larga en Z) la detiene
    }

    // --- la colision de un modelo sigue su forma: un plano delgado dentro de una caja de 4 m solo choca en el plano
    {
        ModelData md;
        float vv[4][3] = {{-.5f, -.5f, 0}, {.5f, -.5f, 0}, {.5f, .5f, 0}, {-.5f, .5f, 0}};
        for (auto& p : vv) md.v.insert(md.v.end(), {p[0], p[1], p[2], 0, 0, 1, 0, 0});
        md.idx = {0, 1, 2, 0, 2, 3};
        std::vector<uint8_t> bytes;
        CHECK(modelWrite(md, bytes));
        Project q;
        q.assets["m.fmdl"] = bytes;
        Scene sc; sc.name = "M"; sc.is3d = true;
        Obj fl; fl.kind = Kind::Floor; fl.name = "F"; fl.pos = {0, -0.1f, 0}; fl.scale = {40, 0.2f, 40}; fl.solid = true;
        Obj m; m.kind = Kind::Model; m.model = "m.fmdl"; m.name = "M"; m.pos = {0, 2, 0}; m.scale = {4, 4, 4};
        sc.objs = {fl, m};
        q.scenes.push_back(sc);
        Game g;
        g.load(std::move(q));
        Input fw; fw.moveY = 1.f;
        g.pos = {0, 0.05f, 5.f};
        for (int i = 0; i < 90; i++) g.update(dt, fw, asp);
        CHECK(g.pos.z < 1.0f && g.pos.z > 0.1f);   // pasa por el espacio vacio y se detiene en el plano
    }

    // --- el proyecto con bloques se guarda y se carga igual
    {
        Project q;
        loadDemo(q);
        std::string txt = writeProject(q);
        Files f; f["project.forge"] = std::vector<uint8_t>(txt.begin(), txt.end());
        Project r; std::string err;
        CHECK(loadProject(f, r, err));
        CHECK(writeProject(r) == txt);
        CHECK(r.scenes[1].objs[5].blocks.size() == q.scenes[1].objs[5].blocks.size());
        CHECK(r.scenes[1].objs[5].blocks[3].f[0] == q.scenes[1].objs[5].blocks[3].f[0]);
    }

    // --- botones por defecto (saltar y disparar) y propios
    {
        auto d = defaultHud();
        bool j = false, sh = false;
        for (auto& b : d) { j |= b.act == HudAct::Jump; sh |= b.act == HudAct::Shoot; }
        CHECK(j && sh);
        Project q;
        loadDemo(q);
        q.hudDefault = false;
        q.hud.clear();                         // "en blanco": sin botones
        q.weapon.rate = 0.4f; q.weapon.tex = "arma.png";
        HudBtn hb; hb.label = "BUM"; hb.act = HudAct::Shoot; hb.x = 0.3f; hb.y = 0.4f; q.hud.push_back(hb);
        std::string txt = writeProject(q);
        Files f; f["project.forge"] = std::vector<uint8_t>(txt.begin(), txt.end());
        Project r; std::string err;
        CHECK(loadProject(f, r, err));
        CHECK(!r.hudDefault && r.hud.size() == 1 && r.hud[0].label == "BUM" && r.hud[0].act == HudAct::Shoot);
        CHECK(r.weapon.tex == "arma.png" && r.weapon.rate > 0.39f && r.weapon.rate < 0.41f);
        CHECK(r.scenes.size() == q.scenes.size());
        CHECK(writeProject(r) == txt);        // estable: guardar y cargar no cambia nada
        Hud hud; hud.setup(r);
        CHECK(hud.btns.size() == 1);
        Hud hd; Project dd; loadDemo(dd); hd.setup(dd);
        CHECK(hd.btns.size() >= 2);
    }

    // --- toques: el boton de disparo del HUD dispara
    {
        Project q; loadDemo(q);
        Hud hud; hud.setup(q);
        PlayControls ctl; ctl.hud = &hud; ctl.w = 1600; ctl.h = 900; ctl.is3d = true;
        ctl.begin(0, 1600 * 0.88f, 900 * 0.68f, 0);
        Input i1 = ctl.consume();
        CHECK(i1.shoot);
        ctl.end(0, 50);
        Input i2 = ctl.consume();
        CHECK(!i2.shoot);
    }

    // --- modelo compacto
    {
        ModelData m; m.v = {0,0,0, 0,1,0, 0,0,  1,0,0, 0,1,0, 1,0,  0,0,1, 0,1,0, 0,1};
        m.idx = {0, 1, 2}; m.tex = "t.png"; m.color[0] = 0.5f;
        std::vector<uint8_t> bytes; ModelData r;
        CHECK(modelWrite(m, bytes) && modelRead(bytes.data(), bytes.size(), r));
        CHECK(r.v == m.v && r.idx == m.idx && r.tex == "t.png" && r.color[0] == 0.5f);
        CHECK(!modelRead(bytes.data(), 5, r));
    }

    // --- casa hueca: se entra por la puerta y las paredes siguen bloqueando
    {
        ModelData m;
        auto quad = [&](float x0, float z0, float x1, float z1) {  // pared vertical de y=-0.5 a 0.5
            uint32_t b = (uint32_t)(m.v.size() / 8);
            float P[4][3] = {{x0, -0.5f, z0}, {x1, -0.5f, z1}, {x1, 0.5f, z1}, {x0, 0.5f, z0}};
            for (auto& q : P) m.v.insert(m.v.end(), {q[0], q[1], q[2], 0, 1, 0, 0, 0});
            m.idx.insert(m.idx.end(), {b, b + 1, b + 2, b, b + 2, b + 3});
        };
        quad(-0.5f, -0.5f, 0.5f, -0.5f);   // fondo
        quad(-0.5f, -0.5f, -0.5f, 0.5f);   // izquierda
        quad(0.5f, -0.5f, 0.5f, 0.5f);     // derecha
        quad(-0.5f, 0.5f, -0.15f, 0.5f);   // frente, a la izquierda de la puerta
        quad(0.15f, 0.5f, 0.5f, 0.5f);     // frente, a la derecha de la puerta
        std::vector<uint8_t> bytes;
        CHECK(modelWrite(m, bytes));
        Project q;
        q.assets["casa.fmdl"] = bytes;
        Scene sc; sc.name = "N"; sc.is3d = true; sc.start = {0, 0.05f, 9.f};
        Obj floor; floor.name = "Suelo"; floor.kind = Kind::Floor; floor.pos = {0, -0.5f, 0}; floor.scale = {40, 1, 40};
        Obj casa; casa.name = "Casa"; casa.kind = Kind::Model; casa.model = "casa.fmdl"; casa.pos = {0, 2, 0}; casa.scale = {10, 4, 10};
        sc.objs.push_back(floor); sc.objs.push_back(casa);
        q.scenes.push_back(sc);
        Game g;
        g.load(std::move(q));
        Input si;
        for (int i = 0; i < 60; i++) g.update(dt, si, asp);
        si.moveY = 1;
        for (int i = 0; i < 150; i++) g.update(dt, si, asp);  // 4.5 m/s: cruza la puerta (z = 5) y entra
        CHECK(g.pos.z < 3.f && std::fabs(g.pos.x) < 1.f);
        for (int i = 0; i < 200; i++) g.update(dt, si, asp);
        CHECK(g.pos.z > -4.9f);                              // la pared del fondo la detiene
        // contra la pared de la fachada (fuera de la puerta) no se puede pasar
        Project q2 = g.proj;
        q2.scenes[0].start = {3.f, 0.05f, 9.f};
        for (auto& o : q2.scenes[0].objs) if (o.kind == Kind::Player) o.pos = {3.f, 0.9f, 9.f};
        Game g2;
        g2.load(std::move(q2));
        Input s2;
        for (int i = 0; i < 60; i++) g2.update(dt, s2, asp);
        s2.moveY = 1;
        for (int i = 0; i < 200; i++) g2.update(dt, s2, asp);
        CHECK(g2.pos.z > 4.9f);
    }

    // --- enemigo que dispara, proyectil del jugador, camaras y bloques nuevos
    {
        Project q;
        q.name = "ia";
        q.globalVars = {"vida", "puntos"};
        q.weapon.projSpeed = 40.f;
        Scene sc; sc.name = "N"; sc.is3d = true; sc.start = {0, 0.05f, 0};
        Obj floor; floor.name = "Suelo"; floor.kind = Kind::Floor; floor.pos = {0, -0.5f, 0}; floor.scale = {60, 1, 60};
        Obj en; en.name = "Malo"; en.kind = Kind::Item; en.pos = {0, 0.9f, -12}; en.scale = {0.8f, 1.8f, 0.8f};
        en.solid = true;
        en.ai.type = AiType::Shooter; en.ai.hp = 3; en.ai.dmg = 5; en.ai.rate = 0.5f; en.ai.sight = 30;
        Obj ctl; ctl.name = "Control"; ctl.kind = Kind::Cube; ctl.pos = {20, 1, 20}; ctl.solid = false;
        auto B = [](Op op, const char* t = "", const char* f0 = "") { Block b; b.op = op; b.t = t; b.f[0] = f0; return b; };
        ctl.blocks = {B(Op::WhenStart), B(Op::SetCamera, "Cámara fija"), B(Op::PlaySoundWait, "x"), B(Op::SetVar, "fin", "1"),
                      };
        Obj w2 = ctl; w2.name = "Espera"; w2.pos = {25, 1, 20};
        w2.blocks = {B(Op::WhenStart), B(Op::WaitUntil, "", "\"go\" = 1"), B(Op::SetVar, "ok", "1")};
        sc.objs.push_back(floor); sc.objs.push_back(en); sc.objs.push_back(ctl); sc.objs.push_back(w2);
        sc.cam = {0, 8, 12};
        q.scenes.push_back(sc);
        Game g;
        g.soundLen = [](const std::string&) { return 2.f; };
        g.load(std::move(q));
        CHECK(playerIndex(*g.sc) >= 0);
        Input si;
        for (int i = 0; i < 20; i++) g.update(dt, si, asp);
        CHECK(g.camMode == kFixed);
        CHECK(std::fabs(g.camEye.y - 8.f) < 1e-3f);
        CHECK(g.vars["fin"].num() == 0.0);        // la musica aun suena: el guion espera
        for (int i = 0; i < 160; i++) g.update(dt, si, asp);
        CHECK(g.vars["fin"].num() == 1.0);
        CHECK(g.vars["vida"].num() < 100.0);      // el enemigo disparo y dio
        g.camMode = kFirstPerson;
        g.vars["vida"] = Val(100.0);
        g.yaw = 0;
        si.shoot = true;
        for (int i = 0; i < 400; i++) g.update(dt, si, asp);
        CHECK(!find(g, "Malo")->alive);           // el jugador lo derribo
        CHECK(g.vars["puntos"].num() >= 10.0);
        CHECK(g.vars["ok"].num() == 0.0);         // "esperar hasta" sigue esperando
        g.vars["go"] = Val(1.0);
        for (int i = 0; i < 5; i++) g.update(dt, si, asp);
        CHECK(g.vars["ok"].num() == 1.0);
    }

    // --- guardar y cargar: enemigo, jugador, arma, proyectil y camara
    {
        Project q;
        q.player.cam = kShoulder; q.player.model = "yo.fmdl"; q.player.speed = 6.f;
        q.weapon.model = "pistola.fmdl"; q.weapon.projShape = 2; q.weapon.projModel = "bala.fmdl"; q.weapon.damage = 2.5f;
        Scene sc; sc.name = "N"; sc.cam = {1, 2, 3};
        Obj e; e.name = "E"; e.kind = Kind::Item;
        e.ai.type = AiType::Melee; e.ai.sprite = true; e.ai.hp = 9; e.ai.anim[kWalk].frames = {"a.png", "b.png"}; e.ai.anim[kWalk].fps = 8;
        e.ai.anim[kAttack].lunge = 0.7f; e.ai.projTex = "p.png";
        sc.objs.push_back(e);
        q.scenes.push_back(sc);
        Project r;
        std::string err;
        Files fl; fl["project.forge"] = std::vector<uint8_t>();
        std::string txt = writeProject(q);
        fl["project.forge"].assign(txt.begin(), txt.end());
        CHECK(loadProject(fl, r, err));
        CHECK(r.player.cam == kShoulder && r.player.model == "yo.fmdl" && r.player.speed == 6.f);
        CHECK(r.weapon.model == "pistola.fmdl" && r.weapon.projShape == 2 && r.weapon.projModel == "bala.fmdl" && r.weapon.damage == 2.5f);
        const Obj& re = r.scenes[0].objs[0];
        CHECK(r.scenes[0].cam.z == 3.f);
        CHECK(re.ai.type == AiType::Melee && re.ai.sprite && re.ai.hp == 9.f && re.ai.projTex == "p.png");
        CHECK(re.ai.anim[kWalk].frames.size() == 2 && re.ai.anim[kWalk].frames[1] == "b.png" && re.ai.anim[kWalk].fps == 8.f);
        CHECK(re.ai.anim[kAttack].lunge == 0.7f);
    }

    // --- clones, romper en pedazos, ir hacia otro objeto
    {
        Project q;
        Scene sc; sc.name = "N"; sc.is3d = false;
        auto B = [](Op op, const char* t = "", const char* f0 = "") { Block b; b.op = op; b.t = t; b.f[0] = f0; return b; };
        Obj a; a.name = "A"; a.kind = Kind::Cube; a.pos = {0, 0, 0};
        a.blocks = {B(Op::WhenStart), B(Op::CreateClone), B(Op::CreateClone),
                    B(Op::WhenCloneStart), B(Op::ChangeVar, "n", "1"), B(Op::MoveTowards, "Meta", "50"), B(Op::BreakApart, "", "6")};
        Obj m; m.name = "Meta"; m.kind = Kind::Cube; m.pos = {100, 0, 0}; m.solid = false;
        sc.objs.push_back(a); sc.objs.push_back(m);
        q.scenes.push_back(sc);
        Game g;
        g.load(std::move(q));
        Input si;
        for (int i = 0; i < 6; i++) g.update(dt, si, asp);
        CHECK(g.sc->objs.size() == 4);                 // original + meta + 2 clones
        CHECK(g.vars["n"].num() == 2.0);               // cada clon ejecuto su guion una vez
        CHECK(g.sc->objs[2].clone && !g.sc->objs[2].alive);  // el clon se rompio
        CHECK(!g.debris.empty());
        for (int i = 0; i < 400; i++) g.update(dt, si, asp);
        CHECK(g.debris.empty());                       // los pedazos desaparecen solos
        CHECK(g.sc->objs[0].alive);                    // el original sigue
    }

    // --- particulas y capa de camara: se emiten, se guardan y se cargan
    {
        Project q;
        Scene sc; sc.name = "N"; sc.is3d = true;
        Obj e; e.name = "Fogata"; e.kind = Kind::Cube; e.pos = {0, 1, -5}; e.solid = false;
        fxPreset(e.fx, 1);
        sc.objs.push_back(e);
        sc.overlays.push_back(Overlay{"marco.png", 0.5f, 0.4f, 0.8f, 0.7f, 0.6f});
        sfxPreset(sc.sfx, 1);
        q.scenes.push_back(sc);
        std::string txt = writeProject(q);
        Project r;
        std::string err;
        Files fl; fl["project.forge"].assign(txt.begin(), txt.end());
        CHECK(loadProject(fl, r, err));
        CHECK(r.scenes[0].overlays.size() == 1 && r.scenes[0].overlays[0].tex == "marco.png" && r.scenes[0].overlays[0].alpha == 0.6f);
        CHECK(r.scenes[0].sfx.scan > 0.5f && r.scenes[0].sfx.track == 1.f);
        const Obj* fo = nullptr;
        for (auto& o : r.scenes[0].objs) if (o.name == "Fogata") fo = &o;
        CHECK(fo && fo->fx.on && fo->fx.glow && fo->fx.rate == 40.f);
        Game g;
        g.load(std::move(r));
        Input si;
        for (int i = 0; i < 60; i++) g.update(dt, si, asp);
        CHECK(g.parts.size() > 10 && g.parts.size() < 120);   // nacen y mueren
    }
    {   // v6: eventos de disparo/boton/movimiento, objetos bloqueados, animaciones del jugador
        Project q;
        q.name = "v6";
        q.globalVars = {"vida"};
        q.weapon.projSpeed = 40.f;
        q.hudDefault = false;
        HudBtn hb; hb.label = "Granada"; hb.x = 0.5f; hb.y = 0.5f; hb.r = 0.1f; hb.act = HudAct::Script;
        q.hud.push_back(hb);
        Scene sc; sc.name = "N"; sc.is3d = true; sc.start = {0, 0.05f, 0};
        Obj floor; floor.name = "Suelo"; floor.kind = Kind::Floor; floor.pos = {0, -0.5f, 0}; floor.scale = {60, 1, 60};
        auto B = [](Op op, const char* t = "", const char* f0 = "") { Block b; b.op = op; b.t = t; b.f[0] = f0; return b; };
        Obj a; a.name = "A"; a.kind = Kind::Cube; a.pos = {20, 1, 20}; a.solid = false; a.locked = true;
        a.blocks = {B(Op::WhenPlayerShoots), B(Op::ChangeVar, "tiros", "1"),
                    B(Op::WhenButton, "Granada"), B(Op::ChangeVar, "granadas", "1"),
                    B(Op::WhenPlayerMoves), B(Op::SetVar, "camino", "1"),
                    B(Op::WhenObjMoves, "M"), B(Op::ChangeVar, "mueve", "1")};
        sc.objs.push_back(floor); sc.objs.push_back(a);
        q.scenes.push_back(sc);
        ensurePlayer(q.scenes[0]);
        Obj& pl = q.scenes[0].objs[playerIndex(q.scenes[0])];
        pl.ai.sprite = true;
        pl.ai.anim[kWalk].frames.push_back("paso.png");
        std::string txt = writeProject(q);
        CHECK(txt.find("script") != std::string::npos);
        Files fl; fl["project.forge"] = std::vector<uint8_t>(txt.begin(), txt.end());
        Project r; std::string err;
        CHECK(loadProject(fl, r, err));
        CHECK(r.hud.size() == 1 && r.hud[0].act == HudAct::Script);
        const Obj* ra = nullptr;
        for (auto& o : r.scenes[0].objs) if (o.name == "A") ra = &o;
        CHECK(ra && ra->locked);
        const Obj& rp = r.scenes[0].objs[playerIndex(r.scenes[0])];
        CHECK(rp.ai.sprite && rp.ai.type == AiType::None && rp.ai.anim[kWalk].frames.size() == 1);
        Game g;
        g.load(std::move(r));
        Input si;
        for (int i = 0; i < 10; i++) g.update(dt, si, asp);
        CHECK(g.vars.count("tiros") == 0 && g.vars.count("camino") == 0);
        si.shoot = true;
        g.update(dt, si, asp);
        si.shoot = false;
        for (int i = 0; i < 3; i++) g.update(dt, si, asp);
        CHECK(g.vars["tiros"].num() >= 1);
        si.buttons.push_back("granada");
        g.update(dt, si, asp);
        si.buttons.clear();
        g.update(dt, si, asp);
        CHECK(g.vars["granadas"].num() == 1);
        si.moveY = 1.f;
        for (int i = 0; i < 10; i++) g.update(dt, si, asp);
        CHECK(g.vars["camino"].num() == 1);
    }
    {   // terreno deformable: la colisión sigue la forma y se guarda
        Project q;
        q.name = "terreno";
        Scene sc; sc.name = "T"; sc.is3d = true; sc.start = {0, 0.05f, 0};
        Obj fl; fl.name = "Suelo"; fl.kind = Kind::Floor; fl.pos = {0, -0.1f, 0}; fl.scale = {40, 0.2f, 40}; fl.solid = true;
        terrainInit(fl, 40);
        for (int i = 0; i < 6; i++) terrainBrush(fl, 0.f, -9.f, 6.f, 0.5f, 0);
        float hill = terrainSurface(fl, 0.f, -9.f);
        CHECK(hill > 0.5f);
        CHECK(terrainSurface(fl, 100.f, 0.f) < -1e8f);
        float tt = 0;
        CHECK(rayTerrain(fl, V3{0, 20, -9}, V3{0, -1, 0}, 100.f, tt) && std::fabs((20.f - tt) - hill) < 0.1f);
        sc.objs.push_back(fl);
        q.scenes.push_back(sc);
        ensurePlayer(q.scenes[0]);
        std::string txt = writeProject(q);
        Files fl2; fl2["project.forge"] = std::vector<uint8_t>(txt.begin(), txt.end());
        Project r; std::string err;
        CHECK(loadProject(fl2, r, err));
        const Obj* rf = nullptr;
        for (auto& o : r.scenes[0].objs) if (o.kind == Kind::Floor) rf = &o;
        CHECK(rf && rf->tn == 40 && std::fabs(terrainSurface(*rf, 0.f, -9.f) - hill) < 0.05f);
        Game g;
        g.load(std::move(r));
        Input si;
        for (int i = 0; i < 30; i++) g.update(dt, si, asp);
        CHECK(g.pos.y < 0.2f);
        si.moveY = 1.f;
        float maxY = 0;
        for (int i = 0; i < 240; i++) { g.update(dt, si, asp); maxY = std::max(maxY, g.pos.y); }
        CHECK(g.pos.z < -4.f);   // avanzó
        CHECK(maxY > 1.5f);      // y subió la montaña (altura máx. ~3 m)
        CHECK(g.pos.y < 0.2f);   // y volvió a bajar
    }
    {   // v8: mientras / repetir hasta / fijar objetivo
        Project q;
        q.name = "v8";
        Scene sc; sc.name = "L"; sc.is3d = true; sc.start = {0, 0.05f, 0};
        Obj floor; floor.name = "Suelo"; floor.kind = Kind::Floor; floor.pos = {0, -0.5f, 0}; floor.scale = {60, 1, 60}; floor.solid = true;
        auto B = [](Op op, const char* t = "", const char* f0 = "") { Block b; b.op = op; b.t = t; b.f[0] = f0; return b; };
        Obj a; a.name = "A"; a.kind = Kind::Cube; a.pos = {20, 1, 20}; a.solid = false;
        a.blocks = {B(Op::WhenStart), B(Op::SetVar, "n", "0"), B(Op::While, "", "n < 5"), B(Op::ChangeVar, "n", "1"), B(Op::LoopEnd),
                    B(Op::SetVar, "m", "0"), B(Op::RepeatUntil, "", "m = 3"), B(Op::ChangeVar, "m", "1"), B(Op::LoopEnd),
                    B(Op::SetVar, "fin", "1"), B(Op::SetTarget, "Enemigo más cercano")};
        Obj en; en.name = "E"; en.kind = Kind::Cube; en.pos = {0, 1, -10}; en.ai.type = AiType::Shooter;
        sc.objs = {floor, a, en};
        q.scenes.push_back(sc);
        std::string txt = writeProject(q);
        Files fl; fl["project.forge"] = std::vector<uint8_t>(txt.begin(), txt.end());
        Project r; std::string err;
        CHECK(loadProject(fl, r, err));
        Game g; g.load(std::move(r));
        Input si;
        for (int i = 0; i < 60; i++) g.update(dt, si, asp);
        CHECK(g.vars["n"].num() == 5);
        CHECK(g.vars["m"].num() == 3);
        CHECK(g.vars["fin"].num() == 1);
        CHECK(g.targetOn_);
        CHECK(std::fabs(g.yaw) < 0.3f);   // el enemigo esta al frente (-z)
    }
    {   // v8: armas (municion, recarga, recoger del suelo) y ajustes de jugador
        Project q;
        q.name = "armas";
        q.weapon.infinite = false; q.weapon.magSize = 3; q.weapon.startAmmo = 6; q.weapon.rate = 0.05f; q.weapon.projSpeed = 0;
        Weapon m; m.name = "Espada"; m.type = 1; m.startWith = false; m.meleeRange = 3.f; m.damage = 5.f;
        q.extraWeapons.push_back(m);
        q.player.faceMove = false; q.player.shoulderDist = 4.f; q.player.mox = 0.5f; q.player.mscale = 1.5f;
        Scene sc; sc.name = "W"; sc.is3d = true; sc.start = {0, 0.05f, 0};
        Obj floor; floor.name = "Suelo"; floor.kind = Kind::Floor; floor.pos = {0, -0.5f, 0}; floor.scale = {60, 1, 60}; floor.solid = true;
        Obj it; it.name = "Item"; it.kind = Kind::Cube; it.pos = {0, 0.5f, -1.5f}; it.solid = false; it.giveWeapon = "Espada";
        sc.objs = {floor, it};
        q.scenes.push_back(sc);
        std::string txt = writeProject(q);
        Files fl; fl["project.forge"] = std::vector<uint8_t>(txt.begin(), txt.end());
        Project r; std::string err;
        CHECK(loadProject(fl, r, err));
        CHECK(r.extraWeapons.size() == 1 && r.extraWeapons[0].name == "Espada" && !r.extraWeapons[0].startWith && r.extraWeapons[0].type == 1);
        CHECK(!r.weapon.infinite && r.weapon.magSize == 3 && r.weapon.startAmmo == 6);
        CHECK(!r.player.faceMove && std::fabs(r.player.shoulderDist - 4.f) < 1e-3f && std::fabs(r.player.mscale - 1.5f) < 1e-3f);
        Game g; g.load(std::move(r));
        Input si;
        g.update(dt, si, asp);
        CHECK(g.curW_ == 0 && g.owned_.size() == 1);
        si.shoot = true;
        for (int i = 0; i < 12; i++) g.update(dt, si, asp);
        CHECK(g.wMag_[0] == 0 || g.reloadT_ > 0 || g.wAmmo_[0] < 6);   // gasto balas y empezo a recargar
        si.shoot = false;
        for (int i = 0; i < 100; i++) g.update(dt, si, asp);
        CHECK(g.wMag_[0] == 3 && g.wAmmo_[0] == 3);                    // recargo del cargador
        si.moveY = 1.f;
        for (int i = 0; i < 60; i++) g.update(dt, si, asp);
        CHECK(g.owned_.size() == 2 && g.curW_ == 1);                   // recogio la espada del suelo
    }
    {   // v8: video (con reproductor falso)
        struct Fake { int plays = 0, pauses = 0, stops = 0, seeks = 0; bool fin = false; } fk;
        VideoApi& api = videoApi();
        api.open = [&](int, const std::string&, const std::vector<uint8_t>&) { return true; };
        api.control = [&](int, int cmd, float) { if (cmd == 0) { fk.plays++; fk.fin = false; } else if (cmd == 1) fk.pauses++; else if (cmd == 2) fk.stops++; else fk.seeks++; };
        api.frame = [&](int, int&, int&, std::vector<uint8_t>&) { return false; };
        api.finished = [&](int) { return fk.fin; };
        api.close = [&](int) {};
        Project q; q.name = "vid";
        Scene sc; sc.name = "V"; sc.is3d = false;
        auto B = [](Op op, const char* t = "", const char* f0 = "") { Block b; b.op = op; b.t = t; b.f[0] = f0; return b; };
        Obj a; a.name = "TV"; a.video = "clip.mp4"; a.noColor = false;
        a.blocks = {B(Op::WhenStart), B(Op::PlayVideoTimes, "", "2"), B(Op::Wait, "", "0.2"), B(Op::PauseVideo), B(Op::Wait, "", "0.2"), B(Op::ResumeVideo)};
        sc.objs = {a};
        q.scenes.push_back(sc);
        q.assets["clip.mp4"] = {1, 2, 3};
        std::string txt = writeProject(q);
        Files fl; fl["project.forge"] = std::vector<uint8_t>(txt.begin(), txt.end());
        Project r; std::string err;
        CHECK(loadProject(fl, r, err));
        CHECK(r.scenes[0].objs[0].video == "clip.mp4");
        r.assets["clip.mp4"] = {1, 2, 3};
        Game g; g.load(std::move(r));
        Input si;
        for (int i = 0; i < 90; i++) g.update(dt, si, asp);
        CHECK(fk.plays >= 2 && fk.pauses == 1);
        fk.fin = true;                       // termino la 1a vuelta: debe reiniciar (2 veces en total)
        int before = fk.plays;
        g.update(dt, si, asp);
        CHECK(fk.plays == before + 1);
        fk.fin = true;
        g.update(dt, si, asp);               // 2a vuelta termina: se detiene
        CHECK(g.vid_[0].state == 0);
        api = VideoApi();
    }
    {   // v9: vegetacion, mar, atmosfera, RTX, camara fija y mantener en pantalla
        Project q; q.name = "v9"; q.rtx = true; q.player.fixedMode = 2; q.player.headBob = true; q.player.bobAmt = 1.5f;
        Scene sc; sc.name = "S"; sc.is3d = false; sc.sea = true; sc.seaY = 1.5f; sc.fogMode = 1; sc.atmoStyle = 1; sc.atmoAmt = 2.5f; sc.atmo = 2;
        VegLayer v; v.name = "Pasto A"; v.style = 2; v.pts = {1, 0, 2, 1, 30, 3, 0, 4, 0.8f, 90};
        sc.veg.push_back(v);
        GroundLayer gl; gl.name = "Roca"; gl.preset = 2; gl.pts = {1, 0, 1, 2, 5, 0, 5, 3};
        sc.gnd.push_back(gl);
        auto B = [](Op op, const char* t = "", const char* f0 = "") { Block b; b.op = op; b.t = t; b.f[0] = f0; return b; };
        Obj a; a.name = "A"; a.pos = V3{0, 0, 0}; a.scale = V3{1, 1, 1};
        a.blocks = {B(Op::WhenStart), B(Op::KeepOnScreen), B(Op::ChangeX, "", "999"), B(Op::TiltCamRight, "", "20")};
        sc.objs = {a};
        q.scenes.push_back(sc);
        std::string txt = writeProject(q);
        Files fl; fl["project.forge"] = std::vector<uint8_t>(txt.begin(), txt.end());
        Project r; std::string err;
        CHECK(loadProject(fl, r, err));
        const Scene& rs = r.scenes[0];
        CHECK(r.rtx && r.player.fixedMode == 2 && r.player.headBob && r.player.bobAmt > 1.4f);
        CHECK(r.scenes[0].gnd.size() == 1 && r.scenes[0].gnd[0].pts.size() == 8 && r.scenes[0].gnd[0].preset == 2);
        CHECK(rs.sea && rs.seaY == 1.5f && rs.fogMode == 1 && rs.atmoStyle == 1 && rs.atmoAmt > 2.4f);
        CHECK(rs.veg.size() == 1 && rs.veg[0].pts.size() == 10 && rs.veg[0].style == 2 && rs.veg[0].name == "Pasto A");
        Game g; g.load(std::move(r));
        Input si;
        for (int i = 0; i < 6; i++) g.update(dt, si, asp);
        CHECK(g.camRollTarget > 0.3f);
        CHECK(g.sc->objs[0].pos.x < g.stageW() * 0.5f && g.sc->objs[0].pos.x > 100.f);   // se quedo en el borde, no se salio
    }
    {   // v9: congelar, sonidos por defecto, linterna
        Project q; q.name = "v9b"; q.player.flashlight = true; q.player.flashOnStart = true; q.snd[3] = "mi.wav";
        Scene sc; sc.name = "S"; sc.is3d = true; sc.shadowAmt = 0.4f;
        Obj pl; pl.kind = Kind::Player; pl.name = "Jugador";
        Obj a; a.name = "A"; a.pos = V3{0, 1, 0}; a.scale = V3{1, 1, 1}; a.phys = Phys::Dynamic;
        sc.objs = {pl, a};
        q.scenes.push_back(sc);
        std::string txt = writeProject(q);
        Files fl; fl["project.forge"] = std::vector<uint8_t>(txt.begin(), txt.end());
        Project r; std::string err;
        CHECK(loadProject(fl, r, err));
        CHECK(r.player.flashlight && r.player.flashOnStart && r.snd[3] == "mi.wav" && std::fabs(r.scenes[0].shadowAmt - 0.4f) < 1e-3f);
        Game g; g.load(std::move(r));
        std::vector<std::string> played;
        g.onSound = [&](const std::string& s) { played.push_back(s); };
        CHECK(g.flashOn_);
        g.worldFrozen_ = true;
        float y0 = g.sc->objs[1].pos.y;
        Input si;
        for (int i = 0; i < 20; i++) g.update(dt, si, asp);
        CHECK(std::fabs(g.sc->objs[1].pos.y - y0) < 1e-4f);   // congelado: no cae
        g.worldFrozen_ = false;
        for (int i = 0; i < 20; i++) g.update(dt, si, asp);
        CHECK(g.sc->objs[1].pos.y < y0 - 0.001f);              // descongelado: cae
        g.playerFrozen_ = true;
        V3 p0 = g.pos;
        si.moveY = 1.f;
        for (int i = 0; i < 10; i++) g.update(dt, si, asp);
        CHECK(len(g.pos - p0) < 1e-4f);                        // jugador congelado
        auto w = makeDefaultSound("disparo");
        CHECK(w.size() > 1000 && w[0] == 'R');
    }
    printf("OK\n");
    return 0;
}
