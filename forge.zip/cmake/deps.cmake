# Dependencias de terceros (solo cabeceras o fuentes pequenas), descargadas al configurar.
# Todas con licencia permisiva (MIT / dominio publico).
include(FetchContent)
set(FETCHCONTENT_QUIET ON)

function(forge_fetch name repo tag shallow)
  FetchContent_Declare(${name} GIT_REPOSITORY ${repo} GIT_TAG ${tag} GIT_SHALLOW ${shallow}
                       SOURCE_SUBDIR __no_cmake__)
  FetchContent_MakeAvailable(${name})
  string(TOUPPER ${name} U)
  set(${U}_DIR ${${name}_SOURCE_DIR} PARENT_SCOPE)
endfunction()

forge_fetch(imgui     https://github.com/ocornut/imgui.git     v1.91.9 TRUE)
forge_fetch(miniaudio https://github.com/mackron/miniaudio.git 0.11.22 TRUE)
forge_fetch(stb       https://github.com/nothings/stb.git      4e9b368bfc071e97206ea5c6adba68dd0cbf8897 FALSE)
if(FORGE_WITH_EDITOR)
  forge_fetch(cgltf   https://github.com/jkuhlmann/cgltf.git   v1.14 TRUE)
  forge_fetch(ufbx    https://github.com/ufbx/ufbx.git         5955c5c0b042ac2dc6f32955ab206aaec0620cfc FALSE)
endif()
