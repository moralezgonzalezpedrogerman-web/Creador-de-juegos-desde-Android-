#include "zip.h"
#include <cstring>

namespace forge {

namespace {
struct Bits {
    const uint8_t* p; size_t n, pos = 0;
    uint32_t buf = 0; int cnt = 0;
    bool bad = false;
    int bit() {
        if (cnt == 0) {
            if (pos >= n) { bad = true; return 0; }
            buf = p[pos++];
            cnt = 8;
        }
        int b = buf & 1;
        buf >>= 1;
        cnt--;
        return b;
    }
    uint32_t bits(int k) {
        uint32_t v = 0;
        for (int i = 0; i < k; i++) v |= (uint32_t)bit() << i;
        return v;
    }
};
struct Huff { uint16_t count[16]; uint16_t sym[320]; };

void build(Huff& h, const uint8_t* len, int n) {
    memset(h.count, 0, sizeof h.count);
    for (int i = 0; i < n; i++) h.count[len[i]]++;
    h.count[0] = 0;
    uint16_t offs[16];
    offs[1] = 0;
    for (int i = 1; i < 15; i++) offs[i + 1] = offs[i] + h.count[i];
    for (int i = 0; i < n; i++) if (len[i]) h.sym[offs[len[i]]++] = (uint16_t)i;
}

int decode(Bits& b, const Huff& h) {
    int code = 0, first = 0, index = 0;
    for (int len = 1; len <= 15; len++) {
        code |= b.bit();
        int count = h.count[len];
        if (code - count < first) return h.sym[index + (code - first)];
        index += count;
        first += count;
        first <<= 1;
        code <<= 1;
        if (b.bad) return -1;
    }
    return -1;
}

const uint16_t kLBase[29] = {3, 4, 5, 6, 7, 8, 9, 10, 11, 13, 15, 17, 19, 23, 27, 31, 35, 43, 51, 59, 67, 83, 99, 115, 131, 163, 195, 227, 258};
const uint16_t kLExt[29] = {0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 2, 2, 2, 2, 3, 3, 3, 3, 4, 4, 4, 4, 5, 5, 5, 5, 0};
const uint16_t kDBase[30] = {1, 2, 3, 4, 5, 7, 9, 13, 17, 25, 33, 49, 65, 97, 129, 193, 257, 385, 513, 769, 1025, 1537, 2049, 3073, 4097, 6145, 8193, 12289, 16385, 24577};
const uint16_t kDExt[30] = {0, 0, 0, 0, 1, 1, 2, 2, 3, 3, 4, 4, 5, 5, 6, 6, 7, 7, 8, 8, 9, 9, 10, 10, 11, 11, 12, 12, 13, 13};

bool codes(Bits& b, std::vector<uint8_t>& out, size_t maxOut, const Huff& lh, const Huff& dh) {
    for (;;) {
        int s = decode(b, lh);
        if (s < 0 || b.bad) return false;
        if (s < 256) {
            if (out.size() >= maxOut) return false;
            out.push_back((uint8_t)s);
        } else if (s == 256) {
            return true;
        } else {
            s -= 257;
            if (s >= 29) return false;
            size_t len = kLBase[s] + b.bits(kLExt[s]);
            int ds = decode(b, dh);
            if (ds < 0 || ds >= 30) return false;
            size_t dist = kDBase[ds] + b.bits(kDExt[ds]);
            if (dist > out.size() || out.size() + len > maxOut) return false;
            size_t from = out.size() - dist;
            for (size_t i = 0; i < len; i++) out.push_back(out[from + i]);
        }
    }
}
}  // namespace

bool inflateRaw(const uint8_t* src, size_t n, std::vector<uint8_t>& out, size_t maxOut) {
    Bits b{src, n};
    int last;
    do {
        last = b.bit();
        int type = (int)b.bits(2);
        if (b.bad) return false;
        if (type == 0) {
            b.cnt = 0;
            if (b.pos + 4 > n) return false;
            size_t len = src[b.pos] | (src[b.pos + 1] << 8);
            b.pos += 4;
            if (b.pos + len > n || out.size() + len > maxOut) return false;
            out.insert(out.end(), src + b.pos, src + b.pos + len);
            b.pos += len;
        } else if (type == 1) {
            uint8_t l[320];
            int i = 0;
            for (; i < 144; i++) l[i] = 8;
            for (; i < 256; i++) l[i] = 9;
            for (; i < 280; i++) l[i] = 7;
            for (; i < 288; i++) l[i] = 8;
            Huff lh, dh;
            build(lh, l, 288);
            for (i = 0; i < 30; i++) l[i] = 5;
            build(dh, l, 30);
            if (!codes(b, out, maxOut, lh, dh)) return false;
        } else if (type == 2) {
            int nlen = (int)b.bits(5) + 257, ndist = (int)b.bits(5) + 1, ncode = (int)b.bits(4) + 4;
            if (nlen > 286 || ndist > 30) return false;
            static const uint8_t order[19] = {16, 17, 18, 0, 8, 7, 9, 6, 10, 5, 11, 4, 12, 3, 13, 2, 14, 1, 15};
            uint8_t lens[320];
            memset(lens, 0, sizeof lens);
            for (int i = 0; i < ncode; i++) lens[order[i]] = (uint8_t)b.bits(3);
            Huff ch;
            build(ch, lens, 19);
            int idx = 0;
            uint8_t all[320];
            memset(all, 0, sizeof all);
            while (idx < nlen + ndist) {
                int sym = decode(b, ch);
                if (sym < 0) return false;
                if (sym < 16) all[idx++] = (uint8_t)sym;
                else {
                    int rep, val = 0;
                    if (sym == 16) { if (idx == 0) return false; val = all[idx - 1]; rep = 3 + (int)b.bits(2); }
                    else if (sym == 17) rep = 3 + (int)b.bits(3);
                    else rep = 11 + (int)b.bits(7);
                    if (idx + rep > nlen + ndist) return false;
                    while (rep--) all[idx++] = (uint8_t)val;
                }
                if (b.bad) return false;
            }
            Huff lh, dh;
            build(lh, all, nlen);
            build(dh, all + nlen, ndist);
            if (!codes(b, out, maxOut, lh, dh)) return false;
        } else {
            return false;
        }
    } while (!last);
    return true;
}

static std::string baseLower(const std::string& n) {
    size_t p = n.find_last_of("/\\");
    std::string b = p == std::string::npos ? n : n.substr(p + 1);
    for (auto& c : b) c = (char)tolower((unsigned char)c);
    return b;
}

bool unzipAll(const std::vector<uint8_t>& z, ResMap& out, std::string& err) {
    auto r16 = [&](size_t p) { return (uint32_t)z[p] | ((uint32_t)z[p + 1] << 8); };
    auto r32 = [&](size_t p) { return r16(p) | (r16(p + 2) << 16); };
    if (z.size() < 22) { err = "el zip esta vacio o dañado"; return false; }
    size_t e = z.size() - 22;
    size_t lim = z.size() > 70000 ? z.size() - 70000 : 0;
    while (e > lim && r32(e) != 0x06054b50u) e--;
    if (r32(e) != 0x06054b50u) { err = "no parece un zip"; return false; }
    uint32_t count = r16(e + 10);
    size_t cd = r32(e + 16);
    size_t total = 0;
    std::string skipped;
    for (uint32_t i = 0; i < count; i++) {
        if (cd + 46 > z.size() || r32(cd) != 0x02014b50u) break;
        uint32_t flags = r16(cd + 8), method = r16(cd + 10);
        uint64_t csize = r32(cd + 20), usize = r32(cd + 24), lo = r32(cd + 42);
        uint32_t nl = r16(cd + 28), xl = r16(cd + 30), cl = r16(cd + 32);
        if (cd + 46 + nl + xl > z.size()) break;
        std::string name((const char*)&z[cd + 46], nl);
        if ((csize == 0xFFFFFFFFu || usize == 0xFFFFFFFFu || lo == 0xFFFFFFFFu) && xl >= 4) {  // zip64
            size_t q = cd + 46 + nl, qe = q + xl;
            while (q + 4 <= qe) {
                uint32_t id = r16(q), sz = r16(q + 2);
                if (id == 1) {
                    size_t f = q + 4;
                    auto r64 = [&](size_t pp) { return (uint64_t)r32(pp) | ((uint64_t)r32(pp + 4) << 32); };
                    if (usize == 0xFFFFFFFFu && f + 8 <= qe) { usize = r64(f); f += 8; }
                    if (csize == 0xFFFFFFFFu && f + 8 <= qe) { csize = r64(f); f += 8; }
                    if (lo == 0xFFFFFFFFu && f + 8 <= qe) { lo = r64(f); f += 8; }
                    break;
                }
                q += 4 + sz;
            }
        }
        cd += 46 + nl + xl + cl;
        if (name.empty() || name.back() == '/') continue;  // carpetas
        if (flags & 1) { skipped = "hay archivos con contraseña"; continue; }
        if (lo + 30 > z.size() || r32(lo) != 0x04034b50u) continue;
        size_t ds = lo + 30 + r16(lo + 26) + r16(lo + 28);
        if (ds + csize > z.size()) { skipped = "el zip está incompleto o dañado"; continue; }
        if (usize > 1400ull * 1024 * 1024 || total + usize > 2000ull * 1024 * 1024) { skipped = "un archivo del zip pesa demasiado (más de 1.4 GB)"; continue; }
        std::vector<uint8_t> data;
        if (method == 0) data.assign(z.begin() + ds, z.begin() + ds + csize);
        else if (method == 8) { data.reserve(usize); if (!inflateRaw(&z[ds], csize, data, usize + 16)) { skipped = "no se pudo descomprimir un archivo"; continue; } }
        else { skipped = "el zip usa una compresión no compatible (usa zip normal / deflate)"; continue; }
        total += data.size();
        out[baseLower(name)] = std::move(data);
    }
    if (out.empty()) { err = skipped.empty() ? std::string("no pude leer archivos dentro del zip") : "no pude leer el zip: " + skipped; return false; }
    return true;
}

bool zipStore(const std::vector<std::pair<std::string, std::vector<uint8_t>>>& files, std::vector<uint8_t>& out) {
    auto le = [&](std::vector<uint8_t>& o, uint32_t v, int n) { for (int i = 0; i < n; i++) o.push_back((uint8_t)((v >> (8 * i)) & 255)); };
    auto crc = [](const std::vector<uint8_t>& d) {
        uint32_t c = 0xFFFFFFFFu;
        for (uint8_t b : d) { c ^= b; for (int k = 0; k < 8; k++) c = (c >> 1) ^ (0xEDB88320u & (0u - (c & 1u))); }
        return ~c;
    };
    out.clear();
    std::vector<uint8_t> cd;
    int cnt = 0;
    for (auto& f : files) {
        if (f.second.size() > 0x7fffffffu) return false;
        uint32_t off = (uint32_t)out.size(), cr = crc(f.second), n = (uint32_t)f.second.size();
        le(out, 0x04034b50, 4); le(out, 20, 2); le(out, 0x0800, 2); le(out, 0, 2); le(out, 0, 2); le(out, 0x21, 2);
        le(out, cr, 4); le(out, n, 4); le(out, n, 4); le(out, (uint32_t)f.first.size(), 2); le(out, 0, 2);
        out.insert(out.end(), f.first.begin(), f.first.end());
        out.insert(out.end(), f.second.begin(), f.second.end());
        le(cd, 0x02014b50, 4); le(cd, 20, 2); le(cd, 20, 2); le(cd, 0x0800, 2); le(cd, 0, 2); le(cd, 0, 2); le(cd, 0x21, 2);
        le(cd, cr, 4); le(cd, n, 4); le(cd, n, 4); le(cd, (uint32_t)f.first.size(), 2); le(cd, 0, 2); le(cd, 0, 2); le(cd, 0, 2); le(cd, 0, 2);
        le(cd, 0, 4); le(cd, off, 4);
        cd.insert(cd.end(), f.first.begin(), f.first.end());
        cnt++;
    }
    uint32_t cdOff = (uint32_t)out.size();
    out.insert(out.end(), cd.begin(), cd.end());
    le(out, 0x06054b50, 4); le(out, 0, 2); le(out, 0, 2); le(out, (uint32_t)cnt, 2); le(out, (uint32_t)cnt, 2);
    le(out, (uint32_t)cd.size(), 4); le(out, cdOff, 4); le(out, 0, 2);
    return true;
}

}  // namespace forge
