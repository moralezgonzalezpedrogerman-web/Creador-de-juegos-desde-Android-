#pragma once
// Controles de ImGui con la etiqueta VISIBLE: el texto se pone arriba (o al lado) y baja de renglon si es largo,
// en lugar de cortarse en ventanas angostas (telefono).
#include "imgui.h"
#include <string>

namespace wrapui {

inline std::string visible(const char* l) {
    std::string s = l ? l : "";
    size_t k = s.find("##");
    return k == std::string::npos ? s : s.substr(0, k);
}
// Boton grande "Cerrar" (la X de la barra casi no se alcanza a pulsar en el telefono).
inline bool CloseBar(bool* open) {
    ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(0.75f, 0.2f, 0.2f, 1.f));
    bool c = ImGui::Button("Cerrar", ImVec2(ImGui::GetContentRegionAvail().x, ImGui::GetFontSize() * 2.6f));
    ImGui::PopStyleColor();
    if (c && open) *open = false;
    return c;
}
// SameLine solo si el siguiente boton cabe en el renglon; si no, baja de renglon (nada se corta).
inline void Next(const char* label, float minW = 0.f) {
    float w = ImGui::CalcTextSize(label).x + ImGui::GetStyle().FramePadding.x * 2.f;
    if (w < minW) w = minW;
    float right = ImGui::GetItemRectMax().x;
    float winRight = ImGui::GetWindowPos().x + ImGui::GetWindowContentRegionMax().x;
    if (right + ImGui::GetStyle().ItemSpacing.x + w <= winRight) ImGui::SameLine();
}
inline std::string hid(const char* l) { return std::string("##w") + (l ? l : ""); }

inline bool Checkbox(const char* label, bool* v) {
    std::string vis = visible(label);
    if (vis.empty()) return ImGui::Checkbox(label, v);
    bool c = ImGui::Checkbox(hid(label).c_str(), v);
    ImGui::SameLine();
    ImGui::PushTextWrapPos(0.f);
    ImGui::TextUnformatted(vis.c_str());
    ImGui::PopTextWrapPos();
    if (ImGui::IsItemClicked()) { *v = !*v; c = true; }
    return c;
}

inline void head(const char* label) {
    std::string vis = visible(label);
    if (vis.empty()) return;
    ImGui::PushTextWrapPos(0.f);
    ImGui::TextUnformatted(vis.c_str());
    ImGui::PopTextWrapPos();
}

inline bool SliderFloat(const char* label, float* v, float mn, float mx, const char* fmt = "%.3f", ImGuiSliderFlags fl = 0) {
    if (visible(label).empty()) return ImGui::SliderFloat(label, v, mn, mx, fmt, fl);
    head(label);
    ImGui::SetNextItemWidth(-1.f);
    return ImGui::SliderFloat(hid(label).c_str(), v, mn, mx, fmt, fl);
}
inline bool SliderInt(const char* label, int* v, int mn, int mx, const char* fmt = "%d", ImGuiSliderFlags fl = 0) {
    if (visible(label).empty()) return ImGui::SliderInt(label, v, mn, mx, fmt, fl);
    head(label);
    ImGui::SetNextItemWidth(-1.f);
    return ImGui::SliderInt(hid(label).c_str(), v, mn, mx, fmt, fl);
}
inline bool ColorEdit3(const char* label, float* c, ImGuiColorEditFlags fl = 0) {
    if (visible(label).empty()) return ImGui::ColorEdit3(label, c, fl);
    head(label);
    ImGui::SetNextItemWidth(-1.f);
    return ImGui::ColorEdit3(hid(label).c_str(), c, fl);
}
inline bool ColorEdit4(const char* label, float* c, ImGuiColorEditFlags fl = 0) {
    if (visible(label).empty()) return ImGui::ColorEdit4(label, c, fl);
    head(label);
    ImGui::SetNextItemWidth(-1.f);
    return ImGui::ColorEdit4(hid(label).c_str(), c, fl);
}
inline bool BeginCombo(const char* label, const char* preview, ImGuiComboFlags fl = 0) {
    if (visible(label).empty()) return ImGui::BeginCombo(label, preview, fl);
    head(label);
    ImGui::SetNextItemWidth(-1.f);
    return ImGui::BeginCombo(hid(label).c_str(), preview, fl);
}
inline bool DragFloat(const char* label, float* v, float sp = 1.f, float mn = 0.f, float mx = 0.f, const char* fmt = "%.3f", ImGuiSliderFlags fl = 0) {
    if (visible(label).empty()) return ImGui::DragFloat(label, v, sp, mn, mx, fmt, fl);
    head(label);
    ImGui::SetNextItemWidth(-1.f);
    return ImGui::DragFloat(hid(label).c_str(), v, sp, mn, mx, fmt, fl);
}

}  // namespace wrapui
