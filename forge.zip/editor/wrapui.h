#pragma once
// Controles de ImGui con la etiqueta VISIBLE: el texto se pone arriba (o al lado) y baja de renglon si es largo,
// en lugar de cortarse en ventanas angostas (telefono).
#include "imgui.h"
#include <algorithm>
#include <cmath>
#include <string>

namespace wrapui {

inline std::string visible(const char* l) {
    std::string s = l ? l : "";
    size_t k = s.find("##");
    return k == std::string::npos ? s : s.substr(0, k);
}
// Boton grande "Cerrar" (la X de la barra casi no se alcanza a pulsar en el telefono).
inline bool CloseBar(bool* open) {
    ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(0.75f, 0.2f, 0.2f, 1.f));
    bool c = ImGui::Button("Cerrar", ImVec2(ImGui::GetContentRegionAvail().x, ImGui::GetFontSize() * 2.6f));
    ImGui::PopStyleColor();
    if (c && open) *open = false;
    return c;
}
// SameLine solo si el siguiente boton cabe en el renglon; si no, baja de renglon (nada se corta).
inline void Next(const char* label, float minW = 0.f) {
    float w = ImGui::CalcTextSize(label).x + ImGui::GetStyle().FramePadding.x * 2.f;
    if (w < minW) w = minW;
    float right = ImGui::GetItemRectMax().x;
    float winRight = ImGui::GetWindowPos().x + ImGui::GetWindowContentRegionMax().x;
    if (right + ImGui::GetStyle().ItemSpacing.x + w <= winRight) ImGui::SameLine();
}
inline std::string hid(const char* l) { return std::string("##w") + (l ? l : ""); }

inline bool Checkbox(const char* label, bool* v) {
    std::string vis = visible(label);
    if (vis.empty()) return ImGui::Checkbox(label, v);
    bool c = ImGui::Checkbox(hid(label).c_str(), v);
    ImGui::SameLine();
    ImGui::PushTextWrapPos(0.f);
    ImGui::TextUnformatted(vis.c_str());
    ImGui::PopTextWrapPos();
    if (ImGui::IsItemClicked()) { *v = !*v; c = true; }
    return c;
}

inline void head(const char* label) {
    std::string vis = visible(label);
    if (vis.empty()) return;
    ImGui::PushTextWrapPos(0.f);
    ImGui::TextUnformatted(vis.c_str());
    ImGui::PopTextWrapPos();
}

inline bool SliderFloat(const char* label, float* v, float mn, float mx, const char* fmt = "%.3f", ImGuiSliderFlags fl = 0) {
    if (visible(label).empty()) return ImGui::SliderFloat(label, v, mn, mx, fmt, fl);
    head(label);
    ImGui::SetNextItemWidth(-1.f);
    return ImGui::SliderFloat(hid(label).c_str(), v, mn, mx, fmt, fl);
}
inline bool SliderInt(const char* label, int* v, int mn, int mx, const char* fmt = "%d", ImGuiSliderFlags fl = 0) {
    if (visible(label).empty()) return ImGui::SliderInt(label, v, mn, mx, fmt, fl);
    head(label);
    ImGui::SetNextItemWidth(-1.f);
    return ImGui::SliderInt(hid(label).c_str(), v, mn, mx, fmt, fl);
}
inline bool ColorEdit3(const char* label, float* c, ImGuiColorEditFlags fl = 0) {
    if (visible(label).empty()) return ImGui::ColorEdit3(label, c, fl);
    head(label);
    ImGui::SetNextItemWidth(-1.f);
    return ImGui::ColorEdit3(hid(label).c_str(), c, fl);
}
inline bool ColorEdit4(const char* label, float* c, ImGuiColorEditFlags fl = 0) {
    if (visible(label).empty()) return ImGui::ColorEdit4(label, c, fl);
    head(label);
    ImGui::SetNextItemWidth(-1.f);
    return ImGui::ColorEdit4(hid(label).c_str(), c, fl);
}
inline bool BeginCombo(const char* label, const char* preview, ImGuiComboFlags fl = 0) {
    if (visible(label).empty()) return ImGui::BeginCombo(label, preview, fl);
    head(label);
    ImGui::SetNextItemWidth(-1.f);
    return ImGui::BeginCombo(hid(label).c_str(), preview, fl);
}
inline bool DragFloat(const char* label, float* v, float sp = 1.f, float mn = 0.f, float mx = 0.f, const char* fmt = "%.3f", ImGuiSliderFlags fl = 0) {
    if (visible(label).empty()) return ImGui::DragFloat(label, v, sp, mn, mx, fmt, fl);
    head(label);
    ImGui::SetNextItemWidth(-1.f);
    return ImGui::DragFloat(hid(label).c_str(), v, sp, mn, mx, fmt, fl);
}

// ---------------------------------------------------------------- dibujos (iconos) y botones que no cortan el texto
enum Ic { IcNone = 0, IcPlay, IcPlus, IcTrash, IcSave, IcFolder, IcClose, IcUp, IcDown, IcGear, IcNote, IcImage, IcCube, IcCopy, IcBack, IcCheck, IcPen, IcEye, IcHome, IcBolt };

inline std::string lower(const std::string& s) { std::string o = s; for (auto& c : o) if (c >= 'A' && c <= 'Z') c = (char)(c + 32); return o; }
inline bool has(const std::string& l, const char* k) { return l.find(k) != std::string::npos; }

// Elige el dibujo segun las palabras del boton (no cambia lo que hace el boton).
inline int iconFor(const std::string& vis) {
    std::string l = lower(vis);
    if (has(l, "borrar") || has(l, "eliminar") || has(l, "quitar") || has(l, "vaciar")) return IcTrash;
    if (has(l, "cerrar") || has(l, "cancelar") || has(l, "parar") || has(l, "detener")) return IcClose;
    if (has(l, "guardar")) return IcSave;
    if (has(l, "exportar") || has(l, "subir") || has(l, "crear apk") || has(l, "crear paquete")) return IcUp;
    if (has(l, "bajar")) return IcDown;
    if (has(l, "importar") || has(l, "abrir") || has(l, "elegir") || has(l, "cargar") || has(l, "carpeta") || has(l, "archivo")) return IcFolder;
    if (has(l, "jugar") || has(l, "probar") || has(l, "reproducir") || has(l, "ver escena") || has(l, "iniciar") || has(l, "play")) return IcPlay;
    if (has(l, "nuev") || has(l, "agregar") || has(l, "crear") || has(l, "insertar") || has(l, "poner")) return IcPlus;
    if (has(l, "copiar") || has(l, "duplicar") || has(l, "clonar")) return IcCopy;
    if (has(l, "volver") || has(l, "atras") || has(l, "atrás") || has(l, "deshacer")) return IcBack;
    if (has(l, "sonido") || has(l, "musica") || has(l, "música") || has(l, "audio") || has(l, "voz")) return IcNote;
    if (has(l, "imagen") || has(l, "textura") || has(l, "icono") || has(l, "foto") || has(l, "fondo")) return IcImage;
    if (has(l, "modelo") || has(l, "objeto") || has(l, "3d") || has(l, "esqueleto")) return IcCube;
    if (has(l, "ajuste") || has(l, "opcion") || has(l, "opción") || has(l, "config") || has(l, "mundo")) return IcGear;
    if (has(l, "editar") || has(l, "dibujar") || has(l, "pintar") || has(l, "renombrar") || has(l, "animaci")) return IcPen;
    if (has(l, "aceptar") || has(l, "listo") || has(l, "usar este") || has(l, "aplicar")) return IcCheck;
    if (has(l, "ver ") || has(l, "mostrar") || has(l, "vista")) return IcEye;
    if (has(l, "luz") || has(l, "rayo") || has(l, "disparo") || has(l, "arma")) return IcBolt;
    return IcNone;
}
inline ImVec4 iconColor(int ic) {
    switch (ic) {
        case IcPlay: case IcPlus: case IcCheck: return ImVec4(0.38f, 0.88f, 0.52f, 1.f);
        case IcTrash: case IcClose: return ImVec4(1.f, 0.45f, 0.42f, 1.f);
        case IcSave: case IcFolder: case IcUp: case IcDown: case IcCopy: case IcBack: return ImVec4(0.45f, 0.72f, 1.f, 1.f);
        case IcNote: return ImVec4(0.78f, 0.58f, 1.f, 1.f);
        case IcImage: case IcPen: case IcBolt: return ImVec4(1.f, 0.78f, 0.32f, 1.f);
        default: return ImVec4(0.30f, 0.88f, 0.78f, 1.f);
    }
}
// Dibuja el icono dentro del cuadrado de lado s con centro c.
inline void drawIcon(ImDrawList* d, int ic, ImVec2 c, float s, ImU32 col) {
    float r = s * 0.5f, t = std::max(1.5f, s * 0.14f);
    auto P = [&](float x, float y) { return ImVec2(c.x + x * r, c.y + y * r); };
    switch (ic) {
        case IcPlay: d->AddTriangleFilled(P(-0.5f, -0.75f), P(-0.5f, 0.75f), P(0.8f, 0.f), col); break;
        case IcPlus: d->AddRectFilled(P(-0.8f, -0.17f), P(0.8f, 0.17f), col, 2.f); d->AddRectFilled(P(-0.17f, -0.8f), P(0.17f, 0.8f), col, 2.f); break;
        case IcClose: d->AddLine(P(-0.6f, -0.6f), P(0.6f, 0.6f), col, t * 1.3f); d->AddLine(P(0.6f, -0.6f), P(-0.6f, 0.6f), col, t * 1.3f); break;
        case IcTrash:
            d->AddRectFilled(P(-0.55f, -0.45f), P(0.55f, 0.85f), col, 2.f);
            d->AddRectFilled(P(-0.8f, -0.75f), P(0.8f, -0.5f), col, 1.f);
            d->AddRectFilled(P(-0.25f, -0.95f), P(0.25f, -0.72f), col, 1.f); break;
        case IcSave:
            d->AddRectFilled(P(-0.8f, -0.8f), P(0.8f, 0.8f), col, 3.f);
            d->AddRectFilled(P(-0.45f, -0.8f), P(0.4f, -0.2f), ImGui::GetColorU32(ImGuiCol_Button), 1.f);
            d->AddRectFilled(P(-0.5f, 0.15f), P(0.5f, 0.8f), ImGui::GetColorU32(ImGuiCol_Button), 2.f); break;
        case IcFolder:
            d->AddRectFilled(P(-0.85f, -0.65f), P(-0.1f, -0.2f), col, 2.f);
            d->AddRectFilled(P(-0.85f, -0.4f), P(0.85f, 0.7f), col, 3.f); break;
        case IcUp: d->AddRectFilled(P(-0.15f, -0.2f), P(0.15f, 0.8f), col); d->AddTriangleFilled(P(-0.7f, -0.1f), P(0.7f, -0.1f), P(0.f, -0.9f), col); break;
        case IcDown: d->AddRectFilled(P(-0.15f, -0.8f), P(0.15f, 0.2f), col); d->AddTriangleFilled(P(-0.7f, 0.1f), P(0.7f, 0.1f), P(0.f, 0.9f), col); break;
        case IcBack: d->AddRectFilled(P(-0.2f, -0.15f), P(0.85f, 0.15f), col); d->AddTriangleFilled(P(-0.1f, -0.7f), P(-0.1f, 0.7f), P(-0.9f, 0.f), col); break;
        case IcGear:
            for (int i = 0; i < 8; i++) {
                float a = i * 0.7853982f;
                d->AddLine(P(cosf(a) * 0.6f, sinf(a) * 0.6f), P(cosf(a) * 0.95f, sinf(a) * 0.95f), col, t * 1.6f);
            }
            d->AddCircleFilled(c, r * 0.7f, col, 20);
            d->AddCircleFilled(c, r * 0.3f, ImGui::GetColorU32(ImGuiCol_Button), 14); break;
        case IcNote:
            d->AddCircleFilled(P(-0.4f, 0.55f), r * 0.38f, col, 14);
            d->AddRectFilled(P(-0.1f, -0.85f), P(0.12f, 0.55f), col);
            d->AddTriangleFilled(P(0.1f, -0.85f), P(0.8f, -0.45f), P(0.1f, -0.2f), col); break;
        case IcImage:
            d->AddRect(P(-0.85f, -0.7f), P(0.85f, 0.7f), col, 3.f, 0, t);
            d->AddTriangleFilled(P(-0.7f, 0.55f), P(-0.15f, -0.1f), P(0.4f, 0.55f), col);
            d->AddCircleFilled(P(0.4f, -0.3f), r * 0.2f, col, 10); break;
        case IcCube: {
            ImVec2 top = P(0.f, -0.9f), ul = P(-0.8f, -0.45f), ur = P(0.8f, -0.45f), mid = P(0.f, 0.f), ll = P(-0.8f, 0.5f), lr = P(0.8f, 0.5f), bot = P(0.f, 0.95f);
            d->AddQuadFilled(top, ur, mid, ul, col);
            ImU32 dark = (col & 0xFF000000) | ((col & 0x00FEFEFE) >> 1);
            d->AddQuadFilled(ul, mid, bot, ll, dark);
            d->AddQuadFilled(mid, ur, lr, bot, (col & 0xFF000000) | ((col & 0x00FCFCFC) >> 2) * 3); break; }
        case IcCopy:
            d->AddRect(P(-0.8f, -0.8f), P(0.2f, 0.2f), col, 2.f, 0, t);
            d->AddRectFilled(P(-0.2f, -0.2f), P(0.8f, 0.8f), col, 2.f); break;
        case IcCheck: d->AddLine(P(-0.75f, 0.05f), P(-0.25f, 0.6f), col, t * 1.4f); d->AddLine(P(-0.25f, 0.6f), P(0.8f, -0.6f), col, t * 1.4f); break;
        case IcPen: d->AddLine(P(-0.7f, 0.7f), P(0.6f, -0.6f), col, t * 1.8f); d->AddTriangleFilled(P(-0.9f, 0.9f), P(-0.8f, 0.45f), P(-0.45f, 0.8f), col); break;
        case IcEye:
            d->PathLineTo(P(-0.95f, 0.f)); d->PathBezierCubicCurveTo(P(-0.4f, -0.8f), P(0.4f, -0.8f), P(0.95f, 0.f), 12);
            d->PathBezierCubicCurveTo(P(0.4f, 0.8f), P(-0.4f, 0.8f), P(-0.95f, 0.f), 12);
            d->PathStroke(col, ImDrawFlags_Closed, t);
            d->AddCircleFilled(c, r * 0.3f, col, 12); break;
        case IcHome: d->AddTriangleFilled(P(-0.95f, -0.05f), P(0.95f, -0.05f), P(0.f, -0.9f), col); d->AddRectFilled(P(-0.6f, -0.05f), P(0.6f, 0.8f), col); break;
        case IcBolt: d->AddTriangleFilled(P(0.2f, -0.95f), P(-0.6f, 0.15f), P(0.05f, 0.15f), col); d->AddTriangleFilled(P(-0.05f, -0.15f), P(0.6f, -0.15f), P(-0.2f, 0.95f), col); break;
        default: break;
    }
}

// Si el siguiente elemento no cabe en lo que queda del renglon (despues de un SameLine), baja de renglon.
inline void FitLine(float needW) {
    if (ImGui::GetCursorPosX() > ImGui::GetCursorStartPos().x + 1.f && ImGui::GetContentRegionAvail().x < needW) ImGui::NewLine();
}

// Boton con dibujo; el texto baja de renglon (y el boton crece) en vez de cortarse.
inline bool Button(const char* label, ImVec2 size = ImVec2(0, 0)) {
    std::string vis = visible(label);
    if (vis.size() <= 2) return ImGui::Button(label, size);
    const ImGuiStyle& st = ImGui::GetStyle();
    float fs = ImGui::GetFontSize(), padx = st.FramePadding.x, pady = st.FramePadding.y;
    int ic = iconFor(vis);
    float iw = ic ? fs * 1.15f : 0.f, gap = ic ? fs * 0.45f : 0.f;
    float natural = ImGui::CalcTextSize(vis.c_str()).x + padx * 2.f + iw + gap;
    if (size.x <= 0.f) FitLine(std::min(natural, ImGui::GetContentRegionMax().x * 0.6f));
    float avail = ImGui::GetContentRegionAvail().x;
    float w = size.x;
    if (w <= 0.f) { w = natural; if (w > avail && avail > fs * 3.f) w = avail; }
    float wrapW = std::max(fs, w - padx * 2.f - iw - gap);
    ImVec2 ts = ImGui::CalcTextSize(vis.c_str(), nullptr, false, wrapW);
    float need = ts.y + pady * 2.f, h = size.y;
    if (h <= 0.f) h = std::max(need, fs + pady * 2.f);
    else if (h < need) h = need;
    ImVec2 pos = ImGui::GetCursorScreenPos();
    std::string id = std::string("##") + label;
    bool c = ImGui::Button(id.c_str(), ImVec2(w, h));
    ImDrawList* dl = ImGui::GetWindowDrawList();
    float cw = iw + gap + std::min(ts.x, wrapW);
    float x0 = pos.x + std::max(padx * 0.5f, (w - cw) * 0.5f);
    if (ic) drawIcon(dl, ic, ImVec2(x0 + iw * 0.5f, pos.y + h * 0.5f), iw, ImGui::GetColorU32(iconColor(ic)));
    dl->AddText(ImGui::GetFont(), fs, ImVec2(x0 + iw + gap, pos.y + (h - ts.y) * 0.5f), ImGui::GetColorU32(ImGuiCol_Text), vis.c_str(), nullptr, wrapW);
    return c;
}

inline bool Selectable(const char* label, bool selected = false, ImGuiSelectableFlags fl = 0, ImVec2 size = ImVec2(0, 0)) {
    std::string vis = visible(label);
    if (vis.empty()) return ImGui::Selectable(label, selected, fl, size);
    float fs = ImGui::GetFontSize();
    float w = size.x > 0.f ? size.x : ImGui::GetContentRegionAvail().x;
    float wrapW = std::max(fs, w - 8.f);
    ImVec2 ts = ImGui::CalcTextSize(vis.c_str(), nullptr, false, wrapW);
    float h = std::max(size.y, ts.y + 4.f);
    ImVec2 pos = ImGui::GetCursorScreenPos();
    std::string id = std::string("##") + label;
    bool c = ImGui::Selectable(id.c_str(), selected, fl, ImVec2(size.x, h));
    ImDrawList* dl = ImGui::GetWindowDrawList();
    dl->AddText(ImGui::GetFont(), fs, ImVec2(pos.x + 4.f, pos.y + (h - ts.y) * 0.5f), ImGui::GetColorU32(ImGuiCol_Text), vis.c_str(), nullptr, wrapW);
    return c;
}
inline bool Selectable(const char* label, bool* sel, ImGuiSelectableFlags fl = 0, ImVec2 size = ImVec2(0, 0)) {
    bool c = Selectable(label, *sel, fl, size);
    if (c) *sel = !*sel;
    return c;
}

inline bool RadioButton(const char* label, bool active) {
    std::string vis = visible(label);
    if (vis.empty()) return ImGui::RadioButton(label, active);
    float fs = ImGui::GetFontSize();
    FitLine(fs * 1.6f + std::min(ImGui::CalcTextSize(vis.c_str()).x, ImGui::GetContentRegionMax().x * 0.7f));
    bool c = ImGui::RadioButton(hid(label).c_str(), active);
    ImGui::SameLine();
    ImGui::PushTextWrapPos(0.f);
    ImGui::TextUnformatted(vis.c_str());
    ImGui::PopTextWrapPos();
    if (ImGui::IsItemClicked()) c = true;
    return c;
}
inline bool RadioButton(const char* label, int* v, int vb) {
    bool c = RadioButton(label, *v == vb);
    if (c) *v = vb;
    return c;
}

// Ventanas: el texto largo continua en el renglon de abajo.
inline bool Begin(const char* name, bool* open = nullptr, ImGuiWindowFlags fl = 0) {
    bool ok = ImGui::Begin(name, open, fl);
    if (ok) ImGui::PushTextWrapPos(0.f);
    return ok;
}
inline bool BeginChild(const char* id, const ImVec2& size = ImVec2(0, 0), ImGuiChildFlags cf = 0, ImGuiWindowFlags fl = 0) {
    bool ok = ImGui::BeginChild(id, size, cf, fl);
    if (ok) ImGui::PushTextWrapPos(0.f);
    return ok;
}

// Mosaico grande: dibujo arriba y nombre abajo (se entiende de un vistazo, tambien para ninos pequenos).
inline bool Tile(const char* id, const char* text, int ic, ImVec4 col, ImVec2 size) {
    ImVec2 p = ImGui::GetCursorScreenPos();
    bool c = ImGui::InvisibleButton(id, size);
    bool hov = ImGui::IsItemHovered(), act = ImGui::IsItemActive();
    ImDrawList* d = ImGui::GetWindowDrawList();
    float k = act ? 0.8f : hov ? 1.15f : 1.f;
    ImVec4 base(std::min(1.f, col.x * k), std::min(1.f, col.y * k), std::min(1.f, col.z * k), 1.f);
    ImVec4 dark(base.x * 0.55f, base.y * 0.55f, base.z * 0.55f, 1.f);
    ImVec2 q(p.x + size.x, p.y + size.y);
    float rad = std::min(size.x, size.y) * 0.16f;
    d->AddRectFilled(ImVec2(p.x, p.y + 3.f), ImVec2(q.x, q.y + 3.f), IM_COL32(0, 0, 0, 90), rad);
    d->AddRectFilled(p, q, ImGui::GetColorU32(dark), rad);
    d->AddRectFilled(p, ImVec2(q.x, q.y - size.y * 0.06f), ImGui::GetColorU32(base), rad);
    float isz = std::min(size.x, size.y) * 0.40f;
    ImVec2 ctr(p.x + size.x * 0.5f, p.y + size.y * 0.36f);
    d->AddCircleFilled(ctr, isz * 0.78f, IM_COL32(255, 255, 255, 46), 28);
    drawIcon(d, ic, ctr, isz, IM_COL32(255, 255, 255, 255));
    float fs = ImGui::GetFontSize(), wrapW = size.x - fs * 0.8f;
    ImVec2 ts = ImGui::CalcTextSize(text, nullptr, false, wrapW);
    d->AddText(ImGui::GetFont(), fs, ImVec2(p.x + (size.x - std::min(ts.x, wrapW)) * 0.5f, p.y + size.y * 0.66f), IM_COL32(255, 255, 255, 255), text, nullptr, wrapW);
    return c;
}

// Fondo degradado de toda la pantalla (detras de las ventanas).
inline void BackdropGradient(float w, float h) {
    ImDrawList* d = ImGui::GetBackgroundDrawList();
    d->AddRectFilledMultiColor(ImVec2(0, 0), ImVec2(w, h), IM_COL32(18, 34, 66, 255), IM_COL32(24, 28, 70, 255), IM_COL32(8, 12, 26, 255), IM_COL32(8, 16, 30, 255));
}

}  // namespace wrapui
