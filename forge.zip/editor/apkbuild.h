#pragma once
// Crea el APK de un juego a partir de la plantilla (el APK de P-Maker): cambia nombre/paquete/version/orientacion,
// anade game.pack, reescribe el zip alineado y lo firma (esquema v2). Version C++ de ApkPatcher.java (sirve en Windows).
#include <cstdint>
#include <map>
#include <string>
#include <vector>

namespace forge {

struct ApkConfig {
    std::string label = "Juego", appId = "com.mijuego.app", verName = "1.0";
    int verCode = 1;
    int orient = 0;  // 0 horizontal, 1 vertical, 2 automatica
    std::string oldPackage = "com.forge.maker";
};

std::vector<uint8_t> sha256(const uint8_t* d, size_t n);
// Firma RSA PKCS#1 v1.5 con SHA-256. pk8 = clave privada PKCS#8 (DER). Devuelve vacio si falla.
std::vector<uint8_t> rsaSignSha256(const std::vector<uint8_t>& pk8, const uint8_t* msg, size_t n);

bool apkPatchManifest(const std::vector<uint8_t>& in, const ApkConfig& c, std::vector<uint8_t>& out, std::string& err);

// template: bytes del APK plantilla. extra: archivos nuevos (ruta -> datos). icon: png o vacio.
bool apkBuild(const std::vector<uint8_t>& tpl, const std::map<std::string, std::vector<uint8_t>>& extra,
              const std::vector<uint8_t>& iconPng, const ApkConfig& c, const std::vector<uint8_t>& pk8,
              const std::vector<uint8_t>& certDer, std::vector<uint8_t>& out, bool* iconReplaced, std::string& err);

}  // namespace forge
