#pragma once
#include "scene.h"
#include "rig.h"
#include "zip.h"
#include <atomic>
#include <string>
#include <vector>

namespace forge {

// Avance (0..1) de la importacion de modelo que se esta haciendo en otro hilo.
extern std::atomic<float> gImportProgress;

// Convierte un modelo 3D (obj, glb, gltf con todo incrustado, fbx) al formato compacto .fmdl
// y lo agrega a los assets. Si el modelo trae textura incrustada, tambien se agrega como asset.
// `res` = archivos hermanos (de un .zip): texturas, .mtl, .bin... para que el modelo conserve su color.
bool importModel(const std::string& fileName, const std::vector<uint8_t>& data, Files& assets,
                 std::string& modelAssetName, std::string& err, const ResMap* res = nullptr);

// Abre un .zip, busca el modelo (glb, gltf, fbx, obj) y lo importa con sus texturas.
bool importModelZip(const std::vector<uint8_t>& zip, Files& assets, std::string& modelAssetName, std::string& err);

// Importa animaciones (glb, gltf, fbx). Con malla+esqueleto crea el esqueleto del modelo 'modelAsset' (rig vacio);
// si 'rig' ya tiene huesos, asigna las animaciones por nombre de hueso. 'clipsAdded' = cuantas animaciones entraron.
bool importAnimations(const std::string& fileName, const std::vector<uint8_t>& data, const std::string& modelAsset, Rig& rig,
                      int& clipsAdded, std::string& err, const ResMap* res = nullptr);

bool isModelFile(const std::string& fileName);

}  // namespace forge
