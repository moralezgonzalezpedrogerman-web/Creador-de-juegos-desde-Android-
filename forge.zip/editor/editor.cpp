#include "editor.h"
#include "fsutil.h"
#include "importer.h"
#include "preview.h"
#include "hud.h"
#include "pack.h"

#include "imgui.h"
#include "misc/cpp/imgui_stdlib.h"

#include <algorithm>
#include <cmath>
#include <cstdio>

namespace forge {

// ---------------------------------------------------------------- ayudantes de interfaz
namespace {

std::string lower(std::string s) {
    for (auto& c : s) c = (char)tolower((unsigned char)c);
    return s;
}
bool ends(const std::string& s, const char* e) {
    std::string l = lower(s);
    size_t n = strlen(e);
    return l.size() >= n && l.compare(l.size() - n, n, e) == 0;
}
std::string sanitize(const std::string& in) {
    std::string o;
    for (char c : in) {
        if (isalnum((unsigned char)c) || c == '_' || c == '-') o += c;
        else if (c == ' ') o += '_';
    }
    return o;
}

std::string shorten(const std::string& s, size_t n = 22) {
    return s.size() <= n ? s : s.substr(0, n - 1) + "…";
}

bool Combo(const char* label, std::string& cur, const std::vector<std::string>& items, const char* none = nullptr) {
    bool ch = false;
    const char* preview = cur.empty() ? (none ? none : "(ninguno)") : cur.c_str();
    if (ImGui::BeginCombo(label, preview)) {
        if (none && ImGui::Selectable(none, cur.empty())) { cur.clear(); ch = true; }
        for (auto& it : items)
            if (ImGui::Selectable(it.c_str(), it == cur)) { cur = it; ch = true; }
        ImGui::EndCombo();
    }
    return ch;
}

}  // namespace

// [-] valor [+]: los botones dan precision; tocar el numero abre el teclado del telefono.
bool Editor::stepper(const char* label, float& v, float step) {
    bool ch = false;
    ImGui::PushID(label);
    float fs = ImGui::GetFontSize();
    ImGui::AlignTextToFramePadding();
    ImGui::TextUnformatted(label);
    ImGui::SameLine(fs * 4.5f);
    if (ImGui::Button("-")) { v -= step; ch = true; }
    ImGui::SameLine();
    if (host_.prompt) {
        char buf[32];
        snprintf(buf, sizeof buf, "%.2f", v);
        std::string lab = std::string(buf) + "##v";
        if (ImGui::Button(lab.c_str(), ImVec2(fs * 5.f, 0)) && tapped() && !promptActive_) {
            promptNum_ = &v; promptLo_ = -1e9f; promptHi_ = 1e9f;
            numBuf_ = buf;
            promptDst_ = &numBuf_;
            promptActive_ = true;
            host_.prompt(label, numBuf_);
        }
    } else {
        ImGui::SetNextItemWidth(fs * 5.f);
        if (ImGui::DragFloat("##v", &v, step * 0.25f, 0, 0, "%.2f")) ch = true;
    }
    ImGui::SameLine();
    if (ImGui::Button("+")) { v += step; ch = true; }
    ImGui::PopID();
    return ch;
}

// Barra deslizante + boton "123" para escribir el valor con el teclado.
bool Editor::numField(const char* label, float& v, float mn, float mx, const char* fmt) {
    bool ch = ImGui::SliderFloat(label, &v, mn, mx, fmt);
    if (host_.prompt) {
        ImGui::PushID(label);
        ImGui::SameLine();
        if (ImGui::Button("123") && tapped() && !promptActive_) {
            char buf[32];
            snprintf(buf, sizeof buf, "%g", v);
            promptNum_ = &v; promptLo_ = mn; promptHi_ = mx;
            numBuf_ = buf;
            promptDst_ = &numBuf_;
            promptActive_ = true;
            host_.prompt(label, numBuf_);
        }
        ImGui::PopID();
    }
    return ch;
}

// Una sola ventana flotante a la vez: al abrir una, las demas se cierran.
void Editor::enforceOneWindow() {
    bool* f[5] = {&showObjs, &showProps, &showWorld, &showHud, &showAssets};
    int newest = -1, first = -1;
    for (int i = 0; i < 5; i++) {
        if (*f[i] && !prevW_[i]) newest = i;
        if (*f[i] && first < 0) first = i;
    }
    int keep = newest >= 0 ? newest : first;
    for (int i = 0; i < 5; i++) if (i != keep) *f[i] = false;
    for (int i = 0; i < 5; i++) prevW_[i] = *f[i];
}

void applyTheme() {
    ImGuiStyle& st = ImGui::GetStyle();
    ImGui::StyleColorsDark(&st);
    st.WindowRounding = 14.f;  st.ChildRounding = 10.f;  st.FrameRounding = 9.f;  st.PopupRounding = 12.f;
    st.GrabRounding = 9.f;     st.ScrollbarRounding = 9.f; st.TabRounding = 9.f;
    st.WindowBorderSize = 0.f; st.FrameBorderSize = 0.f; st.PopupBorderSize = 1.f; st.ChildBorderSize = 0.f;
    st.WindowPadding = ImVec2(14, 12);
    st.FramePadding = ImVec2(12, 8);
    st.ItemSpacing = ImVec2(10, 9);
    st.ItemInnerSpacing = ImVec2(8, 6);
    st.ScrollbarSize = 10.f;
    st.GrabMinSize = 16.f;
    st.WindowTitleAlign = ImVec2(0.5f, 0.5f);
    st.SeparatorTextBorderSize = 2.f;
    st.SeparatorTextPadding = ImVec2(20, 6);
    auto C = [&](ImGuiCol i, float r, float g, float b, float a = 1.f) { st.Colors[i] = ImVec4(r, g, b, a); };
    // grafito azulado con un acento turquesa
    C(ImGuiCol_Text, 0.93f, 0.95f, 0.98f);
    C(ImGuiCol_TextDisabled, 0.52f, 0.58f, 0.67f);
    C(ImGuiCol_WindowBg, 0.075f, 0.085f, 0.115f, 0.97f);
    C(ImGuiCol_ChildBg, 0.10f, 0.115f, 0.15f, 0.9f);
    C(ImGuiCol_PopupBg, 0.095f, 0.11f, 0.145f, 0.98f);
    C(ImGuiCol_Border, 0.22f, 0.26f, 0.33f, 0.8f);
    C(ImGuiCol_FrameBg, 0.13f, 0.15f, 0.20f);
    C(ImGuiCol_FrameBgHovered, 0.17f, 0.20f, 0.27f);
    C(ImGuiCol_FrameBgActive, 0.20f, 0.24f, 0.32f);
    C(ImGuiCol_TitleBg, 0.075f, 0.085f, 0.115f);
    C(ImGuiCol_TitleBgActive, 0.10f, 0.12f, 0.16f);
    C(ImGuiCol_TitleBgCollapsed, 0.075f, 0.085f, 0.115f, 0.8f);
    C(ImGuiCol_MenuBarBg, 0.09f, 0.10f, 0.14f);
    C(ImGuiCol_ScrollbarBg, 0.f, 0.f, 0.f, 0.f);
    C(ImGuiCol_ScrollbarGrab, 0.28f, 0.33f, 0.42f);
    C(ImGuiCol_ScrollbarGrabHovered, 0.36f, 0.42f, 0.52f);
    C(ImGuiCol_ScrollbarGrabActive, 0.18f, 0.78f, 0.68f);
    C(ImGuiCol_CheckMark, 0.18f, 0.85f, 0.74f);
    C(ImGuiCol_SliderGrab, 0.18f, 0.78f, 0.68f);
    C(ImGuiCol_SliderGrabActive, 0.30f, 0.92f, 0.82f);
    C(ImGuiCol_Button, 0.17f, 0.21f, 0.29f);
    C(ImGuiCol_ButtonHovered, 0.22f, 0.28f, 0.38f);
    C(ImGuiCol_ButtonActive, 0.16f, 0.62f, 0.55f);
    C(ImGuiCol_Header, 0.15f, 0.40f, 0.40f, 0.65f);
    C(ImGuiCol_HeaderHovered, 0.17f, 0.50f, 0.48f, 0.80f);
    C(ImGuiCol_HeaderActive, 0.16f, 0.62f, 0.55f);
    C(ImGuiCol_Separator, 0.22f, 0.26f, 0.33f);
    C(ImGuiCol_SeparatorHovered, 0.18f, 0.78f, 0.68f);
    C(ImGuiCol_SeparatorActive, 0.18f, 0.78f, 0.68f);
    C(ImGuiCol_ResizeGrip, 0.18f, 0.78f, 0.68f, 0.25f);
    C(ImGuiCol_ResizeGripHovered, 0.18f, 0.78f, 0.68f, 0.6f);
    C(ImGuiCol_ResizeGripActive, 0.18f, 0.78f, 0.68f, 0.9f);
    C(ImGuiCol_Tab, 0.13f, 0.16f, 0.22f);
    C(ImGuiCol_TabHovered, 0.17f, 0.50f, 0.48f);
    C(ImGuiCol_TabActive, 0.16f, 0.62f, 0.55f);
    C(ImGuiCol_TextSelectedBg, 0.18f, 0.78f, 0.68f, 0.35f);
    C(ImGuiCol_ModalWindowDimBg, 0.f, 0.f, 0.f, 0.55f);
}

// ---------------------------------------------------------------- general
void Editor::init(Audio* audio) {
    audio_ = audio;
    listProjects();
}

void Editor::listProjects() { projList_ = fs::list(host_.dataDir + "/projects", true); }

Obj* Editor::selObj() {
    if (!hasScene() || sel_ < 0 || sel_ >= (int)scene().objs.size()) return nullptr;
    return &scene().objs[sel_];
}

std::string Editor::uniqueName(const std::string& base) {
    Scene& S = scene();
    auto used = [&](const std::string& n) { for (auto& o : S.objs) if (o.name == n) return true; return false; };
    if (!used(base)) return base;
    for (int i = 2;; i++) {
        std::string n = base + "_" + std::to_string(i);
        if (!used(n)) return n;
    }
}

void Editor::resetView() {
    if (!hasScene()) return;
    Scene& S = scene();
    if (S.is3d) { target_ = V3{S.start.x, 0.f, S.start.z}; dist_ = 14.f; yaw_ = 0.6f; pitch_ = 0.55f; }
    else { cx_ = cy_ = 0; h2d_ = kView2DHeight; }
}

void Editor::setScene(int i) {
    if (i < 0 || i >= (int)edit_.proj.scenes.size()) return;
    sceneIdx_ = i;
    sel_ = -1;
    edit_.bindScene(i);
    resetView();
}

std::vector<std::string> Editor::assetsOf(int kind) const {
    std::vector<std::string> v;
    for (auto& a : edit_.proj.assets) {
        bool img = ends(a.first, ".png") || ends(a.first, ".jpg") || ends(a.first, ".jpeg");
        bool snd = Audio::isAudioFile(a.first);
        bool mdl = ends(a.first, ".fmdl");
        if ((kind == 0 && img) || (kind == 1 && snd) || (kind == 2 && mdl)) v.push_back(a.first);
    }
    return v;
}

// ---------------------------------------------------------------- proyectos
bool Editor::newProject(const std::string& nm, bool demo) {
    std::string n = sanitize(nm);
    if (n.empty()) { toast("Escribe un nombre válido (letras, números, _ o -)"); return false; }
    if (fs::exists(host_.dataDir + "/projects/" + n)) { toast("Ya existe un proyecto con ese nombre"); return false; }
    Project p;
    if (demo) {
        loadDemo(p);
    } else {
        Scene s;
        s.name = "Nivel1";
        Obj fl; fl.kind = Kind::Floor; fl.name = "Suelo"; fl.pos = {0, -0.1f, 0}; fl.scale = {40, 0.2f, 40};
        fl.color[0] = 0.45f; fl.color[1] = 0.62f; fl.color[2] = 0.40f;
        Obj lt; lt.kind = Kind::Light; lt.name = "Luz"; lt.pos = {0, 3, 0}; lt.scale = {12, 1, 1}; lt.solid = false;
        lt.color[0] = 1.f; lt.color[1] = 0.8f; lt.color[2] = 0.6f;
        s.objs = {fl, lt};
        s.start = {0, 0.05f, 6};
        p.scenes.push_back(s);
    }
    p.name = n;
    edit_ = Game();
    edit_.proj = std::move(p);
    name_ = n;
    sceneIdx_ = 0;
    sel_ = -1;
    edit_.bindScene(0);
    resetView();
    assetDirty_.clear();
    for (auto& a : edit_.proj.assets) assetDirty_.insert(a.first);
    if (audio_) audio_->setAssets(edit_.proj.assets);
    screen_ = Screen::Edit;
    page_ = Page::Scenes;
    dirty_ = true;
    saveProject();
    listProjects();
    return true;
}

bool Editor::openProject(const std::string& nm) {
    std::string dir = host_.dataDir + "/projects/" + nm;
    Files files;
    std::vector<uint8_t> b;
    if (!fs::read(dir + "/project.forge", b)) { toast("No se pudo abrir el proyecto"); return false; }
    files["project.forge"] = b;
    for (auto& f : fs::list(dir + "/assets", false)) {
        std::vector<uint8_t> d;
        if (fs::read(dir + "/assets/" + f, d)) files[f] = std::move(d);
    }
    Project p;
    std::string err;
    if (!loadProject(files, p, err)) { toast("Proyecto dañado: " + err); return false; }
    edit_ = Game();
    edit_.proj = std::move(p);
    name_ = nm;
    sceneIdx_ = 0;
    sel_ = -1;
    edit_.bindScene(0);
    resetView();
    assetDirty_.clear();
    dirty_ = false;
    if (audio_) audio_->setAssets(edit_.proj.assets);
    screen_ = Screen::Edit;
    page_ = Page::Scenes;
    return true;
}

bool Editor::saveProject() {
    if (name_.empty()) return false;
    std::string dir = host_.dataDir + "/projects/" + name_;
    if (!fs::mkdirs(dir + "/assets")) { toast("No se pudo crear la carpeta del proyecto"); return false; }
    std::string t = writeProject(edit_.proj);
    if (!fs::write(dir + "/project.forge", (const uint8_t*)t.data(), t.size())) { toast("No se pudo guardar"); return false; }
    for (auto& a : edit_.proj.assets) {
        std::string path = dir + "/assets/" + a.first;
        if (assetDirty_.count(a.first) || !fs::exists(path)) fs::write(path, a.second.data(), a.second.size());
    }
    for (auto& f : fs::list(dir + "/assets", false))  // quitar los borrados
        if (!edit_.proj.assets.count(f)) fs::remove(dir + "/assets/" + f);
    assetDirty_.clear();
    dirty_ = false;
    toast("Guardado");
    return true;
}

void Editor::closeProject() {
    if (dirty_) saveProject();
    if (audio_) audio_->stopMusic();
    screen_ = Screen::Projects;
    page_ = Page::Scenes;
    name_.clear();
    listProjects();
}

bool Editor::buildPack(std::vector<uint8_t>& out) {
    Files f = edit_.proj.assets;
    std::string t = writeProject(edit_.proj);
    f["project.forge"] = std::vector<uint8_t>(t.begin(), t.end());
    return packWrite(f, out);
}

bool Editor::buildExe(std::vector<uint8_t>& out, std::string& err) {
    std::vector<uint8_t> rt, pk;
    if (!host_.loadRuntime || !host_.loadRuntime(rt)) {
        err = "Esta app no incluye el runtime de Windows: compílala con GitHub Actions";
        return false;
    }
    buildPack(pk);
    if (!forge::exportExe(rt, pk, out)) { err = "El runtime incluido no es un .exe válido"; return false; }
    return true;
}

void Editor::doExportExe() {
    if (dirty_) saveProject();
    std::vector<uint8_t> out;
    std::string err;
    if (!buildExe(out, err)) { toast(err); return; }
    std::string dir = host_.dataDir + "/export";
    fs::mkdirs(dir);
    std::string exeBase = exportSlug(edit_.proj.exportCfg.exeName.empty() ? name_ : edit_.proj.exportCfg.exeName);
    std::string path = dir + "/" + exeBase + ".exe";
    if (!fs::write(path, out.data(), out.size())) { toast("No se pudo escribir el .exe"); return; }
    if (host_.saveOut) host_.saveOut(exeBase + ".exe", path);
    toast("Elige dónde guardar el .exe");
}

void Editor::doExportPack() {
    if (dirty_) saveProject();
    std::vector<uint8_t> out;
    buildPack(out);
    std::string dir = host_.dataDir + "/export";
    fs::mkdirs(dir);
    std::string path = dir + "/" + name_ + ".pack";
    if (!fs::write(path, out.data(), out.size())) { toast("No se pudo escribir el paquete"); return; }
    if (host_.saveOut) host_.saveOut(name_ + ".pack", path);
    toast("Elige dónde guardar el paquete (.pack)");
}

// Importa un proyecto exportado (.pack): lo guarda como un proyecto nuevo con nombre libre.
bool Editor::importPack(const std::string& fileName, const std::vector<uint8_t>& data) {
    Files files;
    if (!packRead(data.data(), data.size(), files) || !files.count("project.forge")) {
        toast("Ese archivo no es un paquete de P-Maker (.pack)");
        return false;
    }
    Project test;
    std::string err;
    if (!loadProject(files, test, err)) { toast("El paquete está dañado: " + err); return false; }
    std::string base = fileName;
    size_t sl = base.find_last_of("/\\");
    if (sl != std::string::npos) base = base.substr(sl + 1);
    size_t dot = base.find_last_of('.');
    if (dot != std::string::npos) base = base.substr(0, dot);
    base = sanitize(base);
    if (base.empty()) base = "importado";
    std::string n = base;
    for (int i = 2; fs::exists(host_.dataDir + "/projects/" + n); i++) n = base + "_" + std::to_string(i);
    std::string dir = host_.dataDir + "/projects/" + n;
    fs::mkdirs(dir + "/assets");
    const auto& pf = files["project.forge"];
    if (!fs::write(dir + "/project.forge", pf.data(), pf.size())) { toast("No se pudo guardar el proyecto"); return false; }
    for (auto& f : files)
        if (f.first != "project.forge") fs::write(dir + "/assets/" + f.first, f.second.data(), f.second.size());
    listProjects();
    toast("Proyecto importado: " + n);
    return true;
}

void Editor::onFile(const std::string& rawName, std::vector<uint8_t> data) {
    if (ends(rawName, ".pack")) { importPack(rawName, data); return; }
    if (screen_ != Screen::Edit) { toast("Abre un proyecto para importar archivos"); return; }
    std::string name = rawName;
    size_t sl = name.find_last_of("/\\");
    if (sl != std::string::npos) name = name.substr(sl + 1);
    for (auto& c : name) if (c == ' ') c = '_';
    Files& A = edit_.proj.assets;
    if (ends(name, ".png") || ends(name, ".jpg") || ends(name, ".jpeg")) {
        A[name] = std::move(data);
        assetDirty_.insert(name);
        toast("Imagen importada: " + name);
        if (pendingNewObj_ && hasScene()) {
            pendingNewObj_ = false;
            addObject(Kind::Cube);
            if (Obj* n = selObj()) {
                n->tex = name;
                n->color[0] = n->color[1] = n->color[2] = 1.f;
                n->name = uniqueName(name.substr(0, name.find_last_of('.')));
            }
        } else if (page_ == Page::Object && tab_ == 1) {
            if (Obj* n = selObj()) n->looks.push_back(name);
        }
    } else if (Audio::isAudioFile(name)) {
        A[name] = std::move(data);
        assetDirty_.insert(name);
        if (audio_) audio_->setAssets(A);
        toast("Audio importado: " + name);
        if (page_ == Page::Object && tab_ == 2) {
            if (Obj* n = selObj()) n->sounds.push_back(name);
        }
    } else if (ends(name, ".blend") || ends(name, ".blend1")) {
        pendingNewModel_ = false;
        toast("Los .blend no se pueden leer directo. En Blender: Archivo > Exportar > glTF 2.0 (.glb) y elige ese archivo.");
        return;
    } else if (ends(name, ".rar") || ends(name, ".7z")) {
        pendingNewModel_ = false;
        toast("Los .rar y .7z no se pueden abrir aquí. Conviértelo a .zip (o descomprímelo y elige el .glb/.obj).");
        return;
    } else if (isModelFile(name) || ends(name, ".zip")) {
        std::set<std::string> before;
        for (auto& a : A) before.insert(a.first);
        std::string model, err;
        bool okImp = ends(name, ".zip") ? importModelZip(data, A, model, err) : importModel(name, data, A, model, err);
        if (!okImp) { toast("No se pudo importar: " + err); return; }
        for (auto& a : A) if (!before.count(a.first)) assetDirty_.insert(a.first);
        if (pendingNewModel_ && hasScene() && scene().is3d) {
            pendingNewModel_ = false;
            addObject(Kind::Model, model);
            toast("Modelo importado y añadido: " + model);
        } else {
            toast("Modelo importado: " + model + " (Objeto nuevo > Modelo 3D)");
        }
    } else {
        toast("Formato no compatible. Usa png, jpg, mp3, wav, flac, obj, glb, gltf o fbx");
        return;
    }
    markDirty();
}

// ---------------------------------------------------------------- objetos y escenas
void Editor::addObject(Kind k, const std::string& modelName) {
    if (!hasScene()) return;
    Scene& S = scene();
    Obj o;
    o.kind = k;
    float gx = std::round(target_.x), gz = std::round(target_.z);
    V3 at = S.is3d ? V3{gx, 0, gz} : V3{std::round(cx_), std::round(cy_), 0};
    std::string base = "Objeto";
    switch (k) {
        case Kind::Cube:
            base = S.is3d ? "Cubo" : "Objeto";
            o.pos = S.is3d ? V3{at.x, 0.5f, at.z} : V3{at.x, at.y, 0};
            o.scale = S.is3d ? V3{1, 1, 1} : V3{200, 200, 1};
            if (!S.is3d) { o.color[0] = 0.95f; o.color[1] = 0.55f; o.color[2] = 0.15f; o.solid = false; o.yaw = 90; }
            break;
        case Kind::Floor:
            base = "Suelo"; o.pos = {at.x, -0.1f, at.z}; o.scale = {10, 0.2f, 10}; o.texTile = true;
            o.color[0] = 0.45f; o.color[1] = 0.62f; o.color[2] = 0.40f;
            break;
        case Kind::Wall:
            base = "Pared"; o.pos = {at.x, 1.5f, at.z}; o.scale = {4, 3, 0.5f};
            o.color[0] = o.color[1] = 0.8f; o.color[2] = 0.86f;
            break;
        case Kind::Item:
            base = "Item"; o.pos = {at.x, 1.f, at.z}; o.scale = {0.5f, 0.5f, 0.5f}; o.solid = false; o.spin = true;
            o.color[0] = 1.f; o.color[1] = 0.8f; o.color[2] = 0.1f;
            break;
        case Kind::Light:
            base = "Luz"; o.pos = {at.x, 3.f, at.z}; o.scale = {12, 1, 1}; o.solid = false;
            o.color[0] = 1.f; o.color[1] = 0.8f; o.color[2] = 0.6f;
            break;
        case Kind::Model:
            base = "Modelo"; o.pos = {at.x, 1.f, at.z}; o.scale = {2, 2, 2}; o.model = modelName;
            break;
        case Kind::Player: return;
    }
    o.name = uniqueName(base);
    S.objs.push_back(o);
    sel_ = (int)S.objs.size() - 1;
    markDirty();
}

void Editor::addScene(bool is3d) {
    Scene s;
    s.is3d = is3d;
    int n = (int)edit_.proj.scenes.size() + 1;
    auto taken = [&](const std::string& nm) { for (auto& x : edit_.proj.scenes) if (x.name == nm) return true; return false; };
    std::string base = is3d ? "Nivel" : "Menu";
    std::string nm = base + std::to_string(n);
    for (int i = n; taken(nm); i++) nm = base + std::to_string(i + 1);
    s.name = nm;
    if (is3d) {
        Obj fl; fl.kind = Kind::Floor; fl.name = "Suelo"; fl.pos = {0, -0.1f, 0}; fl.scale = {40, 0.2f, 40};
        fl.color[0] = 0.45f; fl.color[1] = 0.62f; fl.color[2] = 0.40f;
        s.objs.push_back(fl);
        s.start = {0, 0.05f, 6};
        for (const char* g : {"vida", "municion", "puntos", "llave"})
            if (std::find(edit_.proj.globalVars.begin(), edit_.proj.globalVars.end(), g) == edit_.proj.globalVars.end())
                edit_.proj.globalVars.push_back(g);
        auto mk = [](Op op, const char* t, const char* a, const char* b2, const char* c) {
            Block b; b.op = op; b.t = t; b.f[0] = a; b.f[1] = b2; b.f[2] = c; return b;
        };
        s.objs[0].blocks = {mk(Op::WhenStart, "", "", "", ""), mk(Op::ShowVar, "vida", "-420", "440", ""),
                            mk(Op::ShowVar, "municion", "420", "440", ""),
                            mk(Op::WhenTrue, "", "\"vida\" <= 0", "", ""), mk(Op::Say, "", "Has muerto", "", ""),
                            mk(Op::SetVar, "vida", "100", "", ""), mk(Op::TeleportPlayer, "", "0", "0.05", "6")};
    } else {
        s.skyTop[0] = 0.10f; s.skyTop[1] = 0.12f; s.skyTop[2] = 0.25f;
        s.skyBot[0] = 0.20f; s.skyBot[1] = 0.25f; s.skyBot[2] = 0.45f;
        Obj bg; bg.name = "Fondo"; bg.bg = true; bg.solid = false; bg.layer = -1000; bg.yaw = 90;
        bg.color[0] = 0.20f; bg.color[1] = 0.25f; bg.color[2] = 0.45f;
        s.objs.push_back(bg);
    }
    ensurePlayer(s);
    edit_.proj.scenes.push_back(s);
    setScene((int)edit_.proj.scenes.size() - 1);
    markDirty();
}

void Editor::startPlay() {
    if (edit_.proj.scenes.empty()) return;
    if (dirty_) saveProject();
    play_.audio = audio_;
    play_.showButtons = true;
    play_.onVibrate = host_.vibrate;
    play_.onSpeak = host_.speak;
    play_.onFlash = host_.flash;
    play_.start(edit_.proj);  // copia: el juego no altera lo que estas editando
    screen_ = Screen::Play;
}

void Editor::stopPlay() {
    if (audio_) { audio_->stopMusic(); audio_->setAssets(edit_.proj.assets); }
    play_.ctl.hud = nullptr;
    play_.ctl.reset();
    screen_ = Screen::Edit;
}

// ---------------------------------------------------------------- camara y seleccion
EditorView Editor::view() const {
    EditorView ev;
    ev.sel = sel_;
    ev.target = target_;
    ev.cx = cx_; ev.cy = cy_; ev.h2d = h2d_;
    V3 dir{std::sin(yaw_) * std::cos(pitch_), std::sin(pitch_), std::cos(yaw_) * std::cos(pitch_)};
    ev.eye = target_ + dir * dist_;
    ev.fwd = norm(target_ - ev.eye);
    return ev;
}

void Editor::rayAt(float x, float y, const EditorView& ev, V3& o, V3& d) const {
    float aspect = h_ > 0 ? (float)w_ / (float)h_ : 1.f;
    float ty = std::tan(1.2217f * 0.5f), tx = ty * aspect;
    float nx = (x / (float)w_) * 2.f - 1.f, ny = 1.f - (y / (float)h_) * 2.f;
    V3 r = norm(cross(ev.fwd, V3{0, 1, 0})), u = cross(r, ev.fwd);
    o = ev.eye;
    d = norm(ev.fwd + r * (nx * tx) + u * (ny * ty));
}

int Editor::pick(float x, float y, const EditorView& ev) {
    if (!hasScene()) return -1;
    Scene& S = scene();
    if (S.is3d) {
        V3 o, d;
        rayAt(x, y, ev, o, d);
        float best = 1e9f;
        int hit = -1;
        for (int i = 0; i < (int)S.objs.size(); i++) {
            const Obj& ob = S.objs[i];
            if (!ob.visible || !ob.alive) continue;
            V3 half = ob.kind == Kind::Light ? V3{0.25f, 0.25f, 0.25f} : ob.scale * 0.5f;
            float t;
            if (rayBoxYaw(o, d, ob.pos, half, ob.kind == Kind::Light ? 0.f : ob.yaw, t) && t < best) { best = t; hit = i; }
        }
        return hit;
    }
    float aspect = h_ > 0 ? (float)w_ / (float)h_ : 1.f;
    float wx = cx_ + (x / (float)w_ - 0.5f) * h2d_ * aspect, wy = cy_ + (0.5f - y / (float)h_) * h2d_;
    for (int i = (int)S.objs.size() - 1; i >= 0; i--) {
        const Obj& ob = S.objs[i];
        if (!ob.visible) continue;
        float ra = -(ob.yaw - 90.f) * 0.0174532925f, cs = std::cos(ra), sn = std::sin(ra);
        float ddx = wx - ob.pos.x, ddy = wy - ob.pos.y;
        if (std::fabs(cs * ddx + sn * ddy) <= ob.scale.x * 0.5f && std::fabs(-sn * ddx + cs * ddy) <= ob.scale.y * 0.5f) return i;
    }
    return -1;
}

// Gestos sobre la vista: 1 dedo gira la camara (o arrastra el objeto seleccionado),
// 2 dedos acercan y desplazan, toque corto selecciona.
void Editor::gestures() {
    ImGuiIO& io = ImGui::GetIO();
    auto& P = play_.ctl.p;
    int ids[2], n = 0;
    for (int i = 0; i < 10 && n < 2; i++) if (P[i].down) ids[n++] = i;
    int total = play_.ctl.downCount();

    if (total == 0) {
        if (prevN_ == 1 && gestOk_ && moveAcc_ < 20.f && hasScene()) sel_ = pick(lastX_, lastY_, view());
        prevN_ = 0;
        dragObj_ = false;
        return;
    }
    if (prevN_ == 0) { gestOk_ = !io.WantCaptureMouse; moveAcc_ = 0; dragObj_ = false; }
    if (!gestOk_ || !hasScene()) { prevN_ = n; return; }

    EditorView ev = view();
    Scene& S = scene();
    float aspect = h_ > 0 ? (float)w_ / (float)h_ : 1.f;

    if (n == 1) {
        float x = P[ids[0]].lx, y = P[ids[0]].ly;
        if (prevN_ != 1) {
            lastX_ = x; lastY_ = y;
            Obj* o = selObj();
            if (prevN_ == 0 && o && pick(x, y, ev) == sel_) {  // el dedo empieza sobre el objeto seleccionado
                dragObj_ = true;
                if (S.is3d) {
                    V3 ro, rd;
                    rayAt(x, y, ev, ro, rd);
                    if (std::fabs(rd.y) > 1e-4f) {
                        float t = (o->pos.y - ro.y) / rd.y;
                        V3 hit = ro + rd * t;
                        grab_ = V3{hit.x - o->pos.x, 0, hit.z - o->pos.z};
                    } else grab_ = V3();
                } else {
                    float wx = cx_ + (x / (float)w_ - 0.5f) * h2d_ * aspect, wy = cy_ + (0.5f - y / (float)h_) * h2d_;
                    grab_ = V3{wx - o->pos.x, wy - o->pos.y, 0};
                }
            }
        }
        float dx = x - lastX_, dy = y - lastY_;
        lastX_ = x; lastY_ = y;
        moveAcc_ += std::fabs(dx) + std::fabs(dy);
        float sn = S.is3d ? snap_ : (snap_ > 0.f ? snap_ * 40.f : 0.f);
        auto snapv = [&](float v) { return sn > 0.f ? std::round(v / sn) * sn : v; };
        if (dragObj_) {
            Obj* o = selObj();
            if (o && moveAcc_ > 14.f) {
                if (S.is3d) {
                    V3 ro, rd;
                    rayAt(x, y, ev, ro, rd);
                    if (std::fabs(rd.y) > 1e-4f) {
                        float t = (o->pos.y - ro.y) / rd.y;
                        if (t > 0) {
                            V3 hit = ro + rd * t;
                            o->pos.x = snapv(hit.x - grab_.x);
                            o->pos.z = snapv(hit.z - grab_.z);
                            markDirty();
                        }
                    }
                } else {
                    float wx = cx_ + (x / (float)w_ - 0.5f) * h2d_ * aspect, wy = cy_ + (0.5f - y / (float)h_) * h2d_;
                    o->pos.x = snapv(wx - grab_.x);
                    o->pos.y = snapv(wy - grab_.y);
                    markDirty();
                }
            }
        } else if (S.is3d) {
            yaw_ -= dx * 0.006f;
            pitch_ = std::max(-1.4f, std::min(1.45f, pitch_ + dy * 0.006f));
        } else {
            float k = h2d_ / (float)h_;
            cx_ -= dx * k;
            cy_ += dy * k;
        }
    } else if (n == 2) {
        Ptr &a = P[ids[0]], &b = P[ids[1]];
        float mx = (a.lx + b.lx) * 0.5f, my = (a.ly + b.ly) * 0.5f;
        float dist = std::sqrt((a.lx - b.lx) * (a.lx - b.lx) + (a.ly - b.ly) * (a.ly - b.ly));
        if (prevN_ != 2) {
            lastX_ = mx; lastY_ = my; lastDist_ = dist;
            moveAcc_ = 1000.f;  // ya no es un toque
        } else {
            if (lastDist_ > 1.f && dist > 1.f) {
                float k = lastDist_ / dist;
                if (S.is3d) dist_ = std::max(2.f, std::min(120.f, dist_ * k));
                else h2d_ = std::max(100.f, std::min(6000.f, h2d_ * k));
            }
            float dx = mx - lastX_, dy = my - lastY_;
            if (S.is3d) {
                V3 r = norm(cross(ev.fwd, V3{0, 1, 0})), u = cross(r, ev.fwd);
                target_ = target_ - r * (dx * dist_ * 0.0016f) + u * (dy * dist_ * 0.0016f);
            } else {
                float k = h2d_ / (float)h_;
                cx_ -= dx * k;
                cy_ += dy * k;
            }
            lastX_ = mx; lastY_ = my; lastDist_ = dist;
        }
    }
    prevN_ = n;
}

// ---------------------------------------------------------------- frame
void Editor::frame(Renderer* r, int w, int h, float dt) {
    w_ = w; h_ = h;
    play_.ctl.w = w;
    play_.ctl.h = h;
    if (toastT_ > 0) toastT_ -= dt;
    switch (screen_) {
        case Screen::Projects: projectsUI(r); break;
        case Screen::Edit: editFrame(r, dt); break;
        case Screen::Play: playFrame(r, dt); break;
    }
    toastUI();
}

void Editor::toastUI() {
    if (toastT_ <= 0 || toast_.empty()) return;
    float fs = ImGui::GetFontSize();
    ImGui::SetNextWindowPos(ImVec2(w_ * 0.5f, h_ - fs * 2.f), ImGuiCond_Always, ImVec2(0.5f, 1.f));
    ImGui::SetNextWindowBgAlpha(0.85f);
    ImGui::Begin("##toast", nullptr,
                 ImGuiWindowFlags_NoDecoration | ImGuiWindowFlags_NoInputs | ImGuiWindowFlags_AlwaysAutoResize |
                     ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoNav | ImGuiWindowFlags_NoFocusOnAppearing);
    ImGui::TextUnformatted(toast_.c_str());
    ImGui::End();
}

void Editor::projectsUI(Renderer* r) {
    if (r) r->clear(w_, h_, 0.08f, 0.09f, 0.13f);
    float fs = ImGui::GetFontSize();
    ImGui::SetNextWindowPos(ImVec2(0, 0));
    ImGui::SetNextWindowSize(ImVec2((float)w_, (float)h_));
    ImGui::Begin("Proyectos", nullptr,
                 ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoResize |
                     ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoBringToFrontOnFocus);
    ImGui::SetWindowFontScale(1.3f);
    ImGui::TextUnformatted("P-Maker code333 - tus juegos");
    ImGui::SetWindowFontScale(1.f);
    ImGui::TextDisabled("Crea escenas 3D como FPS Creator y programa con bloques como Pocket Code.");
    ImGui::Separator();
    if (projList_.empty()) ImGui::TextDisabled("Todavía no tienes proyectos. Crea uno abajo.");
    std::string del;
    for (auto& n : projList_) {
        ImGui::PushID(n.c_str());
        if (ImGui::Button(n.c_str(), ImVec2(fs * 14, 0))) { std::string copy = n; ImGui::PopID(); openProject(copy); return ImGui::End(); }
        ImGui::SameLine();
        if (ImGui::Button("Borrar")) ImGui::OpenPopup("del");
        if (ImGui::BeginPopup("del")) {
            ImGui::Text("¿Borrar \"%s\" para siempre?", n.c_str());
            if (ImGui::Button("Sí, borrar")) { del = n; ImGui::CloseCurrentPopup(); }
            ImGui::SameLine();
            if (ImGui::Button("Cancelar")) ImGui::CloseCurrentPopup();
            ImGui::EndPopup();
        }
        ImGui::PopID();
    }
    if (!del.empty()) { fs::removeTree(host_.dataDir + "/projects/" + del); listProjects(); }
    ImGui::Separator();
    ImGui::SetNextItemWidth(fs * 14);
    textInput("##pn", "Nombre del proyecto", newName_, "nombre del proyecto");
    if (ImGui::Button("Nuevo vacío")) newProject(newName_, false);
    ImGui::SameLine();
    if (ImGui::Button("Nuevo con la demo")) newProject(newName_, true);
    ImGui::Spacing();
    if (host_.pickFile && ImGui::Button("Importar un juego (.pack)")) host_.pickFile();
    ImGui::TextDisabled("Los juegos que exportaste como .pack se pueden volver a abrir aquí.");
    ImGui::End();
}

void Editor::playFrame(Renderer* r, float dt) {
    play_.frame(r, w_, h_, dt);
    ImGui::SetNextWindowPos(ImVec2(10, 10));
    ImGui::SetNextWindowBgAlpha(0.5f);
    ImGui::Begin("##play", nullptr,
                 ImGuiWindowFlags_NoDecoration | ImGuiWindowFlags_AlwaysAutoResize | ImGuiWindowFlags_NoMove |
                     ImGuiWindowFlags_NoSavedSettings);
    if (ImGui::Button("Detener")) stopPlay();
    ImGui::End();
}

void Editor::editFrame(Renderer* r, float dt) {
    if (!hasScene() && !edit_.proj.scenes.empty()) setScene(0);
    play_.ctl.hud = nullptr;
    edit_.time += dt;
    if (ImGui::IsMouseClicked(0)) dragAcc_ = 0;
    if (ImGui::IsMouseDown(0)) dragAcc_ += std::fabs(ImGui::GetIO().MouseDelta.x) + std::fabs(ImGui::GetIO().MouseDelta.y);
    enforceOneWindow();
    rend_ = r;
    if (layerPreview_ && page_ == Page::Viewport && hasScene() && r) drawCameraLayer(ImGui::GetBackgroundDrawList(), edit_, r, w_, h_);
    if (hasScene() && scene().is3d) ensurePlayer(scene());
    if (page_ == Page::Scenes) { pageScenes(r); return; }
    if (page_ == Page::SceneHome) { pageSceneHome(r); return; }
    if (page_ == Page::Object) { pageObject(r); return; }
    menuBar();
    if (screen_ != Screen::Edit) return;  // el menu pudo cerrar el proyecto o iniciar el juego
    gestures();
    if (r && hasScene()) {
        EditorView ev = view();
        r->render(edit_, w_, h_, &ev);
    }
    if (showHud && hasScene()) {
        Hud preview;
        preview.setup(edit_.proj);
        preview.draw(ImGui::GetBackgroundDrawList(), edit_, r, w_, h_, true);
    }
    objectsWin();
    propsWin();
    worldWin();
    hudWin(r);
    assetsWin();

    if (!selObj()) {
        float fs = ImGui::GetFontSize();
        ImGui::GetBackgroundDrawList()->AddText(ImVec2(fs * 0.6f, h_ - fs * 1.6f), IM_COL32(255, 255, 255, 160),
                                                "Arrastra para girar - dos dedos: zoom y mover - toca un objeto para seleccionarlo");
    }
}

// ---------------------------------------------------------------- menu
void Editor::menuBar() {
    if (!ImGui::BeginMainMenuBar()) return;
    bool doPlay = false, doClose = false;
    if (ImGui::MenuItem("< Escena")) { page_ = Page::SceneHome; ImGui::EndMainMenuBar(); return; }
    if (ImGui::BeginMenu("Proyecto")) {
        if (ImGui::MenuItem("Guardar")) saveProject();
        if (ImGui::MenuItem("Exportar juego (APK, EXE, paquete)...")) showExport_ = true;
        ImGui::Separator();
        if (ImGui::MenuItem("Cerrar proyecto")) doClose = true;
        ImGui::EndMenu();
    }
    if (hasScene() && ImGui::BeginMenu(("Escena: " + scene().name).c_str())) {
        for (int i = 0; i < (int)edit_.proj.scenes.size(); i++) {
            auto& s = edit_.proj.scenes[i];
            if (ImGui::MenuItem((s.name + (s.is3d ? "  (3D)" : "  (2D)")).c_str(), nullptr, i == sceneIdx_)) { setScene(i); break; }
        }
        ImGui::Separator();
        if (ImGui::MenuItem("Nueva escena 3D")) addScene(true);
        if (ImGui::MenuItem("Nueva escena 2D")) addScene(false);
        ImGui::EndMenu();
    }
    if (ImGui::BeginMenu("Añadir")) {
        bool is3d = hasScene() && scene().is3d;
        if (ImGui::MenuItem(is3d ? "Cubo" : "Cuadro / botón")) addObject(Kind::Cube);
        if (is3d) {
            if (ImGui::BeginMenu("Objetos de juego")) {
                static const struct { int id; const char* n; } L[] = {{10, "Enemigo"}, {11, "Monstruo"}, {12, "Arma"}, {13, "Munición"},
                    {14, "Botiquín"}, {15, "Llave"}, {16, "Interruptor"}, {24, "Cartel"}, {17, "Puerta horizontal"}, {18, "Puerta vertical"},
                    {19, "Destruible horizontal"}, {20, "Destruible vertical"}, {21, "Fin de nivel"}, {22, "Teleport inicio"},
                    {23, "Teleport fin"}, {25, "Inicio del jugador"}};
                for (auto& it : L) if (ImGui::MenuItem(it.n)) addPreset(it.id);
                ImGui::EndMenu();
            }
            if (ImGui::MenuItem("Suelo")) addObject(Kind::Floor);
            if (ImGui::MenuItem("Pared")) addObject(Kind::Wall);
            if (ImGui::MenuItem("Item")) addObject(Kind::Item);
            if (ImGui::MenuItem("Luz")) addObject(Kind::Light);
            if (ImGui::BeginMenu("Modelo 3D")) {
                auto models = assetsOf(2);
                if (models.empty()) ImGui::TextDisabled("Importa uno en Archivos");
                for (auto& m : models) if (ImGui::MenuItem(m.c_str())) addObject(Kind::Model, m);
                ImGui::EndMenu();
            }
        }
        ImGui::EndMenu();
    }
    if (ImGui::BeginMenu("Ventanas")) {
        ImGui::MenuItem("Objetos", nullptr, &showObjs);
        ImGui::MenuItem("Propiedades", nullptr, &showProps);
            ImGui::MenuItem("Mundo (cielo y luz)", nullptr, &showWorld);
        ImGui::MenuItem("Botones y arma", nullptr, &showHud);
        ImGui::MenuItem("Archivos", nullptr, &showAssets);
        ImGui::EndMenu();
    }
    if (ImGui::MenuItem("JUGAR")) doPlay = true;
    if (dirty_) { ImGui::TextDisabled(" (sin guardar)"); }
    ImGui::EndMainMenuBar();
    if (doClose) closeProject();
    else if (doPlay) startPlay();
}

// ---------------------------------------------------------------- ventanas
static void placeWindow(float x, float y, float w, float h) {
    ImGui::SetNextWindowPos(ImVec2(x, y), ImGuiCond_FirstUseEver);
    ImGui::SetNextWindowSize(ImVec2(w, h), ImGuiCond_FirstUseEver);
}

void Editor::objectsWin() {
    if (!showObjs || !hasScene()) return;
    float fs = ImGui::GetFontSize(), top = ImGui::GetFrameHeight() + 6.f;
    placeWindow(6, top, fs * 14.f, h_ * 0.5f);
    if (ImGui::Begin("Objetos", &showObjs)) {
        Scene& S = scene();
        for (int i = 0; i < (int)S.objs.size(); i++) {
            const Obj& o = S.objs[i];
            static const char tags[] = {'C', 'S', 'P', 'I', 'M', 'L', 'J'};
            std::string lab = std::string("[") + tags[(int)o.kind] + "] " + o.name + (o.visible ? "" : " (oculto)");
            ImGui::PushID(i);
            if (ImGui::Selectable(lab.c_str(), sel_ == i)) sel_ = i;
            ImGui::PopID();
        }
        if (S.objs.empty()) ImGui::TextDisabled("Escena vacía. Usa el menú Añadir.");
        ImGui::Separator();
        ImGui::SetNextItemWidth(fs * 5.f);
        numField("Rejilla", snap_, 0.f, 2.f);
    }
    ImGui::End();
}

// Miniatura de una imagen (kind 0) o de un modelo 3D (kind 2) en el lugar del cursor.
void Editor::assetThumb(const std::string& name, int kind, float size) {
    ImVec2 p = ImGui::GetCursorScreenPos();
    ImGui::Dummy(ImVec2(size, size));
    ImDrawList* dl = ImGui::GetWindowDrawList();
    dl->AddRectFilled(p, ImVec2(p.x + size, p.y + size), IM_COL32(28, 33, 45, 255), 6.f);
    unsigned id = 0;
    int tw = 1, th = 1;
    if (rend_ && !name.empty()) {
        if (kind == 0) {
            id = rend_->textureId(edit_, name, &tw, &th);
        } else {
            auto a = edit_.proj.assets.find(name);
            if (a != edit_.proj.assets.end()) {
                std::string key = "prev:" + name + ":" + std::to_string(a->second.size());
                if (rend_->hasTexture(key)) {
                    id = rend_->uploadRGBA(key, 0, 0, nullptr);
                } else {
                    std::vector<uint8_t> px;
                    if (modelPreviewRGBA(a->second, edit_.proj.assets, 96, px)) id = rend_->uploadRGBA(key, 96, 96, px.data());
                }
                tw = th = 1;
            }
        }
    }
    if (id) {
        float k = kind == 0 ? std::min(size / tw, size / th) : size;
        float iw = kind == 0 ? tw * k : size, ih = kind == 0 ? th * k : size;
        ImVec2 a(p.x + (size - iw) * 0.5f, p.y + (size - ih) * 0.5f);
        dl->AddImage((ImTextureID)(intptr_t)id, a, ImVec2(a.x + iw, a.y + ih), ImVec2(0, kind == 0 ? 1 : 0), ImVec2(1, kind == 0 ? 0 : 1));
    } else if (!name.empty()) {
        dl->AddText(ImVec2(p.x + size * 0.3f, p.y + size * 0.2f), IM_COL32(150, 160, 180, 255), kind == 0 ? "IMG" : "3D");
    }
}

// Selector con previsualizacion: muestra la miniatura del elegido y, al abrirlo, una lista con miniaturas.
bool Editor::assetCombo(const char* label, std::string& cur, int kind, const char* none) {
    bool ch = false;
    float fs = ImGui::GetFontSize();
    ImGui::PushID(label);
    assetThumb(cur, kind, fs * 2.2f);
    ImGui::SameLine();
    const char* preview = cur.empty() ? (none ? none : "(ninguno)") : cur.c_str();
    ImGui::SetNextItemWidth(ImGui::GetContentRegionAvail().x - ImGui::CalcTextSize(label).x - fs);
    if (ImGui::BeginCombo(label, preview)) {
        if (none && ImGui::Selectable(none, cur.empty())) { cur.clear(); ch = true; }
        for (auto& it : assetsOf(kind)) {
            ImGui::PushID(it.c_str());
            assetThumb(it, kind, fs * 2.4f);
            ImGui::SameLine();
            ImGui::AlignTextToFramePadding();
            if (ImGui::Selectable(shorten(it, 30).c_str(), it == cur, 0, ImVec2(0, fs * 2.4f))) { cur = it; ch = true; }
            ImGui::PopID();
        }
        ImGui::EndCombo();
    }
    ImGui::PopID();
    return ch;
}

bool Editor::fxPanel(Obj& o) {
    FxCfg& f = o.fx;
    bool ch = ImGui::Checkbox("Lanza partículas", &f.on);
    if (!f.on && f.rate <= 0) return ch;
    ImGui::TextDisabled("Elige un efecto y luego cámbialo como quieras:");
    static const char* names[5] = {"Humo", "Fuego", "Chispas", "Nieve", "Energía"};
    for (int i = 0; i < 5; i++) {
        if (i) ImGui::SameLine();
        if (ImGui::SmallButton(names[i])) { fxPreset(f, i); ch = true; }
    }
    if (f.on) {
        ch |= ImGui::ColorEdit3("Color al nacer", f.c0);
        ch |= ImGui::ColorEdit3("Color al desaparecer", f.c1);
        ch |= numField("Cuántas por segundo", f.rate, 1.f, 200.f, "%.0f");
        ch |= numField("Cuánto duran (s)", f.life, 0.1f, 10.f);
        ch |= numField("Tamaño", f.size, 0.02f, 3.f);
        ch |= numField("Crecen o se encogen", f.grow, -1.f, 4.f);
        ch |= numField("Velocidad", f.speed, 0.f, 15.f);
        ch |= numField("Se abren hacia los lados", f.spread, 0.f, 8.f);
        ch |= numField("Caen (+) o suben (-)", f.gravity, -10.f, 20.f);
        ch |= numField("Transparencia inicial", f.a0, 0.05f, 1.f);
        ch |= ImGui::Checkbox("Brillan (fuego, luz)", &f.glow);
        ch |= assetCombo("Imagen propia", f.tex, 0, "(punto suave)");
    }
    return ch;
}

bool Editor::layerPanel(Scene& S) {
    bool ch = false;
    ch |= ImGui::Checkbox("Verla aquí en el editor", &layerPreview_);
    ImGui::TextDisabled("Efecto de pantalla:");
    static const char* names[5] = {"Ninguno", "VHS", "Cámara de video", "Visión nocturna", "Película vieja"};
    for (int i = 0; i < 5; i++) {
        if (ImGui::Button(names[i])) { sfxPreset(S.sfx, i); ch = true; }
        if (i % 2 == 0 && i < 4) ImGui::SameLine();
    }
    ScreenFx& f = S.sfx;
    ImGui::TextDisabled("O crea el tuyo:");
    ch |= numField("Líneas de barrido", f.scan, 0.f, 1.f);
    ch |= numField("Grano / ruido", f.noise, 0.f, 1.f);
    ch |= numField("Bordes oscuros", f.vignette, 0.f, 1.f);
    ch |= numField("Banda de interferencia", f.track, 0.f, 1.f);
    ch |= numField("Cantidad de tinte", f.tint, 0.f, 1.f);
    if (f.tint > 0) ch |= ImGui::ColorEdit3("Color del tinte", f.tintC);
    ch |= ImGui::Checkbox("Visor de cámara (REC)", &f.rec);
    ImGui::SeparatorText("Imágenes fijas en la pantalla");
    int del = -1;
    for (int i = 0; i < (int)S.overlays.size(); i++) {
        Overlay& o = S.overlays[i];
        ImGui::PushID(i);
        ImGui::Text("Imagen %d", i + 1);
        ch |= assetCombo("Imagen", o.tex, 0, "(elige una)");
        ch |= numField("Posición izquierda-derecha", o.x, 0.f, 1.f);
        ch |= numField("Posición arriba-abajo", o.y, 0.f, 1.f);
        ch |= numField("Ancho", o.w, 0.02f, 1.f);
        ch |= numField("Alto", o.h, 0.02f, 1.f);
        ch |= numField("Opacidad", o.alpha, 0.f, 1.f);
        if (ImGui::SmallButton("Quitar esta imagen")) del = i;
        ImGui::Separator();
        ImGui::PopID();
    }
    if (del >= 0) { S.overlays.erase(S.overlays.begin() + del); ch = true; }
    if (ImGui::Button("+ Añadir imagen fija")) { S.overlays.push_back(Overlay()); ch = true; }
    return ch;
}

bool Editor::weaponPanel() {
    Project& P = edit_.proj;
    Weapon& w = P.weapon;
    bool ch = false;
    ch |= ImGui::Checkbox("Arma activada (se puede disparar)", &w.enabled);
    ImGui::TextDisabled("Cómo se ve el arma en tu mano:");
    ch |= assetCombo("Imagen (2D)", w.tex, 0, "(arma básica)");
    ch |= assetCombo("o Modelo 3D", w.model, 2, "(ninguno)");
    ch |= numField("Tamaño", w.scale, 0.1f, 1.2f);
    ch |= numField("Mover a los lados", w.ox, -0.5f, 0.5f);
    ch |= numField("Mover arriba/abajo", w.oy, -0.3f, 0.5f);
    ch |= numField("Segundos entre disparos", w.rate, 0.05f, 2.f);
    ch |= numField("Alcance", w.range, 5.f, 200.f);
    ch |= numField("Daño", w.damage, 0.f, 100.f);
    ImGui::SeparatorText("Proyectil (lo que sale al disparar)");
    int shape = w.projShape;
    ch |= ImGui::RadioButton("Bala", &shape, 0); ImGui::SameLine();
    ch |= ImGui::RadioButton("Imagen", &shape, 1); ImGui::SameLine();
    ch |= ImGui::RadioButton("Modelo 3D", &shape, 2);
    w.projShape = shape;
    if (shape == 1) ch |= assetCombo("Imagen del proyectil", w.projTex, 0, "(elige una)");
    if (shape == 2) ch |= assetCombo("Modelo del proyectil", w.projModel, 2, "(elige uno)");
    if (shape == 0) ch |= ImGui::ColorEdit3("Color de la bala", w.projColor);
    ch |= numField("Tamaño del proyectil", w.projSize, 0.05f, 3.f);
    ch |= numField("Velocidad (0 = instantáneo)", w.projSpeed, 0.f, 120.f, "%.1f");
    return ch;
}

bool Editor::playerPanel(Scene& S, Obj& o) {
    Project& P = edit_.proj;
    bool ch = false;
    ImGui::SeparatorText("Cámara del juego");
    int cm = P.player.cam;
    ch |= ImGui::RadioButton("Primera persona", &cm, kFirstPerson);
    ch |= ImGui::RadioButton("Cámara al hombro", &cm, kShoulder);
    ch |= ImGui::RadioButton("Cámara fija (tercera persona)", &cm, kFixed);
    P.player.cam = cm;
    if (cm == kFixed) {
        ImGui::TextDisabled("La cámara azul se coloca donde tú quieras:");
        ch |= stepper("Cámara X", S.cam.x, 1.f);
        ch |= stepper("Cámara Y", S.cam.y, 1.f);
        ch |= stepper("Cámara Z", S.cam.z, 1.f);
        if (ImGui::Button("Poner la cámara donde estoy mirando")) { S.cam = view().eye; ch = true; }
    }
    ImGui::SeparatorText("Cuerpo y movimiento");
    ch |= assetCombo("Modelo del jugador", P.player.model, 2, "(muñeco básico)");
    ImGui::TextDisabled("Se ve en cámara al hombro y fija. Usa Ancho/Alto de arriba para su tamaño.");
    ch |= numField("Velocidad al caminar", P.player.speed, 0.5f, 20.f, "%.1f");
    ch |= numField("Fuerza de salto", P.player.jump, 0.f, 20.f, "%.1f");
    ImGui::SeparatorText("Arma del jugador");
    ch |= weaponPanel();
    (void)o;
    return ch;
}

bool Editor::aiPanel(Obj& o) {
    AiCfg& a = o.ai;
    bool ch = false;
    int t = a.type == AiType::Shooter ? 1 : a.type == AiType::Melee ? 2 : 0;
    ImGui::TextUnformatted("¿Es un enemigo?");
    ch |= ImGui::RadioButton("No", &t, 0); ImGui::SameLine();
    ch |= ImGui::RadioButton("Enemigo (dispara)", &t, 1); ImGui::SameLine();
    ch |= ImGui::RadioButton("Monstruo (cuerpo a cuerpo)", &t, 2);
    a.type = t == 1 ? AiType::Shooter : t == 2 ? AiType::Melee : AiType::None;
    if (a.type == AiType::None) return ch;
    int sp = a.sprite ? 1 : 0;
    ImGui::TextUnformatted("¿Cómo se ve?");
    ch |= ImGui::RadioButton("Modelo 3D / cubo", &sp, 0); ImGui::SameLine();
    ch |= ImGui::RadioButton("Imágenes planas (sprites)", &sp, 1);
    a.sprite = sp == 1;
    if (a.sprite) ImGui::TextDisabled("La imagen siempre mira al jugador. Pon una imagen distinta para cada acción abajo.");
    else if (o.kind != Kind::Model) {
        ImGui::TextDisabled("Para usar un modelo 3D importado, cambia el objeto a tipo Modelo o añade modelos en las animaciones.");
    }
    ch |= numField("Vida", a.hp, 1.f, 500.f, "%.0f");
    ch |= numField("Velocidad", a.speed, 0.f, 15.f, "%.1f");
    ch |= numField("Distancia a la que te ve", a.sight, 2.f, 80.f, "%.0f");
    ch |= numField("Daño al jugador", a.dmg, 0.f, 100.f, "%.0f");
    ch |= numField("Segundos entre ataques", a.rate, 0.1f, 10.f);
    if (a.type == AiType::Melee) ch |= numField("Alcance del golpe", a.reach, 0.5f, 6.f);
    if (a.type == AiType::Shooter) {
        ImGui::SeparatorText("Proyectil del enemigo");
        ch |= assetCombo("Imagen", a.projTex, 0, "(bola de color)");
        ch |= assetCombo("o Modelo 3D", a.projModel, 2, "(ninguno)");
        ch |= ImGui::ColorEdit3("Color de la bola", a.projColor);
        ch |= numField("Tamaño", a.projSize, 0.05f, 3.f);
        ch |= numField("Velocidad", a.projSpeed, 1.f, 60.f, "%.1f");
    }
    ImGui::SeparatorText("Animaciones");
    static const char* names[kAnimCount] = {"Quieto", "Caminar", "Atacar", "Recibir daño"};
    auto imgs = assetsOf(0), mdls = assetsOf(2);
    for (int k = 0; k < kAnimCount; k++) {
        ImGui::PushID(k);
        AnimState& as = a.anim[k];
        std::string head = std::string(names[k]) + " (" + std::to_string(as.frames.size()) + " cuadros)";
        if (ImGui::CollapsingHeader(head.c_str())) {
            for (size_t i = 0; i < as.frames.size(); i++) {
                ImGui::PushID((int)i);
                bool isM = as.frames[i].size() > 5 && as.frames[i].substr(as.frames[i].size() - 5) == ".fmdl";
                assetThumb(as.frames[i], isM ? 2 : 0, ImGui::GetFontSize() * 2.2f);
                ImGui::SameLine();
                ImGui::AlignTextToFramePadding();
                ImGui::Text("%zu. %s", i + 1, shorten(as.frames[i], 22).c_str());
                ImGui::SameLine();
                if (ImGui::SmallButton("Quitar")) { as.frames.erase(as.frames.begin() + i); ch = true; ImGui::PopID(); break; }
                ImGui::PopID();
            }
            if (ImGui::Button("+ Imagen")) ImGui::OpenPopup("addimg");
            ImGui::SameLine();
            if (ImGui::Button("+ Modelo 3D")) ImGui::OpenPopup("addmdl");
            if (ImGui::BeginPopup("addimg")) {
                if (imgs.empty()) ImGui::TextDisabled("Importa imágenes primero (menú Recursos).");
                for (auto& n : imgs) {
                    ImGui::PushID(n.c_str());
                    assetThumb(n, 0, ImGui::GetFontSize() * 2.4f);
                    ImGui::SameLine();
                    if (ImGui::Selectable(shorten(n, 26).c_str(), false, 0, ImVec2(0, ImGui::GetFontSize() * 2.4f))) { as.frames.push_back(n); ch = true; }
                    ImGui::PopID();
                }
                ImGui::EndPopup();
            }
            if (ImGui::BeginPopup("addmdl")) {
                if (mdls.empty()) ImGui::TextDisabled("Importa un modelo primero (menú Recursos).");
                for (auto& n : mdls) {
                    ImGui::PushID(n.c_str());
                    assetThumb(n, 2, ImGui::GetFontSize() * 2.4f);
                    ImGui::SameLine();
                    if (ImGui::Selectable(shorten(n, 26).c_str(), false, 0, ImVec2(0, ImGui::GetFontSize() * 2.4f))) { as.frames.push_back(n); ch = true; }
                    ImGui::PopID();
                }
                ImGui::EndPopup();
            }
            if (as.frames.size() > 1) ch |= numField("Cuadros por segundo", as.fps, 1.f, 30.f, "%.0f");
            if (!a.sprite) {
                ImGui::TextDisabled("Mini animación del modelo:");
                ch |= numField("Subir y bajar", as.bob, 0.f, 1.f);
                ch |= numField("Balanceo (grados)", as.sway, 0.f, 45.f, "%.0f");
                ch |= numField("Embestida", as.lunge, 0.f, 2.f);
                ch |= numField("Aplastar y estirar", as.squash, 0.f, 2.f);
            }
        }
        ImGui::PopID();
    }
    return ch;
}

void Editor::propsWin() {
    if (!showProps || !hasScene()) return;
    float fs = ImGui::GetFontSize(), top = ImGui::GetFrameHeight() + 6.f;
    placeWindow(w_ - fs * 21.f - 6.f, top, fs * 21.f, h_ * 0.75f);
    if (ImGui::Begin("Propiedades", &showProps)) {
        Scene& S = scene();
        Obj* o = selObj();
        if (!o) {
            ImGui::TextDisabled("Toca un objeto en la escena o en la lista.");
        } else {
            bool ch = false;
            ch |= textInput("##on", "Nombre del objeto", o->name, "nombre");
            const char* kinds[] = {"Cubo", "Suelo", "Pared", "Item", "Modelo", "Luz", "Jugador"};
            ImGui::Text("Tipo: %s", kinds[(int)o->kind]);
            ImGui::SeparatorText("Posición");
            float st = S.is3d ? 0.5f : 10.f;
            ch |= stepper("X", o->pos.x, st);
            ch |= stepper("Y", o->pos.y, st);
            if (S.is3d) ch |= stepper("Z", o->pos.z, 0.5f);
            if (o->kind == Kind::Player) {
                ImGui::SeparatorText("Tamaño y giro");
                ch |= stepper("Ancho", o->scale.x, 0.1f);
                ch |= stepper("Alto", o->scale.y, 0.1f);
                ch |= stepper("Fondo", o->scale.z, 0.1f);
                ch |= stepper("Hacia dónde mira", o->yaw, 15.f);
                ch |= playerPanel(S, *o);
            } else if (o->kind == Kind::Light) {
                ImGui::SeparatorText("Luz");
                ch |= stepper("Alcance", o->scale.x, 1.f);
                ch |= ImGui::ColorEdit3("Color de luz", o->color);
            } else {
                ImGui::SeparatorText("Tamaño y giro");
                ch |= stepper("Ancho", o->scale.x, st);
                ch |= stepper("Alto", o->scale.y, st);
                if (S.is3d) ch |= stepper("Fondo", o->scale.z, 0.5f);
                ch |= stepper(S.is3d ? "Giro" : "Dirección", o->yaw, 15.f);
                ImGui::SeparatorText("Apariencia");
                ch |= ImGui::Checkbox("Sin color (transparente)", &o->noColor);
                if (!o->noColor) ch |= ImGui::ColorEdit3("Color", o->color);
                ch |= assetCombo("Textura", o->tex, 0, "(sin textura)");
                if (ImGui::Button("Dibujar una textura nueva")) openPaint("");
                if (!o->tex.empty()) { ImGui::SameLine(); if (ImGui::Button("Editar esta")) openPaint(o->tex); }
                if (!o->tex.empty()) {
                    bool stretch = !o->texTile;
                    if (ImGui::Checkbox("Estirar la imagen a toda la cara", &stretch)) { o->texTile = !stretch; ch = true; }
                }
                if (o->kind == Kind::Model) ch |= assetCombo("Modelo", o->model, 2, "(cubo)");
                ch |= ImGui::Checkbox("Sólido (se puede chocar)", &o->solid);
                ch |= ImGui::Checkbox("Visible al empezar", &o->visible);
                ch |= ImGui::Checkbox("Gira sobre sí mismo", &o->spin);
                if (S.is3d) {
                    ImGui::SeparatorText("Enemigo o monstruo");
                    ch |= aiPanel(*o);
                }
                ImGui::SeparatorText("Partículas (humo, fuego...)");
                ch |= fxPanel(*o);
            }
            if (ch) markDirty();
            ImGui::Separator();
            if (ImGui::Button("Programar (bloques)")) { page_ = Page::Object; tab_ = 0; }
            ImGui::SameLine();
            if (o->kind != Kind::Player && ImGui::Button("Duplicar")) {
                Obj c = *o;
                c.name = uniqueName(o->name);
                c.pos.x += 1.f;
                S.objs.push_back(c);
                sel_ = (int)S.objs.size() - 1;
                markDirty();
                o = nullptr;
            }
            if (o && o->kind != Kind::Player) {
                ImGui::SameLine();
                if (ImGui::Button("Eliminar")) {
                    S.objs.erase(S.objs.begin() + sel_);
                    sel_ = -1;
                    markDirty();
                    o = nullptr;
                }
            }
            if (o && !S.is3d) {  // en 2D el orden de la lista es el orden de capas
                if (ImGui::Button("Subir capa") && sel_ + 1 < (int)S.objs.size()) { std::swap(S.objs[sel_], S.objs[sel_ + 1]); sel_++; markDirty(); }
                ImGui::SameLine();
                if (ImGui::Button("Bajar capa") && sel_ > 0) { std::swap(S.objs[sel_], S.objs[sel_ - 1]); sel_--; markDirty(); }
            }
        }
    }
    ImGui::End();
}

void Editor::worldWin() {
    if (!showWorld || !hasScene()) return;
    float fs = ImGui::GetFontSize(), top = ImGui::GetFrameHeight() + 6.f;
    placeWindow(w_ - fs * 22.f - 6.f, top, fs * 22.f, h_ * 0.8f);
    if (ImGui::Begin("Mundo", &showWorld)) {
        Scene& S = scene();
        bool ch = false;
        ch |= textInput("##sn", "Nombre de la escena", S.name, "nombre de la escena");
        bool was3d = S.is3d;
        if (ImGui::Checkbox("Escena 3D (si no, es 2D)", &S.is3d)) {
            ch = true;
            if (!S.is3d)  // en 2D no hay jugador
                S.objs.erase(std::remove_if(S.objs.begin(), S.objs.end(), [](const Obj& x) { return x.kind == Kind::Player; }), S.objs.end());
            sel_ = -1;
            if (was3d != S.is3d) resetView();
        }
        if (S.is3d) {
            ImGui::SeparatorText("Cielo");
            ch |= ImGui::ColorEdit3("Arriba", S.skyTop);
            ch |= ImGui::ColorEdit3("Horizonte y niebla", S.skyBot);
            ImGui::SeparatorText("Sol y luz");
            V3 d = norm(S.sunDir);
            float el = std::asin(std::max(-1.f, std::min(1.f, -d.y))), az = std::atan2(-d.x, -d.z);
            bool sc = false;
            sc |= ImGui::SliderAngle("Altura del sol", &el, 5.f, 89.f);
            sc |= ImGui::SliderAngle("Dirección", &az, -180.f, 180.f);
            if (sc) {
                S.sunDir = V3{-std::cos(el) * std::sin(az), -std::sin(el), -std::cos(el) * std::cos(az)};
                ch = true;
            }
            ch |= ImGui::ColorEdit3("Color del sol", S.sun);
            ch |= numField("Luz ambiente", S.ambient, 0.f, 1.f);
            ch |= numField("Niebla", S.fog, 0.f, 0.08f, "%.3f");
            ImGui::SeparatorText("Jugador");
            ImGui::TextWrapped("El jugador es el objeto verde \"Jugador\": tócalo en la escena y arrástralo para moverlo; sus opciones (cámara, arma, proyectil) salen en Propiedades.");
            if (ImGui::Button("Seleccionar al jugador")) { sel_ = playerIndex(S); showProps = true; }
            ImGui::SameLine();
            if (ImGui::Button("Jugador = centro de la vista")) {
                int pi = playerIndex(S);
                if (pi >= 0) { S.objs[pi].pos = V3{target_.x, 0.9f, target_.z}; ch = true; }
            }
        } else {
            ch |= ImGui::ColorEdit3("Fondo", S.skyBot);
        }
        ImGui::SeparatorText("Capa de la cámara (efectos e imágenes fijas)");
        ch |= layerPanel(S);
        ImGui::Separator();
        if (edit_.proj.scenes.size() > 1 && ImGui::Button("Borrar esta escena")) ImGui::OpenPopup("delscene");
        if (ImGui::BeginPopup("delscene")) {
            ImGui::TextUnformatted("¿Borrar la escena y todos sus objetos?");
            if (ImGui::Button("Sí, borrar")) {
                edit_.proj.scenes.erase(edit_.proj.scenes.begin() + sceneIdx_);
                setScene(std::min(sceneIdx_, (int)edit_.proj.scenes.size() - 1));
                ch = true;
                ImGui::CloseCurrentPopup();
            }
            ImGui::SameLine();
            if (ImGui::Button("Cancelar")) ImGui::CloseCurrentPopup();
            ImGui::EndPopup();
        }
        if (ch) markDirty();
    }
    ImGui::End();
}

void Editor::hudWin(Renderer*) {
    if (!showHud) return;
    Project& P = edit_.proj;
    float fs = ImGui::GetFontSize(), top = ImGui::GetFrameHeight() + 6.f;
    placeWindow(w_ - fs * 23.f - 6.f, top, fs * 23.f, h_ * 0.85f);
    if (ImGui::Begin("Botones y arma", &showHud)) {
        bool ch = false;
        ImGui::SeparatorText("Botones en pantalla (escenas 3D)");
        int mode = P.hudDefault ? 0 : (P.hud.empty() ? 2 : 1);
        int nm = mode;
        ImGui::RadioButton("Por defecto: saltar y disparar", &nm, 0);
        ImGui::RadioButton("Personalizados", &nm, 1);
        ImGui::RadioButton("Ninguno (en blanco)", &nm, 2);
        if (nm != mode) {
            if (nm == 0) P.hudDefault = true;
            else if (nm == 1) { P.hudDefault = false; if (P.hud.empty()) P.hud = defaultHud(); }
            else { P.hudDefault = false; P.hud.clear(); }
            ch = true;
        }
        if (!P.hudDefault && !P.hud.empty()) {
            int del = -1;
            for (int i = 0; i < (int)P.hud.size(); i++) {
                HudBtn& b = P.hud[i];
                ImGui::PushID(i);
                if (ImGui::TreeNodeEx(b.label.c_str(), ImGuiTreeNodeFlags_DefaultOpen)) {
                    ch |= textInput("##bl", "Texto del botón", b.label, "texto");
                    int a = (int)b.act;
                    if (ImGui::Combo("Acción", &a, "Nada\0Saltar\0Disparar\0Interactuar\0")) { b.act = (HudAct)a; ch = true; }
                    ch |= numField("Posición X", b.x, 0.f, 1.f);
                    ch |= numField("Posición Y", b.y, 0.f, 1.f);
                    ch |= numField("Tamaño", b.r, 0.03f, 0.25f);
                    ch |= ImGui::ColorEdit3("Color", b.color);
                    if (ImGui::Button("Quitar botón")) del = i;
                    ImGui::TreePop();
                }
                ImGui::PopID();
            }
            if (del >= 0) { P.hud.erase(P.hud.begin() + del); ch = true; }
        }
        if (!P.hudDefault) {
            if (ImGui::Button("+ Añadir botón")) {
                HudBtn b;
                b.label = "Botón";
                b.act = HudAct::Interact;
                P.hud.push_back(b);
                ch = true;
            }
            ImGui::SameLine();
            if (ImGui::Button("Copiar los de por defecto")) { P.hud = defaultHud(); ch = true; }
        }
        ImGui::SeparatorText("Arma del jugador");
        ch |= weaponPanel();
        ImGui::SeparatorText("Pantalla");
        ch |= ImGui::Checkbox("Mostrar variables (contadores)", &P.showVars);
        ImGui::TextDisabled("La vista previa se ve sobre la escena 3D. Los disparos activan el evento \"Al recibir un disparo\".");
        if (ch) markDirty();
    }
    ImGui::End();
}

void Editor::assetsWin() {
    paintWin();
    exportWin();
    if (!showAssets) return;
    float fs = ImGui::GetFontSize(), top = ImGui::GetFrameHeight() + 6.f;
    placeWindow(6, top, fs * 22.f, h_ * 0.7f);
    if (ImGui::Begin("Archivos", &showAssets)) {
        if (ImGui::Button("Importar archivo...")) { if (host_.pickFile) host_.pickFile(); }
        ImGui::SameLine();
        if (ImGui::Button("Dibujar textura")) openPaint("");
        ImGui::TextDisabled("Imágenes png/jpg, audio mp3/wav/flac, modelos obj/glb/gltf/fbx.");
        ImGui::TextDisabled("Para el disparo usa un archivo llamado \"disparo\" (p. ej. disparo.wav).");
        ImGui::Separator();
        size_t total = 0;
        std::string del;
        for (auto& a : edit_.proj.assets) {
            total += a.second.size();
            ImGui::PushID(a.first.c_str());
            bool isImg = !Audio::isAudioFile(a.first) && a.first.size() > 5 && a.first.substr(a.first.size() - 5) != ".fmdl";
            bool isMdl = a.first.size() > 5 && a.first.substr(a.first.size() - 5) == ".fmdl";
            if (isImg || isMdl) { assetThumb(a.first, isMdl ? 2 : 0, fs * 2.2f); ImGui::SameLine(); }
            ImGui::Text("%s  (%.0f KB)", a.first.c_str(), a.second.size() / 1024.0);
            if (isImg) { ImGui::SameLine(); if (ImGui::SmallButton("Dibujar")) openPaint(a.first); }
            if (Audio::isAudioFile(a.first) && audio_) {
                ImGui::SameLine();
                if (ImGui::SmallButton("Probar")) audio_->play(a.first);
            }
            ImGui::SameLine();
            if (ImGui::SmallButton("Borrar")) del = a.first;
            ImGui::PopID();
        }
        if (edit_.proj.assets.empty()) ImGui::TextDisabled("Sin archivos todavía.");
        ImGui::Separator();
        ImGui::Text("Total: %.1f MB", total / (1024.0 * 1024.0));
        if (!del.empty()) {
            edit_.proj.assets.erase(del);
            if (audio_) audio_->setAssets(edit_.proj.assets);
            markDirty();
        }
    }
    ImGui::End();
}

}  // namespace forge
