#include "editor.h"
#include "brand.h"
#include "fsutil.h"
#include "importer.h"
#include "preview.h"
#include "hud.h"
#include "defsounds.h"
#include "pack.h"

#include "imgui.h"
#include "wrapui.h"
#include "misc/cpp/imgui_stdlib.h"

#include <cstring>
#include <thread>
#ifndef _WIN32
#include <pthread.h>
#endif
#include <atomic>
#include <algorithm>
#include <cmath>
#include <cstdio>

static struct { bool on = false; float x = 0, y = 0, w = 0, h = 0; } gDock;
namespace forge {
static bool isVideoName(const std::string& n) {
    std::string l = n;
    for (auto& c : l) c = (char)std::tolower((unsigned char)c);
    for (const char* e : {".mp4", ".3gp", ".webm", ".mkv", ".avi", ".mov", ".m4v", ".mpeg", ".mpg", ".flv", ".wmv", ".ts"})
        if (l.size() > strlen(e) && l.compare(l.size() - strlen(e), strlen(e), e) == 0) return true;
    return false;
}

// ---------------------------------------------------------------- ayudantes de interfaz
namespace {

std::string lower(std::string s) {
    for (auto& c : s) c = (char)tolower((unsigned char)c);
    return s;
}
bool ends(const std::string& s, const char* e) {
    std::string l = lower(s);
    size_t n = strlen(e);
    return l.size() >= n && l.compare(l.size() - n, n, e) == 0;
}
std::string sanitize(const std::string& in) {
    std::string o;
    for (char c : in) {
        if (isalnum((unsigned char)c) || c == '_' || c == '-') o += c;
        else if (c == ' ') o += '_';
    }
    return o;
}

std::string shorten(const std::string& s, size_t n = 22) {
    n *= 4;  // los textos largos continuan en el renglon de abajo; solo se recortan los absurdamente largos
    return s.size() <= n ? s : s.substr(0, n - 1) + "…";
}

bool Combo(const char* label, std::string& cur, const std::vector<std::string>& items, const char* none = nullptr) {
    bool ch = false;
    const char* preview = cur.empty() ? (none ? none : "(ninguno)") : cur.c_str();
    if (wrapui::BeginCombo(label, preview)) {
        if (none && wrapui::Selectable(none, cur.empty())) { cur.clear(); ch = true; }
        for (auto& it : items)
            if (wrapui::Selectable(it.c_str(), it == cur)) { cur = it; ch = true; }
        ImGui::EndCombo();
    }
    return ch;
}

}  // namespace

// [-] valor [+]: los botones dan precision; tocar el numero abre el teclado del telefono.
bool Editor::stepper(const char* label, float& v, float step) {
    bool ch = false;
    ImGui::PushID(label);
    float fs = ImGui::GetFontSize();
    ImGui::AlignTextToFramePadding();
    ImGui::TextUnformatted(label);
    ImGui::SameLine(fs * 4.5f);
    if (wrapui::Button("-")) { v -= step; ch = true; }
    ImGui::SameLine();
    if (host_.prompt) {
        char buf[32];
        snprintf(buf, sizeof buf, "%.2f", v);
        std::string lab = std::string(buf) + "##v";
        if (wrapui::Button(lab.c_str(), ImVec2(fs * 5.f, 0)) && tapped() && !promptActive_) {
            promptNum_ = &v; promptLo_ = -1e9f; promptHi_ = 1e9f;
            numBuf_ = buf;
            promptDst_ = &numBuf_;
            promptActive_ = true;
            host_.prompt(label, numBuf_);
        }
    } else {
        ImGui::SetNextItemWidth(fs * 5.f);
        if (wrapui::DragFloat("##v", &v, step * 0.25f, 0, 0, "%.2f")) ch = true;
    }
    wrapui::Next("+");
    if (wrapui::Button("+")) { v += step; ch = true; }
    ImGui::PopID();
    return ch;
}

// Barra deslizante + boton "123" para escribir el valor con el teclado.
bool Editor::numField(const char* label, float& v, float mn, float mx, const char* fmt) {
    wrapui::head(label);
    ImGui::SetNextItemWidth(host_.prompt ? -ImGui::GetFontSize() * 3.4f : -1.f);
    bool ch = ImGui::SliderFloat(wrapui::hid(label).c_str(), &v, mn, mx, fmt);
    if (host_.prompt) {
        ImGui::PushID(label);
        wrapui::Next("123");
        if (wrapui::Button("123") && tapped() && !promptActive_) {
            char buf[32];
            snprintf(buf, sizeof buf, "%g", v);
            promptNum_ = &v; promptLo_ = mn; promptHi_ = mx;
            numBuf_ = buf;
            promptDst_ = &numBuf_;
            promptActive_ = true;
            host_.prompt(label, numBuf_);
        }
        ImGui::PopID();
    }
    return ch;
}

// Una sola ventana flotante a la vez: al abrir una, las demas se cierran.
void Editor::enforceOneWindow() {
    bool* f[5] = {&showObjs, &showProps, &showWorld, &showHud, &showAssets};
    int newest = -1, first = -1;
    for (int i = 0; i < 5; i++) {
        if (*f[i] && !prevW_[i]) newest = i;
        if (*f[i] && first < 0) first = i;
    }
    int keep = newest >= 0 ? newest : first;
    for (int i = 0; i < 5; i++) if (i != keep) *f[i] = false;
    for (int i = 0; i < 5; i++) prevW_[i] = *f[i];
}

void applyTheme() {
    ImGuiStyle& st = ImGui::GetStyle();
    ImGui::StyleColorsDark(&st);
    st.WindowRounding = 14.f;  st.ChildRounding = 10.f;  st.FrameRounding = 9.f;  st.PopupRounding = 12.f;
    st.GrabRounding = 9.f;     st.ScrollbarRounding = 9.f; st.TabRounding = 9.f;
    st.WindowBorderSize = 0.f; st.FrameBorderSize = 0.f; st.PopupBorderSize = 1.f; st.ChildBorderSize = 0.f;
    st.WindowPadding = ImVec2(14, 12);
    st.FramePadding = ImVec2(12, 10);
    st.ItemSpacing = ImVec2(10, 9);
    st.ItemInnerSpacing = ImVec2(8, 6);
    st.ScrollbarSize = 10.f;
    st.GrabMinSize = 16.f;
    st.WindowTitleAlign = ImVec2(0.5f, 0.5f);
    st.SeparatorTextBorderSize = 2.f;
    st.SeparatorTextPadding = ImVec2(20, 6);
    auto C = [&](ImGuiCol i, float r, float g, float b, float a = 1.f) { st.Colors[i] = ImVec4(r, g, b, a); };
    // grafito azulado con un acento turquesa
    C(ImGuiCol_Text, 0.93f, 0.95f, 0.98f);
    C(ImGuiCol_TextDisabled, 0.52f, 0.58f, 0.67f);
    C(ImGuiCol_WindowBg, 0.075f, 0.085f, 0.115f, 0.97f);
    C(ImGuiCol_ChildBg, 0.10f, 0.115f, 0.15f, 0.9f);
    C(ImGuiCol_PopupBg, 0.095f, 0.11f, 0.145f, 0.98f);
    C(ImGuiCol_Border, 0.22f, 0.26f, 0.33f, 0.8f);
    C(ImGuiCol_FrameBg, 0.13f, 0.15f, 0.20f);
    C(ImGuiCol_FrameBgHovered, 0.17f, 0.20f, 0.27f);
    C(ImGuiCol_FrameBgActive, 0.20f, 0.24f, 0.32f);
    C(ImGuiCol_TitleBg, 0.075f, 0.085f, 0.115f);
    C(ImGuiCol_TitleBgActive, 0.10f, 0.12f, 0.16f);
    C(ImGuiCol_TitleBgCollapsed, 0.075f, 0.085f, 0.115f, 0.8f);
    C(ImGuiCol_MenuBarBg, 0.09f, 0.10f, 0.14f);
    C(ImGuiCol_ScrollbarBg, 0.f, 0.f, 0.f, 0.f);
    C(ImGuiCol_ScrollbarGrab, 0.28f, 0.33f, 0.42f);
    C(ImGuiCol_ScrollbarGrabHovered, 0.36f, 0.42f, 0.52f);
    C(ImGuiCol_ScrollbarGrabActive, 0.18f, 0.78f, 0.68f);
    C(ImGuiCol_CheckMark, 0.18f, 0.85f, 0.74f);
    C(ImGuiCol_SliderGrab, 0.18f, 0.78f, 0.68f);
    C(ImGuiCol_SliderGrabActive, 0.30f, 0.92f, 0.82f);
    C(ImGuiCol_Button, 0.18f, 0.24f, 0.36f);
    C(ImGuiCol_ButtonHovered, 0.24f, 0.34f, 0.50f);
    C(ImGuiCol_ButtonActive, 0.16f, 0.62f, 0.55f);
    C(ImGuiCol_Header, 0.15f, 0.40f, 0.40f, 0.65f);
    C(ImGuiCol_HeaderHovered, 0.17f, 0.50f, 0.48f, 0.80f);
    C(ImGuiCol_HeaderActive, 0.16f, 0.62f, 0.55f);
    C(ImGuiCol_Separator, 0.22f, 0.26f, 0.33f);
    C(ImGuiCol_SeparatorHovered, 0.18f, 0.78f, 0.68f);
    C(ImGuiCol_SeparatorActive, 0.18f, 0.78f, 0.68f);
    C(ImGuiCol_ResizeGrip, 0.18f, 0.78f, 0.68f, 0.25f);
    C(ImGuiCol_ResizeGripHovered, 0.18f, 0.78f, 0.68f, 0.6f);
    C(ImGuiCol_ResizeGripActive, 0.18f, 0.78f, 0.68f, 0.9f);
    C(ImGuiCol_Tab, 0.13f, 0.16f, 0.22f);
    C(ImGuiCol_TabHovered, 0.17f, 0.50f, 0.48f);
    C(ImGuiCol_TabActive, 0.16f, 0.62f, 0.55f);
    C(ImGuiCol_TextSelectedBg, 0.18f, 0.78f, 0.68f, 0.35f);
    C(ImGuiCol_ModalWindowDimBg, 0.f, 0.f, 0.f, 0.55f);
}

// ---------------------------------------------------------------- general
void Editor::init(Audio* audio) {
    audio_ = audio;
    listProjects();
}

void Editor::listProjects() { projList_ = fs::list(host_.dataDir + "/projects", true); }

Obj* Editor::selObj() {
    if (!hasScene() || sel_ < 0 || sel_ >= (int)scene().objs.size()) return nullptr;
    return &scene().objs[sel_];
}

std::string Editor::uniqueName(const std::string& base) {
    Scene& S = scene();
    auto used = [&](const std::string& n) { for (auto& o : S.objs) if (o.name == n) return true; return false; };
    if (!used(base)) return base;
    for (int i = 2;; i++) {
        std::string n = base + "_" + std::to_string(i);
        if (!used(n)) return n;
    }
}

void Editor::resetView() {
    if (!hasScene()) return;
    Scene& S = scene();
    if (S.is3d) { target_ = V3{S.start.x, 0.f, S.start.z}; dist_ = 14.f; yaw_ = 0.6f; pitch_ = 0.55f; }
    else { cx_ = cy_ = 0; h2d_ = kView2DHeight; }
}

void Editor::setScene(int i) {
    if (i < 0 || i >= (int)edit_.proj.scenes.size()) return;
    sceneIdx_ = i;
    sel_ = -1;
    edit_.bindScene(i);
    resetView();
}

std::vector<std::string> Editor::assetsOf(int kind) const {
    std::vector<std::string> v;
    for (auto& a : edit_.proj.assets) {
        bool img = ends(a.first, ".png") || ends(a.first, ".jpg") || ends(a.first, ".jpeg");
        bool snd = Audio::isAudioFile(a.first);
        bool mdl = ends(a.first, ".fmdl");
        if ((kind == 0 && img) || (kind == 1 && snd) || (kind == 2 && mdl)) v.push_back(a.first);
    }
    return v;
}

std::vector<std::string> Editor::soundList() const {
    std::vector<std::string> v = assetsOf(1);
    for (auto& d : defaultSoundNames()) {
        std::string n = d + ".wav";
        if (std::find(v.begin(), v.end(), n) == v.end()) v.push_back(n);
    }
    return v;
}

// Sonidos del juego: cada uno usa el de por defecto o el que tu elijas.
bool Editor::soundPanel() {
    bool ch = false;
    static const char* nm[8] = {"Pasos", "Salto", "Aterrizaje", "Disparo", "Recarga", "Golpe cuerpo a cuerpo", "Recibir daño", "Explosión"};
    ImGui::SeparatorText("Sonidos del juego");
    ImGui::TextWrapped("Ya traen sonidos por defecto (estilo militar). Elige otro audio para cambiarlo.");
    auto list = soundList();
    for (int k = 0; k < 8; k++) {
        std::string& cur = edit_.proj.snd[k];
        std::string lab = std::string(nm[k]) + ": " + (cur.empty() ? "(por defecto)" : cur);
        ImGui::PushID(3000 + k);
        if (ImGui::BeginCombo(("##snd" + std::to_string(k)).c_str(), lab.c_str())) {
            if (wrapui::Selectable("(por defecto)", cur.empty())) { cur.clear(); ch = true; }
            for (auto& a : list) if (wrapui::Selectable(a.c_str(), cur == a)) { cur = a; ch = true; }
            ImGui::EndCombo();
        }
        ImGui::PopID();
    }
    return ch;
}

// Linterna del jugador (para juegos de terror).
bool Editor::flashPanel() {
    bool ch = false;
    PlayerCfg& pc = edit_.proj.player;
    ImGui::SeparatorText("Linterna");
    ch |= wrapui::Checkbox("El jugador tiene linterna (botón LUZ / tecla F)", &pc.flashlight);
    if (!pc.flashlight) return ch;
    ch |= wrapui::Checkbox("Empieza encendida", &pc.flashOnStart);
    ch |= wrapui::Checkbox("Parpadea (terror)", &pc.flashFlicker);
    ch |= numField("Alcance", pc.flashRange, 3.f, 80.f);
    ch |= numField("Apertura (grados)", pc.flashAngle, 8.f, 70.f);
    ch |= numField("Fuerza", pc.flashInt, 0.2f, 4.f);
    ch |= wrapui::ColorEdit3("Color de la luz", pc.flashCol);
    ch |= assetCombo("Dibujo de la luz (opcional)", pc.flashTex, 0, "(sin dibujo: solo el efecto)");
    return ch;
}

// ---------------------------------------------------------------- proyectos
bool Editor::newProject(const std::string& nm, bool demo) {
    std::string n = sanitize(nm);
    if (n.empty()) { toast("Escribe un nombre válido (letras, números, _ o -)"); return false; }
    if (fs::exists(host_.dataDir + "/projects/" + n)) { toast("Ya existe un proyecto con ese nombre"); return false; }
    Project p;
    if (demo) {
        loadDemo(p);
    } else {
        Scene s;
        s.name = "Nivel1";
        Obj fl; fl.kind = Kind::Floor; fl.name = "Suelo"; fl.pos = {0, -0.1f, 0}; fl.scale = {40, 0.2f, 40};
        fl.color[0] = 0.45f; fl.color[1] = 0.62f; fl.color[2] = 0.40f;
        Obj lt; lt.kind = Kind::Light; lt.name = "Luz"; lt.pos = {0, 3, 0}; lt.scale = {12, 1, 1}; lt.solid = false;
        lt.color[0] = 1.f; lt.color[1] = 0.8f; lt.color[2] = 0.6f;
        s.objs = {fl, lt};
        s.start = {0, 0.05f, 6};
        p.scenes.push_back(s);
    }
    p.name = n;
    edit_ = Game();
    edit_.proj = std::move(p);
    name_ = n;
    sceneIdx_ = 0;
    sel_ = -1;
    edit_.bindScene(0);
    resetView();
    assetDirty_.clear();
    for (auto& a : edit_.proj.assets) assetDirty_.insert(a.first);
    if (audio_) audio_->setAssets(edit_.proj.assets);
    screen_ = Screen::Edit;
    page_ = Page::Scenes;
    dirty_ = true;
    saveProject();
    listProjects();
    return true;
}

bool Editor::openProject(const std::string& nm) {
    std::string dir = host_.dataDir + "/projects/" + nm;
    Files files;
    std::vector<uint8_t> b;
    if (!fs::read(dir + "/project.forge", b)) { toast("No se pudo abrir el proyecto"); return false; }
    files["project.forge"] = b;
    for (auto& f : fs::list(dir + "/assets", false)) {
        std::vector<uint8_t> d;
        if (fs::read(dir + "/assets/" + f, d)) files[f] = std::move(d);
    }
    Project p;
    std::string err;
    if (!loadProject(files, p, err)) { toast("Proyecto dañado: " + err); return false; }
    edit_ = Game();
    edit_.proj = std::move(p);
    name_ = nm;
    sceneIdx_ = 0;
    sel_ = -1;
    edit_.bindScene(0);
    resetView();
    assetDirty_.clear();
    dirty_ = false;
    if (audio_) audio_->setAssets(edit_.proj.assets);
    screen_ = Screen::Edit;
    page_ = Page::Scenes;
    return true;
}

bool Editor::saveProject() {
    if (name_.empty()) return false;
    std::string dir = host_.dataDir + "/projects/" + name_;
    if (!fs::mkdirs(dir + "/assets")) { toast("No se pudo crear la carpeta del proyecto"); return false; }
    std::string t = writeProject(edit_.proj);
    if (!fs::write(dir + "/project.forge", (const uint8_t*)t.data(), t.size())) { toast("No se pudo guardar"); return false; }
    for (auto& a : edit_.proj.assets) {
        std::string path = dir + "/assets/" + a.first;
        if (assetDirty_.count(a.first) || !fs::exists(path)) fs::write(path, a.second.data(), a.second.size());
    }
    for (auto& f : fs::list(dir + "/assets", false))  // quitar los borrados
        if (!edit_.proj.assets.count(f)) fs::remove(dir + "/assets/" + f);
    assetDirty_.clear();
    dirty_ = false;
    toast("Guardado");
    return true;
}

void Editor::closeProject() {
    if (dirty_) saveProject();
    if (audio_) audio_->stopMusic();
    screen_ = Screen::Projects;
    page_ = Page::Scenes;
    name_.clear();
    listProjects();
}

bool Editor::buildPack(std::vector<uint8_t>& out) {
    Files f = edit_.proj.assets;
    std::string t = writeProject(edit_.proj);
    f["project.forge"] = std::vector<uint8_t>(t.begin(), t.end());
    return packWrite(f, out);
}

bool Editor::buildExe(std::vector<uint8_t>& out, std::string& err) {
    std::vector<uint8_t> rt, pk;
    if (!host_.loadRuntime || !host_.loadRuntime(rt)) {
        err = "Esta app no incluye el runtime de Windows: compílala con GitHub Actions";
        return false;
    }
    buildPack(pk);
    if (!forge::exportExe(rt, pk, out)) { err = "El runtime incluido no es un .exe válido"; return false; }
    return true;
}

void Editor::doExportExe() {
    if (dirty_) saveProject();
    std::vector<uint8_t> out;
    std::string err;
    if (!buildExe(out, err)) { toast(err); return; }
    std::string dir = host_.dataDir + "/export";
    fs::mkdirs(dir);
    std::string exeBase = exportSlug(edit_.proj.exportCfg.exeName.empty() ? name_ : edit_.proj.exportCfg.exeName);
    std::string path = dir + "/" + exeBase + ".exe";
    if (!fs::write(path, out.data(), out.size())) { toast("No se pudo escribir el .exe"); return; }
    if (host_.saveOut) host_.saveOut(exeBase + ".exe", path);
    toast("Elige dónde guardar el .exe");
}

void Editor::doExportPack() {
    if (dirty_) saveProject();
    std::vector<uint8_t> out;
    buildPack(out);
    std::string dir = host_.dataDir + "/export";
    fs::mkdirs(dir);
    std::string path = dir + "/" + name_ + ".pack";
    if (!fs::write(path, out.data(), out.size())) { toast("No se pudo escribir el paquete"); return; }
    if (host_.saveOut) host_.saveOut(name_ + ".pack", path);
    toast("Elige dónde guardar el paquete (.pack)");
}

// Importa un proyecto exportado (.pack): lo guarda como un proyecto nuevo con nombre libre.
bool Editor::importPack(const std::string& fileName, const std::vector<uint8_t>& data) {
    Files files;
    if (!packRead(data.data(), data.size(), files) || !files.count("project.forge")) {
        toast("Ese archivo no es un paquete de P-Maker (.pack)");
        return false;
    }
    Project test;
    std::string err;
    if (!loadProject(files, test, err)) { toast("El paquete está dañado: " + err); return false; }
    std::string base = fileName;
    size_t sl = base.find_last_of("/\\");
    if (sl != std::string::npos) base = base.substr(sl + 1);
    size_t dot = base.find_last_of('.');
    if (dot != std::string::npos) base = base.substr(0, dot);
    base = sanitize(base);
    if (base.empty()) base = "importado";
    std::string n = base;
    for (int i = 2; fs::exists(host_.dataDir + "/projects/" + n); i++) n = base + "_" + std::to_string(i);
    std::string dir = host_.dataDir + "/projects/" + n;
    fs::mkdirs(dir + "/assets");
    const auto& pf = files["project.forge"];
    if (!fs::write(dir + "/project.forge", pf.data(), pf.size())) { toast("No se pudo guardar el proyecto"); return false; }
    for (auto& f : files)
        if (f.first != "project.forge") fs::write(dir + "/assets/" + f.first, f.second.data(), f.second.size());
    listProjects();
    toast("Proyecto importado: " + n);
    return true;
}

void Editor::onFile(const std::string& rawName, std::vector<uint8_t> data) {
    if (!rawName.empty() && rawName[0] == '\x01') {  // avisos del selector de archivos
        if (rawName.compare(1, 5, "START") == 0) { reading_ = true; readingT_ = 0.f; }
        else { reading_ = false; toast(std::string(data.begin(), data.end())); }
        return;
    }
    reading_ = false;
    if (ends(rawName, ".pack")) { importPack(rawName, data); return; }
    if (screen_ != Screen::Edit) { toast("Abre un proyecto para importar archivos"); return; }
    std::string name = rawName;
    size_t sl = name.find_last_of("/\\");
    if (sl != std::string::npos) name = name.substr(sl + 1);
    for (auto& c : name) if (c == ' ') c = '_';
    Files& A = edit_.proj.assets;
    if (ends(name, ".png") || ends(name, ".jpg") || ends(name, ".jpeg")) {
        A[name] = std::move(data);
        assetDirty_.insert(name);
        toast("Imagen importada: " + name);
        if (pendingNewObj_ && hasScene()) {
            pendingNewObj_ = false;
            addObject(Kind::Cube);
            if (Obj* n = selObj()) {
                n->tex = name;
                n->color[0] = n->color[1] = n->color[2] = 1.f;
                n->name = uniqueName(name.substr(0, name.find_last_of('.')));
            }
        } else if (page_ == Page::Object && tab_ == 1) {
            if (Obj* n = selObj()) n->looks.push_back(name);
        }
    } else if (Audio::isAudioFile(name)) {
        A[name] = std::move(data);
        assetDirty_.insert(name);
        if (audio_) audio_->setAssets(A);
        toast("Audio importado: " + name);
        if (page_ == Page::Object && tab_ == 2) {
            if (Obj* n = selObj()) n->sounds.push_back(name);
        }
    } else if (isVideoName(name)) {
        A[name] = std::move(data);
        assetDirty_.insert(name);
        toast("Video importado: " + name + " (ponlo en un objeto: Propiedades → Video)");
        if (pendingNewObj_ && hasScene()) {
            pendingNewObj_ = false;
            addObject(Kind::Cube);
            if (Obj* n = selObj()) {
                n->video = name; n->videoAuto = true; n->noColor = false;
                n->color[0] = n->color[1] = n->color[2] = 1.f;
                if (!scene().is3d) n->scale = V3{320, 180, 1};
                n->name = uniqueName("Video");
            }
        }
    } else if (ends(name, ".blend") || ends(name, ".blend1")) {
        pendingNewModel_ = false;
        toast("Los .blend no se pueden leer directo. En Blender: Archivo > Exportar > glTF 2.0 (.glb) y elige ese archivo.");
        return;
    } else if (ends(name, ".rar") || ends(name, ".7z")) {
        pendingNewModel_ = false;
        toast("Los .rar y .7z no se pueden abrir aquí. Conviértelo a .zip (o descomprímelo y elige el .glb/.obj).");
        return;
    } else if (animImportPending_ && (ends(name, ".glb") || ends(name, ".gltf") || ends(name, ".fbx"))) {
        animImportPending_ = false;
        int added = 0;
        std::string err;
        if (animRig_.bones.empty()) {  // sin esqueleto todavía: si el archivo trae modelo y esqueleto, se crea
            if (!importAnimations(name, data, animRig_.model, animRig_, added, err)) { toast("No se pudo: " + err); return; }
            animFixSizes();
        } else if (!importAnimations(name, data, animRig_.model, animRig_, added, err)) { toast("No se pudo: " + err); return; }
        animFixSizes();
        toast("Animaciones importadas: " + std::to_string(added));
        return;
    } else if (isModelFile(name) || ends(name, ".zip")) {
        if (imp_) { toast("Espera: ya se está importando otro archivo"); return; }
        startModelImport(name, std::move(data));
        return;
    } else {
        toast("Formato no compatible. Usa png, jpg, mp3, wav, flac, obj, glb, gltf o fbx");
        return;
    }
    markDirty();
}

// ---------------------------------------------------------------- objetos y escenas
void Editor::addObject(Kind k, const std::string& modelName) {
    if (!hasScene()) return;
    Scene& S = scene();
    Obj o;
    o.kind = k;
    float gx = std::round(target_.x), gz = std::round(target_.z);
    V3 at = S.is3d ? V3{gx, 0, gz} : V3{std::round(cx_), std::round(cy_), 0};
    std::string base = "Objeto";
    switch (k) {
        case Kind::Cube:
            base = S.is3d ? "Cubo" : "Objeto";
            o.pos = S.is3d ? V3{at.x, 0.5f, at.z} : V3{at.x, at.y, 0};
            o.scale = S.is3d ? V3{1, 1, 1} : V3{200, 200, 1};
            if (!S.is3d) { o.color[0] = o.color[1] = o.color[2] = 1.f; o.noColor = true; o.solid = false; o.yaw = 90; }
            break;
        case Kind::Floor:
            base = "Suelo"; o.pos = {at.x, -0.1f, at.z}; o.scale = {10, 0.2f, 10}; o.texTile = true;
            o.color[0] = 0.45f; o.color[1] = 0.62f; o.color[2] = 0.40f;
            break;
        case Kind::Wall:
            base = "Pared"; o.pos = {at.x, 1.5f, at.z}; o.scale = {4, 3, 0.5f};
            o.color[0] = o.color[1] = 0.8f; o.color[2] = 0.86f;
            break;
        case Kind::Item:
            base = "Item"; o.pos = {at.x, 1.f, at.z}; o.scale = {0.5f, 0.5f, 0.5f}; o.solid = false; o.spin = true;
            o.color[0] = 1.f; o.color[1] = 0.8f; o.color[2] = 0.1f;
            break;
        case Kind::Light:
            base = "Luz"; o.pos = {at.x, 3.f, at.z}; o.scale = {12, 1, 1}; o.solid = false;
            o.color[0] = 1.f; o.color[1] = 0.8f; o.color[2] = 0.6f;
            break;
        case Kind::Model:
            base = "Modelo"; o.pos = {at.x, 1.f, at.z}; o.scale = {2, 2, 2}; o.model = modelName;
            break;
        case Kind::Player: return;
    }
    o.name = uniqueName(base);
    S.objs.push_back(o);
    sel_ = (int)S.objs.size() - 1;
    markDirty();
}

void Editor::addScene(bool is3d) {
    Scene s;
    s.is3d = is3d;
    int n = (int)edit_.proj.scenes.size() + 1;
    auto taken = [&](const std::string& nm) { for (auto& x : edit_.proj.scenes) if (x.name == nm) return true; return false; };
    std::string base = is3d ? "Nivel" : "Menu";
    std::string nm = base + std::to_string(n);
    for (int i = n; taken(nm); i++) nm = base + std::to_string(i + 1);
    s.name = nm;
    if (is3d) {
        Obj fl; fl.kind = Kind::Floor; fl.name = "Suelo"; fl.pos = {0, -0.1f, 0}; fl.scale = {40, 0.2f, 40};
        fl.color[0] = 0.45f; fl.color[1] = 0.62f; fl.color[2] = 0.40f;
        s.objs.push_back(fl);
        s.start = {0, 0.05f, 6};
        for (const char* g : {"vida", "municion", "puntos", "llave"})
            if (std::find(edit_.proj.globalVars.begin(), edit_.proj.globalVars.end(), g) == edit_.proj.globalVars.end())
                edit_.proj.globalVars.push_back(g);
        auto mk = [](Op op, const char* t, const char* a, const char* b2, const char* c) {
            Block b; b.op = op; b.t = t; b.f[0] = a; b.f[1] = b2; b.f[2] = c; return b;
        };
        s.objs[0].blocks = {mk(Op::WhenStart, "", "", "", ""), mk(Op::ShowVar, "vida", "-420", "440", ""),
                            mk(Op::ShowVar, "municion", "420", "440", ""),
                            mk(Op::WhenTrue, "", "\"vida\" <= 0", "", ""), mk(Op::Say, "", "Has muerto", "", ""),
                            mk(Op::SetVar, "vida", "100", "", ""), mk(Op::TeleportPlayer, "", "0", "0.05", "6")};
    } else {
        s.skyTop[0] = 0.10f; s.skyTop[1] = 0.12f; s.skyTop[2] = 0.25f;
        s.skyBot[0] = 0.20f; s.skyBot[1] = 0.25f; s.skyBot[2] = 0.45f;
        Obj bg; bg.name = "Fondo"; bg.bg = true; bg.solid = false; bg.layer = -1000; bg.yaw = 90;
        bg.color[0] = 0.20f; bg.color[1] = 0.25f; bg.color[2] = 0.45f;
        s.objs.push_back(bg);
    }
    ensurePlayer(s);
    edit_.proj.scenes.push_back(s);
    setScene((int)edit_.proj.scenes.size() - 1);
    markDirty();
}

void Editor::startPlay() {
    if (edit_.proj.scenes.empty()) return;
    if (dirty_) saveProject();
    play_.audio = audio_;
    play_.showButtons = true;
    play_.onVibrate = host_.vibrate;
    play_.onSpeak = host_.speak;
    play_.onFlash = host_.flash;
    play_.start(edit_.proj);  // copia: el juego no altera lo que estas editando
    screen_ = Screen::Play;
}

void Editor::stopPlay() {
    if (audio_) { audio_->stopMusic(); audio_->setAssets(edit_.proj.assets); }
    play_.ctl.hud = nullptr;
    play_.ctl.reset();
    screen_ = Screen::Edit;
}

// ---------------------------------------------------------------- camara y seleccion
EditorView Editor::view() const {
    EditorView ev;
    ev.sel = sel_;
    ev.target = target_;
    ev.cx = cx_; ev.cy = cy_; ev.h2d = h2d_;
    V3 dir{std::sin(yaw_) * std::cos(pitch_), std::sin(pitch_), std::cos(yaw_) * std::cos(pitch_)};
    ev.eye = target_ + dir * dist_;
    ev.fwd = norm(target_ - ev.eye);
    return ev;
}

void Editor::rayAt(float x, float y, const EditorView& ev, V3& o, V3& d) const {
    float aspect = h_ > 0 ? (float)w_ / (float)h_ : 1.f;
    float ty = std::tan(1.2217f * 0.5f), tx = ty * aspect;
    float nx = (x / (float)w_) * 2.f - 1.f, ny = 1.f - (y / (float)h_) * 2.f;
    V3 r = norm(cross(ev.fwd, V3{0, 1, 0})), u = cross(r, ev.fwd);
    o = ev.eye;
    d = norm(ev.fwd + r * (nx * tx) + u * (ny * ty));
}

int Editor::pick(float x, float y, const EditorView& ev) {
    if (!hasScene()) return -1;
    Scene& S = scene();
    if (S.is3d) {
        V3 o, d;
        rayAt(x, y, ev, o, d);
        float best = 1e9f;
        int hit = -1;
        for (int i = 0; i < (int)S.objs.size(); i++) {
            const Obj& ob = S.objs[i];
            if (!ob.visible || !ob.alive || ob.locked) continue;
            V3 half = ob.kind == Kind::Light ? V3{0.25f, 0.25f, 0.25f} : ob.scale * 0.5f;
            float t;
            if (ob.kind == Kind::Floor && ob.tn >= 2) { if (rayTerrain(ob, o, d, 400.f, t) && t < best) { best = t; hit = i; } continue; }
            if (rayBoxYaw(o, d, ob.pos, half, ob.kind == Kind::Light ? 0.f : ob.yaw, t) && t < best) { best = t; hit = i; }
        }
        return hit;
    }
    float aspect = h_ > 0 ? (float)w_ / (float)h_ : 1.f;
    float wx = cx_ + (x / (float)w_ - 0.5f) * h2d_ * aspect, wy = cy_ + (0.5f - y / (float)h_) * h2d_;
    for (int i = (int)S.objs.size() - 1; i >= 0; i--) {
        const Obj& ob = S.objs[i];
        if (!ob.visible || ob.locked) continue;
        float ra = -(ob.yaw - 90.f) * 0.0174532925f, cs = std::cos(ra), sn = std::sin(ra);
        float ddx = wx - ob.pos.x, ddy = wy - ob.pos.y;
        if (std::fabs(cs * ddx + sn * ddy) <= ob.scale.x * 0.5f && std::fabs(-sn * ddx + cs * ddy) <= ob.scale.y * 0.5f) return i;
    }
    return -1;
}

// Gestos sobre la vista: 1 dedo gira la camara (o arrastra el objeto seleccionado),
// 2 dedos acercan y desplazan, toque corto selecciona.
void Editor::gestures() {
    ImGuiIO& io = ImGui::GetIO();
    auto& P = play_.ctl.p;
    int ids[2], n = 0;
    for (int i = 0; i < 10 && n < 2; i++) if (P[i].down) ids[n++] = i;
    int total = play_.ctl.downCount();

    if (total == 0) {
        if (prevN_ == 1 && gestOk_ && moveAcc_ < 20.f && hasScene()) sel_ = pick(lastX_, lastY_, view());
        prevN_ = 0;
        dragObj_ = false;
        return;
    }
    if (prevN_ == 0) { gestOk_ = !io.WantCaptureMouse; moveAcc_ = 0; dragObj_ = false; }
    if (!gestOk_ || !hasScene()) { prevN_ = n; return; }

    EditorView ev = view();
    Scene& S = scene();
    float aspect = h_ > 0 ? (float)w_ / (float)h_ : 1.f;

    if (n == 1) {
        float x = P[ids[0]].lx, y = P[ids[0]].ly;
        if (terrainPaint_ && S.is3d) {  // esculpir el terreno seleccionado
            Obj* tr = selObj();
            if (tr && tr->kind == Kind::Floor && tr->tn >= 2) {
                V3 ro, rd;
                rayAt(x, y, ev, ro, rd);
                float tt;
                if (rayTerrain(*tr, ro, rd, 400.f, tt)) {
                    V3 hit = ro + rd * tt;
                    if (prevN_ != 1) terrTarget_ = terrainSurface(*tr, hit.x, hit.z) - (tr->pos.y + tr->scale.y * 0.5f);
                    terrainBrush(*tr, hit.x, hit.z, terrRadius_, terrStrength_ * std::min(0.05f, io.DeltaTime), terrMode_, terrTarget_);
                    markDirty();
                }
                lastX_ = x; lastY_ = y;
                moveAcc_ = 1000.f;
                prevN_ = 1;
                return;
            }
        }
        bool gOn = gndPaint_ && S.is3d && gndSel_ >= 0 && gndSel_ < (int)S.gnd.size();
        bool vOn = vegPaint_ && S.is3d && vegSel_ >= 0 && vegSel_ < (int)S.veg.size();
        if (gOn || vOn) {  // pintar vegetacion o texturas del suelo
            V3 ro, rd, hit;
            rayAt(x, y, ev, ro, rd);
            if (groundHit(S, ro, rd, hit)) {
                float dx = hit.x - vegLastX_, dz = hit.z - vegLastZ_, rr = gOn ? gndRadius_ : vegRadius_;
                if (prevN_ != 1 || dx * dx + dz * dz > rr * rr * 0.12f) { if (gOn) gndStamp(S, hit); else vegStamp(S, hit); vegLastX_ = hit.x; vegLastZ_ = hit.z; }
            }
            if (prevN_ != 1) { vegLastX_ = 1e9f; }
            lastX_ = x; lastY_ = y;
            moveAcc_ = 1000.f;
            prevN_ = 1;
            return;
        }
        if (prevN_ != 1) {
            lastX_ = x; lastY_ = y;
            Obj* o = selObj();
            if (prevN_ == 0 && o && pick(x, y, ev) == sel_) {  // el dedo empieza sobre el objeto seleccionado
                dragObj_ = true;
                if (S.is3d) {
                    V3 ro, rd;
                    rayAt(x, y, ev, ro, rd);
                    if (std::fabs(rd.y) > 1e-4f) {
                        float t = (o->pos.y - ro.y) / rd.y;
                        V3 hit = ro + rd * t;
                        grab_ = V3{hit.x - o->pos.x, 0, hit.z - o->pos.z};
                    } else grab_ = V3();
                } else {
                    float wx = cx_ + (x / (float)w_ - 0.5f) * h2d_ * aspect, wy = cy_ + (0.5f - y / (float)h_) * h2d_;
                    grab_ = V3{wx - o->pos.x, wy - o->pos.y, 0};
                }
            }
        }
        float dx = x - lastX_, dy = y - lastY_;
        lastX_ = x; lastY_ = y;
        moveAcc_ += std::fabs(dx) + std::fabs(dy);
        float sn = S.is3d ? snap_ : (snap_ > 0.f ? snap_ * 40.f : 0.f);
        auto snapv = [&](float v) { return sn > 0.f ? std::round(v / sn) * sn : v; };
        if (dragObj_) {
            Obj* o = selObj();
            if (o && moveAcc_ > 14.f) {
                if (S.is3d) {
                    V3 ro, rd;
                    rayAt(x, y, ev, ro, rd);
                    if (std::fabs(rd.y) > 1e-4f) {
                        float t = (o->pos.y - ro.y) / rd.y;
                        if (t > 0) {
                            V3 hit = ro + rd * t;
                            o->pos.x = snapv(hit.x - grab_.x);
                            o->pos.z = snapv(hit.z - grab_.z);
                            markDirty();
                        }
                    }
                } else {
                    float wx = cx_ + (x / (float)w_ - 0.5f) * h2d_ * aspect, wy = cy_ + (0.5f - y / (float)h_) * h2d_;
                    o->pos.x = snapv(wx - grab_.x);
                    o->pos.y = snapv(wy - grab_.y);
                    markDirty();
                }
            }
        } else if (S.is3d) {
            yaw_ -= dx * 0.006f;
            pitch_ = std::max(-1.4f, std::min(1.45f, pitch_ + dy * 0.006f));
        } else {
            float k = h2d_ / (float)h_;
            cx_ -= dx * k;
            cy_ += dy * k;
        }
    } else if (n == 2) {
        Ptr &a = P[ids[0]], &b = P[ids[1]];
        float mx = (a.lx + b.lx) * 0.5f, my = (a.ly + b.ly) * 0.5f;
        float dist = std::sqrt((a.lx - b.lx) * (a.lx - b.lx) + (a.ly - b.ly) * (a.ly - b.ly));
        if (prevN_ != 2) {
            lastX_ = mx; lastY_ = my; lastDist_ = dist;
            moveAcc_ = 1000.f;  // ya no es un toque
        } else {
            if (lastDist_ > 1.f && dist > 1.f) {
                float k = lastDist_ / dist;
                if (S.is3d) dist_ = std::max(2.f, std::min(120.f, dist_ * k));
                else h2d_ = std::max(100.f, std::min(6000.f, h2d_ * k));
            }
            float dx = mx - lastX_, dy = my - lastY_;
            if (S.is3d) {
                V3 r = norm(cross(ev.fwd, V3{0, 1, 0})), u = cross(r, ev.fwd);
                target_ = target_ - r * (dx * dist_ * 0.0016f) + u * (dy * dist_ * 0.0016f);
            } else {
                float k = h2d_ / (float)h_;
                cx_ -= dx * k;
                cy_ += dy * k;
            }
            lastX_ = mx; lastY_ = my; lastDist_ = dist;
        }
    }
    prevN_ = n;
}

// ---------------------------------------------------------------- frame
void Editor::frame(Renderer* r, int w, int h, float dt) {
    w_ = w; h_ = h;
    play_.ctl.w = w;
    play_.ctl.h = h;
    if (toastT_ > 0) toastT_ -= dt;
    switch (screen_) {
        case Screen::Projects: projectsUI(r); break;
        case Screen::Edit: editFrame(r, dt); break;
        case Screen::Play: playFrame(r, dt); break;
    }
    if (screen_ != Screen::Projects) pollImport();  // en todas las páginas, no solo en el editor 3D
    importOverlay();
    toastUI();
}

// ---------------------------------------------------------------- importar modelos (otro hilo + pantalla de carga)
struct ImpJob {
    std::string name, model, err, rigText;
    std::vector<uint8_t> data;
    Files out;
    Rig rg;
    int added = 0;
    bool ok = false, hasRig = false;
    std::atomic<bool> done{false};
};

void Editor::startModelImport(const std::string& name, std::vector<uint8_t> data) {
    auto job = std::make_shared<ImpJob>();
    job->name = name;
    job->data = std::move(data);
    imp_ = job;
    gImportProgress = 0.f;
    auto work = [](std::shared_ptr<ImpJob> job) {
        try {
            const std::string& nm = job->name;
            job->ok = ends(nm, ".zip") ? importModelZip(job->data, job->out, job->model, job->err)
                                       : importModel(nm, job->data, job->out, job->model, job->err);
            if (job->ok && (ends(nm, ".glb") || ends(nm, ".gltf") || ends(nm, ".fbx"))) {
                std::string e2;
                job->hasRig = importAnimations(nm, job->data, job->model, job->rg, job->added, e2) && job->added > 0;
            }
        } catch (const std::exception& ex) {
            job->ok = false;
            job->err = std::string("falta memoria o el archivo es demasiado pesado (") + ex.what() + ")";
        } catch (...) {
            job->ok = false;
            job->err = "falta memoria o el archivo es demasiado pesado";
        }
        gImportProgress = 1.f;
        job->done = true;
    };
#ifdef _WIN32
    std::thread(work, job).detach();
#else
    {   // hilo con pila grande: los modelos pesados necesitan mas pila que el hilo normal
        struct Arg { std::shared_ptr<ImpJob> job; void (*fn)(std::shared_ptr<ImpJob>); };
        Arg* arg = new Arg{job, +work};
        pthread_attr_t at;
        pthread_attr_init(&at);
        pthread_attr_setstacksize(&at, 64u * 1024 * 1024);
        pthread_attr_setdetachstate(&at, PTHREAD_CREATE_DETACHED);
        pthread_t th;
        int rc = pthread_create(&th, &at, [](void* p) -> void* {
            Arg* a = (Arg*)p;
            a->fn(a->job);
            delete a;
            return nullptr;
        }, arg);
        pthread_attr_destroy(&at);
        if (rc != 0) { delete arg; std::thread(work, job).detach(); }
    }
#endif
}

void Editor::pollImport() {
    if (!imp_ || !imp_->done) return;
    std::shared_ptr<ImpJob> job = imp_;
    imp_.reset();
    if (!job->ok) { toast("No se pudo importar: " + job->err); return; }
    Files& A = edit_.proj.assets;
    std::string model = job->model;
    if (A.count(model)) {  // nombre ya usado: se busca uno libre
        std::string base = model.substr(0, model.size() - 5);
        std::string nn;
        for (int i = 2;; i++) { nn = base + "_" + std::to_string(i) + ".fmdl"; if (!A.count(nn)) break; }
        job->out[nn] = std::move(job->out[model]);
        job->out.erase(model);
        model = nn;
    }
    for (auto& kv : job->out) {
        const std::string& key = kv.first == job->model ? model : kv.first;
        A[key] = std::move(kv.second);
        assetDirty_.insert(key);
    }
    if (job->hasRig) {
        job->rg.model = model;
        std::string rn = model.substr(0, model.size() - 5) + ".fanim", txt = rigWrite(job->rg);
        A[rn] = std::vector<uint8_t>(txt.begin(), txt.end());
        assetDirty_.insert(rn);
        toast("Modelo importado con " + std::to_string(job->added) + " animaciones: " + rn);
    }
    if (pendingNewModel_ && hasScene() && scene().is3d) {
        pendingNewModel_ = false;
        addObject(Kind::Model, model);
        toast("Modelo importado y añadido: " + model);
    } else if (!job->hasRig) {
        toast("Modelo importado: " + model + " (Objeto nuevo > Modelo 3D)");
    }
    markDirty();
}

void Editor::importOverlay() {
    if (reading_) readingT_ += ImGui::GetIO().DeltaTime;
    if (reading_ && readingT_ > 180.f) reading_ = false;
    if (!imp_ && !reading_) return;
    float fs = ImGui::GetFontSize();
    ImGui::GetForegroundDrawList()->AddRectFilled(ImVec2(0, 0), ImVec2((float)w_, (float)h_), IM_COL32(0, 0, 0, 170));
    ImGui::SetNextWindowPos(ImVec2(w_ * 0.5f, h_ * 0.5f), ImGuiCond_Always, ImVec2(0.5f, 0.5f));
    ImGui::SetNextWindowSize(ImVec2(std::min((float)w_ * 0.9f, fs * 26.f), 0));
    ImGui::SetNextWindowFocus();
    ImGui::Begin("##importando", nullptr, ImGuiWindowFlags_NoDecoration | ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoSavedSettings);
    float p = imp_ ? std::max(0.02f, std::min(1.f, gImportProgress.load())) : 0.f;
    if (!imp_) {
        ImGui::TextUnformatted("Leyendo el archivo…");
        float t = (float)std::fmod(ImGui::GetTime() * 0.6, 1.0);
        ImGui::ProgressBar(t, ImVec2(-1, fs * 2.2f), "");
        ImGui::TextDisabled("Los archivos grandes tardan unos segundos.");
        ImGui::End();
        return;
    }
    ImGui::Text("Importando %s…", shorten(imp_->name, 28).c_str());
    ImGui::Spacing();
    char buf[32];
    snprintf(buf, sizeof buf, "%d%%", (int)(p * 100.f));
    ImGui::ProgressBar(p, ImVec2(-1, fs * 2.2f), buf);
    ImGui::TextDisabled("Los modelos pesados tardan un poco. No cierres la app.");
    ImGui::End();
}

void Editor::toastUI() {
    if (toastT_ <= 0 || toast_.empty()) return;
    float fs = ImGui::GetFontSize();
    ImGui::SetNextWindowPos(ImVec2(w_ * 0.5f, h_ - fs * 2.f), ImGuiCond_Always, ImVec2(0.5f, 1.f));
    ImGui::SetNextWindowBgAlpha(0.85f);
    ImGui::Begin("##toast", nullptr,
                 ImGuiWindowFlags_NoDecoration | ImGuiWindowFlags_NoInputs | ImGuiWindowFlags_AlwaysAutoResize |
                     ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoNav | ImGuiWindowFlags_NoFocusOnAppearing);
    ImGui::TextUnformatted(toast_.c_str());
    ImGui::End();
}

void Editor::projectsUI(Renderer* r) {
    if (r) r->clear(w_, h_, 0.08f, 0.09f, 0.13f);
    float fs = ImGui::GetFontSize();
    drawMenuBackdrop(ImGui::GetBackgroundDrawList(), r, w_, h_, 1 + menuBg_ % 2, (float)ImGui::GetTime());
    ImGui::SetNextWindowPos(ImVec2(0, 0));
    ImGui::SetNextWindowSize(ImVec2((float)w_, (float)h_));
    ImGui::PushStyleColor(ImGuiCol_WindowBg, ImVec4(0, 0, 0, 0));
    wrapui::Begin("Proyectos", nullptr,
                 ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoResize |
                     ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoBringToFrontOnFocus);
    {
        int lw = 0, lh = 0;
        unsigned lid = brandTexture(r, 0, &lw, &lh);
        ImVec2 hp = ImGui::GetCursorScreenPos();
        float hh = fs * 4.6f;
        ImGui::GetWindowDrawList()->AddRectFilledMultiColor(ImVec2(0, hp.y - 12.f), ImVec2((float)w_, hp.y + hh), IM_COL32(20, 150, 140, 255), IM_COL32(40, 90, 190, 255), IM_COL32(30, 60, 150, 255), IM_COL32(16, 100, 110, 255));
        ImGui::SetCursorScreenPos(ImVec2(hp.x + fs * 0.3f, hp.y + fs * 0.35f));
        if (lid) {
            ImGui::Image((ImTextureID)(intptr_t)lid, ImVec2(fs * 3.4f, fs * 3.4f));
            ImGui::SameLine();
        }
        ImGui::BeginGroup();
        ImGui::SetWindowFontScale(1.7f);
        ImGui::TextUnformatted("P-Maker code333");
        ImGui::SetWindowFontScale(1.f);
        ImGui::TextUnformatted("Crea tus propios juegos");
        ImGui::EndGroup();
        ImGui::SetCursorScreenPos(ImVec2(hp.x, hp.y + hh + fs * 0.5f));
    }
    // ---- empezar algo nuevo (mosaicos grandes con dibujo)
    ImGui::SetNextItemWidth(-1.f);
    textInput("##pn", "Nombre del proyecto", newName_, "nombre del proyecto");
    {
        float avail = ImGui::GetContentRegionAvail().x, sp = ImGui::GetStyle().ItemSpacing.x;
        int cols = host_.pickFile ? 3 : 2;
        float tw = (avail - sp * (cols - 1)) / cols, th = std::max(fs * 6.2f, tw * 0.8f);
        if (th > fs * 8.f) th = fs * 8.f;
        if (wrapui::Tile("##nv", "Nuevo vacío", wrapui::IcPlus, ImVec4(0.12f, 0.62f, 0.55f, 1.f), ImVec2(tw, th))) newProject(newName_, false);
        ImGui::SameLine();
        if (wrapui::Tile("##nd", "Nuevo con la demo", wrapui::IcCube, ImVec4(0.45f, 0.35f, 0.82f, 1.f), ImVec2(tw, th))) newProject(newName_, true);
        if (host_.pickFile) {
            ImGui::SameLine();
            if (wrapui::Tile("##im", "Importar un juego (.pack)", wrapui::IcFolder, ImVec4(0.22f, 0.48f, 0.85f, 1.f), ImVec2(tw, th))) host_.pickFile();
        }
    }
    ImGui::Spacing();
    ImGui::SeparatorText("Tus juegos");
    if (projList_.empty()) ImGui::TextDisabled("Todavía no tienes proyectos. Toca un mosaico de arriba para crear el primero.");
    std::string del;
    for (auto& n : projList_) {
        ImGui::PushID(n.c_str());
        float avail = ImGui::GetContentRegionAvail().x, sp = ImGui::GetStyle().ItemSpacing.x;
        float ch = fs * 3.6f, delW = fs * 5.2f;
        ImVec2 p0 = ImGui::GetCursorScreenPos();
        bool open = ImGui::InvisibleButton("##open", ImVec2(avail - delW - sp, ch)) && tapped();
        bool hov = ImGui::IsItemHovered();
        unsigned hsh = 0;
        for (unsigned char c : n) hsh = hsh * 131u + c;
        static const ImU32 pal[6] = {IM_COL32(30, 170, 150, 255), IM_COL32(90, 110, 230, 255), IM_COL32(220, 120, 60, 255), IM_COL32(170, 90, 210, 255), IM_COL32(60, 160, 90, 255), IM_COL32(210, 80, 120, 255)};
        ImDrawList* dl = ImGui::GetWindowDrawList();
        ImVec2 p1(p0.x + avail - delW - sp, p0.y + ch);
        dl->AddRectFilled(p0, p1, hov ? IM_COL32(48, 66, 108, 255) : IM_COL32(32, 46, 80, 255), fs * 0.7f);
        float is = ch * 0.72f;
        ImVec2 ic0(p0.x + ch * 0.14f, p0.y + (ch - is) * 0.5f);
        dl->AddRectFilled(ic0, ImVec2(ic0.x + is, ic0.y + is), pal[hsh % 6], fs * 0.5f);
        wrapui::drawIcon(dl, wrapui::IcPlay, ImVec2(ic0.x + is * 0.5f, ic0.y + is * 0.5f), is * 0.55f, IM_COL32(255, 255, 255, 255));
        float tx = ic0.x + is + fs * 0.6f, ww = std::max(fs * 3.f, p1.x - tx - fs * 0.4f);
        ImVec2 ts = ImGui::CalcTextSize(n.c_str(), nullptr, false, ww);
        dl->AddText(ImGui::GetFont(), fs * 1.15f, ImVec2(tx, p0.y + std::max(2.f, (ch - ts.y * 1.15f) * 0.5f)), IM_COL32(255, 255, 255, 255), n.c_str(), nullptr, ww);
        ImGui::SameLine();
        ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(0.62f, 0.22f, 0.24f, 1.f));
        bool ask = wrapui::Button("Borrar", ImVec2(delW, ch));
        ImGui::PopStyleColor();
        if (ask) ImGui::OpenPopup("del");
        if (open) { std::string copy = n; ImGui::PopID(); openProject(copy); ImGui::End(); ImGui::PopStyleColor(); return; }
        if (ImGui::BeginPopup("del")) {
            ImGui::Text("¿Borrar \"%s\" para siempre?", n.c_str());
            if (wrapui::Button("Sí, borrar")) { del = n; ImGui::CloseCurrentPopup(); }
            wrapui::Next("Cancelar");
            if (wrapui::Button("Cancelar")) ImGui::CloseCurrentPopup();
            ImGui::EndPopup();
        }
        ImGui::PopID();
    }
    if (!del.empty()) { fs::removeTree(host_.dataDir + "/projects/" + del); listProjects(); }
    ImGui::Spacing();
    ImGui::TextDisabled("Los juegos que exportaste como .pack se pueden volver a abrir aquí.");
    ImGui::End();
    ImGui::PopStyleColor();
}

void Editor::playFrame(Renderer* r, float dt) {
    play_.frame(r, w_, h_, dt);
    ImGui::SetNextWindowPos(ImVec2(10, 10));
    ImGui::SetNextWindowBgAlpha(0.5f);
    ImGui::Begin("##play", nullptr,
                 ImGuiWindowFlags_NoDecoration | ImGuiWindowFlags_AlwaysAutoResize | ImGuiWindowFlags_NoMove |
                     ImGuiWindowFlags_NoSavedSettings);
    if (wrapui::Button("Detener")) stopPlay();
    ImGui::End();
}

void Editor::editFrame(Renderer* r, float dt) {
    if (!hasScene() && !edit_.proj.scenes.empty()) setScene(0);
    play_.ctl.hud = nullptr;
    edit_.time += dt;
    if (ImGui::IsMouseClicked(0)) dragAcc_ = 0;
    if (ImGui::IsMouseDown(0)) dragAcc_ += std::fabs(ImGui::GetIO().MouseDelta.x) + std::fabs(ImGui::GetIO().MouseDelta.y);
    enforceOneWindow();
    rend_ = r;
    if (layerPreview_ && page_ == Page::Viewport && hasScene() && r) drawCameraLayer(ImGui::GetBackgroundDrawList(), edit_, r, w_, h_);
    if (hasScene() && scene().is3d) ensurePlayer(scene());
    if (page_ == Page::Scenes) { pageScenes(r); return; }
    if (page_ == Page::SceneHome) { pageSceneHome(r); return; }
    if (page_ == Page::Object) { pageObject(r); return; }
    menuBar();
    if (screen_ != Screen::Edit) return;  // el menu pudo cerrar el proyecto o iniciar el juego
    gestures();
    if (r && hasScene()) {
        EditorView ev = view();
        r->render(edit_, w_, h_, &ev);
    }
    if (showHud && hasScene()) {
        Hud preview;
        preview.setup(edit_.proj);
        preview.draw(ImGui::GetBackgroundDrawList(), edit_, r, w_, h_, true);
    }
    {   // telefono: ventanas fijas, una a la vez, en la mitad de la pantalla
        gDock.on = (bool)host_.prompt;
        if (gDock.on) {
            float top = ImGui::GetFrameHeight() + 6.f;
            bool wide = w_ >= h_;
            gDock.x = wide ? w_ * 0.46f : 0.f;
            gDock.y = wide ? top : h_ * 0.46f;
            gDock.w = wide ? w_ * 0.54f : (float)w_;
            gDock.h = wide ? h_ - top : h_ * 0.54f;
            bool now[4] = {showObjs, showProps, showWorld, showHud};
            static bool prev[4] = {false, false, false, false};
            int keep = -1;
            for (int i = 0; i < 4; i++) if (now[i] && !prev[i]) keep = i;
            if (keep >= 0) {
                showObjs = keep == 0; showProps = keep == 1; showWorld = keep == 2; showHud = keep == 3;
                now[0] = showObjs; now[1] = showProps; now[2] = showWorld; now[3] = showHud;
            }
            for (int i = 0; i < 4; i++) prev[i] = now[i];
        }
    }
    objectsWin();
    propsWin();
    worldWin();
    hudWin(r);
    assetsWin();

    if (!selObj()) {
        float fs = ImGui::GetFontSize();
        ImGui::GetBackgroundDrawList()->AddText(ImVec2(fs * 0.6f, h_ - fs * 1.6f), IM_COL32(255, 255, 255, 160),
                                                "Arrastra para girar - dos dedos: zoom y mover - toca un objeto para seleccionarlo");
    }
}

// ---------------------------------------------------------------- menu
void Editor::menuBar() {
    if (!ImGui::BeginMainMenuBar()) return;
    bool doPlay = false, doClose = false;
    if (ImGui::MenuItem("< Escena")) { page_ = Page::SceneHome; ImGui::EndMainMenuBar(); return; }
    if (ImGui::BeginMenu("Proyecto")) {
        if (ImGui::MenuItem("Guardar")) saveProject();
        if (ImGui::MenuItem("Exportar juego (APK, EXE, paquete)...")) showExport_ = true;
        ImGui::Separator();
        if (ImGui::MenuItem("Cerrar proyecto")) doClose = true;
        ImGui::EndMenu();
    }
    if (hasScene() && ImGui::BeginMenu(("Escena: " + scene().name).c_str())) {
        for (int i = 0; i < (int)edit_.proj.scenes.size(); i++) {
            auto& s = edit_.proj.scenes[i];
            if (ImGui::MenuItem((s.name + (s.is3d ? "  (3D)" : "  (2D)")).c_str(), nullptr, i == sceneIdx_)) { setScene(i); break; }
        }
        ImGui::Separator();
        if (ImGui::MenuItem("Nueva escena 3D")) addScene(true);
        if (ImGui::MenuItem("Nueva escena 2D")) addScene(false);
        ImGui::EndMenu();
    }
    if (ImGui::BeginMenu("Añadir")) {
        bool is3d = hasScene() && scene().is3d;
        if (ImGui::MenuItem(is3d ? "Cubo" : "Cuadro / botón")) addObject(Kind::Cube);
        if (is3d) {
            if (ImGui::BeginMenu("Objetos de juego")) {
                static const struct { int id; const char* n; } L[] = {{10, "Enemigo"}, {11, "Monstruo"}, {12, "Arma"}, {13, "Munición"},
                    {14, "Botiquín"}, {15, "Llave"}, {16, "Interruptor"}, {24, "Cartel"}, {17, "Puerta horizontal"}, {18, "Puerta vertical"},
                    {19, "Destruible horizontal"}, {20, "Destruible vertical"}, {21, "Fin de nivel"}, {22, "Teleport inicio"},
                    {23, "Teleport fin"}, {25, "Inicio del jugador"}};
                for (auto& it : L) if (ImGui::MenuItem(it.n)) addPreset(it.id);
                ImGui::EndMenu();
            }
            if (ImGui::MenuItem("Suelo")) addObject(Kind::Floor);
            if (ImGui::MenuItem("Pared")) addObject(Kind::Wall);
            if (ImGui::MenuItem("Item")) addObject(Kind::Item);
            if (ImGui::MenuItem("Luz")) addObject(Kind::Light);
            if (ImGui::BeginMenu("Modelo 3D")) {
                auto models = assetsOf(2);
                if (models.empty()) ImGui::TextDisabled("Importa uno en Archivos");
                for (auto& m : models) if (ImGui::MenuItem(m.c_str())) addObject(Kind::Model, m);
                ImGui::EndMenu();
            }
        }
        ImGui::EndMenu();
    }
    if (ImGui::BeginMenu("Ventanas")) {
        ImGui::MenuItem("Objetos", nullptr, &showObjs);
        ImGui::MenuItem("Propiedades", nullptr, &showProps);
            ImGui::MenuItem("Mundo (cielo y luz)", nullptr, &showWorld);
        ImGui::MenuItem("Botones y arma", nullptr, &showHud);
        ImGui::MenuItem("Archivos", nullptr, &showAssets);
        ImGui::EndMenu();
    }
    if (ImGui::MenuItem("JUGAR")) doPlay = true;
    if (dirty_) { ImGui::TextDisabled(" (sin guardar)"); }
    ImGui::EndMainMenuBar();
    if (doClose) closeProject();
    else if (doPlay) startPlay();
}

// ---------------------------------------------------------------- ventanas
// En el telefono las ventanas van fijas (no se arrastran por accidente) y se desliza el dedo para ver todo.
static void placeWindow(float x, float y, float w, float h) {
    if (gDock.on) {
        ImGui::SetNextWindowPos(ImVec2(gDock.x, gDock.y), ImGuiCond_Always);
        ImGui::SetNextWindowSize(ImVec2(gDock.w, gDock.h), ImGuiCond_Always);
        return;
    }
    ImGui::SetNextWindowPos(ImVec2(x, y), ImGuiCond_FirstUseEver);
    ImGui::SetNextWindowSize(ImVec2(w, h), ImGuiCond_FirstUseEver);
}
static ImGuiWindowFlags dockFlags() { return gDock.on ? (ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoScrollWithMouse | ImGuiWindowFlags_NoCollapse) : 0; }

void Editor::objectsWin() {
    if (!showObjs || !hasScene()) return;
    float fs = ImGui::GetFontSize(), top = ImGui::GetFrameHeight() + 6.f;
    placeWindow(6, top, fs * 14.f, h_ * 0.5f);
    if (wrapui::Begin("Objetos", &showObjs, dockFlags())) {
        wrapui::CloseBar(&showObjs);
        if (gDock.on) dragScroll();
        Scene& S = scene();
        for (int i = 0; i < (int)S.objs.size(); i++) {
            const Obj& o = S.objs[i];
            static const char tags[] = {'C', 'S', 'P', 'I', 'M', 'L', 'J'};
            std::string lab = std::string("[") + tags[(int)o.kind] + "] " + o.name + (o.visible ? "" : " (oculto)");
            ImGui::PushID(i);
            bool lk = o.locked;
            ImGui::PushStyleColor(ImGuiCol_Button, lk ? ImVec4(0.85f, 0.55f, 0.15f, 1.f) : ImVec4(0.25f, 0.30f, 0.38f, 1.f));
            if (ImGui::SmallButton(lk ? "Bloq" : "Libre") && tapped()) { scene().objs[i].locked = !lk; markDirty(); }
            ImGui::PopStyleColor();
            ImGui::SameLine();
            if (wrapui::Selectable(lab.c_str(), sel_ == i)) sel_ = i;
            ImGui::PopID();
        }
        if (S.objs.empty()) ImGui::TextDisabled("Escena vacía. Usa el menú Añadir.");
        ImGui::Separator();
        ImGui::SetNextItemWidth(fs * 5.f);
        numField("Rejilla", snap_, 0.f, 2.f);
    }
    ImGui::End();
}

// Miniatura de una imagen (kind 0) o de un modelo 3D (kind 2) en el lugar del cursor.
void Editor::assetThumb(const std::string& name, int kind, float size) {
    auto fs0 = []() { return ImGui::GetFontSize(); };
    ImVec2 p = ImGui::GetCursorScreenPos();
    ImGui::Dummy(ImVec2(size, size));
    ImDrawList* dl = ImGui::GetWindowDrawList();
    dl->AddRectFilled(p, ImVec2(p.x + size, p.y + size), IM_COL32(28, 33, 45, 255), 6.f);
    unsigned id = 0;
    int tw = 1, th = 1;
    if (rend_ && !name.empty()) {
        if (kind == 0) {
            id = rend_->textureId(edit_, name, &tw, &th);
        } else {
            auto a = edit_.proj.assets.find(name);
            if (a != edit_.proj.assets.end()) {
                int pxs = size > fs0() * 4.f ? 192 : 96;
                std::string key = "prev:" + name + ":" + std::to_string(a->second.size()) + ":" + std::to_string(pxs);
                if (rend_->hasTexture(key)) {
                    id = rend_->uploadRGBA(key, 0, 0, nullptr);
                } else {
                    std::vector<uint8_t> px;
                    if (modelPreviewRGBA(a->second, edit_.proj.assets, pxs, px)) id = rend_->uploadRGBA(key, pxs, pxs, px.data());
                }
                tw = th = 1;
            }
        }
    }
    if (id) {
        float k = kind == 0 ? std::min(size / tw, size / th) : size;
        float iw = kind == 0 ? tw * k : size, ih = kind == 0 ? th * k : size;
        ImVec2 a(p.x + (size - iw) * 0.5f, p.y + (size - ih) * 0.5f);
        dl->AddImage((ImTextureID)(intptr_t)id, a, ImVec2(a.x + iw, a.y + ih), ImVec2(0, kind == 0 ? 1 : 0), ImVec2(1, kind == 0 ? 0 : 1));
    } else if (!name.empty()) {
        dl->AddText(ImVec2(p.x + size * 0.3f, p.y + size * 0.2f), IM_COL32(150, 160, 180, 255), kind == 0 ? "IMG" : "3D");
    }
}

// Cuadrícula grande de miniaturas (ventana casi a pantalla completa). Devuelve true si se eligió algo.
bool Editor::gridPicker(const char* id, std::string& cur, int kind, const char* none, bool open) {
    bool ch = false;
    float fs = ImGui::GetFontSize();
    if (open) ImGui::OpenPopup(id);
    ImGui::SetNextWindowPos(ImVec2(w_ * 0.02f, h_ * 0.02f));
    ImGui::SetNextWindowSize(ImVec2(w_ * 0.96f, h_ * 0.96f));
    if (ImGui::BeginPopupModal(id, nullptr, ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoScrollbar |
                                                ImGuiWindowFlags_NoScrollWithMouse | ImGuiWindowFlags_NoSavedSettings)) {
        // barra fija arriba
        ImGui::AlignTextToFramePadding();
        ImGui::TextUnformatted(kind == 0 ? "Elige una textura" : kind == 2 ? "Elige un modelo 3D" : "Elige un sonido");
        wrapui::Next("Cerrar");
        if (wrapui::Button("Cerrar", ImVec2(fs * 6.f, fs * 2.2f)) && tapped()) ImGui::CloseCurrentPopup();
        if (none) {
            ImGui::SameLine();
            if (wrapui::Button(none, ImVec2(0, fs * 2.2f)) && tapped()) { cur.clear(); ch = true; ImGui::CloseCurrentPopup(); }
        }
        if (host_.pickFile) {
            wrapui::Next("Importar desde archivos...");
            if (wrapui::Button("Importar desde archivos...", ImVec2(0, fs * 2.2f)) && tapped()) host_.pickFile();
        }
        if (kind == 0) {
            wrapui::Next("Dibujar una nueva");
            if (wrapui::Button("Dibujar una nueva", ImVec2(0, fs * 2.2f)) && tapped()) { ImGui::CloseCurrentPopup(); openPaint(""); }
        }
        ImGui::Separator();
        wrapui::BeginChild("##grid", ImVec2(0, 0), false, ImGuiWindowFlags_NoScrollbar);
        dragScroll();
        float cell = fs * (kind == 1 ? 9.f : 8.f), gap = fs * 0.6f;
        int cols = std::max(1, (int)((ImGui::GetContentRegionAvail().x + gap) / (cell + gap)));
        auto items = assetsOf(kind);
        if (items.empty()) ImGui::TextDisabled("No hay archivos de este tipo todavía. Usa \"Importar desde archivos\".");
        int n = 0;
        for (auto& it : items) {
            if (n % cols) ImGui::SameLine(0, gap);
            n++;
            ImGui::PushID(it.c_str());
            ImGui::BeginGroup();
            ImVec2 p = ImGui::GetCursorScreenPos();
            bool sel = it == cur;
            if (kind != 1) assetThumb(it, kind, cell);
            else ImGui::Dummy(ImVec2(cell, cell * 0.6f));
            ImVec2 pe(p.x + cell, p.y + (kind == 1 ? cell * 0.6f : cell));
            ImGui::SetCursorScreenPos(p);
            bool hit = ImGui::InvisibleButton("##pick", ImVec2(cell, pe.y - p.y)) && tapped();
            ImDrawList* dl = ImGui::GetWindowDrawList();
            if (kind == 1) dl->AddRectFilled(p, pe, IM_COL32(40, 48, 66, 255), 8.f);
            if (sel) dl->AddRect(p, pe, IM_COL32(30, 220, 190, 255), 8.f, 0, 3.f);
            else if (ImGui::IsItemHovered()) dl->AddRect(p, pe, IM_COL32(255, 255, 255, 90), 8.f, 0, 2.f);
            if (kind == 1) dl->AddText(ImVec2(p.x + fs * 0.6f, p.y + cell * 0.2f), IM_COL32(220, 230, 250, 255), "SONIDO");
            ImGui::PushTextWrapPos(ImGui::GetCursorPosX() + cell);
            ImGui::TextUnformatted(shorten(it, 22).c_str());
            ImGui::PopTextWrapPos();
            ImGui::EndGroup();
            if (hit) { cur = it; ch = true; ImGui::CloseCurrentPopup(); }
            ImGui::PopID();
        }
        ImGui::Dummy(ImVec2(1, fs * 2.f));
        ImGui::EndChild();
        ImGui::EndPopup();
    }
    return ch;
}

// Selector con previsualizacion: muestra la miniatura del elegido; al tocarlo abre la cuadrícula grande.
bool Editor::assetCombo(const char* label, std::string& cur, int kind, const char* none) {
    float fs = ImGui::GetFontSize();
    ImGui::PushID(label);
    assetThumb(cur, kind, fs * 3.2f);
    ImGui::SameLine();
    ImGui::BeginGroup();
    ImGui::TextUnformatted(label);
    const char* preview = cur.empty() ? (none ? none : "(ninguno)") : cur.c_str();
    bool open = wrapui::Button((shorten(preview, 24) + "  [cambiar]").c_str()) && tapped();
    ImGui::EndGroup();
    bool ch = gridPicker("##gridpick", cur, kind, none, open);
    ImGui::PopID();
    return ch;
}

// Suelo deformable: montañas y hoyos que también cambian la colisión.
bool Editor::terrainPanel(Obj& o) {
    bool ch = false;
    float fs = ImGui::GetFontSize();
    ImGui::SeparatorText("Terreno (montañas)");
    if (o.tn < 2) {
        ImGui::TextWrapped("Convierte este suelo en terreno para subirlo y bajarlo con el dedo. Más puntos = más detalle (y más lento).");
        static const int sizes[3] = {24, 48, 80};
        static const char* nm[3] = {"Básico (24)", "Medio (48)", "Fino (80)"};
        for (int i = 0; i < 3; i++) {
            if (i) ImGui::SameLine();
            if (wrapui::Button(nm[i], ImVec2(0, fs * 2.2f)) && tapped()) { terrainInit(o, sizes[i]); ch = true; }
        }
        return ch;
    }
    wrapui::Checkbox("Modo esculpir (tocar y arrastrar sobre el terreno)", &terrainPaint_);
    if (terrainPaint_) ImGui::TextDisabled("Con este modo activo, un dedo esculpe; dos dedos mueven y acercan la cámara.");
    static const char* modes[4] = {"Subir montaña", "Bajar / quitar", "Aplanar", "Suavizar"};
    for (int i = 0; i < 4; i++) {
        bool sel = terrMode_ == i;
        if (i % 2) ImGui::SameLine();
        ImGui::PushStyleColor(ImGuiCol_Button, sel ? ImVec4(0.12f, 0.62f, 0.56f, 1.f) : ImVec4(0.18f, 0.20f, 0.28f, 1.f));
        if (wrapui::Button(modes[i], ImVec2(ImGui::GetContentRegionAvail().x * (i % 2 ? 1.f : 0.5f) - (i % 2 ? 0.f : 4.f), fs * 2.2f)) && tapped()) terrMode_ = i;
        ImGui::PopStyleColor();
    }
    numField("Tamaño del pincel", terrRadius_, 0.5f, 20.f);
    numField("Fuerza", terrStrength_, 0.5f, 20.f);
    if (wrapui::Button("Dejar plano", ImVec2(0, fs * 2.2f)) && tapped()) { std::fill(o.heights.begin(), o.heights.end(), 0.f); o.terrVer++; ch = true; }
    wrapui::Next("Volver a suelo normal");
    if (wrapui::Button("Volver a suelo normal", ImVec2(0, fs * 2.2f)) && tapped()) { o.tn = 0; o.heights.clear(); terrainPaint_ = false; ch = true; }
    ImGui::TextDisabled("La colisión sigue la forma: se pueden subir laderas suaves; las muy empinadas bloquean.");
    return ch;
}

// Nombres de las animaciones de esqueleto que sirven para este objeto (las de su esqueleto, o las de su modelo).
std::vector<std::string> Editor::clipsFor(const Obj& o) const {
    std::vector<std::string> v;
    for (auto& a : edit_.proj.assets) {
        if (!ends(a.first, ".fanim")) continue;
        Rig r;
        if (!rigRead(std::string(a.second.begin(), a.second.end()), r)) continue;
        if (!o.rig.empty() ? a.first != o.rig : r.model != o.model) continue;
        for (auto& c : r.clips) v.push_back(c.name);
    }
    return v;
}

bool Editor::clipCombo(const char* label, const Obj& o, std::string& clip) {
    bool ch = false;
    if (wrapui::BeginCombo(label, clip.empty() ? "(ninguna)" : clip.c_str())) {
        if (wrapui::Selectable("(ninguna)", clip.empty())) { clip.clear(); ch = true; }
        for (auto& n : clipsFor(o)) if (wrapui::Selectable(n.c_str(), n == clip)) { clip = n; ch = true; }
        ImGui::EndCombo();
    }
    return ch;
}

// Animación con esqueleto: archivo de esqueleto del objeto y animación que se reproduce.
bool Editor::skelPanel(Obj& o) {
    bool ch = false;
    float fs = ImGui::GetFontSize();
    ImGui::SeparatorText("Animación con esqueleto");
    std::string curRig = o.rig.empty() ? "(el de su modelo)" : o.rig;
    if (wrapui::BeginCombo("Esqueleto", curRig.c_str())) {
        if (wrapui::Selectable("(el de su modelo)", o.rig.empty())) { o.rig.clear(); ch = true; }
        for (auto& a : edit_.proj.assets) if (ends(a.first, ".fanim") && wrapui::Selectable(a.first.c_str(), a.first == o.rig)) { o.rig = a.first; ch = true; }
        ImGui::EndCombo();
    }
    ch |= clipCombo("Animación inicial", o, o.clip);
    if (wrapui::Button("Abrir editor de animación", ImVec2(0, fs * 2.2f)) && tapped()) openAnimEditor(o.rig);
    ImGui::TextDisabled("Con el bloque \"Reproducir animación de esqueleto\" puedes cambiarla jugando.");
    return ch;
}

bool Editor::fxPanel(Obj& o) {
    FxCfg& f = o.fx;
    bool ch = wrapui::Checkbox("Lanza partículas", &f.on);
    if (!f.on && f.rate <= 0) return ch;
    ImGui::TextDisabled("Elige un efecto y luego cámbialo como quieras:");
    static const char* names[5] = {"Humo", "Fuego", "Chispas", "Nieve", "Energía"};
    for (int i = 0; i < 5; i++) {
        if (i) ImGui::SameLine();
        if (ImGui::SmallButton(names[i])) { fxPreset(f, i); ch = true; }
    }
    if (f.on) {
        ch |= wrapui::ColorEdit3("Color al nacer", f.c0);
        ch |= wrapui::ColorEdit3("Color al desaparecer", f.c1);
        ch |= numField("Cuántas por segundo", f.rate, 1.f, 200.f, "%.0f");
        ch |= numField("Cuánto duran (s)", f.life, 0.1f, 10.f);
        ch |= numField("Tamaño", f.size, 0.02f, 3.f);
        ch |= numField("Crecen o se encogen", f.grow, -1.f, 4.f);
        ch |= numField("Velocidad", f.speed, 0.f, 15.f);
        ch |= numField("Se abren hacia los lados", f.spread, 0.f, 8.f);
        ch |= numField("Caen (+) o suben (-)", f.gravity, -10.f, 20.f);
        ch |= numField("Transparencia inicial", f.a0, 0.05f, 1.f);
        ch |= wrapui::Checkbox("Brillan (fuego, luz)", &f.glow);
        ch |= assetCombo("Imagen propia", f.tex, 0, "(punto suave)");
    }
    return ch;
}

bool Editor::layerPanel(Scene& S) {
    bool ch = false;
    ch |= wrapui::Checkbox("Verla aquí en el editor", &layerPreview_);
    ImGui::TextDisabled("Efecto de pantalla:");
    static const char* names[5] = {"Ninguno", "VHS", "Cámara de video", "Visión nocturna", "Película vieja"};
    for (int i = 0; i < 5; i++) {
        if (wrapui::Button(names[i])) { sfxPreset(S.sfx, i); ch = true; }
        if (i % 2 == 0 && i < 4) ImGui::SameLine();
    }
    ScreenFx& f = S.sfx;
    ImGui::TextDisabled("O crea el tuyo:");
    ch |= numField("Líneas de barrido", f.scan, 0.f, 1.f);
    ch |= numField("Grano / ruido", f.noise, 0.f, 1.f);
    ch |= numField("Bordes oscuros", f.vignette, 0.f, 1.f);
    ch |= numField("Banda de interferencia", f.track, 0.f, 1.f);
    ch |= numField("Cantidad de tinte", f.tint, 0.f, 1.f);
    if (f.tint > 0) ch |= wrapui::ColorEdit3("Color del tinte", f.tintC);
    ch |= wrapui::Checkbox("Visor de cámara (REC)", &f.rec);
    ImGui::SeparatorText("Imágenes fijas en la pantalla");
    int del = -1;
    for (int i = 0; i < (int)S.overlays.size(); i++) {
        Overlay& o = S.overlays[i];
        ImGui::PushID(i);
        ImGui::Text("Imagen %d", i + 1);
        ch |= assetCombo("Imagen", o.tex, 0, "(elige una)");
        ch |= numField("Posición izquierda-derecha", o.x, 0.f, 1.f);
        ch |= numField("Posición arriba-abajo", o.y, 0.f, 1.f);
        ch |= numField("Ancho", o.w, 0.02f, 1.f);
        ch |= numField("Alto", o.h, 0.02f, 1.f);
        ch |= numField("Opacidad", o.alpha, 0.f, 1.f);
        if (ImGui::SmallButton("Quitar esta imagen")) del = i;
        ImGui::Separator();
        ImGui::PopID();
    }
    if (del >= 0) { S.overlays.erase(S.overlays.begin() + del); ch = true; }
    if (wrapui::Button("+ Añadir imagen fija")) { S.overlays.push_back(Overlay()); ch = true; }
    return ch;
}

bool Editor::weaponFields(Weapon& w, bool primary) {
    bool ch = false;
    if (!primary) {
        char nm[64];
        snprintf(nm, sizeof nm, "%s", w.name.c_str());
        if (ImGui::InputText("Nombre del arma", nm, sizeof nm)) { w.name = nm; ch = true; }
    }
    ImGui::TextUnformatted("Tipo de arma:");
    for (int k = 0; k < 4; k++) {
        if (k == 2) {} else if (k) ImGui::SameLine();
        if (wrapui::RadioButton(kWeaponTypeNames[k], w.type == k)) {
            w.type = k; ch = true;
            if (k == 1) { w.projSpeed = 0; w.rate = std::max(w.rate, 0.5f); }
            if (k == 2 && w.projSpeed < 1.f) w.projSpeed = 16.f;
            if (k == 3) { w.projSpeed = 14.f; w.projShape = 0; w.rate = std::max(w.rate, 1.5f); }
        }
    }
    ch |= wrapui::Checkbox("Arma activada (se puede usar)", &w.enabled);
    {
        int sw = w.startWith ? 0 : 1;
        ch |= wrapui::RadioButton("Empezar con esta arma", &sw, 0); ImGui::SameLine();
        ch |= wrapui::RadioButton("Recogerla del suelo", &sw, 1);
        w.startWith = sw == 0;
        if (sw == 1) ImGui::TextDisabled("En un objeto: Propiedades → \"Da esta arma\" con el nombre del arma.");
    }
    ImGui::TextDisabled("Cómo se ve el arma en tu mano:");
    ch |= assetCombo("Imagen (2D)", w.tex, 0, "(arma básica)");
    ch |= assetCombo("o Modelo 3D", w.model, 2, "(ninguno)");
    ch |= numField("Tamaño", w.scale, 0.1f, 1.2f);
    ch |= numField("Mover a los lados", w.ox, -0.5f, 0.5f);
    ch |= numField("Mover arriba/abajo", w.oy, -0.3f, 0.5f);
    ch |= numField("Segundos entre usos", w.rate, 0.05f, 3.f);
    ch |= numField("Daño", w.damage, 0.f, 100.f);
    ch |= numField("Retroceso (0 = ninguno)", w.recoilAmt, 0.f, 3.f);
    if (w.type == 0) {
        ch |= numField("Alcance", w.range, 5.f, 200.f);
        ImGui::SeparatorText("Balas");
        ch |= wrapui::Checkbox("Disparo infinito", &w.infinite);
        if (!w.infinite) {
            ch |= numFieldI("Balas por cargador (0 = sin recarga)", w.magSize, 0, 200);
            ch |= numFieldI("Balas con las que empiezas", w.startAmmo, 0, 999);
            if (w.magSize > 0) ch |= numField("Segundos para recargar", w.reloadTime, 0.2f, 6.f);
        }
    } else if (w.type == 1) {
        ch |= numField("Alcance del golpe (metros)", w.meleeRange, 0.5f, 8.f);
    } else {
        ch |= wrapui::Checkbox("Cantidad limitada", &w.infinite); ImGui::SameLine(); ImGui::TextDisabled("(marcado = infinita)");
        if (!w.infinite) ch |= numFieldI("Cantidad con la que empiezas", w.startAmmo, 0, 999);
        ch |= numField("Fuerza del lanzamiento", w.projSpeed, 3.f, 40.f, "%.1f");
        if (w.type == 3) {
            ch |= numField("Segundos para explotar", w.fuse, 0.5f, 8.f);
            ch |= numField("Radio de la explosión", w.blast, 1.f, 20.f);
        }
    }
    if (w.type != 1) {
        ImGui::SeparatorText(w.type == 0 ? "Proyectil (lo que sale al disparar)" : "Lo que se lanza");
        int shape = w.projShape;
        ch |= wrapui::RadioButton("Bala", &shape, 0); ImGui::SameLine();
        ch |= wrapui::RadioButton("Imagen", &shape, 1); ImGui::SameLine();
        ch |= wrapui::RadioButton("Modelo 3D", &shape, 2);
        w.projShape = shape;
        if (shape == 1) ch |= assetCombo("Imagen del proyectil", w.projTex, 0, "(elige una)");
        if (shape == 2) ch |= assetCombo("Modelo del proyectil", w.projModel, 2, "(elige uno)");
        if (shape == 0) ch |= wrapui::ColorEdit3("Color de la bala", w.projColor);
        ch |= numField("Tamaño del proyectil", w.projSize, 0.05f, 3.f);
        if (w.type == 0) ch |= numField("Velocidad (0 = instantáneo)", w.projSpeed, 0.f, 120.f, "%.1f");
    }
    return ch;
}

bool Editor::weaponPanel() {
    Project& P = edit_.proj;
    bool ch = false;
    ImGui::TextDisabled("Arma principal (la que ya tenías):");
    ch |= weaponFields(P.weapon, true);
    int del = -1;
    for (size_t i = 0; i < P.extraWeapons.size(); i++) {
        ImGui::PushID((int)i + 5000);
        ImGui::Separator();
        std::string hd = "Arma extra: " + P.extraWeapons[i].name + " (" + kWeaponTypeNames[std::max(0, std::min(3, P.extraWeapons[i].type))] + ")";
        if (ImGui::CollapsingHeader(hd.c_str())) {
            ch |= weaponFields(P.extraWeapons[i], false);
            if (wrapui::Button("Borrar esta arma")) del = (int)i;
        }
        ImGui::PopID();
    }
    if (del >= 0) { P.extraWeapons.erase(P.extraWeapons.begin() + del); ch = true; }
    ImGui::Separator();
    ImGui::TextDisabled("Armas extra (opcionales): se cambian con el botón ARMA o la tecla Q.");
    const char* nn[3] = {"+ Arma cuerpo a cuerpo", "+ Arma arrojadiza", "+ Granada"};
    for (int k = 0; k < 3; k++) {
        if (wrapui::Button(nn[k])) {
            Weapon w;
            w.type = k + 1;
            w.name = k == 0 ? "Cuchillo" : k == 1 ? "Lanza" : "Granada";
            if (P.extraWeapons.size() > 0) w.name += std::to_string(P.extraWeapons.size() + 1);
            if (k == 0) { w.projSpeed = 0; w.rate = 0.5f; w.damage = 3.f; }
            if (k == 1) { w.projSpeed = 16.f; w.rate = 0.8f; w.damage = 3.f; w.infinite = false; w.startAmmo = 5; }
            if (k == 2) { w.projSpeed = 14.f; w.rate = 1.5f; w.damage = 8.f; w.infinite = false; w.startAmmo = 3; }
            w.startWith = false;
            P.extraWeapons.push_back(w);
            ch = true;
        }
        if (k < 2) ImGui::SameLine();
    }
    return ch;
}

bool Editor::playerPanel(Scene& S, Obj& o) {
    Project& P = edit_.proj;
    bool ch = false;
    ImGui::SeparatorText("Cámara del juego");
    int cm = P.player.cam;
    ch |= wrapui::RadioButton("Primera persona", &cm, kFirstPerson);
    ch |= wrapui::RadioButton("Cámara al hombro", &cm, kShoulder);
    ch |= wrapui::RadioButton("Cámara fija (tercera persona)", &cm, kFixed);
    P.player.cam = cm;
    ch |= flashPanel();
    ch |= soundPanel();
    ch |= wrapui::Checkbox("Balanceo de cámara al caminar (primera persona)", &P.player.headBob);
    if (P.player.headBob) ch |= wrapui::SliderFloat("Fuerza del balanceo", &P.player.bobAmt, 0.2f, 3.f);
    if (cm == kFixed) {
        ImGui::TextDisabled("La cámara azul se coloca donde tú quieras:");
        ch |= stepper("Cámara X", S.cam.x, 1.f);
        ch |= stepper("Cámara Y", S.cam.y, 1.f);
        ch |= stepper("Cámara Z", S.cam.z, 1.f);
        if (wrapui::Button("Poner la cámara donde estoy mirando")) { S.cam = view().eye; ch = true; }
        ImGui::TextUnformatted("¿Cómo se comporta la cámara?");
        int fm = P.player.fixedMode;
        ch |= wrapui::RadioButton("Se queda en su lugar y gira para seguir al jugador", &fm, 0);
        ch |= wrapui::RadioButton("Se mueve junto al jugador (mantiene la distancia)", &fm, 1);
        ch |= wrapui::RadioButton("Totalmente fija (no se mueve ni gira)", &fm, 2);
        P.player.fixedMode = fm;
    }
    if (cm == kShoulder) ch |= numField("Distancia de la cámara", P.player.shoulderDist, 1.f, 8.f, "%.1f");
    ImGui::SeparatorText("Cuerpo y movimiento");
    ch |= assetCombo("Modelo del jugador", P.player.model, 2, "(muñeco básico)");
    {
        int fm = P.player.faceMove ? 0 : 1;
        ImGui::TextUnformatted("¿Hacia dónde mira el cuerpo?");
        ch |= wrapui::RadioButton("Gira hacia donde camina", &fm, 0); ImGui::SameLine();
        ch |= wrapui::RadioButton("Siempre mira al frente", &fm, 1);
        P.player.faceMove = fm == 0;
        if (ImGui::TreeNode("Ajustar el modelo (posición, giro, tamaño)")) {
            ch |= numField("Mover a los lados", P.player.mox, -2.f, 2.f);
            ch |= numField("Mover arriba/abajo", P.player.moy, -2.f, 2.f);
            ch |= numField("Mover adelante/atrás", P.player.moz, -2.f, 2.f);
            ch |= numField("Girar el modelo (grados)", P.player.myaw, -180.f, 180.f, "%.0f");
            ch |= numField("Tamaño del modelo", P.player.mscale, 0.2f, 3.f);
            ImGui::TreePop();
        }
    }
    ImGui::TextDisabled("Se ve en cámara al hombro y fija. Usa Ancho/Alto de arriba para su tamaño.");
    {
        int sp = o.ai.sprite ? 1 : 0;
        ImGui::TextUnformatted("¿Cómo se ve el jugador?");
        ch |= wrapui::RadioButton("Modelo 3D / muñeco", &sp, 0); ImGui::SameLine();
        ch |= wrapui::RadioButton("Imágenes planas (sprites)", &sp, 1);
        o.ai.sprite = sp == 1;
        ch |= animPanel(o);
    }
    ch |= numField("Velocidad al caminar", P.player.speed, 0.5f, 20.f, "%.1f");
    ch |= numField("Fuerza de salto", P.player.jump, 0.f, 20.f, "%.1f");
    ImGui::SeparatorText("Arma del jugador");
    ch |= weaponPanel();
    return ch;
}

bool Editor::aiPanel(Obj& o) {
    AiCfg& a = o.ai;
    bool ch = false;
    int t = a.type == AiType::Shooter ? 1 : a.type == AiType::Melee ? 2 : 0;
    ImGui::TextUnformatted("¿Es un enemigo?");
    ch |= wrapui::RadioButton("No", &t, 0); ImGui::SameLine();
    ch |= wrapui::RadioButton("Enemigo (dispara)", &t, 1); ImGui::SameLine();
    ch |= wrapui::RadioButton("Monstruo (cuerpo a cuerpo)", &t, 2);
    a.type = t == 1 ? AiType::Shooter : t == 2 ? AiType::Melee : AiType::None;
    if (a.type == AiType::None) return ch;
    int sp = a.sprite ? 1 : 0;
    ImGui::TextUnformatted("¿Cómo se ve?");
    ch |= wrapui::RadioButton("Modelo 3D / cubo", &sp, 0); ImGui::SameLine();
    ch |= wrapui::RadioButton("Imágenes planas (sprites)", &sp, 1);
    a.sprite = sp == 1;
    if (a.sprite) ImGui::TextDisabled("La imagen siempre mira al jugador. Pon una imagen distinta para cada acción abajo.");
    else if (o.kind != Kind::Model) {
        ImGui::TextDisabled("Para usar un modelo 3D importado, cambia el objeto a tipo Modelo o añade modelos en las animaciones.");
    }
    {
        int fc = a.face;
        ImGui::TextUnformatted("¿Hacia dónde mira?");
        ch |= wrapui::RadioButton("Gira hacia donde va", &fc, 0); ImGui::SameLine();
        ch |= wrapui::RadioButton("Siempre mira al frente", &fc, 1);
        a.face = fc;
    }
    ch |= numField("Vida", a.hp, 1.f, 500.f, "%.0f");
    ch |= numField("Velocidad", a.speed, 0.f, 15.f, "%.1f");
    ch |= numField("Distancia a la que te ve", a.sight, 2.f, 80.f, "%.0f");
    ch |= numField("Daño al jugador", a.dmg, 0.f, 100.f, "%.0f");
    ch |= numField("Segundos entre ataques", a.rate, 0.1f, 10.f);
    if (a.type == AiType::Melee) ch |= numField("Alcance del golpe", a.reach, 0.5f, 6.f);
    if (a.type == AiType::Shooter) {
        ImGui::SeparatorText("Proyectil del enemigo");
        ch |= assetCombo("Imagen", a.projTex, 0, "(bola de color)");
        ch |= assetCombo("o Modelo 3D", a.projModel, 2, "(ninguno)");
        ch |= wrapui::ColorEdit3("Color de la bola", a.projColor);
        ch |= numField("Tamaño", a.projSize, 0.05f, 3.f);
        ch |= numField("Velocidad", a.projSpeed, 1.f, 60.f, "%.1f");
    }
    return ch | animPanel(o);
}

// Animaciones por estado (quieto, caminar, atacar, recibir daño): imágenes o modelos que se alternan.
bool Editor::animPanel(Obj& o) {
    AiCfg& a = o.ai;
    bool ch = false;
    ImGui::SeparatorText("Animaciones");
    static const char* names[kAnimCount] = {"Quieto", "Caminar", "Atacar", "Recibir daño"};
    auto imgs = assetsOf(0), mdls = assetsOf(2);
    for (int k = 0; k < kAnimCount; k++) {
        ImGui::PushID(k);
        AnimState& as = a.anim[k];
        std::string head = std::string(names[k]) + " (" + std::to_string(as.frames.size()) + " cuadros)";
        if (ImGui::CollapsingHeader(head.c_str())) {
            for (size_t i = 0; i < as.frames.size(); i++) {
                ImGui::PushID((int)i);
                bool isM = as.frames[i].size() > 5 && as.frames[i].substr(as.frames[i].size() - 5) == ".fmdl";
                assetThumb(as.frames[i], isM ? 2 : 0, ImGui::GetFontSize() * 2.2f);
                ImGui::SameLine();
                ImGui::AlignTextToFramePadding();
                ImGui::Text("%zu. %s", i + 1, shorten(as.frames[i], 22).c_str());
                ImGui::SameLine();
                if (ImGui::SmallButton("Quitar")) { as.frames.erase(as.frames.begin() + i); ch = true; ImGui::PopID(); break; }
                ImGui::PopID();
            }
            if (wrapui::Button("+ Imagen")) ImGui::OpenPopup("addimg");
            wrapui::Next("+ Modelo 3D");
            if (wrapui::Button("+ Modelo 3D")) ImGui::OpenPopup("addmdl");
            if (ImGui::BeginPopup("addimg")) {
                if (imgs.empty()) ImGui::TextDisabled("Importa imágenes primero (menú Recursos).");
                for (auto& n : imgs) {
                    ImGui::PushID(n.c_str());
                    assetThumb(n, 0, ImGui::GetFontSize() * 2.4f);
                    ImGui::SameLine();
                    if (wrapui::Selectable(shorten(n, 26).c_str(), false, 0, ImVec2(0, ImGui::GetFontSize() * 2.4f))) { as.frames.push_back(n); ch = true; }
                    ImGui::PopID();
                }
                ImGui::EndPopup();
            }
            if (ImGui::BeginPopup("addmdl")) {
                if (mdls.empty()) ImGui::TextDisabled("Importa un modelo primero (menú Recursos).");
                for (auto& n : mdls) {
                    ImGui::PushID(n.c_str());
                    assetThumb(n, 2, ImGui::GetFontSize() * 2.4f);
                    ImGui::SameLine();
                    if (wrapui::Selectable(shorten(n, 26).c_str(), false, 0, ImVec2(0, ImGui::GetFontSize() * 2.4f))) { as.frames.push_back(n); ch = true; }
                    ImGui::PopID();
                }
                ImGui::EndPopup();
            }
            if (as.frames.size() > 1) ch |= numField("Cuadros por segundo", as.fps, 1.f, 30.f, "%.0f");
            if (!a.sprite) {
                // animación de esqueleto: elegir una existente o crear una nueva
                std::string mdl;
                for (auto& fr : as.frames) if (ends(fr, ".fmdl")) { mdl = fr; break; }
                if (mdl.empty()) mdl = o.kind == Kind::Player ? edit_.proj.player.model : o.model;
                std::vector<std::string> cl;
                std::string rigName;
                for (auto& ast : edit_.proj.assets) {
                    if (!ends(ast.first, ".fanim")) continue;
                    Rig rr;
                    if (!rigRead(std::string(ast.second.begin(), ast.second.end()), rr)) continue;
                    if (!mdl.empty() && rr.model != mdl) continue;
                    if (rigName.empty()) rigName = ast.first;
                    for (auto& c : rr.clips) cl.push_back(c.name);
                }
                ImGui::TextDisabled("Animación de esqueleto (mueve el modelo de verdad):");
                if (wrapui::BeginCombo("Elegir animación", as.clip.empty() ? "(ninguna)" : as.clip.c_str())) {
                    if (wrapui::Selectable("(ninguna)", as.clip.empty())) { as.clip.clear(); ch = true; }
                    for (auto& n : cl) if (wrapui::Selectable(n.c_str(), n == as.clip)) { as.clip = n; ch = true; }
                    ImGui::EndCombo();
                }
                if (wrapui::Button("Crear animación nueva", ImVec2(0, ImGui::GetFontSize() * 2.2f)) && tapped()) openAnimEditor("", mdl);
                if (!rigName.empty()) {
                    wrapui::Next("Editar");
                    if (wrapui::Button("Editar", ImVec2(0, ImGui::GetFontSize() * 2.2f)) && tapped()) openAnimEditor(rigName);
                }
                if (mdl.empty()) ImGui::TextDisabled("Primero elige un modelo 3D para este objeto.");
                ImGui::TextDisabled("Mini animación del modelo:");
                ch |= numField("Subir y bajar", as.bob, 0.f, 1.f);
                ch |= numField("Balanceo (grados)", as.sway, 0.f, 45.f, "%.0f");
                ch |= numField("Embestida", as.lunge, 0.f, 2.f);
                ch |= numField("Aplastar y estirar", as.squash, 0.f, 2.f);
            }
        }
        ImGui::PopID();
    }
    return ch;
}

void Editor::propsWin() {
    if (!showProps || !hasScene()) return;
    float fs = ImGui::GetFontSize(), top = ImGui::GetFrameHeight() + 6.f;
    placeWindow(w_ - fs * 21.f - 6.f, top, fs * 21.f, h_ * 0.75f);
    if (wrapui::Begin("Propiedades", &showProps, dockFlags())) {
        wrapui::CloseBar(&showProps);
        if (gDock.on) dragScroll();
        Scene& S = scene();
        Obj* o = selObj();
        if (!o) {
            ImGui::TextDisabled("Toca un objeto en la escena o en la lista.");
        } else {
            bool ch = false;
            ch |= textInput("##on", "Nombre del objeto", o->name, "nombre");
            const char* kinds[] = {"Cubo", "Suelo", "Pared", "Item", "Modelo", "Luz", "Jugador"};
            ImGui::Text("Tipo: %s", kinds[(int)o->kind]);
            ch |= wrapui::Checkbox("Bloqueado (no se mueve ni se selecciona tocando la escena)", &o->locked);
            if (true) if (scene().is3d) ch |= wrapui::Checkbox("Reflejos (brillo del cielo y el sol)", &o->reflect);
            {
                std::vector<std::string> vids;
                for (auto& as : edit_.proj.assets) if (isVideoName(as.first)) vids.push_back(as.first);
                ImGui::SeparatorText("Video en este objeto");
                if (wrapui::BeginCombo("Video", o->video.empty() ? "(ninguno)" : o->video.c_str())) {
                    if (wrapui::Selectable("(ninguno)", o->video.empty())) { o->video.clear(); ch = true; }
                    for (auto& v : vids) if (wrapui::Selectable(v.c_str(), v == o->video)) { o->video = v; o->noColor = false; ch = true; }
                    ImGui::EndCombo();
                }
                if (vids.empty()) ImGui::TextDisabled("Importa un video en Archivos → Videos (o con Importar archivo).");
                if (!o->video.empty()) {
                    ch |= wrapui::Checkbox("Reproducir al empezar", &o->videoAuto);
                    ch |= wrapui::Checkbox("Repetir siempre (ciclo)", &o->videoLoop);
                    ImGui::TextDisabled("Bloques: reproducir, pausar, reanudar, ciclo, N veces, reiniciar, detener.");
                }
            }
            if (scene().is3d && !edit_.proj.extraWeapons.empty()) {
                const char* cur = o->giveWeapon.empty() ? "(ninguna)" : o->giveWeapon.c_str();
                if (wrapui::BeginCombo("Da esta arma al tocarlo", cur)) {
                    if (wrapui::Selectable("(ninguna)", o->giveWeapon.empty())) { o->giveWeapon.clear(); ch = true; }
                    std::vector<std::string> nm = {edit_.proj.weapon.name};
                    for (auto& w : edit_.proj.extraWeapons) nm.push_back(w.name);
                    for (auto& n : nm) if (wrapui::Selectable(n.c_str(), o->giveWeapon == n)) { o->giveWeapon = n; ch = true; }
                    ImGui::EndCombo();
                }
            }
            if (o->kind == Kind::Floor && scene().is3d) ch |= terrainPanel(*o);
            if (scene().is3d && (o->kind == Kind::Model || o->kind == Kind::Player)) ch |= skelPanel(*o);
            ImGui::SeparatorText("Posición");
            float st = S.is3d ? 0.5f : 10.f;
            ch |= stepper("X", o->pos.x, st);
            ch |= stepper("Y", o->pos.y, st);
            if (S.is3d) ch |= stepper("Z", o->pos.z, 0.5f);
            if (o->kind == Kind::Player) {
                ImGui::SeparatorText("Tamaño y giro");
                ch |= stepper("Ancho", o->scale.x, 0.1f);
                ch |= stepper("Alto", o->scale.y, 0.1f);
                ch |= stepper("Fondo", o->scale.z, 0.1f);
                ch |= stepper("Hacia dónde mira", o->yaw, 15.f);
                ch |= playerPanel(S, *o);
            } else if (o->kind == Kind::Light) {
                ImGui::SeparatorText("Luz");
                ch |= stepper("Alcance", o->scale.x, 1.f);
                ch |= wrapui::ColorEdit3("Color de luz", o->color);
            } else {
                ImGui::SeparatorText("Tamaño y giro");
                ch |= stepper("Ancho", o->scale.x, st);
                ch |= stepper("Alto", o->scale.y, st);
                if (S.is3d) ch |= stepper("Fondo", o->scale.z, 0.5f);
                ch |= stepper(S.is3d ? "Giro" : "Dirección", o->yaw, 15.f);
                ImGui::SeparatorText("Apariencia");
                ch |= wrapui::Checkbox("Sin color (transparente)", &o->noColor);
                if (!o->noColor) ch |= wrapui::ColorEdit3("Color", o->color);
                ch |= assetCombo("Textura", o->tex, 0, "(sin textura)");
                if (wrapui::Button("Dibujar una textura nueva")) openPaint("");
                if (!o->tex.empty()) { wrapui::Next("Editar esta"); if (wrapui::Button("Editar esta")) openPaint(o->tex); }
                if (!o->tex.empty()) {
                    bool stretch = !o->texTile;
                    if (wrapui::Checkbox("Estirar la imagen a toda la cara", &stretch)) { o->texTile = !stretch; ch = true; }
                }
                if (o->kind == Kind::Model) ch |= assetCombo("Modelo", o->model, 2, "(cubo)");
                ch |= wrapui::Checkbox("Sólido (se puede chocar)", &o->solid);
                ch |= wrapui::Checkbox("Visible al empezar", &o->visible);
                ch |= wrapui::Checkbox("Gira sobre sí mismo", &o->spin);
                if (S.is3d) {
                    ImGui::SeparatorText("Enemigo o monstruo");
                    ch |= aiPanel(*o);
                }
                ImGui::SeparatorText("Partículas (humo, fuego...)");
                ch |= fxPanel(*o);
            }
            if (ch) markDirty();
            ImGui::Separator();
            if (wrapui::Button("Programar (bloques)")) { page_ = Page::Object; tab_ = 0; }
            ImGui::SameLine();
            if (o->kind != Kind::Player && wrapui::Button("Duplicar")) {
                Obj c = *o;
                c.name = uniqueName(o->name);
                c.pos.x += 1.f;
                S.objs.push_back(c);
                sel_ = (int)S.objs.size() - 1;
                markDirty();
                o = nullptr;
            }
            if (o && o->kind != Kind::Player) {
                wrapui::Next("Eliminar");
                if (wrapui::Button("Eliminar")) {
                    S.objs.erase(S.objs.begin() + sel_);
                    sel_ = -1;
                    markDirty();
                    o = nullptr;
                }
            }
            if (o && !S.is3d) {  // en 2D el orden de la lista es el orden de capas
                if (wrapui::Button("Subir capa") && sel_ + 1 < (int)S.objs.size()) { std::swap(S.objs[sel_], S.objs[sel_ + 1]); sel_++; markDirty(); }
                wrapui::Next("Bajar capa");
                if (wrapui::Button("Bajar capa") && sel_ > 0) { std::swap(S.objs[sel_], S.objs[sel_ - 1]); sel_--; markDirty(); }
            }
        }
    }
    ImGui::End();
}

// Punto donde un rayo toca el suelo (terreno, suelos o el plano y=0).
bool Editor::groundHit(Scene& S, V3 ro, V3 rd, V3& hit) {
    float best = 1e9f;
    for (auto& o : S.objs) {
        if (!o.alive || o.kind != Kind::Floor) continue;
        float t;
        if (o.tn >= 2) {
            if (rayTerrain(o, ro, rd, 400.f, t) && t < best) best = t;
        } else if (std::fabs(rd.y) > 1e-5f) {
            float ty = o.pos.y + o.scale.y * 0.5f;
            t = (ty - ro.y) / rd.y;
            if (t > 0 && t < best) {
                V3 q = ro + rd * t;
                if (std::fabs(q.x - o.pos.x) <= o.scale.x * 0.5f && std::fabs(q.z - o.pos.z) <= o.scale.z * 0.5f) best = t;
            }
        }
    }
    if (best >= 1e8f && std::fabs(rd.y) > 1e-5f) {
        float t = -ro.y / rd.y;
        if (t > 0 && t < 400.f) best = t;
    }
    if (best >= 1e8f) return false;
    hit = ro + rd * best;
    return true;
}

void Editor::vegStamp(Scene& S, V3 hit) {
    VegLayer& L = S.veg[vegSel_];
    if (vegErase_) {
        float r2 = vegRadius_ * vegRadius_;
        std::vector<float> keep;
        keep.reserve(L.pts.size());
        for (size_t i = 0; i + 4 < L.pts.size(); i += 5) {
            float dx = L.pts[i] - hit.x, dz = L.pts[i + 2] - hit.z;
            if (dx * dx + dz * dz > r2) keep.insert(keep.end(), L.pts.begin() + i, L.pts.begin() + i + 5);
        }
        if (keep.size() != L.pts.size()) { L.pts.swap(keep); L.ver++; markDirty(); }
        return;
    }
    int n = std::max(1, (int)(vegRadius_ * vegRadius_ * 3.f * vegDensity_));
    if (L.pts.size() / 5 + n > 20000) { toast("Esta capa ya tiene muchas matas (20000)"); return; }
    static unsigned st = 2463534242u;
    auto rnd = [&]() { st ^= st << 13; st ^= st >> 17; st ^= st << 5; return (float)(st & 0xFFFFFF) / 16777215.f; };
    Obj* tr = nullptr;
    for (auto& o : S.objs) if (o.alive && o.kind == Kind::Floor && o.tn >= 2) { float lx = std::fabs(hit.x - o.pos.x), lz = std::fabs(hit.z - o.pos.z); if (lx <= o.scale.x * 0.5f && lz <= o.scale.z * 0.5f) { tr = &o; break; } }
    for (int i = 0; i < n; i++) {
        float a = rnd() * 6.2831853f, d = std::sqrt(rnd()) * vegRadius_;
        float x = hit.x + std::cos(a) * d, z = hit.z + std::sin(a) * d;
        float y = hit.y;
        if (tr) y = terrainSurface(*tr, x, z);
        L.pts.insert(L.pts.end(), {x, y, z, 0.75f + 0.5f * rnd(), rnd() * 180.f});
    }
    L.ver++;
    markDirty();
}

void Editor::gndStamp(Scene& S, V3 hit) {
    GroundLayer& L = S.gnd[gndSel_];
    if (gndErase_) {
        float r2 = gndRadius_ * gndRadius_;
        std::vector<float> keep;
        for (size_t i = 0; i + 3 < L.pts.size(); i += 4) {
            float dx = L.pts[i] - hit.x, dz = L.pts[i + 2] - hit.z;
            if (dx * dx + dz * dz > r2) keep.insert(keep.end(), L.pts.begin() + i, L.pts.begin() + i + 4);
        }
        if (keep.size() != L.pts.size()) { L.pts.swap(keep); L.ver++; markDirty(); }
        return;
    }
    if (L.pts.size() / 4 + 6 > 4000) { toast("Esta capa ya tiene muchas pinceladas (4000)"); return; }
    static unsigned st = 88172645u;
    auto rnd = [&]() { st ^= st << 13; st ^= st >> 17; st ^= st << 5; return (float)(st & 0xFFFFFF) / 16777215.f; };
    int n = std::max(1, (int)(gndRadius_ * gndRadius_ * 0.25f));
    for (int i = 0; i < n; i++) {
        float a = rnd() * 6.2831853f, d = std::sqrt(rnd()) * gndRadius_ * 0.6f;
        L.pts.insert(L.pts.end(), {hit.x + std::cos(a) * d, hit.y, hit.z + std::sin(a) * d, gndRadius_ * (0.55f + 0.4f * rnd())});
    }
    L.ver++;
    markDirty();
}

// Lapiz de texturas: arena, pasto, roca, nieve, tierra o una imagen tuya.
bool Editor::gndPanel(Scene& S) {
    bool ch = false;
    float fs = ImGui::GetFontSize();
    ImGui::SeparatorText("Pintar el suelo (lápiz de texturas)");
    if (S.gnd.empty()) ImGui::TextWrapped("Crea una capa, elige la textura (arena, pasto, roca...) y pasa el dedo por el suelo.");
    for (int i = 0; i < (int)S.gnd.size(); i++) {
        ImGui::PushID(1000 + i);
        ImGui::PushStyleColor(ImGuiCol_Button, gndSel_ == i ? ImVec4(0.12f, 0.62f, 0.3f, 1.f) : ImVec4(0.18f, 0.20f, 0.28f, 1.f));
        std::string lab = S.gnd[i].name + " (" + std::to_string(S.gnd[i].pts.size() / 4) + ")";
        if (wrapui::Button(lab.c_str(), ImVec2(ImGui::GetContentRegionAvail().x, fs * 2.2f)) && tapped()) gndSel_ = i;
        ImGui::PopStyleColor();
        ImGui::PopID();
    }
    if (wrapui::Button("+ Capa nueva de suelo", ImVec2(0, fs * 2.2f)) && tapped()) {
        GroundLayer L;
        L.name = "Suelo " + std::to_string(S.gnd.size() + 1);
        S.gnd.push_back(L);
        gndSel_ = (int)S.gnd.size() - 1;
        ch = true;
    }
    if (gndSel_ < 0 || gndSel_ >= (int)S.gnd.size()) { gndSel_ = S.gnd.empty() ? -1 : 0; if (gndSel_ < 0) return ch; }
    GroundLayer& L = S.gnd[gndSel_];
    ch |= textInput("##gn", "Nombre de la capa", L.name, "nombre");
    wrapui::Checkbox("Pintar el suelo (un dedo pinta, dos dedos mueven la cámara)", &gndPaint_);
    if (gndPaint_) vegPaint_ = false;
    {
        int m = gndErase_ ? 1 : 0;
        wrapui::RadioButton("Pintar##g", &m, 0); ImGui::SameLine();
        wrapui::RadioButton("Borrar##g", &m, 1);
        gndErase_ = m == 1;
    }
    numField("Tamaño del lápiz", gndRadius_, 0.5f, 15.f);
    static const char* nm[6] = {"Arena", "Pasto", "Roca", "Nieve", "Tierra", "Mi textura"};
    ImGui::TextUnformatted("Textura");
    for (int k = 0; k < 6; k++) {
        if (k % 3) ImGui::SameLine();
        ImGui::PushStyleColor(ImGuiCol_Button, L.preset == k ? ImVec4(0.12f, 0.62f, 0.3f, 1.f) : ImVec4(0.18f, 0.20f, 0.28f, 1.f));
        ImGui::PushID(2000 + k);
        if (wrapui::Button(nm[k], ImVec2(ImGui::GetContentRegionAvail().x / (3 - k % 3) - 4.f, fs * 2.2f)) && tapped()) { L.preset = k; L.ver++; ch = true; }
        ImGui::PopID();
        ImGui::PopStyleColor();
    }
    if (L.preset == 5) ch |= assetCombo("Imagen del suelo", L.tex, 0, "(elige una imagen)");
    ch |= numField("Repetición de la textura", L.scale, 0.02f, 2.f);
    if (wrapui::Button("Borrar toda la capa##g", ImVec2(0, fs * 2.2f)) && tapped()) {
        S.gnd.erase(S.gnd.begin() + gndSel_);
        gndSel_ = std::min(gndSel_, (int)S.gnd.size() - 1);
        if (S.gnd.empty()) gndPaint_ = false;
        ch = true;
    }
    return ch;
}

// Panel para pintar pasto y plantas sobre el suelo.
bool Editor::vegPanel(Scene& S) {
    bool ch = false;
    float fs = ImGui::GetFontSize();
    ImGui::SeparatorText("Vegetación (pintar pasto con el dedo)");
    if (S.veg.empty()) ImGui::TextWrapped("Crea una capa de pasto, activa \"Pintar\" y pasa el dedo por el suelo.");
    for (int i = 0; i < (int)S.veg.size(); i++) {
        ImGui::PushID(i);
        bool sel = vegSel_ == i;
        ImGui::PushStyleColor(ImGuiCol_Button, sel ? ImVec4(0.12f, 0.62f, 0.3f, 1.f) : ImVec4(0.18f, 0.20f, 0.28f, 1.f));
        std::string lab = S.veg[i].name + " (" + std::to_string(S.veg[i].pts.size() / 5) + ")";
        if (wrapui::Button(lab.c_str(), ImVec2(ImGui::GetContentRegionAvail().x, fs * 2.2f)) && tapped()) vegSel_ = i;
        ImGui::PopStyleColor();
        ImGui::PopID();
    }
    if (wrapui::Button("+ Capa nueva de pasto", ImVec2(0, fs * 2.2f)) && tapped()) {
        VegLayer L;
        L.name = "Pasto " + std::to_string(S.veg.size() + 1);
        S.veg.push_back(L);
        vegSel_ = (int)S.veg.size() - 1;
        ch = true;
    }
    if (vegSel_ < 0 || vegSel_ >= (int)S.veg.size()) { vegSel_ = S.veg.empty() ? -1 : 0; if (vegSel_ < 0) return ch; }
    VegLayer& L = S.veg[vegSel_];
    ch |= textInput("##vn", "Nombre de la capa", L.name, "nombre");
    wrapui::Checkbox("Pintar (un dedo pinta, dos dedos mueven la cámara)", &vegPaint_);
    if (vegPaint_) gndPaint_ = false;
    {
        int m = vegErase_ ? 1 : 0;
        wrapui::RadioButton("Pintar matas", &m, 0); ImGui::SameLine();
        wrapui::RadioButton("Borrar matas", &m, 1);
        vegErase_ = m == 1;
    }
    numField("Tamaño del pincel", vegRadius_, 0.5f, 12.f);
    numField("Cantidad (densidad)", vegDensity_, 0.2f, 4.f);
    static const char* st[4] = {"Realista", "Animado (dibujo)", "Lowpoly", "Mi textura"};
    ImGui::TextUnformatted("Tipo de pasto");
    for (int k = 0; k < 4; k++) {
        if (k % 2) ImGui::SameLine();
        ImGui::PushStyleColor(ImGuiCol_Button, L.style == k ? ImVec4(0.12f, 0.62f, 0.3f, 1.f) : ImVec4(0.18f, 0.20f, 0.28f, 1.f));
        if (wrapui::Button(st[k], ImVec2(ImGui::GetContentRegionAvail().x * (k % 2 ? 1.f : 0.5f) - (k % 2 ? 0.f : 4.f), fs * 2.2f)) && tapped()) {
            L.style = k;
            if (k == 3) { for (int q = 0; q < 3; q++) L.col[q] = L.col2[q] = 1.f; }
            else if (k == 1) { float a[3] = {0.20f, 0.65f, 0.25f}, b[3] = {0.55f, 0.92f, 0.30f}; for (int q = 0; q < 3; q++) { L.col[q] = a[q]; L.col2[q] = b[q]; } }
            else { float a[3] = {0.28f, 0.50f, 0.16f}, b[3] = {0.62f, 0.78f, 0.30f}; for (int q = 0; q < 3; q++) { L.col[q] = a[q]; L.col2[q] = b[q]; } }
            L.ver++;
            ch = true;
        }
        ImGui::PopStyleColor();
    }
    if (L.style == 3) ch |= assetCombo("Textura del pasto (con transparencia)", L.tex, 0, "(elige una imagen png)");
    ch |= wrapui::ColorEdit3(L.style == 3 ? "Tinte base" : "Color de la base", L.col);
    ch |= wrapui::ColorEdit3(L.style == 3 ? "Tinte punta" : "Color de la punta", L.col2);
    bool g2 = false;
    g2 |= numField("Altura", L.h, 0.1f, 3.f);
    g2 |= numField("Ancho", L.w, 0.1f, 2.f);
    ch |= numField("Movimiento con el viento", L.sway, 0.f, 2.f);
    if (g2) { L.ver++; ch = true; }
    if (wrapui::Button("Borrar toda la capa", ImVec2(0, fs * 2.2f)) && tapped()) {
        S.veg.erase(S.veg.begin() + vegSel_);
        vegSel_ = std::min(vegSel_, (int)S.veg.size() - 1);
        if (S.veg.empty()) vegPaint_ = false;
        ch = true;
    }
    return ch;
}

void Editor::worldWin() {
    if (!showWorld || !hasScene()) return;
    float fs = ImGui::GetFontSize(), top = ImGui::GetFrameHeight() + 6.f;
    placeWindow(w_ - fs * 22.f - 6.f, top, fs * 22.f, h_ * 0.8f);
    if (wrapui::Begin("Mundo", &showWorld, dockFlags())) {
        wrapui::CloseBar(&showWorld);
        if (gDock.on) dragScroll();
        Scene& S = scene();
        bool ch = false;
        ch |= textInput("##sn", "Nombre de la escena", S.name, "nombre de la escena");
        bool was3d = S.is3d;
        if (wrapui::Checkbox("Escena 3D (si no, es 2D)", &S.is3d)) {
            ch = true;
            if (!S.is3d)  // en 2D no hay jugador
                S.objs.erase(std::remove_if(S.objs.begin(), S.objs.end(), [](const Obj& x) { return x.kind == Kind::Player; }), S.objs.end());
            sel_ = -1;
            if (was3d != S.is3d) resetView();
        }
        if (S.is3d) {
            ImGui::SeparatorText("Cielo");
            ch |= wrapui::ColorEdit3("Arriba", S.skyTop);
            ch |= wrapui::ColorEdit3("Horizonte y niebla", S.skyBot);
            ImGui::SeparatorText("Sol y luz");
            V3 d = norm(S.sunDir);
            float el = std::asin(std::max(-1.f, std::min(1.f, -d.y))), az = std::atan2(-d.x, -d.z);
            bool sc = false;
            sc |= ImGui::SliderAngle("Altura del sol", &el, 5.f, 89.f);
            sc |= ImGui::SliderAngle("Dirección", &az, -180.f, 180.f);
            if (sc) {
                S.sunDir = V3{-std::cos(el) * std::sin(az), -std::sin(el), -std::cos(el) * std::cos(az)};
                ch = true;
            }
            ch |= wrapui::ColorEdit3("Color del sol", S.sun);
            ch |= numField("Luz ambiente", S.ambient, 0.f, 1.f);
            ch |= wrapui::SliderFloat("Oscuridad de las sombras (izq = claras, der = oscuras)", &S.shadowAmt, 0.f, 1.6f);
            ch |= numField("Niebla", S.fog, 0.f, 0.15f, "%.3f");
            {
                bool own = S.fogMode == 1;
                if (wrapui::Checkbox("Color propio para la niebla", &own)) { S.fogMode = own ? 1 : 0; ch = true; }
                if (own) ch |= wrapui::ColorEdit3("Color de la niebla", S.fogCol);
            }
            ImGui::SeparatorText("Calidad general");
            for (int k = 0; k < 3; k++) {
                if (k) ImGui::SameLine();
                if (wrapui::RadioButton(kQualityNames[k], edit_.proj.quality == k)) { edit_.proj.quality = k; ch = true; }
            }
            ImGui::SeparatorText("Ambientación (color del mundo)");
            for (int k = 0; k < 3; k++) {
                if (k) ImGui::SameLine();
                if (wrapui::RadioButton(kToneNames[k], S.tone == k)) { S.tone = k; ch = true; }
            }
            ImGui::SeparatorText("Clima y niebla del mundo");
            for (int k = 0; k < 6; k++) {
                if (k % 3) ImGui::SameLine();
                if (wrapui::RadioButton(kAtmoNames[k], S.atmo == k)) {
                    S.atmo = k;
                    float a;
                    atmoDefaults(k, S.atmoCol, a);
                    if (k) S.atmoAmt = a;
                    ch = true;
                }
            }
            if (S.atmo > 0) {
                ch |= wrapui::SliderFloat("Cantidad (hasta 3 = muchísimo)", &S.atmoAmt, 0.f, 3.f);
                ch |= wrapui::ColorEdit3("Color", S.atmoCol);
                ImGui::TextUnformatted("Diseño");
                if (wrapui::RadioButton("Clásico", S.atmoStyle == 0)) { S.atmoStyle = 0; ch = true; }
                ImGui::SameLine();
                if (wrapui::RadioButton("Realista", S.atmoStyle == 1)) { S.atmoStyle = 1; ch = true; }
            }
            ImGui::SeparatorText("Mar / agua (opcional)");
            ch |= wrapui::Checkbox("Poner agua en la escena", &S.sea);
            if (S.sea) {
                ch |= stepper("Altura del agua", S.seaY, 0.5f);
                ch |= wrapui::SliderFloat("Transparencia", &S.seaAlpha, 0.2f, 1.f);
                ch |= wrapui::ColorEdit3("Color del agua", S.seaCol);
            }
            ch |= gndPanel(S);
            ch |= vegPanel(S);
            ImGui::SeparatorText("Modo RTX (opcional)");
            ch |= wrapui::Checkbox("Activar RTX (sombras suaves, brillos y reflejos extra)", &edit_.proj.rtx);
            ImGui::TextDisabled("Es una imitación visual: pide más al teléfono. Desactivado por defecto.");
            ImGui::SeparatorText("Jugador");
            ImGui::TextWrapped("El jugador es el objeto verde \"Jugador\": tócalo en la escena y arrástralo para moverlo; sus opciones (cámara, arma, proyectil) salen en Propiedades.");
            if (wrapui::Button("Seleccionar al jugador")) { sel_ = playerIndex(S); showProps = true; }
            wrapui::Next("Jugador = centro de la vista");
            if (wrapui::Button("Jugador = centro de la vista")) {
                int pi = playerIndex(S);
                if (pi >= 0) { S.objs[pi].pos = V3{target_.x, 0.9f, target_.z}; ch = true; }
            }
        } else {
            ch |= wrapui::ColorEdit3("Fondo", S.skyBot);
        }
        ImGui::SeparatorText("Capa de la cámara (efectos e imágenes fijas)");
        ch |= layerPanel(S);
        ImGui::Separator();
        if (edit_.proj.scenes.size() > 1 && wrapui::Button("Borrar esta escena")) ImGui::OpenPopup("delscene");
        if (ImGui::BeginPopup("delscene")) {
            ImGui::TextUnformatted("¿Borrar la escena y todos sus objetos?");
            if (wrapui::Button("Sí, borrar")) {
                edit_.proj.scenes.erase(edit_.proj.scenes.begin() + sceneIdx_);
                setScene(std::min(sceneIdx_, (int)edit_.proj.scenes.size() - 1));
                ch = true;
                ImGui::CloseCurrentPopup();
            }
            wrapui::Next("Cancelar");
            if (wrapui::Button("Cancelar")) ImGui::CloseCurrentPopup();
            ImGui::EndPopup();
        }
        if (ch) markDirty();
    }
    ImGui::End();
}

void Editor::hudWin(Renderer*) {
    if (!showHud) return;
    Project& P = edit_.proj;
    float fs = ImGui::GetFontSize(), top = ImGui::GetFrameHeight() + 6.f;
    placeWindow(w_ - fs * 23.f - 6.f, top, fs * 23.f, h_ * 0.85f);
    if (wrapui::Begin("Botones y arma", &showHud, dockFlags())) {
        wrapui::CloseBar(&showHud);
        if (gDock.on) dragScroll();
        bool ch = false;
        ImGui::SeparatorText("Botones en pantalla (escenas 3D)");
        int mode = P.hudDefault ? 0 : (P.hud.empty() ? 2 : 1);
        int nm = mode;
        wrapui::RadioButton("Por defecto: saltar y disparar", &nm, 0);
        wrapui::RadioButton("Personalizados", &nm, 1);
        wrapui::RadioButton("Ninguno (en blanco)", &nm, 2);
        if (nm != mode) {
            if (nm == 0) P.hudDefault = true;
            else if (nm == 1) { P.hudDefault = false; if (P.hud.empty()) P.hud = defaultHud(); }
            else { P.hudDefault = false; P.hud.clear(); }
            ch = true;
        }
        if (!P.hudDefault && !P.hud.empty()) {
            int del = -1;
            for (int i = 0; i < (int)P.hud.size(); i++) {
                HudBtn& b = P.hud[i];
                ImGui::PushID(i);
                if (ImGui::TreeNodeEx(b.label.c_str(), ImGuiTreeNodeFlags_DefaultOpen)) {
                    ch |= textInput("##bl", "Texto del botón", b.label, "texto");
                    int a = (int)b.act;
                    if (ImGui::Combo("Acción", &a, "Nada\0Saltar\0Disparar\0Interactuar\0Solo bloques (programable)\0")) { b.act = (HudAct)a; ch = true; }
                    ch |= numField("Posición X", b.x, 0.f, 1.f);
                    ch |= numField("Posición Y", b.y, 0.f, 1.f);
                    ch |= numField("Tamaño", b.r, 0.03f, 0.25f);
                    ch |= wrapui::ColorEdit3("Color", b.color);
                    if (wrapui::Button("Quitar botón")) del = i;
                    ImGui::TreePop();
                }
                ImGui::PopID();
            }
            if (del >= 0) { P.hud.erase(P.hud.begin() + del); ch = true; }
        }
        if (!P.hudDefault) {
            if (wrapui::Button("+ Añadir botón")) {
                HudBtn b;
                b.label = "Botón";
                b.act = HudAct::Script;
                P.hud.push_back(b);
                ch = true;
            }
            wrapui::Next("Copiar los de por defecto");
            if (wrapui::Button("Copiar los de por defecto")) { P.hud = defaultHud(); ch = true; }
        }
        ImGui::SeparatorText("Arma del jugador");
        ch |= weaponPanel();
        ImGui::SeparatorText("Pantalla");
        ch |= wrapui::Checkbox("Mostrar variables (contadores)", &P.showVars);
        ImGui::TextDisabled("Para programar un botón: Acción \"Solo bloques\" y en un objeto usa el evento \"Cuando se presione el botón\" con su texto.");
        ImGui::TextDisabled("La vista previa se ve sobre la escena 3D. Los disparos activan el evento \"Al recibir un disparo\".");
        if (ch) markDirty();
    }
    ImGui::End();
}

void Editor::assetsWin() {
    paintWin();
    animWin();
    exportWin();
    if (!showAssets) return;
    float fs = ImGui::GetFontSize(), top = ImGui::GetFrameHeight() + 6.f;
    ImGui::SetNextWindowPos(ImVec2(w_ * 0.01f, top));
    ImGui::SetNextWindowSize(ImVec2(w_ * 0.98f, h_ - top - h_ * 0.01f));
    if (wrapui::Begin("Archivos", &showAssets, ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoScrollbar |
                                                  ImGuiWindowFlags_NoScrollWithMouse | ImGuiWindowFlags_NoSavedSettings)) {
        // ---- parte fija: acciones y pestañas
        wrapui::CloseBar(&showAssets);
        if (wrapui::Button("Importar archivo...", ImVec2(0, fs * 2.2f))) { if (host_.pickFile) host_.pickFile(); }
        wrapui::Next("Dibujar textura");
        if (wrapui::Button("Dibujar textura", ImVec2(0, fs * 2.2f))) openPaint("");
        size_t total = 0;
        for (auto& a : edit_.proj.assets) total += a.second.size();
        ImGui::SameLine();
        ImGui::Text("Total: %.1f MB", total / (1024.0 * 1024.0));
        static int tab = 0;
        const char* names[5] = {"Imágenes", "Modelos 3D", "Sonidos", "Animaciones", "Videos"};
        float tw = ImGui::GetContentRegionAvail().x / 5.f;
        for (int i = 0; i < 5; i++) {
            if (i) ImGui::SameLine(0, 0);
            ImGui::PushStyleColor(ImGuiCol_Button, tab == i ? ImVec4(0.12f, 0.62f, 0.56f, 1.f) : ImVec4(0.18f, 0.20f, 0.28f, 1.f));
            if (wrapui::Button(names[i], ImVec2(tw, fs * 2.4f)) && tapped()) tab = i;
            ImGui::PopStyleColor();
        }
        // ---- contenido que se desliza con el dedo
        wrapui::BeginChild("##assetgrid", ImVec2(0, 0), false, ImGuiWindowFlags_NoScrollbar);
        dragScroll();
        std::string del;
        std::vector<std::string> items;
        if (tab == 3) {
            for (auto& a : edit_.proj.assets) if (ends(a.first, ".fanim") || ends(a.first, ".frig")) items.push_back(a.first);
        } else if (tab == 4) {
            for (auto& a : edit_.proj.assets) if (isVideoName(a.first)) items.push_back(a.first);
        } else items = assetsOf(tab == 0 ? 0 : tab == 1 ? 2 : 1);
        float cell = fs * 8.f, gap = fs * 0.7f;
        int cols = std::max(1, (int)((ImGui::GetContentRegionAvail().x + gap) / (cell + gap)));
        int n = 0;
        for (auto& it : items) {
            if (n % cols) ImGui::SameLine(0, gap);
            n++;
            ImGui::PushID(it.c_str());
            ImGui::BeginGroup();
            if (tab == 0 || tab == 1) assetThumb(it, tab == 0 ? 0 : 2, cell);
            else {
                ImVec2 p = ImGui::GetCursorScreenPos();
                ImGui::Dummy(ImVec2(cell, cell));
                ImGui::GetWindowDrawList()->AddRectFilled(p, ImVec2(p.x + cell, p.y + cell), IM_COL32(40, 48, 66, 255), 8.f);
                ImGui::GetWindowDrawList()->AddText(ImVec2(p.x + fs, p.y + cell * 0.4f), IM_COL32(220, 230, 250, 255), tab == 2 ? "SONIDO" : tab == 4 ? "VIDEO" : "ANIM");
            }
            ImGui::PushTextWrapPos(ImGui::GetCursorPosX() + cell);
            ImGui::TextUnformatted(shorten(it, 22).c_str());
            ImGui::PopTextWrapPos();
            ImGui::TextDisabled("%.0f KB", edit_.proj.assets[it].size() / 1024.0);
            if (tab == 0 && ImGui::SmallButton("Dibujar")) openPaint(it);
            if (tab == 2 && audio_) { if (ImGui::SmallButton("Probar")) audio_->play(it); }
            if (tab == 3 && ends(it, ".fanim") && ImGui::SmallButton("Editar")) openAnimEditor(it);
            if ((tab == 0 && true) || tab == 2 || tab == 3) ImGui::SameLine();
            if (ImGui::SmallButton("Borrar")) del = it;
            ImGui::EndGroup();
            ImGui::PopID();
        }
        if (tab == 3) {
            ImGui::NewLine();
            if (wrapui::Button("Abrir editor de animación", ImVec2(0, fs * 2.4f))) openAnimEditor("");
            ImGui::TextDisabled("También puedes importar animaciones de archivos .glb/.gltf/.fbx con \"Importar archivo\".");
        }
        if (items.empty()) ImGui::TextDisabled("Nada en esta pestaña todavía.");
        ImGui::Dummy(ImVec2(1, fs * 3.f));
        ImGui::EndChild();
        if (!del.empty()) {
            edit_.proj.assets.erase(del);
            if (rend_) rend_->forget(del);
            if (audio_) audio_->setAssets(edit_.proj.assets);
            markDirty();
        }
    }
    ImGui::End();
}

}  // namespace forge
