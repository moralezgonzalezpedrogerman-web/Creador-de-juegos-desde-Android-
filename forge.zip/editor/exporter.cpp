// Exportar el juego: paquete para compilar el APK en GitHub, .exe y paquetes de respaldo.
#include "editor.h"
#include "fsutil.h"
#include "pack.h"
#include "zip.h"
#include "imgui.h"
#include "stb_image.h"
#include "stb_image_write.h"
#include <algorithm>
#include <cmath>

namespace forge {

static void pngSink(void* ctx, void* data, int n) {
    auto* v = (std::vector<uint8_t>*)ctx;
    v->insert(v->end(), (uint8_t*)data, (uint8_t*)data + n);
}

// Convierte la imagen del icono a un PNG cuadrado de size x size (recorta al centro y ajusta).
bool makeIconPng(const std::vector<uint8_t>& src, int size, std::vector<uint8_t>& out) {
    int w, h, c;
    stbi_set_flip_vertically_on_load(0);
    unsigned char* d = stbi_load_from_memory(src.data(), (int)src.size(), &w, &h, &c, 4);
    if (!d) return false;
    int side = std::min(w, h), ox = (w - side) / 2, oy = (h - side) / 2;
    std::vector<uint8_t> px((size_t)size * size * 4);
    for (int y = 0; y < size; y++)
        for (int x = 0; x < size; x++) {
            float fx = ox + (x + 0.5f) * side / size - 0.5f, fy = oy + (y + 0.5f) * side / size - 0.5f;
            int x0 = std::max(0, std::min(w - 1, (int)std::floor(fx))), y0 = std::max(0, std::min(h - 1, (int)std::floor(fy)));
            int x1 = std::min(w - 1, x0 + 1), y1 = std::min(h - 1, y0 + 1);
            float tx = std::max(0.f, std::min(1.f, fx - x0)), ty = std::max(0.f, std::min(1.f, fy - y0));
            for (int k = 0; k < 4; k++) {
                float a = d[((size_t)y0 * w + x0) * 4 + k] * (1 - tx) + d[((size_t)y0 * w + x1) * 4 + k] * tx;
                float b = d[((size_t)y1 * w + x0) * 4 + k] * (1 - tx) + d[((size_t)y1 * w + x1) * 4 + k] * tx;
                px[((size_t)y * size + x) * 4 + k] = (uint8_t)(a * (1 - ty) + b * ty + 0.5f);
            }
        }
    stbi_image_free(d);
    out.clear();
    return stbi_write_png_to_func(pngSink, &out, size, size, 4, px.data(), size * 4) != 0;
}

// Nombre seguro para carpeta / archivo.
std::string exportSlug(const std::string& s) {
    std::string o;
    for (unsigned char c : s) {
        if (std::isalnum(c)) o += (char)std::tolower(c);
        else if (c == ' ' || c == '-' || c == '_') o += '_';
    }
    return o.empty() ? "mi_juego" : o;
}

// Un paquete de Android valido: segmentos separados por puntos, empiezan con letra, solo a-z 0-9 _
bool validAppId(const std::string& id) {
    int seg = 0;
    bool start = true;
    for (unsigned char c : id) {
        if (c == '.') { if (start) return false; start = true; seg++; continue; }
        if (start && !std::isalpha(c)) return false;
        if (!(std::islower(c) || std::isdigit(c) || c == '_')) return false;
        start = false;
    }
    return !start && seg >= 1;
}

static std::string xmlSafe(std::string s) {
    std::string o;
    for (char c : s) {
        if (c == '&' || c == '<' || c == '>' || c == '"' || c == '\'' || c == '\n' || c == '\r') o += ' ';
        else o += c;
    }
    return o;
}

// Zip con todo lo necesario para que GitHub Actions compile el APK de este juego.
bool Editor::buildApkPackage(std::vector<uint8_t>& out, std::string& err) {
    ExportCfg& e = edit_.proj.exportCfg;
    if (!validAppId(e.appId)) {
        err = "El nombre del paquete no es válido. Ejemplo: com.tuestudio.tujuego (minúsculas, números y puntos)";
        return false;
    }
    std::vector<uint8_t> pk;
    buildPack(pk);
    std::string slug = exportSlug(name_);
    std::string dir = "games/" + slug + "/";
    std::string name = e.appName.empty() ? name_ : e.appName;
    static const char* orients[3] = {"sensorLandscape", "sensorPortrait", "fullSensor"};
    std::string props = "appName=" + xmlSafe(name) + "\nappId=" + e.appId + "\nverName=" + xmlSafe(e.verName) + "\nverCode=" +
                        std::to_string(std::max(1, e.verCode)) + "\norient=" + orients[std::max(0, std::min(2, e.orient))] + "\n";
    std::vector<std::pair<std::string, std::vector<uint8_t>>> files;
    files.push_back({dir + "game.pack", pk});
    files.push_back({dir + "apk.properties", std::vector<uint8_t>(props.begin(), props.end())});
    bool hasIcon = false;
    if (!e.icon.empty()) {
        auto a = edit_.proj.assets.find(e.icon);
        std::vector<uint8_t> png;
        if (a != edit_.proj.assets.end() && makeIconPng(a->second, 192, png)) { files.push_back({dir + "icon.png", png}); hasIcon = true; }
        else { err = "No se pudo usar la imagen del icono (usa un png o jpg)"; return false; }
    }
    std::string readme =
        "PASOS PARA CREAR EL APK DE \"" + name + "\"\n\n"
        "1. Descomprime este zip y sube la carpeta games/" + slug + " a tu repositorio de GitHub (junto a forge.zip y build.yml).\n"
        "2. En GitHub entra a Actions > build > Run workflow.\n"
        "3. En el cuadro \"game_dir\" escribe:  games/" + slug + "\n"
        "4. Cuando termine, baja el archivo \"game-apk\" de la ejecución: dentro está el .apk listo para instalar.\n\n"
        "Nombre de la app: " + name + "\nPaquete: " + e.appId + "\nVersión: " + e.verName + " (" + std::to_string(e.verCode) + ")\n" +
        (hasIcon ? "Icono: incluido\n" : "Icono: el de P-Maker (no elegiste uno)\n");
    files.push_back({"LEEME_APK_" + slug + ".txt", std::vector<uint8_t>(readme.begin(), readme.end())});
    return zipStore(files, out);
}

// Zip con el juego listo para compilar o abrir despues en Windows.
bool Editor::buildExePackage(std::vector<uint8_t>& out, std::string& err) {
    (void)err;
    std::vector<uint8_t> pk;
    buildPack(pk);
    ExportCfg& e = edit_.proj.exportCfg;
    std::string slug = exportSlug(e.exeName.empty() ? name_ : e.exeName);
    std::string readme =
        "JUEGO PARA WINDOWS: " + name_ + "\n\n"
        "game.pack es tu juego completo.\n"
        "- Para jugarlo: abre forge_runtime.exe (se descarga de GitHub Actions > build > forge_runtime) pasándole el archivo:\n"
        "      forge_runtime.exe game.pack\n"
        "- Para tener un .exe de un solo archivo: en P-Maker abre este proyecto > Exportar juego > \"Crear .exe\".\n";
    std::vector<std::pair<std::string, std::vector<uint8_t>>> files;
    files.push_back({slug + "/game.pack", pk});
    files.push_back({slug + "/LEEME.txt", std::vector<uint8_t>(readme.begin(), readme.end())});
    return zipStore(files, out);
}

void Editor::exportWin() {
    if (!showExport_) return;
    ExportCfg& e = edit_.proj.exportCfg;
    float fs = ImGui::GetFontSize();
    ImGui::SetNextWindowPos(ImVec2(w_ * 0.5f, 4.f), ImGuiCond_Appearing, ImVec2(0.5f, 0.f));
    ImGui::SetNextWindowSize(ImVec2(std::min((float)w_ - 8.f, fs * 28.f), (float)h_ - 8.f), ImGuiCond_Appearing);
    if (!ImGui::Begin("Exportar juego", &showExport_)) { ImGui::End(); return; }
    bool ch = false;
    if (ImGui::CollapsingHeader("Android (APK)", ImGuiTreeNodeFlags_DefaultOpen)) {
        ch |= textInput("##an", "Nombre de la app", e.appName, name_.c_str());
        ch |= textInput("##aid", "Paquete (com.tuestudio.tujuego)", e.appId, "com.mijuego.app");
        if (!validAppId(e.appId)) ImGui::TextColored(ImVec4(1.f, 0.5f, 0.4f, 1.f), "Usa solo minúsculas, números, _ y puntos. Ej: com.juan.aventura");
        ch |= textInput("##av", "Versión (texto)", e.verName, "1.0");
        float vc = (float)e.verCode;
        if (numField("Número de versión", vc, 1.f, 9999.f, "%.0f")) { e.verCode = (int)vc; ch = true; }
        int o = e.orient;
        ImGui::TextUnformatted("Pantalla:");
        ch |= ImGui::RadioButton("Horizontal", &o, 0); ImGui::SameLine();
        ch |= ImGui::RadioButton("Vertical", &o, 1); ImGui::SameLine();
        ch |= ImGui::RadioButton("Automática", &o, 2);
        e.orient = o;
        ch |= assetCombo("Icono de la app", e.icon, 0, "(icono de P-Maker)");
        ImGui::TextDisabled("Los botones del juego se editan en Ajustes del juego > Botones.");
        if (ImGui::Button("Abrir los botones del juego")) showHud = true;
        ImGui::Spacing();
        if (host_.buildApk) {  // Android: APK ya compilado dentro del telefono
            static bool busy = false;
            static std::string result;
            if (busy && host_.buildApkStatus) {
                std::string st = host_.buildApkStatus();
                if (!st.empty()) { result = st; busy = false; }
            }
            ImGui::BeginDisabled(busy);
            if (ImGui::Button("Crear APK instalable (compilado)") && !busy) {
                if (!validAppId(e.appId)) toast("El nombre del paquete no es válido");
                else {
                    if (dirty_) saveProject();
                    std::vector<uint8_t> pk;
                    buildPack(pk);
                    std::string dir = host_.dataDir + "/export";
                    fs::mkdirs(dir);
                    std::string slug = exportSlug(name_), packPath = dir + "/" + slug + "_game.pack", iconPath;
                    bool ok = fs::write(packPath, pk.data(), pk.size());
                    if (ok && !e.icon.empty()) {
                        auto a = edit_.proj.assets.find(e.icon);
                        std::vector<uint8_t> png;
                        if (a != edit_.proj.assets.end() && makeIconPng(a->second, 192, png)) {
                            iconPath = dir + "/" + slug + "_icon.png";
                            ok = fs::write(iconPath, png.data(), png.size());
                        } else { toast("No se pudo usar la imagen del icono (usa un png o jpg)"); ok = false; }
                    }
                    if (ok) {
                        std::string label = xmlSafe(e.appName.empty() ? name_ : e.appName);
                        host_.buildApk(packPath, label, e.appId, iconPath, xmlSafe(e.verName), slug + ".apk", e.orient, std::max(1, e.verCode));
                        busy = true;
                        result.clear();
                    } else toast("No se pudo preparar el juego para el APK");
                }
            }
            ImGui::EndDisabled();
            if (busy) ImGui::TextUnformatted("Creando el APK... (puede tardar un minuto, no cierres la app)");
            else if (result.compare(0, 3, "OK:") == 0) {
                std::string path = result.substr(3), note;
                size_t bar = path.find('|');
                if (bar != std::string::npos) { note = path.substr(bar + 1); path = path.substr(0, bar); }
                ImGui::TextColored(ImVec4(0.4f, 0.9f, 0.5f, 1.f), "APK listo: %s", path.c_str());
                if (!note.empty()) ImGui::TextWrapped("%s", note.c_str());
                if (host_.installApk && ImGui::Button("Instalar ahora")) host_.installApk(path);
                if (host_.installApk) ImGui::SameLine();
                if (host_.saveOut && ImGui::Button("Guardar una copia en...")) host_.saveOut(exportSlug(name_) + ".apk", path);
            } else if (result.compare(0, 6, "ERROR:") == 0) {
                ImGui::TextColored(ImVec4(1.f, 0.5f, 0.4f, 1.f), "No se pudo crear el APK: %s", result.c_str() + 6);
                ImGui::TextWrapped("Puedes usar \"Exportar sin compilar\" (abajo) y compilarlo en GitHub.");
            }
            ImGui::TextWrapped("Crea el .apk dentro del teléfono, firmado con la clave de P-Maker, listo para instalar. El icono no cambia si la plantilla no lo trae.");
            ImGui::Separator();
        }
        if (ImGui::Button(host_.buildApk ? "Exportar sin compilar (para GitHub)" : "Crear paquete para compilar el APK (.zip)")) {
            if (dirty_) saveProject();
            std::vector<uint8_t> out;
            std::string err;
            if (!buildApkPackage(out, err)) toast(err);
            else {
                std::string dir = host_.dataDir + "/export";
                fs::mkdirs(dir);
                std::string fn = "APK_" + exportSlug(name_) + ".zip", path = dir + "/" + fn;
                if (fs::write(path, out.data(), out.size())) {
                    if (host_.saveOut) host_.saveOut(fn, path);
                    toast("Elige dónde guardar el paquete del APK");
                } else toast("No se pudo escribir el paquete");
            }
        }
        ImGui::TextWrapped("Este zip trae tu juego y la configuración. Súbelo a tu repositorio y GitHub compila el .apk listo para instalar (instrucciones dentro del zip).");
    }
    if (ImGui::CollapsingHeader("Windows (EXE)", ImGuiTreeNodeFlags_DefaultOpen)) {
        ch |= textInput("##en", "Nombre del archivo .exe", e.exeName, name_.c_str());
        ch |= textInput("##wt", "Título de la ventana", e.winTitle, name_.c_str());
        ch |= ImGui::Checkbox("Pantalla completa", &e.fullscreen);
        if (!e.fullscreen) {
            float ww = (float)e.winW, wh = (float)e.winH;
            if (numField("Ancho de ventana", ww, 320.f, 3840.f, "%.0f")) { e.winW = (int)ww; ch = true; }
            if (numField("Alto de ventana", wh, 240.f, 2160.f, "%.0f")) { e.winH = (int)wh; ch = true; }
        }
        ImGui::TextDisabled("El icono del .exe no se puede cambiar desde la app todavía.");
        if (ImGui::Button("Crear .exe ya compilado")) doExportExe();
        ImGui::SameLine();
        if (ImGui::Button("Paquete para compilar después (.zip)")) {
            if (dirty_) saveProject();
            std::vector<uint8_t> out;
            std::string err;
            buildExePackage(out, err);
            std::string dir = host_.dataDir + "/export";
            fs::mkdirs(dir);
            std::string fn = "EXE_" + exportSlug(name_) + ".zip", path = dir + "/" + fn;
            if (fs::write(path, out.data(), out.size())) {
                if (host_.saveOut) host_.saveOut(fn, path);
                toast("Elige dónde guardar el paquete");
            } else toast("No se pudo escribir el paquete");
        }
    }
    if (ImGui::CollapsingHeader("Copia del proyecto (.pack)")) {
        ImGui::TextWrapped("Sirve para guardar o compartir tu proyecto. Se puede volver a abrir desde la lista de proyectos.");
        if (ImGui::Button("Exportar .pack")) doExportPack();
    }
    if (ch) markDirty();
    ImGui::End();
}

}  // namespace forge
