#pragma once
#include <ctime>
#include "audio.h"
#include "playview.h"
#include "renderer.h"
#include <functional>
#include <set>
#include <string>
#include <vector>

namespace forge {

// Servicios que la plataforma ofrece al editor.
struct EditorHost {
    std::string dataDir;  // carpeta privada: proyectos y exportaciones
    std::function<void()> pickFile;  // abre el selector; el archivo llega a Editor::onFile
    std::function<void(const std::string& displayName, const std::string& path)> saveOut;  // copiar a donde elija el usuario
    std::function<bool(std::vector<uint8_t>&)> loadRuntime;  // forge_runtime.exe (para exportar)
    std::function<void(const std::string& title, const std::string& initial)> prompt;  // cuadro de texto nativo (Android)
    std::function<void(float)> vibrate;                      // segundos
    std::function<void(const std::string&)> speak;           // texto a voz
    std::function<void(bool)> flash;                         // linterna
};

// Exportacion (editor/exporter.cpp)
bool makeIconPng(const std::vector<uint8_t>& src, int size, std::vector<uint8_t>& out);
std::string exportSlug(const std::string& s);
bool validAppId(const std::string& id);

// Tema visual de toda la aplicacion (colores, bordes redondeados, espacios). Llamar antes de ScaleAllSizes.
void applyTheme();

enum class Screen { Projects, Edit, Play };
// Dentro de un proyecto (como Pocket Code): lista de escenas -> escena (fondo y objetos) -> objeto (pestañas) -> editor visual.
enum class Page { Scenes, SceneHome, Object, Viewport };

class Editor {
public:
    explicit Editor(EditorHost h) : host_(std::move(h)) {}
    void init(Audio* audio);

    // Una vez por frame, con ImGui::NewFrame() ya llamado. r puede ser null (pruebas).
    void frame(Renderer* r, int w, int h, float dt);
    bool importPack(const std::string& fileName, const std::vector<uint8_t>& data);
    void onFile(const std::string& name, std::vector<uint8_t> data);  // archivo elegido por el usuario
    void onText(const std::string& text, bool ok);                    // respuesta del cuadro de texto nativo
    PlayControls& controls() { return play_.ctl; }

    // --- proyectos
    bool newProject(const std::string& name, bool demo);
    bool openProject(const std::string& name);
    bool saveProject();
    void closeProject();
    bool buildPack(std::vector<uint8_t>& out);
    bool buildExe(std::vector<uint8_t>& out, std::string& err);

    // --- edicion (tambien usados por las pruebas)
    void addObject(Kind k, const std::string& modelName = "");
    void addScene(bool is3d);
    void select(int i) { sel_ = i; }
    void startPlay();
    void stopPlay();
    Screen screen() const { return screen_; }
    Project& project() { return edit_.proj; }
    PlayView& play() { return play_; }
    int sceneIndex() const { return sceneIdx_; }
    void setScene(int i);
    int selected() const { return sel_; }
    const std::vector<std::string>& projectNames() const { return projList_; }
    bool dirty() const { return dirty_; }

    // Ventanas visibles (publico para poder activarlas desde pruebas).
    bool showObjs = false, showProps = true, showWorld = false, showHud = false, showAssets = false;
    Page page() const { return page_; }
    void setPage(Page p) { page_ = p; }
    void openObject(int i) { sel_ = i; page_ = Page::Object; tab_ = 0; }
    int tab() const { return tab_; }
    void addObjectPreset(int id) { addPreset(id); }
    void openPalette() { pal_ = -1; }
    void openFormula(int blk, int field, const std::string& cur) { fe_.open = true; fe_.blk = blk; fe_.field = field; fe_.buf = cur; }
    void openChoose(int blk) { te_.open = true; te_.blk = blk; }
    void setTab(int t) { tab_ = t; }
    // Bloques (usados tambien por las pruebas)
    int addBlock(Obj& o, Op op);                       // agrega con sus cierres (si, bucles); devuelve el indice
    static bool blockRange(const std::vector<Block>& B, int i, int& end);  // [i, end) que se mueve junto con el bloque i
    static bool moveRange(std::vector<Block>& B, int from, int to);       // mueve el grupo i antes del bloque "to"

private:
    EditorHost host_;
    Audio* audio_ = nullptr;
    Screen screen_ = Screen::Projects;
    Game edit_;                 // el proyecto en edicion (edit_.proj)
    PlayView play_;
    std::string name_, newName_ = "mi_juego";
    std::vector<std::string> projList_;
    std::set<std::string> assetDirty_;
    int sceneIdx_ = 0, sel_ = -1;
    bool dirty_ = false;
    float snap_ = 0.25f;
    int w_ = 1, h_ = 1;

    // mensaje temporal
    std::string toast_;
    float toastT_ = 0;
    void toast(const std::string& t) { toast_ = t; toastT_ = 3.5f; }

    // camara del editor
    float yaw_ = 0.6f, pitch_ = 0.55f, dist_ = 14.f;
    V3 target_;
    float cx_ = 0, cy_ = 0, h2d_ = kView2DHeight;

    // gestos
    int prevN_ = 0;
    bool gestOk_ = false, dragObj_ = false;
    float lastX_ = 0, lastY_ = 0, lastDist_ = 0, moveAcc_ = 0;
    Page page_ = Page::Scenes;
    int tab_ = 0;
    float dragAcc_ = 0;
    V3 grab_;

    // ayudantes
    Scene& scene() { return edit_.proj.scenes[sceneIdx_]; }
    bool hasScene() const { return sceneIdx_ >= 0 && sceneIdx_ < (int)edit_.proj.scenes.size(); }
    Obj* selObj();
    std::string uniqueName(const std::string& base);
    void listProjects();
    void resetView();
    EditorView view() const;
    void rayAt(float x, float y, const EditorView& ev, V3& o, V3& d) const;
    int pick(float x, float y, const EditorView& ev);
    void gestures();
    std::vector<std::string> assetsOf(int kind) const;  // 0 imagen, 1 audio, 2 modelo
    void doExportExe();
    void doExportPack();
    bool showExport_ = false;
    bool buildApkPackage(std::vector<uint8_t>& out, std::string& err);
    bool buildExePackage(std::vector<uint8_t>& out, std::string& err);
    void exportWin();

    // pantallas y ventanas
    void projectsUI(Renderer* r);
    void editFrame(Renderer* r, float dt);
    void playFrame(Renderer* r, float dt);
    void menuBar();
    void objectsWin();
    void propsWin();
    void worldWin();
    void hudWin(Renderer* r);
    void assetsWin();
    void toastUI();

    // paginas (pages.cpp)
    void pageScenes(Renderer* r);
    void pageSceneHome(Renderer* r);
    void pageObject(Renderer* r);
    void scriptsTab(Obj& o);
    void looksTab(Obj& o, Renderer* r);
    void soundsTab(Obj& o);
    void palettePage(Obj& o);
    void formulaPage(Obj& o);
    void choosePage(Obj& o);
    void dragScroll();
    bool tapped() const;  // el ultimo item se solto sin arrastrar
    bool beginPage(const char* id);
    void endPage();
    bool topBar(const std::string& title, bool* back, bool* menu);
    void fab(bool* play, bool* plus);
    void objectMenuItems(int idx);
    void thumb(Renderer* r, const Obj& o, float size);
    Obj* currentObj() { return hasScene() && sel_ >= 0 && sel_ < (int)scene().objs.size() ? &scene().objs[sel_] : nullptr; }
    std::vector<std::string> varNames(const Obj& o) const;
    std::vector<std::string> messageNames() const;

    int pal_ = -2;  // -2 cerrada, -1 categorias, 0.. categoria
    std::string palSearch_;
    struct FEdit { bool open = false; int blk = -1, field = 0; std::string buf; } fe_;
    struct TEdit { bool open = false; int blk = -1; std::string buf; } te_;
    bool newVarOpen_ = false, newVarLocal_ = false;
    std::string newVarName_;
    int formulaList_ = 0;  // sublista abierta en el editor de formulas
    std::string renameBuf_;
    int renameWhat_ = 0, renameIdx_ = -1;  // 1 escena, 2 objeto
    bool pendingNewObj_ = false, pendingNewModel_ = false;
    std::string* promptDst_ = nullptr;
    bool promptActive_ = false;
    bool textInput(const char* id, const char* title, std::string& s, const char* hint = nullptr, float width = 0.f);
    void applyRename();
    void modalOpen(const char* name);  // la proxima imagen importada crea un objeto
    bool plusOpen_ = false, projMenu_ = false;
    void renameUI();
    bool stepper(const char* label, float& v, float step);
    void assetThumb(const std::string& name, int kind, float size);
    bool assetCombo(const char* label, std::string& cur, int kind, const char* none);
    Renderer* rend_ = nullptr;
    int menuBg_ = (int)(std::time(nullptr) % 2);  // fondo del menú: pasillo o bosque
    int sceneHold_ = -1;               // escena que se esta moviendo (pulsacion larga)
    std::vector<std::pair<float, float>> sceneRows_;  // alto de cada fila (pantalla) para saber donde soltar
    bool playerPanel(Scene& S, Obj& o);
    bool aiPanel(Obj& o);
    bool animPanel(Obj& o);
    bool fxPanel(Obj& o);
    // editor de texturas (dibujar pixeles)
    bool paintOpen_ = false;
    std::string paintName_;
    int paintW_ = 32, paintH_ = 32, paintTool_ = 0, paintBrush_ = 1, paintNewSize_ = 32;
    std::vector<uint8_t> paintPx_;
    std::vector<std::vector<uint8_t>> paintUndo_, paintRedo_;
    float paintCol_[4] = {0.9f, 0.2f, 0.2f, 1.f};
    bool paintSym_ = false;
    void openPaint(const std::string& existing);
    bool paintSave();
    void paintWin();
    bool layerPanel(Scene& S);
    bool layerPreview_ = true;
    bool weaponPanel();
    bool numField(const char* label, float& v, float mn, float mx, const char* fmt = "%.2f");
    void enforceOneWindow();
    float* promptNum_ = nullptr;
    float promptLo_ = -1e9f, promptHi_ = 1e9f;
    std::string numBuf_;
    bool prevW_[5] = {false, false, false, false, false};
    void addPreset(int id);
    bool grid3dOpen_ = false, modelsOpen_ = false;
    void projectMenu();
    void newObjectMenu();
    void markDirty() { dirty_ = true; }
};

}  // namespace forge
