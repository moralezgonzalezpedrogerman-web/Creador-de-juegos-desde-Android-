#pragma once
#include <memory>
#include "rig.h"
#include "model.h"
#include <ctime>
#include "audio.h"
#include "playview.h"
#include "renderer.h"
#include <functional>
#include <set>
#include <string>
#include <vector>

namespace forge {

// Servicios que la plataforma ofrece al editor.
struct EditorHost {
    std::string dataDir;  // carpeta privada: proyectos y exportaciones
    std::function<void()> pickFile;  // abre el selector; el archivo llega a Editor::onFile
    std::function<void(const std::string& displayName, const std::string& path)> saveOut;  // copiar a donde elija el usuario
    std::function<bool(std::vector<uint8_t>&)> loadRuntime;  // forge_runtime.exe (para exportar)
    std::function<void(const std::string& title, const std::string& initial)> prompt;  // cuadro de texto nativo (Android)
    std::function<void(float)> vibrate;                      // segundos
    std::function<void(const std::string&)> speak;           // texto a voz
    std::function<void(bool)> flash;                         // linterna
    // Android: crear un APK ya compilado e instalable dentro del telefono (vacio = no disponible)
    std::function<void(const std::string& packPath, const std::string& label, const std::string& appId, const std::string& iconPath,
                       const std::string& verName, const std::string& outName, int orient, int verCode)> buildApk;
    std::function<std::string()> buildApkStatus;             // "" trabajando, "OK:<ruta>[|AVISO:..]" o "ERROR:<mensaje>"
    std::function<void(const std::string& path)> installApk;  // abre el instalador de Android
};

// Exportacion (editor/exporter.cpp)
bool makeIconPng(const std::vector<uint8_t>& src, int size, std::vector<uint8_t>& out);
std::string exportSlug(const std::string& s);
bool validAppId(const std::string& id);

// Tema visual de toda la aplicacion (colores, bordes redondeados, espacios). Llamar antes de ScaleAllSizes.
void applyTheme();

enum class Screen { Projects, Edit, Play };
// Dentro de un proyecto (como Pocket Code): lista de escenas -> escena (fondo y objetos) -> objeto (pestañas) -> editor visual.
enum class Page { Scenes, SceneHome, Object, Viewport };

class Editor {
public:
    explicit Editor(EditorHost h) : host_(std::move(h)) {}
    void init(Audio* audio);

    // Una vez por frame, con ImGui::NewFrame() ya llamado. r puede ser null (pruebas).
    void frame(Renderer* r, int w, int h, float dt);
    bool importPack(const std::string& fileName, const std::vector<uint8_t>& data);
    void onFile(const std::string& name, std::vector<uint8_t> data);  // archivo elegido por el usuario
    void onText(const std::string& text, bool ok);                    // respuesta del cuadro de texto nativo
    PlayControls& controls() { return play_.ctl; }

    // --- proyectos
    bool newProject(const std::string& name, bool demo);
    bool openProject(const std::string& name);
    bool saveProject();
    void closeProject();
    bool buildPack(std::vector<uint8_t>& out);
    bool buildExe(std::vector<uint8_t>& out, std::string& err);

    // --- edicion (tambien usados por las pruebas)
    void addObject(Kind k, const std::string& modelName = "");
    void addScene(bool is3d);
    void select(int i) { sel_ = i; }
    void startPlay();
    void stopPlay();
    Screen screen() const { return screen_; }
    Project& project() { return edit_.proj; }
    PlayView& play() { return play_; }
    int sceneIndex() const { return sceneIdx_; }
    void setScene(int i);
    int selected() const { return sel_; }
    const std::vector<std::string>& projectNames() const { return projList_; }
    bool dirty() const { return dirty_; }

    // Ventanas visibles (publico para poder activarlas desde pruebas).
    bool showObjs = false, showProps = true, showWorld = false, showHud = false, showAssets = false;
    Page page() const { return page_; }
    void setPage(Page p) { page_ = p; }
    void openObject(int i) { sel_ = i; page_ = Page::Object; tab_ = 0; }
    int tab() const { return tab_; }
    void addObjectPreset(int id) { addPreset(id); }
    void openPalette() { pal_ = -1; }
    void openFormula(int blk, int field, const std::string& cur) { fe_.open = true; fe_.blk = blk; fe_.field = field; fe_.buf = cur; fe_.sel = -1; fe_.selArg = 0; fe_.replaceNext = false; fe_.kbPending = false; fe_.abcOn = false; }
    void openChoose(int blk) { te_.open = true; te_.blk = blk; }
    void setTab(int t) { tab_ = t; }
    // Bloques (usados tambien por las pruebas)
    int addBlock(Obj& o, Op op);                       // agrega con sus cierres (si, bucles); devuelve el indice
    static bool blockRange(const std::vector<Block>& B, int i, int& end);  // [i, end) que se mueve junto con el bloque i
    static bool moveRange(std::vector<Block>& B, int from, int to);       // mueve el grupo i antes del bloque "to"

private:
    EditorHost host_;
    Audio* audio_ = nullptr;
    Screen screen_ = Screen::Projects;
    Game edit_;                 // el proyecto en edicion (edit_.proj)
    PlayView play_;
    std::string name_, newName_ = "mi_juego";
    std::vector<std::string> projList_;
    std::set<std::string> assetDirty_;
    int sceneIdx_ = 0, sel_ = -1;
    bool dirty_ = false;
    float snap_ = 0.25f;
    int w_ = 1, h_ = 1;

    // mensaje temporal
    std::string toast_;
    float toastT_ = 0;
    void toast(const std::string& t) { toast_ = t; toastT_ = 3.5f; }

    // camara del editor
    float yaw_ = 0.6f, pitch_ = 0.55f, dist_ = 14.f;
    V3 target_;
    float cx_ = 0, cy_ = 0, h2d_ = kView2DHeight;

    // gestos
    int prevN_ = 0;
    bool gestOk_ = false, dragObj_ = false;
    float lastX_ = 0, lastY_ = 0, lastDist_ = 0, moveAcc_ = 0;
    Page page_ = Page::Scenes;
    int tab_ = 0;
    float dragAcc_ = 0;
    V3 grab_;

    // ayudantes
    Scene& scene() { return edit_.proj.scenes[sceneIdx_]; }
    bool hasScene() const { return sceneIdx_ >= 0 && sceneIdx_ < (int)edit_.proj.scenes.size(); }
    Obj* selObj();
    std::string uniqueName(const std::string& base);
    void listProjects();
    void resetView();
    EditorView view() const;
    void rayAt(float x, float y, const EditorView& ev, V3& o, V3& d) const;
    int pick(float x, float y, const EditorView& ev);
    void gestures();
    std::vector<std::string> assetsOf(int kind) const;  // 0 imagen, 1 audio, 2 modelo
    void doExportExe();
    void doExportPack();
    bool showExport_ = false;
    bool buildApkPackage(std::vector<uint8_t>& out, std::string& err);
    bool buildExePackage(std::vector<uint8_t>& out, std::string& err);
    void exportWin();

    // pantallas y ventanas
    void projectsUI(Renderer* r);
    void editFrame(Renderer* r, float dt);
    void playFrame(Renderer* r, float dt);
    void menuBar();
    void objectsWin();
    void propsWin();
    void worldWin();
    void hudWin(Renderer* r);
    void assetsWin();
    void toastUI();

    // paginas (pages.cpp)
    void pageScenes(Renderer* r);
    void pageSceneHome(Renderer* r);
    void pageObject(Renderer* r);
    void scriptsTab(Obj& o);
    void looksTab(Obj& o, Renderer* r);
    void soundsTab(Obj& o);
    void palettePage(Obj& o);
    void formulaPage(Obj& o);
    void choosePage(Obj& o);
    void dragScroll();
    bool tapped() const;  // el ultimo item se solto sin arrastrar
    bool beginPage(const char* id);
    void endPage();
    bool topBar(const std::string& title, bool* back, bool* menu);
    void fab(bool* play, bool* plus);
    void objectMenuItems(int idx);
    void thumb(Renderer* r, const Obj& o, float size);
    Obj* currentObj() { return hasScene() && sel_ >= 0 && sel_ < (int)scene().objs.size() ? &scene().objs[sel_] : nullptr; }
    std::vector<std::string> varNames(const Obj& o) const;
    std::vector<std::string> messageNames() const;

    int pal_ = -2;  // -2 cerrada, -1 categorias, 0.. categoria
    std::string palSearch_;
    struct FEdit { bool open = false; int blk = -1, field = 0; std::string buf; int sel = -1, selArg = 0; bool replaceNext = false, kbPending = false, abcOn = false; std::string kb; } fe_;
    struct TEdit { bool open = false; int blk = -1; std::string buf; } te_;
    bool newVarOpen_ = false, newVarLocal_ = false;
    std::string newVarName_;
    int formulaList_ = 0;  // sublista abierta en el editor de formulas
    std::string renameBuf_;
    int renameWhat_ = 0, renameIdx_ = -1;  // 1 escena, 2 objeto
    bool pendingNewObj_ = false, pendingNewModel_ = false;
    std::string* promptDst_ = nullptr;
    bool promptActive_ = false;
    bool textInput(const char* id, const char* title, std::string& s, const char* hint = nullptr, float width = 0.f);
    void applyRename();
    void modalOpen(const char* name);  // la proxima imagen importada crea un objeto
    bool plusOpen_ = false, projMenu_ = false;
    void renameUI();
    bool stepper(const char* label, float& v, float step);
    void assetThumb(const std::string& name, int kind, float size);
    bool gridPicker(const char* id, std::string& cur, int kind, const char* none, bool open);
    bool assetCombo(const char* label, std::string& cur, int kind, const char* none);
    Renderer* rend_ = nullptr;
    int menuBg_ = (int)(std::time(nullptr) % 2);  // fondo del menú: pasillo o bosque
    int sceneHold_ = -1;               // escena que se esta moviendo (pulsacion larga)
    std::vector<std::pair<float, float>> sceneRows_;  // alto de cada fila (pantalla) para saber donde soltar
    bool playerPanel(Scene& S, Obj& o);
    bool aiPanel(Obj& o);
    bool terrainPanel(Obj& o);
    bool skelPanel(Obj& o);
    std::vector<std::string> clipsFor(const Obj& o) const;
    bool clipCombo(const char* label, const Obj& o, std::string& clip);
    bool terrainPaint_ = false;
    // v9: vegetacion
    bool vegPaint_ = false, vegErase_ = false;
    int vegSel_ = 0;
    float vegRadius_ = 2.5f, vegDensity_ = 1.f, vegLastX_ = 1e9f, vegLastZ_ = 1e9f;
    bool gndPaint_ = false, gndErase_ = false;
    int gndSel_ = 0;
    float gndRadius_ = 3.f;
    bool gndPanel(Scene& S);
    void gndStamp(Scene& S, V3 hit);
    std::vector<std::string> soundList() const;   // sonidos del proyecto + los de por defecto
    bool soundPanel();
    bool flashPanel();
    bool vegPanel(Scene& S);
    bool groundHit(Scene& S, V3 ro, V3 rd, V3& hit);
    void vegStamp(Scene& S, V3 hit);
    int terrMode_ = 0;
    float terrRadius_ = 3.f, terrStrength_ = 4.f, terrTarget_ = 0.f;
    bool animPanel(Obj& o);
    bool fxPanel(Obj& o);
    // editor de texturas (dibujar pixeles)
    // editor de animación con esqueleto
    bool animOpen_ = false, animImportPending_ = false, animImgDirty_ = true, animWDirty_ = true, animAdd_ = false, animPlay_ = false, animMdOk_ = false;
    std::string animName_;
    Rig animRig_;
    ModelData animMd_;
    RigWeights animW_;
    RigPose animPose_;
    bool animFlip_ = false, animSwap_ = false;
    int animTab_ = 0, animView_ = 0, animSel_ = -1, animClip_ = 0, animKey_ = -1;
    float animT_ = 0;
    std::vector<uint8_t> animPx_;
    void openAnimEditor(const std::string& name, const std::string& modelHint = "");
    void animWin();
    // v8: importar modelos pesados en otro hilo con pantalla de carga
    std::shared_ptr<struct ImpJob> imp_;
    void startModelImport(const std::string& name, std::vector<uint8_t> data);
    void pollImport();
    void importOverlay();
    bool reading_ = false;
    float readingT_ = 0.f;
    float animZoom_ = 1.f, animPanX_ = 0.f, animPanY_ = 0.f;
    bool animSave();
    void animLoadModel();
    void animFixSizes();
    void animPresets();
    bool paintOpen_ = false;
    std::string paintName_;
    int paintW_ = 32, paintH_ = 32, paintTool_ = 0, paintBrush_ = 1, paintNewSize_ = 32;
    std::vector<uint8_t> paintPx_;
    std::vector<std::vector<uint8_t>> paintUndo_, paintRedo_;
    float paintCol_[4] = {0.9f, 0.2f, 0.2f, 1.f};
    bool paintSym_ = false;
    void openPaint(const std::string& existing);
    bool paintSave();
    void paintWin();
    bool layerPanel(Scene& S);
    bool layerPreview_ = true;
    bool weaponPanel();
    bool weaponFields(Weapon& w, bool primary);
    bool numField(const char* label, float& v, float mn, float mx, const char* fmt = "%.2f");
    bool numFieldI(const char* l, int& v, int mn, int mx) { float f = (float)v; bool c = numField(l, f, (float)mn, (float)mx, "%.0f"); if (c) v = (int)(f + 0.5f); return c; }
    void enforceOneWindow();
    float* promptNum_ = nullptr;
    float promptLo_ = -1e9f, promptHi_ = 1e9f;
    std::string numBuf_;
    bool prevW_[5] = {false, false, false, false, false};
    void addPreset(int id);
    bool grid3dOpen_ = false, modelsOpen_ = false;
    void projectMenu();
    void newObjectMenu();
    void markDirty() { dirty_ = true; }
};

}  // namespace forge
