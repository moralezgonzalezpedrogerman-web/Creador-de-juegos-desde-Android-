#include "importer.h"
#include "model.h"
#include "rig.h"
#include "stb_image.h"
#define STB_IMAGE_WRITE_IMPLEMENTATION
#include "stb_image_write.h"

#define CGLTF_IMPLEMENTATION
#include "cgltf.h"
#include "ufbx.h"

#include <algorithm>
#include <cmath>
#include <cstring>
#include <functional>
#include <map>
#include <set>
#include <sstream>
#include <unordered_map>

namespace forge {

static std::string lower(std::string s) {
    for (auto& c : s) c = (char)tolower((unsigned char)c);
    return s;
}

static std::string extOf(const std::string& n) {
    size_t p = n.rfind('.');
    return p == std::string::npos ? "" : lower(n.substr(p + 1));
}

static std::string baseOf(const std::string& n) {
    std::string b = n;
    size_t p = b.rfind('.');
    if (p != std::string::npos) b = b.substr(0, p);
    for (auto& c : b) if (c == ' ' || c == '/' || c == '\\') c = '_';
    return b.empty() ? "modelo" : b;
}

bool isModelFile(const std::string& n) {
    std::string e = extOf(n);
    return e == "obj" || e == "glb" || e == "gltf" || e == "fbx";
}

struct Mat {
    float color[3] = {1, 1, 1};
    std::vector<uint8_t> img;  // imagen codificada (png/jpg) o vacia
};

// Triangulos sin indexar: 8 floats por vertice (pos, normal, uv). Normal (0,0,0) = sin normal.
struct Raw {
    std::vector<float> v;
    std::string tex;
    float color[3] = {1, 1, 1};
    int cur = 0;                 // material actual
    std::vector<Mat> mats;
    std::vector<int> triMat;     // material de cada triangulo
    void add(const float* p, const float* n, const float* uv) {
        v.insert(v.end(), {p[0], p[1], p[2], n[0], n[1], n[2], uv[0], uv[1]});
        if ((v.size() / 8) % 3 == 0) triMat.push_back(cur);
    }
};

static std::string baseLowerName(const std::string& n) {
    size_t p = n.find_last_of("/\\");
    std::string b = p == std::string::npos ? n : n.substr(p + 1);
    while (!b.empty() && (b.back() == '\r' || b.back() == ' ')) b.pop_back();
    for (auto& c : b) c = (char)tolower((unsigned char)c);
    return b;
}

static const std::vector<uint8_t>* findRes(const ResMap* res, const std::string& name) {
    if (!res || name.empty()) return nullptr;
    auto it = res->find(baseLowerName(name));
    return it == res->end() ? nullptr : &it->second;
}

// ---------------------------------------------------------------- OBJ
struct MtlDef { float kd[3] = {0.8f, 0.8f, 0.8f}; std::string map; };

static bool parseObj(const std::string& text, Raw& raw, std::string& err, const ResMap* res) {
    std::vector<float> P, T, N;
    std::map<std::string, MtlDef> mtl;
    std::map<std::string, int> matIdx;
    std::istringstream in(text);
    std::string line;
    while (std::getline(in, line)) {
        std::istringstream ls(line);
        std::string tag;
        ls >> tag;
        if (tag == "v") { float x = 0, y = 0, z = 0; ls >> x >> y >> z; P.insert(P.end(), {x, y, z}); }
        else if (tag == "vt") { float u = 0, v = 0; ls >> u >> v; T.insert(T.end(), {u, v}); }
        else if (tag == "vn") { float x = 0, y = 0, z = 0; ls >> x >> y >> z; N.insert(N.end(), {x, y, z}); }
        else if (tag == "mtllib") {
            std::string fn;
            std::getline(ls >> std::ws, fn);
            if (const auto* d = findRes(res, fn)) {
                std::istringstream ms(std::string(d->begin(), d->end()));
                std::string ml, cur;
                while (std::getline(ms, ml)) {
                    std::istringstream mls(ml);
                    std::string mt;
                    mls >> mt;
                    if (mt == "newmtl") { std::getline(mls >> std::ws, cur); while (!cur.empty() && (cur.back() == '\r' || cur.back() == ' ')) cur.pop_back(); mtl[cur]; }
                    else if (mt == "Kd" && !cur.empty()) mls >> mtl[cur].kd[0] >> mtl[cur].kd[1] >> mtl[cur].kd[2];
                    else if (mt == "map_Kd" && !cur.empty()) {
                        std::string rest, tok;
                        while (mls >> tok) rest = tok;  // el ultimo token es el archivo (antes pueden ir opciones -s 1 1 1)
                        mtl[cur].map = rest;
                    }
                }
            }
        }
        else if (tag == "usemtl") {
            std::string nm;
            std::getline(ls >> std::ws, nm);
            while (!nm.empty() && (nm.back() == '\r' || nm.back() == ' ')) nm.pop_back();
            auto it = matIdx.find(nm);
            if (it == matIdx.end()) {
                Mat m;
                auto d = mtl.find(nm);
                if (d != mtl.end()) {
                    for (int k = 0; k < 3; k++) m.color[k] = d->second.kd[k];
                    if (const auto* img = findRes(res, d->second.map)) m.img = *img;
                }
                raw.mats.push_back(m);
                it = matIdx.emplace(nm, (int)raw.mats.size() - 1).first;
            }
            raw.cur = it->second;
        }
        else if (tag == "f") {
            struct Ref { int p = -1, t = -1, n = -1; };
            std::vector<Ref> face;
            std::string tok;
            while (ls >> tok) {
                Ref r;
                int idx[3] = {0, 0, 0}, k = 0;
                bool has[3] = {false, false, false};
                size_t i = 0;
                while (i <= tok.size() && k < 3) {
                    size_t j = tok.find('/', i);
                    std::string part = tok.substr(i, j == std::string::npos ? std::string::npos : j - i);
                    if (!part.empty()) { idx[k] = atoi(part.c_str()); has[k] = true; }
                    k++;
                    if (j == std::string::npos) break;
                    i = j + 1;
                }
                auto res = [](int v, size_t count) { return v > 0 ? v - 1 : (int)count + v; };
                if (has[0]) r.p = res(idx[0], P.size() / 3);
                if (has[1]) r.t = res(idx[1], T.size() / 2);
                if (has[2]) r.n = res(idx[2], N.size() / 3);
                if (r.p < 0 || (size_t)r.p >= P.size() / 3) { err = "OBJ con indices invalidos"; return false; }
                if (r.t >= 0 && (size_t)r.t >= T.size() / 2) r.t = -1;
                if (r.n >= 0 && (size_t)r.n >= N.size() / 3) r.n = -1;
                face.push_back(r);
            }
            for (size_t i = 1; i + 1 < face.size(); i++) {
                const Ref* t3[3] = {&face[0], &face[i], &face[i + 1]};
                for (auto* r : t3) {
                    float uv[2] = {0, 0}, n[3] = {0, 0, 0};
                    if (r->t >= 0) { uv[0] = T[r->t * 2]; uv[1] = T[r->t * 2 + 1]; }
                    if (r->n >= 0) { n[0] = N[r->n * 3]; n[1] = N[r->n * 3 + 1]; n[2] = N[r->n * 3 + 2]; }
                    raw.add(&P[r->p * 3], n, uv);
                }
            }
        }
    }
    return true;
}

// ---------------------------------------------------------------- glTF / GLB
static cgltf_result readRes(const cgltf_memory_options* mo, const cgltf_file_options* fo, const char* path,
                            cgltf_size* size, void** data) {
    const ResMap* r = (const ResMap*)fo->user_data;
    std::string p = path ? path : "";
    if (!p.empty()) { std::vector<char> tmp(p.begin(), p.end()); tmp.push_back(0); cgltf_decode_uri(tmp.data()); p = tmp.data(); }
    const auto* d = findRes(r, p);
    if (!d) return cgltf_result_file_not_found;
    void* mem = mo->alloc_func ? mo->alloc_func(mo->user_data, d->size()) : malloc(d->size());
    if (!mem) return cgltf_result_out_of_memory;
    memcpy(mem, d->data(), d->size());
    *size = d->size();
    *data = mem;
    return cgltf_result_success;
}
static void releaseRes(const cgltf_memory_options* mo, const cgltf_file_options*, void* data) {
    if (mo->free_func) mo->free_func(mo->user_data, data);
    else free(data);
}

static bool parseGltf(const std::vector<uint8_t>& data, Raw& raw, const ResMap* res, std::string& err) {
    cgltf_options opt;
    memset(&opt, 0, sizeof opt);
    if (res) {
        opt.file.read = readRes;
        opt.file.release = releaseRes;
        opt.file.user_data = (void*)res;
    }
    cgltf_data* d = nullptr;
    if (cgltf_parse(&opt, data.data(), data.size(), &d) != cgltf_result_success) {
        err = "archivo glTF/GLB invalido";
        return false;
    }
    struct Free { cgltf_data* d; ~Free() { cgltf_free(d); } } guard{d};
    if (cgltf_load_buffers(&opt, d, "") != cgltf_result_success) {
        err = "el glTF usa archivos externos (.bin, texturas): importalo desde un .zip que los incluya, o usa un .glb";
        return false;
    }
    std::map<const cgltf_material*, int> matIdx;
    auto matFor = [&](const cgltf_material* m) {
        auto it = matIdx.find(m);
        if (it != matIdx.end()) return it->second;
        Mat mt;
        if (m && m->has_pbr_metallic_roughness) {
            for (int k = 0; k < 3; k++) mt.color[k] = m->pbr_metallic_roughness.base_color_factor[k];
            cgltf_texture* tx = m->pbr_metallic_roughness.base_color_texture.texture;
            if (tx && tx->image) {
                if (tx->image->buffer_view) {
                    cgltf_buffer_view* bv = tx->image->buffer_view;
                    const uint8_t* src = (const uint8_t*)bv->buffer->data + bv->offset;
                    mt.img.assign(src, src + bv->size);
                } else if (tx->image->uri) {
                    std::string u = tx->image->uri;
                    std::vector<char> tmp(u.begin(), u.end());
                    tmp.push_back(0);
                    cgltf_decode_uri(tmp.data());
                    if (const auto* im = findRes(res, tmp.data())) mt.img = *im;
                }
            }
        } else if (m && m->has_pbr_specular_glossiness) {
            for (int k = 0; k < 3; k++) mt.color[k] = m->pbr_specular_glossiness.diffuse_factor[k];
        }
        raw.mats.push_back(mt);
        int idx = (int)raw.mats.size() - 1;
        matIdx[m] = idx;
        return idx;
    };
    for (size_t ni = 0; ni < d->nodes_count; ni++) {
        cgltf_node* node = &d->nodes[ni];
        if (!node->mesh) continue;
        float M[16];
        cgltf_node_transform_world(node, M);
        for (size_t pi = 0; pi < node->mesh->primitives_count; pi++) {
            cgltf_primitive* pr = &node->mesh->primitives[pi];
            if (pr->type != cgltf_primitive_type_triangles) continue;
            cgltf_accessor *ap = nullptr, *an = nullptr, *at = nullptr;
            for (size_t a = 0; a < pr->attributes_count; a++) {
                cgltf_attribute& at_ = pr->attributes[a];
                if (at_.type == cgltf_attribute_type_position && at_.index == 0) ap = at_.data;
                if (at_.type == cgltf_attribute_type_normal && at_.index == 0) an = at_.data;
                if (at_.type == cgltf_attribute_type_texcoord && at_.index == 0) at = at_.data;
            }
            if (!ap) continue;
            raw.cur = matFor(pr->material);
            size_t count = pr->indices ? pr->indices->count : ap->count;
            for (size_t k = 0; k + 3 <= count; k += 3) {
                for (int c = 0; c < 3; c++) {
                    size_t vi = pr->indices ? cgltf_accessor_read_index(pr->indices, k + c) : k + c;
                    float p[3] = {0, 0, 0}, n[3] = {0, 0, 0}, uv[2] = {0, 0};
                    cgltf_accessor_read_float(ap, vi, p, 3);
                    if (an) cgltf_accessor_read_float(an, vi, n, 3);
                    if (at) { cgltf_accessor_read_float(at, vi, uv, 2); uv[1] = 1.f - uv[1]; }
                    float wp[3] = {M[0] * p[0] + M[4] * p[1] + M[8] * p[2] + M[12],
                                   M[1] * p[0] + M[5] * p[1] + M[9] * p[2] + M[13],
                                   M[2] * p[0] + M[6] * p[1] + M[10] * p[2] + M[14]};
                    float wn[3] = {M[0] * n[0] + M[4] * n[1] + M[8] * n[2], M[1] * n[0] + M[5] * n[1] + M[9] * n[2],
                                   M[2] * n[0] + M[6] * n[1] + M[10] * n[2]};
                    raw.add(wp, wn, uv);
                }
            }
        }
    }
    return true;
}

// ---------------------------------------------------------------- FBX
static bool parseFbx(const std::vector<uint8_t>& data, Raw& raw, const ResMap* res, std::string& err) {
    ufbx_load_opts opts;
    memset(&opts, 0, sizeof opts);
    opts.target_axes = ufbx_axes_right_handed_y_up;
    opts.target_unit_meters = 1.0f;
    ufbx_error uerr;
    ufbx_scene* sc = ufbx_load_memory(data.data(), data.size(), &opts, &uerr);
    if (!sc) {
        err = std::string("FBX invalido: ") + uerr.description.data;
        return false;
    }
    for (size_t ni = 0; ni < sc->nodes.count; ni++) {
        ufbx_node* node = sc->nodes.data[ni];
        ufbx_mesh* mesh = node->mesh;
        if (!mesh) continue;
        ufbx_matrix gm = node->geometry_to_world;
        std::vector<int> mm(mesh->materials.count + 1, -1);
        auto matOf = [&](size_t fi) {
            size_t k = mesh->face_material.count > fi ? mesh->face_material.data[fi] : 0;
            if (k >= mesh->materials.count) return -1;
            if (mm[k] >= 0) return mm[k];
            Mat m;
            const ufbx_material* um = mesh->materials.data[k];
            if (um) {
                m.color[0] = (float)um->pbr.base_color.value_vec3.x;
                m.color[1] = (float)um->pbr.base_color.value_vec3.y;
                m.color[2] = (float)um->pbr.base_color.value_vec3.z;
                const ufbx_texture* tx = um->pbr.base_color.texture;
                if (tx) {
                    if (tx->content.size > 0) m.img.assign((const uint8_t*)tx->content.data, (const uint8_t*)tx->content.data + tx->content.size);
                    else {
                        const auto* im = findRes(res, std::string(tx->relative_filename.data, tx->relative_filename.length));
                        if (!im) im = findRes(res, std::string(tx->filename.data, tx->filename.length));
                        if (im) m.img = *im;
                    }
                }
            }
            raw.mats.push_back(m);
            return mm[k] = (int)raw.mats.size() - 1;
        };
        std::vector<uint32_t> tris(mesh->max_face_triangles * 3);
        for (size_t fi = 0; fi < mesh->faces.count; fi++) {
            size_t nt = ufbx_triangulate_face(tris.data(), tris.size(), mesh, mesh->faces.data[fi]);
            { int mi = matOf(fi); if (mi >= 0) raw.cur = mi; }
            for (size_t j = 0; j < nt * 3; j++) {
                uint32_t ix = tris[j];
                ufbx_vec3 p = ufbx_transform_position(&gm, ufbx_get_vertex_vec3(&mesh->vertex_position, ix));
                ufbx_vec3 n = {0, 0, 0};
                if (mesh->vertex_normal.exists) n = ufbx_transform_direction(&gm, ufbx_get_vertex_vec3(&mesh->vertex_normal, ix));
                ufbx_vec2 uv = {0, 0};
                if (mesh->vertex_uv.exists) uv = ufbx_get_vertex_vec2(&mesh->vertex_uv, ix);
                float pf[3] = {(float)p.x, (float)p.y, (float)p.z}, nf[3] = {(float)n.x, (float)n.y, (float)n.z},
                      uf[2] = {(float)uv.x, (float)uv.y};
                raw.add(pf, nf, uf);
            }
        }
    }
    ufbx_free_scene(sc);
    return true;
}

// ---------------------------------------------------------------- materiales -> una sola textura (atlas)
static bool isPng(const std::vector<uint8_t>& d) { return d.size() > 4 && d[0] == 0x89 && d[1] == 'P'; }

static void pngOut(void* ctx, void* data, int n) {
    auto* v = (std::vector<uint8_t>*)ctx;
    v->insert(v->end(), (uint8_t*)data, (uint8_t*)data + n);
}

struct Tile { int w = 4, h = 4, x = 0, y = 0; std::vector<uint8_t> px; };

static std::vector<uint8_t> resizeRGBA(const std::vector<uint8_t>& s, int w, int h, int nw, int nh) {
    std::vector<uint8_t> o((size_t)nw * nh * 4);
    for (int y = 0; y < nh; y++)
        for (int x = 0; x < nw; x++) {
            float fx = (x + 0.5f) * w / nw - 0.5f, fy = (y + 0.5f) * h / nh - 0.5f;
            int x0 = std::max(0, std::min(w - 1, (int)std::floor(fx))), y0 = std::max(0, std::min(h - 1, (int)std::floor(fy)));
            int x1 = std::min(w - 1, x0 + 1), y1 = std::min(h - 1, y0 + 1);
            float tx = std::max(0.f, std::min(1.f, fx - x0)), ty = std::max(0.f, std::min(1.f, fy - y0));
            for (int c = 0; c < 4; c++) {
                float a = s[((size_t)y0 * w + x0) * 4 + c] * (1 - tx) + s[((size_t)y0 * w + x1) * 4 + c] * tx;
                float b = s[((size_t)y1 * w + x0) * 4 + c] * (1 - tx) + s[((size_t)y1 * w + x1) * 4 + c] * tx;
                o[((size_t)y * nw + x) * 4 + c] = (uint8_t)(a * (1 - ty) + b * ty + 0.5f);
            }
        }
    return o;
}

static bool applyMaterials(Raw& raw, Files& assets, const std::string& base, std::string& err) {
    if (raw.mats.empty()) return true;
    std::set<int> usedSet(raw.triMat.begin(), raw.triMat.end());
    std::vector<int> used(usedSet.begin(), usedSet.end());
    if (used.empty()) return true;
    if (used.size() == 1) {
        Mat& m = raw.mats[used[0]];
        for (int k = 0; k < 3; k++) raw.color[k] = m.color[k];
        if (!m.img.empty()) {
            std::string tn = base + (isPng(m.img) ? "_tex.png" : "_tex.jpg");
            assets[tn] = m.img;
            raw.tex = tn;
        }
        return true;
    }
    std::map<int, Tile> tiles;
    stbi_set_flip_vertically_on_load(0);
    for (int mi : used) {
        Mat& m = raw.mats[mi];
        Tile t;
        bool ok = false;
        if (!m.img.empty()) {
            int w, h, c;
            unsigned char* d = stbi_load_from_memory(m.img.data(), (int)m.img.size(), &w, &h, &c, 4);
            if (d) {
                t.w = w; t.h = h;
                t.px.assign(d, d + (size_t)w * h * 4);
                stbi_image_free(d);
                for (size_t i = 0; i < t.px.size(); i += 4)
                    for (int k = 0; k < 3; k++) t.px[i + k] = (uint8_t)std::min(255.f, t.px[i + k] * m.color[k]);
                ok = true;
            }
        }
        if (!ok) {
            t.w = t.h = 4;
            t.px.resize(64);
            for (int i = 0; i < 16; i++) {
                for (int k = 0; k < 3; k++) t.px[i * 4 + k] = (uint8_t)std::max(0.f, std::min(255.f, m.color[k] * 255.f + 0.5f));
                t.px[i * 4 + 3] = 255;
            }
        }
        tiles[mi] = std::move(t);
    }
    const int AW = 2048, G = 2;
    int AH = 0;
    std::vector<int> order = used;
    bool fit = false;
    for (int attempt = 0; attempt < 6 && !fit; attempt++) {
        if (attempt > 0)
            for (auto& kv : tiles) {
                Tile& t = kv.second;
                if (t.w <= 4 && t.h <= 4) continue;
                int nw = std::max(4, t.w / 2), nh = std::max(4, t.h / 2);
                t.px = resizeRGBA(t.px, t.w, t.h, nw, nh);
                t.w = nw; t.h = nh;
            }
        std::sort(order.begin(), order.end(), [&](int a, int b) { return tiles[a].h > tiles[b].h; });
        int x = 0, y = 0, rowH = 0;
        bool bad = false;
        for (int mi : order) {
            Tile& t = tiles[mi];
            if (t.w + 2 * G > AW) { bad = true; break; }
            if (x + t.w + 2 * G > AW) { x = 0; y += rowH; rowH = 0; }
            t.x = x + G; t.y = y + G;
            x += t.w + 2 * G;
            rowH = std::max(rowH, t.h + 2 * G);
        }
        if (bad) continue;
        int H = y + rowH;
        if (H <= 2048) { AH = 1; while (AH < H) AH <<= 1; fit = true; }
    }
    if (!fit) { err = "el modelo tiene demasiadas texturas"; return false; }
    std::vector<uint8_t> atlas((size_t)AW * AH * 4, 0);
    for (auto& kv : tiles) {
        Tile& t = kv.second;
        for (int gy = -G; gy < t.h + G; gy++)
            for (int gx = -G; gx < t.w + G; gx++) {
                int sx = std::max(0, std::min(t.w - 1, gx)), sy = std::max(0, std::min(t.h - 1, gy));
                memcpy(&atlas[((size_t)(t.y + gy) * AW + (t.x + gx)) * 4], &t.px[((size_t)sy * t.w + sx) * 4], 4);
            }
    }
    size_t nt = raw.v.size() / 24;
    for (size_t t = 0; t < nt; t++) {
        Tile& tl = tiles[raw.triMat[t]];
        for (int k = 0; k < 3; k++) {
            float* v = &raw.v[(t * 3 + k) * 8];
            float u = v[6], w = v[7];
            if (u < 0.f || u > 1.f) u -= std::floor(u);
            if (w < 0.f || w > 1.f) w -= std::floor(w);
            v[6] = (tl.x + u * tl.w) / (float)AW;
            v[7] = 1.f - (tl.y + (1.f - w) * tl.h) / (float)AH;  // la textura se carga volteada: v crece hacia arriba
        }
    }
    std::vector<uint8_t> png;
    if (!stbi_write_png_to_func(pngOut, &png, AW, AH, 4, atlas.data(), AW * 4)) { err = "no se pudo crear la textura del modelo"; return false; }
    std::string tn = base + "_atlas.png";
    for (int i = 2; assets.count(tn); i++) tn = base + "_atlas" + std::to_string(i) + ".png";
    assets[tn] = std::move(png);
    raw.tex = tn;
    raw.color[0] = raw.color[1] = raw.color[2] = 1.f;
    return true;
}

// ---------------------------------------------------------------- normalizar y compactar
struct Key {
    uint32_t k[8];
    bool operator==(const Key& o) const { return memcmp(k, o.k, sizeof k) == 0; }
};
struct KeyHash {
    size_t operator()(const Key& a) const {
        size_t h = 1469598103934665603ull;
        for (uint32_t x : a.k) { h ^= x; h *= 1099511628211ull; }
        return h;
    }
};

static bool finalize(Raw& raw, ModelData& out, std::string& err) {
    size_t nv = raw.v.size() / 8;
    if (nv < 3) { err = "el modelo no tiene triangulos"; return false; }
    if (nv > 6000000) { err = "el modelo es demasiado grande"; return false; }
    float mn[3] = {1e30f, 1e30f, 1e30f}, mx[3] = {-1e30f, -1e30f, -1e30f};
    for (size_t i = 0; i < nv; i++)
        for (int c = 0; c < 3; c++) {
            mn[c] = std::min(mn[c], raw.v[i * 8 + c]);
            mx[c] = std::max(mx[c], raw.v[i * 8 + c]);
        }
    float ext = std::max(mx[0] - mn[0], std::max(mx[1] - mn[1], mx[2] - mn[2]));
    if (!(ext > 1e-9f)) { err = "el modelo no tiene volumen"; return false; }
    float s = 1.f / ext, ce[3] = {(mn[0] + mx[0]) * .5f, (mn[1] + mx[1]) * .5f, (mn[2] + mx[2]) * .5f};
    for (size_t i = 0; i < nv; i++) {
        float* v = &raw.v[i * 8];
        for (int c = 0; c < 3; c++) v[c] = (v[c] - ce[c]) * s;
    }
    // Normales planas donde falten.
    for (size_t t = 0; t + 2 < nv; t += 3) {
        float* a = &raw.v[t * 8];
        float* b = a + 8;
        float* c = b + 8;
        float e1[3] = {b[0] - a[0], b[1] - a[1], b[2] - a[2]}, e2[3] = {c[0] - a[0], c[1] - a[1], c[2] - a[2]};
        float n[3] = {e1[1] * e2[2] - e1[2] * e2[1], e1[2] * e2[0] - e1[0] * e2[2], e1[0] * e2[1] - e1[1] * e2[0]};
        float l = std::sqrt(n[0] * n[0] + n[1] * n[1] + n[2] * n[2]);
        if (l > 1e-12f) { n[0] /= l; n[1] /= l; n[2] /= l; } else { n[0] = 0; n[1] = 1; n[2] = 0; }
        for (float* v : {a, b, c}) {
            float vl = std::sqrt(v[3] * v[3] + v[4] * v[4] + v[5] * v[5]);
            if (vl < 1e-6f) { v[3] = n[0]; v[4] = n[1]; v[5] = n[2]; }
            else { v[3] /= vl; v[4] /= vl; v[5] /= vl; }
        }
    }
    // Quitar vertices repetidos (indexar): baja mucho la memoria.
    std::unordered_map<Key, uint32_t, KeyHash> seen;
    seen.reserve(nv / 2);
    out.v.clear();
    out.idx.clear();
    for (size_t i = 0; i < nv; i++) {
        Key k;
        memcpy(k.k, &raw.v[i * 8], 32);
        auto it = seen.find(k);
        if (it == seen.end()) {
            it = seen.emplace(k, (uint32_t)(out.v.size() / 8)).first;
            out.v.insert(out.v.end(), raw.v.begin() + i * 8, raw.v.begin() + i * 8 + 8);
        }
        out.idx.push_back(it->second);
    }
    out.tex = raw.tex;
    for (int c = 0; c < 3; c++) out.color[c] = raw.color[c];
    return true;
}


// ---------------------------------------------------------------- animaciones (esqueleto)
// Para cada hueso se guarda el giro "mundial" respecto al reposo (D); luego se convierte a giros locales del esqueleto destino.
struct AnimSrcClip {
    std::string name;
    float len = 1.f;
    std::vector<float> times;
    std::vector<std::vector<Quat>> D;  // [muestra][hueso]
    std::vector<V3> root;              // [muestra]
};
struct AnimSrc {
    std::vector<std::string> names;
    std::vector<int> parent;
    std::vector<V3> head;              // posicion de reposo normalizada (solo si habia malla)
    std::vector<AnimSrcClip> clips;
    bool haveSkeleton = false;
};

static Quat gltfQuat(const float* q) { return qNorm(Quat{q[0], q[1], q[2], q[3]}); }

static Quat matRotQuat(const float m[16]) {  // m en columnas; extrae la rotacion ignorando escala
    float c0[3] = {m[0], m[1], m[2]}, c1[3] = {m[4], m[5], m[6]}, c2[3] = {m[8], m[9], m[10]};
    auto nrm = [](float* c) { float l = std::sqrt(c[0] * c[0] + c[1] * c[1] + c[2] * c[2]); if (l > 1e-9f) { c[0] /= l; c[1] /= l; c[2] /= l; } };
    nrm(c0); nrm(c1); nrm(c2);
    float r00 = c0[0], r10 = c0[1], r20 = c0[2], r01 = c1[0], r11 = c1[1], r21 = c1[2], r02 = c2[0], r12 = c2[1], r22 = c2[2];
    Quat q;
    float tr = r00 + r11 + r22;
    if (tr > 0) {
        float sq = std::sqrt(tr + 1.f) * 2.f;
        q = {(r21 - r12) / sq, (r02 - r20) / sq, (r10 - r01) / sq, 0.25f * sq};
    } else if (r00 > r11 && r00 > r22) {
        float sq = std::sqrt(1.f + r00 - r11 - r22) * 2.f;
        q = {0.25f * sq, (r01 + r10) / sq, (r02 + r20) / sq, (r21 - r12) / sq};
    } else if (r11 > r22) {
        float sq = std::sqrt(1.f + r11 - r00 - r22) * 2.f;
        q = {(r01 + r10) / sq, 0.25f * sq, (r12 + r21) / sq, (r02 - r20) / sq};
    } else {
        float sq = std::sqrt(1.f + r22 - r00 - r11) * 2.f;
        q = {(r02 + r20) / sq, (r12 + r21) / sq, 0.25f * sq, (r10 - r01) / sq};
    }
    return qNorm(q);
}

static void bboxNorm(const Raw& raw, float ce[3], float& s) {
    size_t nv = raw.v.size() / 8;
    float mn[3] = {1e30f, 1e30f, 1e30f}, mx[3] = {-1e30f, -1e30f, -1e30f};
    for (size_t i = 0; i < nv; i++)
        for (int c = 0; c < 3; c++) { mn[c] = std::min(mn[c], raw.v[i * 8 + c]); mx[c] = std::max(mx[c], raw.v[i * 8 + c]); }
    float ext = std::max(mx[0] - mn[0], std::max(mx[1] - mn[1], mx[2] - mn[2]));
    s = ext > 1e-9f ? 1.f / ext : 1.f;
    for (int c = 0; c < 3; c++) ce[c] = nv ? (mn[c] + mx[c]) * 0.5f : 0.f;
}

static std::string cleanBoneName(std::string n) {
    size_t p = n.rfind(':');
    if (p != std::string::npos) n = n.substr(p + 1);
    for (auto& c : n) if (c == ' ' || c == '\t') c = '_';
    return n;
}

static bool gltfAnim(const std::vector<uint8_t>& data, AnimSrc& out, const ResMap* res, std::string& err) {
    cgltf_options opt;
    memset(&opt, 0, sizeof opt);
    cgltf_data* d = nullptr;
    if (cgltf_parse(&opt, data.data(), data.size(), &d) != cgltf_result_success) { err = "archivo glTF/GLB invalido"; return false; }
    struct Free { cgltf_data* d; ~Free() { cgltf_free(d); } } guard{d};
    if (cgltf_load_buffers(&opt, d, "") != cgltf_result_success) { err = "el glTF usa archivos externos: usa un .glb o un .zip"; return false; }
    if (d->animations_count == 0) { err = "el archivo no trae animaciones"; return false; }
    Raw raw;
    std::string e2;
    bool hasMesh = parseGltf(data, raw, res, e2) && raw.v.size() >= 24;
    float ce[3] = {0, 0, 0}, sc = 1.f;
    if (hasMesh) bboxNorm(raw, ce, sc);

    // huesos: los joints del primer "skin"; si no hay, los nodos que reciben animacion de giro
    std::vector<cgltf_node*> joints;
    if (d->skins_count > 0) for (size_t i = 0; i < d->skins[0].joints_count; i++) joints.push_back(d->skins[0].joints[i]);
    else {
        std::set<cgltf_node*> st;
        for (size_t a = 0; a < d->animations_count; a++)
            for (size_t c = 0; c < d->animations[a].channels_count; c++)
                if (d->animations[a].channels[c].target_node && d->animations[a].channels[c].target_path == cgltf_animation_path_type_rotation)
                    st.insert(d->animations[a].channels[c].target_node);
        for (size_t i = 0; i < d->nodes_count; i++) if (st.count(&d->nodes[i])) joints.push_back(&d->nodes[i]);
    }
    if (joints.empty()) { err = "no encontre esqueleto en el archivo"; return false; }
    // los padres antes que los hijos
    auto depth = [](cgltf_node* n) { int k = 0; while (n->parent) { n = n->parent; k++; } return k; };
    std::stable_sort(joints.begin(), joints.end(), [&](cgltf_node* a, cgltf_node* b) { return depth(a) < depth(b); });
    std::map<cgltf_node*, int> jid;
    for (size_t i = 0; i < joints.size(); i++) jid[joints[i]] = (int)i;
    size_t nb = joints.size();
    out.names.resize(nb);
    out.parent.assign(nb, -1);
    out.head.resize(nb);
    std::vector<Quat> restG(nb);
    for (size_t i = 0; i < nb; i++) {
        cgltf_node* n = joints[i];
        out.names[i] = n->name ? cleanBoneName(n->name) : "hueso_" + std::to_string(i);
        for (cgltf_node* p = n->parent; p; p = p->parent) if (jid.count(p)) { out.parent[i] = jid[p]; break; }
        float M[16];
        cgltf_node_transform_world(n, M);
        out.head[i] = V3{(M[12] - ce[0]) * sc, (M[13] - ce[1]) * sc, (M[14] - ce[2]) * sc};
        restG[i] = matRotQuat(M);
    }
    out.haveSkeleton = hasMesh;

    // rotacion global (animada) de un nodo
    struct Track { std::vector<float> t, v; int comps = 4; cgltf_interpolation_type it = cgltf_interpolation_type_linear; };
    for (size_t ai = 0; ai < d->animations_count; ai++) {
        cgltf_animation& an = d->animations[ai];
        std::map<cgltf_node*, Track> rot, trn;
        float dur = 0;
        for (size_t c = 0; c < an.channels_count; c++) {
            cgltf_animation_channel& ch = an.channels[c];
            if (!ch.target_node || !ch.sampler) continue;
            bool isR = ch.target_path == cgltf_animation_path_type_rotation, isT = ch.target_path == cgltf_animation_path_type_translation;
            if (!isR && !isT) continue;
            Track tr;
            tr.comps = isR ? 4 : 3;
            tr.it = ch.sampler->interpolation;
            size_t n = ch.sampler->input->count;
            tr.t.resize(n);
            for (size_t k = 0; k < n; k++) cgltf_accessor_read_float(ch.sampler->input, k, &tr.t[k], 1);
            size_t stride = tr.it == cgltf_interpolation_type_cubic_spline ? 3 : 1;
            tr.v.resize(n * tr.comps);
            for (size_t k = 0; k < n; k++) {
                float tmp[4] = {0, 0, 0, 1};
                cgltf_accessor_read_float(ch.sampler->output, k * stride + (stride == 3 ? 1 : 0), tmp, tr.comps);
                for (int q = 0; q < tr.comps; q++) tr.v[k * tr.comps + q] = tmp[q];
            }
            if (n) dur = std::max(dur, tr.t.back());
            (isR ? rot : trn)[ch.target_node] = std::move(tr);
        }
        if (rot.empty() && trn.empty()) continue;
        auto sampleQ = [&](const Track& tr, float t, Quat& q) {
            size_t n = tr.t.size();
            if (!n) return;
            if (t <= tr.t[0]) { q = gltfQuat(&tr.v[0]); return; }
            if (t >= tr.t[n - 1]) { q = gltfQuat(&tr.v[(n - 1) * 4]); return; }
            size_t k = 0;
            while (k + 1 < n && tr.t[k + 1] < t) k++;
            Quat a = gltfQuat(&tr.v[k * 4]), b = gltfQuat(&tr.v[(k + 1) * 4]);
            if (tr.it == cgltf_interpolation_type_step) { q = a; return; }
            float f = (t - tr.t[k]) / std::max(1e-6f, tr.t[k + 1] - tr.t[k]);
            q = qSlerp(a, b, f);
        };
        auto sampleV = [&](const Track& tr, float t, V3& v) {
            size_t n = tr.t.size();
            if (!n) return;
            auto at = [&](size_t k) { return V3{tr.v[k * 3], tr.v[k * 3 + 1], tr.v[k * 3 + 2]}; };
            if (t <= tr.t[0]) { v = at(0); return; }
            if (t >= tr.t[n - 1]) { v = at(n - 1); return; }
            size_t k = 0;
            while (k + 1 < n && tr.t[k + 1] < t) k++;
            if (tr.it == cgltf_interpolation_type_step) { v = at(k); return; }
            float f = (t - tr.t[k]) / std::max(1e-6f, tr.t[k + 1] - tr.t[k]);
            v = at(k) + (at(k + 1) - at(k)) * f;
        };
        AnimSrcClip clip;
        clip.name = an.name && *an.name ? an.name : "animacion" + std::to_string(ai + 1);
        for (auto& ch : clip.name) if (ch == ' ') ch = '_';
        clip.len = std::max(0.05f, dur);
        int nk = std::max(2, std::min(48, (int)std::ceil(dur * 20.f) + 1));
        // cache de rotacion local por nodo para un instante
        std::map<cgltf_node*, Quat> lrot;
        std::function<Quat(cgltf_node*, float)> localQ = [&](cgltf_node* n, float t) {
            auto it = rot.find(n);
            Quat q;
            if (n->has_rotation) q = gltfQuat(n->rotation);
            else if (n->has_matrix) q = matRotQuat(n->matrix);
            if (it != rot.end()) sampleQ(it->second, t, q);
            return q;
        };
        std::function<Quat(cgltf_node*, float)> globalQ = [&](cgltf_node* n, float t) -> Quat {
            Quat l = localQ(n, t);
            return n->parent ? qNorm(qMul(globalQ(n->parent, t), l)) : l;
        };
        for (int k = 0; k < nk; k++) {
            float t = dur * (float)k / (float)(nk - 1);
            clip.times.push_back(t);
            std::vector<Quat> Dv(nb);
            for (size_t i = 0; i < nb; i++) Dv[i] = qNorm(qMul(globalQ(joints[i], t), qInv(restG[i])));
            clip.D.push_back(std::move(Dv));
            V3 rt{0, 0, 0};
            for (size_t i = 0; i < nb; i++) {
                if (out.parent[i] >= 0) continue;
                auto it = trn.find(joints[i]);
                if (it == trn.end()) break;
                V3 cur;
                sampleV(it->second, t, cur);
                V3 rest = joints[i]->has_translation ? V3{joints[i]->translation[0], joints[i]->translation[1], joints[i]->translation[2]} : V3{cur};
                V3 dl = cur - V3{rest.x, rest.y, rest.z};
                if (!joints[i]->has_translation) { V3 first; sampleV(it->second, 0.f, first); dl = cur - first; }
                float M[16] = {1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1};
                if (joints[i]->parent) cgltf_node_transform_world(joints[i]->parent, M);
                rt = V3{M[0] * dl.x + M[4] * dl.y + M[8] * dl.z, M[1] * dl.x + M[5] * dl.y + M[9] * dl.z, M[2] * dl.x + M[6] * dl.y + M[10] * dl.z} * sc;
                break;
            }
            clip.root.push_back(rt);
        }
        out.clips.push_back(std::move(clip));
    }
    if (out.clips.empty()) { err = "no pude leer ninguna animación de giros"; return false; }
    return true;
}

static bool fbxAnim(const std::vector<uint8_t>& data, AnimSrc& out, const ResMap* res, std::string& err) {
    ufbx_load_opts opts;
    memset(&opts, 0, sizeof opts);
    opts.target_axes = ufbx_axes_right_handed_y_up;
    opts.target_unit_meters = 1.0f;
    ufbx_error uerr;
    ufbx_scene* sc = ufbx_load_memory(data.data(), data.size(), &opts, &uerr);
    if (!sc) { err = std::string("FBX invalido: ") + uerr.description.data; return false; }
    struct Free { ufbx_scene* s; ~Free() { ufbx_free_scene(s); } } guard{sc};
    if (sc->anim_stacks.count == 0) { err = "el archivo no trae animaciones"; return false; }
    Raw raw;
    bool hasMesh = parseFbx(data, raw, res, err) && raw.v.size() >= 24;
    err.clear();
    float ce[3] = {0, 0, 0}, ns = 1.f;
    if (hasMesh) bboxNorm(raw, ce, ns);
    std::vector<ufbx_node*> bones;
    std::set<ufbx_node*> seen;
    for (size_t i = 0; i < sc->skin_deformers.count; i++)
        for (size_t c = 0; c < sc->skin_deformers.data[i]->clusters.count; c++) {
            ufbx_node* bn = sc->skin_deformers.data[i]->clusters.data[c]->bone_node;
            if (bn && !seen.count(bn)) { seen.insert(bn); bones.push_back(bn); }
        }
    if (bones.empty())
        for (size_t i = 0; i < sc->bones.count; i++) for (size_t k = 0; k < sc->bones.data[i]->instances.count; k++) {
            ufbx_node* bn = sc->bones.data[i]->instances.data[k];
            if (!seen.count(bn)) { seen.insert(bn); bones.push_back(bn); }
        }
    if (bones.empty()) { err = "no encontre esqueleto en el archivo"; return false; }
    std::stable_sort(bones.begin(), bones.end(), [](ufbx_node* a, ufbx_node* b) { return a->node_depth < b->node_depth; });
    std::map<ufbx_node*, int> jid;
    for (size_t i = 0; i < bones.size(); i++) jid[bones[i]] = (int)i;
    size_t nb = bones.size();
    out.names.resize(nb);
    out.parent.assign(nb, -1);
    out.head.resize(nb);
    std::vector<Quat> restG(nb);
    auto q4 = [](ufbx_quat q) { return qNorm(Quat{(float)q.x, (float)q.y, (float)q.z, (float)q.w}); };
    for (size_t i = 0; i < nb; i++) {
        ufbx_node* n = bones[i];
        out.names[i] = cleanBoneName(std::string(n->name.data, n->name.length));
        for (ufbx_node* p = n->parent; p; p = p->parent) if (jid.count(p)) { out.parent[i] = jid[p]; break; }
        ufbx_transform wt = ufbx_matrix_to_transform(&n->node_to_world);
        out.head[i] = V3{((float)wt.translation.x - ce[0]) * ns, ((float)wt.translation.y - ce[1]) * ns, ((float)wt.translation.z - ce[2]) * ns};
        restG[i] = q4(wt.rotation);
    }
    out.haveSkeleton = hasMesh;
    for (size_t si = 0; si < sc->anim_stacks.count; si++) {
        ufbx_anim_stack* st = sc->anim_stacks.data[si];
        double t0 = st->time_begin, t1 = st->time_end, dur = std::max(0.05, t1 - t0);
        AnimSrcClip clip;
        clip.name = std::string(st->name.data, st->name.length);
        if (clip.name.empty()) clip.name = "animacion" + std::to_string(si + 1);
        for (auto& ch : clip.name) if (ch == ' ') ch = '_';
        clip.len = (float)dur;
        int nk = std::max(2, std::min(48, (int)std::ceil(dur * 20.0) + 1));
        std::function<Quat(ufbx_node*, double)> globalQ = [&](ufbx_node* n, double t) -> Quat {
            ufbx_transform lt = ufbx_evaluate_transform(st->anim, n, t);
            Quat l = q4(lt.rotation);
            return n->parent ? qNorm(qMul(globalQ(n->parent, t), l)) : l;
        };
        ufbx_transform rootRest = ufbx_evaluate_transform(st->anim, bones[0], t0);
        for (int k = 0; k < nk; k++) {
            double t = t0 + dur * (double)k / (double)(nk - 1);
            clip.times.push_back((float)(t - t0));
            std::vector<Quat> Dv(nb);
            for (size_t i = 0; i < nb; i++) Dv[i] = qNorm(qMul(globalQ(bones[i], t), qInv(globalQ(bones[i], t0))));
            clip.D.push_back(std::move(Dv));
            ufbx_transform rt = ufbx_evaluate_transform(st->anim, bones[0], t);
            clip.root.push_back(V3{(float)(rt.translation.x - rootRest.translation.x), (float)(rt.translation.y - rootRest.translation.y),
                                   (float)(rt.translation.z - rootRest.translation.z)} * ns);
        }
        (void)restG;
        out.clips.push_back(std::move(clip));
    }
    return true;
}

// Convierte los giros "mundiales" de la animacion a giros locales de un esqueleto, buscando los huesos por nombre.
static int bakeClips(const AnimSrc& src, Rig& dst, int& matched) {
    auto key = [](std::string n) { n = cleanBoneName(n); for (auto& c : n) c = (char)tolower((unsigned char)c); return n; };
    std::map<std::string, int> sidx;
    for (size_t i = 0; i < src.names.size(); i++) sidx[key(src.names[i])] = (int)i;
    size_t nb = dst.bones.size();
    std::vector<int> map(nb, -1);
    matched = 0;
    for (size_t i = 0; i < nb; i++) {
        auto it = sidx.find(key(dst.bones[i].name));
        if (it != sidx.end()) { map[i] = it->second; matched++; }
    }
    if (!matched) return 0;
    int added = 0;
    for (auto& c : src.clips) {
        RigClip rc;
        rc.name = c.name;
        for (int dup = 2; rigFindClip(dst, rc.name) >= 0; dup++) rc.name = c.name + "_" + std::to_string(dup);
        rc.len = c.len;
        rc.loop = true;
        for (size_t k = 0; k < c.times.size(); k++) {
            RigKey rk;
            rk.t = c.times[k];
            rk.pose.rot.assign(nb, Quat());
            std::vector<Quat> D(nb);
            for (size_t i = 0; i < nb; i++) D[i] = map[i] >= 0 ? c.D[k][map[i]] : Quat();
            for (size_t i = 0; i < nb; i++) {
                int p = dst.bones[i].parent;
                Quat dp = p >= 0 ? D[p] : Quat();
                rk.pose.rot[i] = qNorm(qMul(qInv(dp), D[i]));
            }
            rk.pose.root = c.root[k];
            rc.keys.push_back(rk);
        }
        dst.clips.push_back(rc);
        added++;
    }
    return added;
}

// Importa las animaciones de un archivo (glb, gltf, fbx). Si trae malla y esqueleto, crea el esqueleto (para 'modelAsset').
// Si 'rig' ya tiene huesos, las animaciones se asignan por nombre de hueso a ese esqueleto.
bool importAnimations(const std::string& fileName, const std::vector<uint8_t>& data, const std::string& modelAsset, Rig& rig,
                      int& clipsAdded, std::string& err, const ResMap* res) {
    std::string e = extOf(fileName);
    AnimSrc src;
    bool ok = false;
    if (e == "glb" || e == "gltf") ok = gltfAnim(data, src, res, err);
    else if (e == "fbx") ok = fbxAnim(data, src, res, err);
    else { err = "formato de animación no compatible (usa glb, gltf o fbx)"; return false; }
    if (!ok) return false;
    if (rig.bones.empty()) {
        if (!src.haveSkeleton) { err = "este archivo solo trae animaciones: primero crea o importa un esqueleto para el modelo"; return false; }
        rig.model = modelAsset;
        for (size_t i = 0; i < src.names.size(); i++) {
            RigBone b;
            b.name = src.names[i];
            b.parent = src.parent[i];
            b.head = src.head[i];
            rig.bones.push_back(b);
        }
    }
    int matched = 0;
    clipsAdded = bakeClips(src, rig, matched);
    if (!clipsAdded) { err = "los huesos del archivo no coinciden con los del esqueleto del modelo (nombres distintos)"; return false; }
    return true;
}

bool importModel(const std::string& fileName, const std::vector<uint8_t>& data, Files& assets,
                 std::string& modelAssetName, std::string& err, const ResMap* res) {
    std::string e = extOf(fileName), base = baseOf(fileName);
    Raw raw;
    bool ok = false;
    if (e == "obj") ok = parseObj(std::string(data.begin(), data.end()), raw, err, res);
    else if (e == "glb" || e == "gltf") ok = parseGltf(data, raw, res, err);
    else if (e == "fbx") ok = parseFbx(data, raw, res, err);
    else { err = "formato de modelo no compatible (usa obj, glb, gltf o fbx)"; return false; }
    if (!ok) return false;
    if (!applyMaterials(raw, assets, base, err)) return false;

    ModelData md;
    if (!finalize(raw, md, err)) return false;
    std::vector<uint8_t> bytes;
    if (!modelWrite(md, bytes)) { err = "no se pudo convertir el modelo"; return false; }

    std::string name = base + ".fmdl";
    for (int i = 2; assets.count(name); i++) name = base + "_" + std::to_string(i) + ".fmdl";
    assets[name] = std::move(bytes);
    modelAssetName = name;
    return true;
}

bool importModelZip(const std::vector<uint8_t>& zip, Files& assets, std::string& modelAssetName, std::string& err) {
    ResMap res;
    if (!unzipAll(zip, res, err)) return false;
    static const char* pref[] = {"glb", "gltf", "fbx", "obj"};
    for (const char* ext : pref)
        for (auto& kv : res)
            if (extOf(kv.first) == ext) return importModel(kv.first, kv.second, assets, modelAssetName, err, &res);
    err = "el zip no trae ningun modelo (obj, glb, gltf o fbx)";
    return false;
}

}  // namespace forge
