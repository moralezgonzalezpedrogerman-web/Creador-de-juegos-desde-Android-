#pragma once
// Utilidades de archivos (POSIX): Android y Linux.
#include <dirent.h>
#include <sys/stat.h>
#include <unistd.h>

#include <algorithm>
#include <cstdint>
#include <cstdio>
#include <string>
#include <vector>

namespace forge { namespace fs {

inline bool exists(const std::string& p) { struct stat s; return stat(p.c_str(), &s) == 0; }

inline bool mkdirs(const std::string& path) {
    for (size_t i = 1; i <= path.size(); i++) {
        if (i == path.size() || path[i] == '/') {
            std::string sub = path.substr(0, i);
            if (!sub.empty() && !exists(sub)) mkdir(sub.c_str(), 0755);
        }
    }
    return exists(path);
}

inline std::vector<std::string> list(const std::string& dir, bool dirsOnly = false) {
    std::vector<std::string> out;
    if (DIR* d = opendir(dir.c_str())) {
        while (dirent* e = readdir(d)) {
            std::string n = e->d_name;
            if (n == "." || n == "..") continue;
            struct stat s;
            bool isDir = stat((dir + "/" + n).c_str(), &s) == 0 && S_ISDIR(s.st_mode);
            if (isDir == dirsOnly) out.push_back(n);
        }
        closedir(d);
    }
    std::sort(out.begin(), out.end());
    return out;
}

inline bool read(const std::string& p, std::vector<uint8_t>& out) {
    FILE* f = fopen(p.c_str(), "rb");
    if (!f) return false;
    fseek(f, 0, SEEK_END);
    long n = ftell(f);
    fseek(f, 0, SEEK_SET);
    out.resize(n > 0 ? (size_t)n : 0);
    bool ok = n <= 0 || fread(out.data(), 1, (size_t)n, f) == (size_t)n;
    fclose(f);
    return ok;
}

inline bool write(const std::string& p, const uint8_t* d, size_t n) {
    FILE* f = fopen(p.c_str(), "wb");
    if (!f) return false;
    bool ok = n == 0 || fwrite(d, 1, n, f) == n;
    fclose(f);
    return ok;
}

inline bool remove(const std::string& p) { return ::remove(p.c_str()) == 0; }

inline void removeTree(const std::string& dir) {
    for (auto& f : list(dir, false)) remove(dir + "/" + f);
    for (auto& d : list(dir, true)) removeTree(dir + "/" + d);
    rmdir(dir.c_str());
}

}}  // namespace forge::fs
