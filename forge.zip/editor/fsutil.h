#pragma once
// Utilidades de archivos (std::filesystem): Android, Linux y Windows.
#include <algorithm>
#include <filesystem>
#include <system_error>
#include <cstdint>
#include <cstdio>
#include <string>
#include <vector>

namespace forge { namespace fs {

namespace stdfs = std::filesystem;

inline bool exists(const std::string& p) { std::error_code ec; return stdfs::exists(stdfs::u8path(p), ec); }

inline bool mkdirs(const std::string& path) {
    std::error_code ec;
    stdfs::create_directories(stdfs::u8path(path), ec);
    return exists(path);
}

inline std::vector<std::string> list(const std::string& dir, bool dirsOnly = false) {
    std::vector<std::string> out;
    std::error_code ec;
    for (stdfs::directory_iterator it(stdfs::u8path(dir), ec), end; !ec && it != end; it.increment(ec)) {
        std::error_code e2;
        bool isDir = it->is_directory(e2);
        if (isDir == dirsOnly) out.push_back(it->path().filename().u8string());
    }
    std::sort(out.begin(), out.end());
    return out;
}

inline bool read(const std::string& p, std::vector<uint8_t>& out) {
    FILE* f = fopen(p.c_str(), "rb");
    if (!f) return false;
    fseek(f, 0, SEEK_END);
    long n = ftell(f);
    fseek(f, 0, SEEK_SET);
    out.resize(n > 0 ? (size_t)n : 0);
    bool ok = n <= 0 || fread(out.data(), 1, (size_t)n, f) == (size_t)n;
    fclose(f);
    return ok;
}

inline bool write(const std::string& p, const uint8_t* d, size_t n) {
    FILE* f = fopen(p.c_str(), "wb");
    if (!f) return false;
    bool ok = n == 0 || fwrite(d, 1, n, f) == n;
    fclose(f);
    return ok;
}

inline bool remove(const std::string& p) { std::error_code ec; return stdfs::remove(stdfs::u8path(p), ec); }

inline void removeTree(const std::string& dir) {
    std::error_code ec;
    stdfs::remove_all(stdfs::u8path(dir), ec);
}

}}  // namespace forge::fs
