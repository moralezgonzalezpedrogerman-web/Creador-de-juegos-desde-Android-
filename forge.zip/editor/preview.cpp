#include "preview.h"
#include "model.h"
#include "stb_image.h"
#include <algorithm>
#include <cmath>

namespace forge {

bool modelPreviewRGBA(const std::vector<uint8_t>& fmdl, const Files& assets, int N, std::vector<uint8_t>& rgba) {
    ModelData m;
    if (!modelRead(fmdl.data(), fmdl.size(), m) || m.idx.size() < 3 || N < 8) return false;
    rgba.assign((size_t)N * N * 4, 0);
    std::vector<float> zb((size_t)N * N, -1e9f);

    int tw = 0, th = 0, tc = 0;
    unsigned char* tex = nullptr;
    auto ta = m.tex.empty() ? assets.end() : assets.find(m.tex);
    if (ta != assets.end()) {
        stbi_set_flip_vertically_on_load(0);
        tex = stbi_load_from_memory(ta->second.data(), (int)ta->second.size(), &tw, &th, &tc, 4);
    }

    const float ya = 0.62f, xa = -0.45f;  // vista de tres cuartos
    const float cy = std::cos(ya), sy = std::sin(ya), cx = std::cos(xa), sx = std::sin(xa);
    auto xf = [&](const float* p, float& X, float& Y, float& Z) {
        float x1 = cy * p[0] + sy * p[2], z1 = -sy * p[0] + cy * p[2], y1 = p[1];
        X = x1;
        Y = cx * y1 - sx * z1;
        Z = sx * y1 + cx * z1;
    };
    const float S = N * 0.62f, C = N * 0.5f;
    const float L[3] = {0.35f, 0.75f, 0.55f};
    float ll = std::sqrt(L[0] * L[0] + L[1] * L[1] + L[2] * L[2]);

    for (size_t t = 0; t + 2 < m.idx.size(); t += 3) {
        const float* v[3] = {&m.v[m.idx[t] * 8], &m.v[m.idx[t + 1] * 8], &m.v[m.idx[t + 2] * 8]};
        float X[3], Y[3], Z[3];
        for (int k = 0; k < 3; k++) xf(v[k], X[k], Y[k], Z[k]);
        float ex1 = X[1] - X[0], ey1 = Y[1] - Y[0], ez1 = Z[1] - Z[0], ex2 = X[2] - X[0], ey2 = Y[2] - Y[0], ez2 = Z[2] - Z[0];
        float nx = ey1 * ez2 - ez1 * ey2, ny = ez1 * ex2 - ex1 * ez2, nz = ex1 * ey2 - ey1 * ex2;
        float nl = std::sqrt(nx * nx + ny * ny + nz * nz);
        float light = 0.7f;
        if (nl > 1e-9f) {
            nx /= nl; ny /= nl; nz /= nl;
            light = 0.40f + 0.60f * std::fabs((nx * L[0] + ny * L[1] + nz * L[2]) / ll);
        }
        float px[3] = {C + X[0] * S, C - Y[0] * S, 0}, py[3];
        px[0] = C + X[0] * S; px[1] = C + X[1] * S; px[2] = C + X[2] * S;
        py[0] = C - Y[0] * S; py[1] = C - Y[1] * S; py[2] = C - Y[2] * S;
        float den = (py[1] - py[2]) * (px[0] - px[2]) + (px[2] - px[1]) * (py[0] - py[2]);
        if (std::fabs(den) < 1e-9f) continue;
        int x0 = std::max(0, (int)std::floor(std::min({px[0], px[1], px[2]}))), x1 = std::min(N - 1, (int)std::ceil(std::max({px[0], px[1], px[2]})));
        int y0 = std::max(0, (int)std::floor(std::min({py[0], py[1], py[2]}))), y1 = std::min(N - 1, (int)std::ceil(std::max({py[0], py[1], py[2]})));
        for (int y = y0; y <= y1; y++)
            for (int x = x0; x <= x1; x++) {
                float fx = x + 0.5f, fy = y + 0.5f;
                float a = ((py[1] - py[2]) * (fx - px[2]) + (px[2] - px[1]) * (fy - py[2])) / den;
                float b = ((py[2] - py[0]) * (fx - px[2]) + (px[0] - px[2]) * (fy - py[2])) / den;
                float c = 1.f - a - b;
                if (a < -0.02f || b < -0.02f || c < -0.02f) continue;
                float z = a * Z[0] + b * Z[1] + c * Z[2];
                size_t o = (size_t)y * N + x;
                if (z <= zb[o]) continue;
                zb[o] = z;
                float r = m.color[0], g = m.color[1], bl = m.color[2];
                if (tex) {
                    float u = a * v[0][6] + b * v[1][6] + c * v[2][6], w = a * v[0][7] + b * v[1][7] + c * v[2][7];
                    u -= std::floor(u);
                    w = 1.f - w;
                    w -= std::floor(w);
                    int ix = std::min(tw - 1, (int)(u * tw)), iy = std::min(th - 1, (int)(w * th));
                    const unsigned char* p = tex + ((size_t)iy * tw + ix) * 4;
                    r *= p[0] / 255.f; g *= p[1] / 255.f; bl *= p[2] / 255.f;
                }
                rgba[o * 4 + 0] = (uint8_t)std::min(255.f, r * light * 255.f);
                rgba[o * 4 + 1] = (uint8_t)std::min(255.f, g * light * 255.f);
                rgba[o * 4 + 2] = (uint8_t)std::min(255.f, bl * light * 255.f);
                rgba[o * 4 + 3] = 255;
            }
    }
    if (tex) stbi_image_free(tex);
    return true;
}

}  // namespace forge
