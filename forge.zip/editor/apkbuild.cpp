#include "apkbuild.h"

#include <algorithm>
#include <cstring>

#include "zip.h"

namespace forge {

typedef std::vector<uint8_t> Bytes;

// ------------------------------------------------------------------ SHA-256 y CRC32
namespace {
const uint32_t K256[64] = {
    0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b, 0x59f111f1, 0x923f82a4, 0xab1c5ed5, 0xd807aa98, 0x12835b01, 0x243185be,
    0x550c7dc3, 0x72be5d74, 0x80deb1fe, 0x9bdc06a7, 0xc19bf174, 0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc, 0x2de92c6f, 0x4a7484aa,
    0x5cb0a9dc, 0x76f988da, 0x983e5152, 0xa831c66d, 0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147, 0x06ca6351, 0x14292967, 0x27b70a85,
    0x2e1b2138, 0x4d2c6dfc, 0x53380d13, 0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85, 0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3,
    0xd192e819, 0xd6990624, 0xf40e3585, 0x106aa070, 0x19a4c116, 0x1e376c08, 0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f,
    0x682e6ff3, 0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208, 0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2};
inline uint32_t rr(uint32_t x, int n) { return (x >> n) | (x << (32 - n)); }

struct Sha {
    uint32_t h[8] = {0x6a09e667, 0xbb67ae85, 0x3c6ef372, 0xa54ff53a, 0x510e527f, 0x9b05688c, 0x1f83d9ab, 0x5be0cd19};
    uint8_t buf[64];
    size_t fill = 0;
    uint64_t total = 0;
    void block(const uint8_t* p) {
        uint32_t w[64];
        for (int i = 0; i < 16; i++) w[i] = (uint32_t)p[4 * i] << 24 | p[4 * i + 1] << 16 | p[4 * i + 2] << 8 | p[4 * i + 3];
        for (int i = 16; i < 64; i++) {
            uint32_t s0 = rr(w[i - 15], 7) ^ rr(w[i - 15], 18) ^ (w[i - 15] >> 3), s1 = rr(w[i - 2], 17) ^ rr(w[i - 2], 19) ^ (w[i - 2] >> 10);
            w[i] = w[i - 16] + s0 + w[i - 7] + s1;
        }
        uint32_t a = h[0], b = h[1], c = h[2], d = h[3], e = h[4], f = h[5], g = h[6], hh = h[7];
        for (int i = 0; i < 64; i++) {
            uint32_t S1 = rr(e, 6) ^ rr(e, 11) ^ rr(e, 25), ch = (e & f) ^ (~e & g), t1 = hh + S1 + ch + K256[i] + w[i];
            uint32_t S0 = rr(a, 2) ^ rr(a, 13) ^ rr(a, 22), mj = (a & b) ^ (a & c) ^ (b & c), t2 = S0 + mj;
            hh = g; g = f; f = e; e = d + t1; d = c; c = b; b = a; a = t1 + t2;
        }
        h[0] += a; h[1] += b; h[2] += c; h[3] += d; h[4] += e; h[5] += f; h[6] += g; h[7] += hh;
    }
    void update(const uint8_t* d, size_t n) {
        total += n;
        while (n) {
            size_t k = std::min(n, 64 - fill);
            memcpy(buf + fill, d, k);
            fill += k; d += k; n -= k;
            if (fill == 64) { block(buf); fill = 0; }
        }
    }
    Bytes finish() {
        uint64_t bits = total * 8;
        uint8_t pad = 0x80;
        update(&pad, 1);
        uint8_t z = 0;
        while (fill != 56) update(&z, 1);
        uint8_t l[8];
        for (int i = 0; i < 8; i++) l[i] = (uint8_t)(bits >> (56 - 8 * i));
        update(l, 8);
        Bytes o(32);
        for (int i = 0; i < 8; i++) { o[4 * i] = h[i] >> 24; o[4 * i + 1] = h[i] >> 16; o[4 * i + 2] = h[i] >> 8; o[4 * i + 3] = h[i]; }
        return o;
    }
};

uint32_t crc32(const uint8_t* d, size_t n) {
    static uint32_t T[256];
    static bool init = false;
    if (!init) {
        for (uint32_t i = 0; i < 256; i++) { uint32_t c = i; for (int k = 0; k < 8; k++) c = c & 1 ? 0xEDB88320u ^ (c >> 1) : c >> 1; T[i] = c; }
        init = true;
    }
    uint32_t c = 0xffffffffu;
    for (size_t i = 0; i < n; i++) c = T[(c ^ d[i]) & 255] ^ (c >> 8);
    return ~c;
}

// ------------------------------------------------------------------ enteros grandes (RSA)
typedef std::vector<uint32_t> Big;  // little endian

Big fromBE(const uint8_t* p, size_t n) {
    Big b((n + 3) / 4, 0);
    for (size_t i = 0; i < n; i++) b[i / 4] |= (uint32_t)p[n - 1 - i] << (8 * (i % 4));
    return b;
}
bool geq(const Big& a, const Big& n) {
    for (size_t i = a.size(); i-- > 0;) { if (a[i] != n[i]) return a[i] > n[i]; }
    return true;
}
void subIn(Big& a, const Big& n) {
    int64_t br = 0;
    for (size_t i = 0; i < a.size(); i++) {
        int64_t v = (int64_t)a[i] - n[i] - br;
        br = v < 0;
        a[i] = (uint32_t)v;
    }
}
struct Mont {
    Big n;
    uint32_t n0;
    size_t L;
    explicit Mont(const Big& nn) : n(nn), L(nn.size()) {
        uint32_t x = n[0];
        for (int i = 0; i < 5; i++) x *= 2 - n[0] * x;
        n0 = (uint32_t)(0 - x);
    }
    Big mul(const Big& a, const Big& b) const {
        std::vector<uint32_t> t(L + 2, 0);
        for (size_t i = 0; i < L; i++) {
            uint64_t C = 0;
            for (size_t j = 0; j < L; j++) { uint64_t s = (uint64_t)t[j] + (uint64_t)a[j] * b[i] + C; t[j] = (uint32_t)s; C = s >> 32; }
            uint64_t s = (uint64_t)t[L] + C;
            t[L] = (uint32_t)s; t[L + 1] = (uint32_t)(s >> 32);
            uint32_t m = t[0] * n0;
            s = (uint64_t)t[0] + (uint64_t)m * n[0];
            C = s >> 32;
            for (size_t j = 1; j < L; j++) { s = (uint64_t)t[j] + (uint64_t)m * n[j] + C; t[j - 1] = (uint32_t)s; C = s >> 32; }
            s = (uint64_t)t[L] + C;
            t[L - 1] = (uint32_t)s; C = s >> 32;
            t[L] = t[L + 1] + (uint32_t)C;
        }
        Big r(t.begin(), t.begin() + L);
        if (t[L] || geq(r, n)) subIn(r, n);
        return r;
    }
    Big r2() const {  // 2^(64 L) mod n
        Big x(L, 0);
        x[0] = 1;
        for (size_t i = 0; i < 64 * L; i++) {
            uint32_t carry = 0;
            for (size_t j = 0; j < L; j++) { uint32_t nc = x[j] >> 31; x[j] = (x[j] << 1) | carry; carry = nc; }
            if (carry || geq(x, n)) subIn(x, n);
        }
        return x;
    }
};
Big modexp(const Big& base, const Big& d, const Big& n) {
    Mont M(n);
    Big R2 = M.r2(), b = base;
    b.resize(M.L, 0);
    Big one(M.L, 0);
    one[0] = 1;
    Big x = M.mul(one, R2), bm = M.mul(b, R2);
    for (size_t i = d.size() * 32; i-- > 0;) {
        x = M.mul(x, x);
        if ((d[i / 32] >> (i % 32)) & 1) x = M.mul(x, bm);
    }
    return M.mul(x, one);
}

// ------------------------------------------------------------------ DER minimo
struct Tlv { uint8_t tag; size_t hdr, len, pos; };  // pos = inicio del elemento
bool tlv(const Bytes& b, size_t pos, Tlv& t) {
    if (pos + 2 > b.size()) return false;
    t.tag = b[pos]; t.pos = pos;
    size_t l = b[pos + 1], h = 2;
    if (l & 0x80) {
        size_t k = l & 0x7f;
        if (k == 0 || k > 4 || pos + 2 + k > b.size()) return false;
        l = 0;
        for (size_t i = 0; i < k; i++) l = (l << 8) | b[pos + 2 + i];
        h = 2 + k;
    }
    t.hdr = h; t.len = l;
    return pos + h + l <= b.size();
}
}  // namespace

std::vector<uint8_t> sha256(const uint8_t* d, size_t n) { Sha s; s.update(d, n); return s.finish(); }

std::vector<uint8_t> rsaSignSha256(const Bytes& pk8, const uint8_t* msg, size_t n) {
    // PrivateKeyInfo { INT, SEQ algo, OCTET STRING { RSAPrivateKey { INT 0, n, e, d, ... } } }
    Tlv t;
    if (!tlv(pk8, 0, t) || t.tag != 0x30) return {};
    size_t p = t.pos + t.hdr;
    Tlv v, alg, oct;
    if (!tlv(pk8, p, v) || v.tag != 2) return {};
    p = v.pos + v.hdr + v.len;
    if (!tlv(pk8, p, alg) || alg.tag != 0x30) return {};
    p = alg.pos + alg.hdr + alg.len;
    if (!tlv(pk8, p, oct) || oct.tag != 4) return {};
    Tlv rsa;
    if (!tlv(pk8, oct.pos + oct.hdr, rsa) || rsa.tag != 0x30) return {};
    p = rsa.pos + rsa.hdr;
    Tlv f[4];
    for (int i = 0; i < 4; i++) {
        if (!tlv(pk8, p, f[i]) || f[i].tag != 2) return {};
        p = f[i].pos + f[i].hdr + f[i].len;
    }
    auto num = [&](const Tlv& x) {
        size_t s = x.pos + x.hdr, l = x.len;
        while (l > 1 && pk8[s] == 0) { s++; l--; }
        return fromBE(&pk8[s], l);
    };
    size_t ns = f[1].pos + f[1].hdr, nl = f[1].len;
    while (nl > 1 && pk8[ns] == 0) { ns++; nl--; }
    size_t k = nl;
    if (k < 64) return {};
    Big N = fromBE(&pk8[ns], nl), D = num(f[3]);
    Bytes h = sha256(msg, n);
    static const uint8_t pre[19] = {0x30, 0x31, 0x30, 0x0d, 0x06, 0x09, 0x60, 0x86, 0x48, 0x01, 0x65, 0x03, 0x04, 0x02, 0x01, 0x05, 0x00, 0x04, 0x20};
    Bytes em(k, 0xff);
    em[0] = 0; em[1] = 1;
    size_t tl = 19 + 32;
    em[k - tl - 1] = 0;
    memcpy(&em[k - tl], pre, 19);
    memcpy(&em[k - 32], h.data(), 32);
    Big S = modexp(fromBE(em.data(), em.size()), D, N);
    Bytes out(k);
    for (size_t i = 0; i < k; i++) out[k - 1 - i] = (uint8_t)(S[i / 4] >> (8 * (i % 4)));
    return out;
}

// ------------------------------------------------------------------ utilidades binarias
namespace {
inline int u16(const Bytes& b, size_t o) { return b[o] | (b[o + 1] << 8); }
inline uint32_t u32(const Bytes& b, size_t o) { return (uint32_t)u16(b, o) | ((uint32_t)u16(b, o + 2) << 16); }
inline void p16(Bytes& b, size_t o, int v) { b[o] = (uint8_t)v; b[o + 1] = (uint8_t)(v >> 8); }
inline void p32(Bytes& b, size_t o, uint32_t v) { p16(b, o, v & 0xffff); p16(b, o + 2, v >> 16); }
void put32(Bytes& o, uint32_t v) { for (int i = 0; i < 4; i++) o.push_back((uint8_t)(v >> (8 * i))); }
void put64(Bytes& o, uint64_t v) { put32(o, (uint32_t)v); put32(o, (uint32_t)(v >> 32)); }
void app(Bytes& o, const Bytes& b) { o.insert(o.end(), b.begin(), b.end()); }
Bytes lp(const Bytes& b) { Bytes o; put32(o, (uint32_t)b.size()); app(o, b); return o; }
Bytes cat(std::initializer_list<Bytes> ps) { Bytes o; for (auto& p : ps) app(o, p); return o; }
Bytes le32(uint32_t v) { Bytes o; put32(o, v); return o; }

// ---- manifest binario
const int RES_XML = 3, RES_POOL = 1, RES_MAP = 0x180, XML_START = 0x102;
const uint32_t ATTR_LABEL = 0x01010001, ATTR_AUTH = 0x01010018, ATTR_ORIENT = 0x0101001e, ATTR_VERCODE = 0x0101021b, ATTR_VERNAME = 0x0101021c;

size_t strLen(const Bytes& b, size_t o, bool utf8) {
    if (utf8) {
        size_t p = o;
        int l = b[p]; p += (l & 0x80) ? 2 : 1;
        int bl = b[p];
        if (bl & 0x80) { bl = ((bl & 0x7f) << 8) | b[p + 1]; p += 2; } else p += 1;
        return (p - o) + bl + 1;
    }
    size_t l = u16(b, o), p = o + 2;
    if (l & 0x8000) { l = ((l & 0x7fff) << 16) | u16(b, o + 2); p += 2; }
    return (p - o) + l * 2 + 2;
}
std::string decodeStr(const Bytes& b, size_t o, bool utf8) {
    if (utf8) {
        size_t p = o;
        int l = b[p]; p += (l & 0x80) ? 2 : 1;
        int bl = b[p];
        if (bl & 0x80) { bl = ((bl & 0x7f) << 8) | b[p + 1]; p += 2; } else p += 1;
        return std::string((const char*)&b[p], bl);
    }
    size_t l = u16(b, o), p = o + 2;
    if (l & 0x8000) { l = ((l & 0x7fff) << 16) | u16(b, o + 2); p += 2; }
    std::string s;  // los nombres del manifest son ASCII
    for (size_t i = 0; i < l; i++) s += (char)b[p + 2 * i];
    return s;
}
Bytes encodeStr(const std::string& s, bool utf8) {
    Bytes o;
    if (utf8) {
        size_t cl = 0;
        for (unsigned char ch : s) if ((ch & 0xC0) != 0x80) cl++;
        if (cl > 0x7f) { o.push_back((uint8_t)((cl >> 8) | 0x80)); o.push_back(cl & 0xff); } else o.push_back((uint8_t)cl);
        if (s.size() > 0x7f) { o.push_back((uint8_t)((s.size() >> 8) | 0x80)); o.push_back(s.size() & 0xff); } else o.push_back((uint8_t)s.size());
        o.insert(o.end(), s.begin(), s.end());
        o.push_back(0);
    } else {
        std::vector<uint16_t> u;  // UTF-8 -> UTF-16
        for (size_t i = 0; i < s.size();) {
            unsigned c = (unsigned char)s[i];
            unsigned cp = c; int ex = 0;
            if (c >= 0xF0) { cp = c & 7; ex = 3; } else if (c >= 0xE0) { cp = c & 15; ex = 2; } else if (c >= 0xC0) { cp = c & 31; ex = 1; }
            i++;
            for (int k = 0; k < ex && i < s.size(); k++, i++) cp = (cp << 6) | ((unsigned char)s[i] & 63);
            if (cp >= 0x10000) { cp -= 0x10000; u.push_back((uint16_t)(0xD800 + (cp >> 10))); u.push_back((uint16_t)(0xDC00 + (cp & 0x3ff))); }
            else u.push_back((uint16_t)cp);
        }
        size_t cl = u.size();
        o.push_back(cl & 0xff); o.push_back((cl >> 8) & 0x7f);
        for (uint16_t c : u) { o.push_back(c & 0xff); o.push_back(c >> 8); }
        o.push_back(0); o.push_back(0);
    }
    return o;
}
}  // namespace

bool apkPatchManifest(const Bytes& in, const ApkConfig& c, Bytes& out, std::string& err) {
    if (in.size() < 36 || u16(in, 0) != RES_XML) { err = "AndroidManifest.xml no es binario"; return false; }
    size_t ps = u16(in, 2);
    if (u16(in, ps) != RES_POOL) { err = "Falta el pool de strings del manifest"; return false; }
    size_t poolSize = u32(in, ps + 4), count = u32(in, ps + 8), styleCount = u32(in, ps + 12);
    uint32_t flags = u32(in, ps + 16);
    size_t strStart = u32(in, ps + 20);
    if (styleCount != 0) { err = "Manifest con estilos: no soportado"; return false; }
    bool utf8 = (flags & (1 << 8)) != 0;
    size_t offBase = ps + u16(in, ps + 2);
    std::vector<Bytes> raw;
    std::vector<std::string> txt;
    for (size_t i = 0; i < count; i++) {
        size_t o = ps + strStart + u32(in, offBase + 4 * i);
        size_t n = strLen(in, o, utf8);
        raw.emplace_back(in.begin() + o, in.begin() + o + n);
        txt.push_back(decodeStr(in, o, utf8));
    }
    Bytes rest(in.begin() + ps + poolSize, in.end());
    std::vector<uint32_t> resId(count, 0);
    size_t off = 0;
    while (off + 8 <= rest.size()) {
        int type = u16(rest, off);
        size_t size = u32(rest, off + 4);
        if (size < 8) { err = "Chunk invalido"; return false; }
        if (type == RES_MAP) {
            size_t n = (size - u16(rest, off + 2)) / 4;
            for (size_t i = 0; i < n && i < count; i++) resId[i] = u32(rest, off + u16(rest, off + 2) + 4 * i);
        }
        off += size;
    }
    std::vector<std::string> add;
    long newPkg = -1, newLabel = -1, newVerName = -1, newAuth = -1;
    std::string oldAuth = c.oldPackage + ".apkprovider", cur;
    bool sawPkg = false, sawLabel = false;
    off = 0;
    while (off + 8 <= rest.size()) {
        int type = u16(rest, off);
        size_t size = u32(rest, off + 4);
        if (type == XML_START) {
            uint32_t nameIdx = u32(rest, off + 20);
            cur = nameIdx < count ? txt[nameIdx] : "";
            size_t attrStart = off + 16 + u16(rest, off + 24), attrSize = u16(rest, off + 26), attrCount = u16(rest, off + 28);
            for (size_t a = 0; a < attrCount; a++) {
                size_t ao = attrStart + a * attrSize;
                uint32_t ns = u32(rest, ao), nm = u32(rest, ao + 4);
                uint32_t id = nm < count ? resId[nm] : 0;
                std::string aname = nm < count ? txt[nm] : "";
                int dtype = rest[ao + 15];
                auto newStr = [&](long& slot, const std::string& s) { if (slot < 0) { add.push_back(s); slot = (long)count + (long)add.size() - 1; } return (uint32_t)slot; };
                auto setStr = [&](uint32_t idx) { p32(rest, ao + 8, idx); rest[ao + 15] = 3; p32(rest, ao + 16, idx); };
                if (cur == "manifest") {
                    if (ns == 0xffffffffu && aname == "package") { setStr(newStr(newPkg, c.appId)); sawPkg = true; }
                    else if (id == ATTR_VERCODE) { p32(rest, ao + 16, (uint32_t)c.verCode); rest[ao + 15] = 0x10; p32(rest, ao + 8, 0xffffffffu); }
                    else if (id == ATTR_VERNAME) setStr(newStr(newVerName, c.verName));
                } else if (cur == "application" && id == ATTR_LABEL) { setStr(newStr(newLabel, c.label)); sawLabel = true; }
                else if (cur == "activity" && id == ATTR_ORIENT) {
                    uint32_t v = c.orient == 1 ? 7 : c.orient == 2 ? 10 : 6;
                    rest[ao + 15] = 0x10; p32(rest, ao + 16, v); p32(rest, ao + 8, 0xffffffffu);
                } else if (cur == "provider" && id == ATTR_AUTH && dtype == 3) {
                    uint32_t si = u32(rest, ao + 8);
                    if (si < count && txt[si] == oldAuth) { uint32_t ni = newStr(newAuth, c.appId + ".apkprovider"); p32(rest, ao + 8, ni); p32(rest, ao + 16, ni); }
                }
            }
        }
        off += size;
    }
    if (!sawPkg) { err = "El manifest de la plantilla no trae el paquete"; return false; }
    if (!sawLabel) { err = "El manifest de la plantilla no trae la etiqueta de la app"; return false; }
    for (auto& s : add) raw.push_back(encodeStr(s, utf8));
    size_t n = raw.size(), dataLen = 0;
    for (auto& r : raw) dataLen += r.size();
    size_t pad = (4 - dataLen % 4) % 4, newStrStart = 28 + 4 * n, newPoolSize = newStrStart + dataLen + pad;
    Bytes pool(newPoolSize, 0);
    p16(pool, 0, RES_POOL); p16(pool, 2, 28); p32(pool, 4, (uint32_t)newPoolSize);
    p32(pool, 8, (uint32_t)n); p32(pool, 12, 0);
    p32(pool, 16, flags & ~1u);
    p32(pool, 20, (uint32_t)newStrStart); p32(pool, 24, 0);
    size_t cu = 0;
    for (size_t i = 0; i < n; i++) {
        p32(pool, 28 + 4 * i, (uint32_t)cu);
        memcpy(&pool[newStrStart + cu], raw[i].data(), raw[i].size());
        cu += raw[i].size();
    }
    out.assign(in.begin(), in.begin() + ps);
    app(out, pool);
    app(out, rest);
    p32(out, 4, (uint32_t)out.size());
    return true;
}

// ------------------------------------------------------------------ zip
namespace {
struct ZEntry {
    std::string name;
    int method = 0, flags = 0, time = 0, date = 0;
    uint32_t crc = 0, csize = 0, usize = 0, extAttr = 0, localOff = 0;
    Bytes data;
    bool fresh = false;
};

bool readCentral(const Bytes& f, std::vector<ZEntry>& list, std::string& err) {
    if (f.size() < 22) { err = "La plantilla no es un zip/APK"; return false; }
    long e = -1;
    for (long i = (long)f.size() - 22; i >= 0 && i >= (long)f.size() - 65557; i--) if (u32(f, i) == 0x06054b50u) { e = i; break; }
    if (e < 0) { err = "La plantilla no es un zip/APK valido"; return false; }
    size_t n = u16(f, e + 10), cdOff = u32(f, e + 16);
    size_t p = cdOff;
    for (size_t i = 0; i < n; i++) {
        if (p + 46 > f.size() || u32(f, p) != 0x02014b50u) { err = "Directorio central danado"; return false; }
        ZEntry z;
        z.flags = u16(f, p + 8); z.method = u16(f, p + 10); z.time = u16(f, p + 12); z.date = u16(f, p + 14);
        z.crc = u32(f, p + 16); z.csize = u32(f, p + 20); z.usize = u32(f, p + 24);
        size_t nl = u16(f, p + 28), el = u16(f, p + 30), cl = u16(f, p + 32);
        z.extAttr = u32(f, p + 38); z.localOff = u32(f, p + 42);
        z.name.assign((const char*)&f[p + 46], nl);
        list.push_back(z);
        p += 46 + nl + el + cl;
    }
    return true;
}
bool rawOf(const Bytes& f, const ZEntry& z, const uint8_t*& ptr, std::string& err) {
    size_t o = z.localOff;
    if (o + 30 > f.size() || u32(f, o) != 0x04034b50u) { err = "Cabecera local danada: " + z.name; return false; }
    size_t d = o + 30 + u16(f, o + 26) + u16(f, o + 28);
    if (d + z.csize > f.size()) { err = "Entrada truncada: " + z.name; return false; }
    ptr = &f[d];
    return true;
}
bool readEntry(const Bytes& f, const ZEntry& z, Bytes& out, std::string& err) {
    const uint8_t* p;
    if (!rawOf(f, z, p, err)) return false;
    if (z.method == 0) { out.assign(p, p + z.csize); return true; }
    out.clear();
    if (!inflateRaw(p, z.csize, out, (size_t)z.usize + 16) || out.size() != z.usize) { err = "Entrada corrupta: " + z.name; return false; }
    return true;
}
bool endsWith(const std::string& s, const char* e) { size_t n = strlen(e); return s.size() >= n && s.compare(s.size() - n, n, e) == 0; }
}  // namespace

bool apkBuild(const Bytes& tpl, const std::map<std::string, Bytes>& extra, const Bytes& iconPng, const ApkConfig& c, const Bytes& pk8,
              const Bytes& certDer, Bytes& out, bool* iconReplaced, std::string& err) {
    // paquete valido: [a-z][a-z0-9_]*(.[a-z][a-z0-9_]*)+
    {
        int dots = 0; bool ok = !c.appId.empty(), start = true;
        for (char ch : c.appId) {
            if (start) { if (!(ch >= 'a' && ch <= 'z')) { ok = false; break; } start = false; }
            else if (ch == '.') { dots++; start = true; }
            else if (!((ch >= 'a' && ch <= 'z') || (ch >= '0' && ch <= '9') || ch == '_')) { ok = false; break; }
        }
        if (!ok || start || dots == 0 || c.appId.size() > 127) { err = "Paquete invalido: " + c.appId; return false; }
    }
    std::vector<ZEntry> in;
    if (!readCentral(tpl, in, err)) return false;
    ZEntry *man = nullptr, *arsc = nullptr;
    for (auto& z : in) { if (z.name == "AndroidManifest.xml") man = &z; else if (z.name == "resources.arsc") arsc = &z; }
    if (!man) { err = "La plantilla no tiene AndroidManifest.xml"; return false; }
    if (!arsc) { err = "La plantilla no tiene resources.arsc"; return false; }

    std::map<std::string, ZEntry> repl;
    auto fresh = [&](const ZEntry& like, Bytes d) {
        ZEntry z; z.name = like.name; z.data = std::move(d); z.method = 0; z.time = like.time; z.date = like.date; z.fresh = true;
        return z;
    };
    Bytes mdata, mout, adata;
    if (!readEntry(tpl, *man, mdata, err) || !apkPatchManifest(mdata, c, mout, err)) return false;
    repl[man->name] = fresh(*man, mout);
    if (!readEntry(tpl, *arsc, adata, err)) return false;
    if (adata.size() < 12 || u16(adata, 0) != 2) { err = "resources.arsc invalido"; return false; }
    bool any = false;
    for (size_t off = u16(adata, 2); off + 8 <= adata.size();) {
        int type = u16(adata, off);
        size_t size = u32(adata, off + 4);
        if (size < 8) break;
        if (type == 0x200 && off + 12 + 256 <= adata.size()) {
            Bytes nm;  // appId en UTF-16LE (ASCII)
            for (char ch : c.appId) { nm.push_back((uint8_t)ch); nm.push_back(0); }
            for (size_t i = 0; i < 256; i++) adata[off + 12 + i] = i < nm.size() ? nm[i] : 0;
            any = true;
        }
        off += size;
    }
    if (!any) { err = "resources.arsc sin paquete"; return false; }
    repl[arsc->name] = fresh(*arsc, adata);
    bool iconDone = false;
    if (!iconPng.empty())
        for (auto& z : in)
            if (z.name.compare(0, 4, "res/") == 0 && endsWith(z.name, "app_icon.png")) { repl[z.name] = fresh(z, iconPng); iconDone = true; }
    if (iconReplaced) *iconReplaced = iconDone;
    for (auto& e : extra) {
        ZEntry z; z.name = e.first; z.data = e.second; z.method = 0; z.time = 0; z.date = (1 << 5) | 1 | (46 << 9); z.fresh = true;
        repl[z.name] = z;
    }

    Bytes dst, cdAll;
    uint32_t count = 0;
    auto writeEntry = [&](const ZEntry& z) -> bool {
        const uint8_t* stored = nullptr;
        size_t slen = 0;
        uint32_t crc = z.crc, usize = z.usize;
        if (z.fresh) { stored = z.data.data(); slen = z.data.size(); crc = crc32(stored, slen); usize = (uint32_t)slen; }
        else { if (!rawOf(tpl, z, stored, err)) return false; slen = z.csize; }
        int method = z.method;
        if (slen >= 0xffffffffu) { err = "Archivo demasiado grande para el APK"; return false; }
        size_t nameLen = z.name.size();
        int align = method != 0 ? 0 : (endsWith(z.name, ".so") ? 4096 : 4);
        size_t pad = 0;
        if (align > 0) {
            size_t dataPos = dst.size() + 30 + nameLen;
            pad = (align - dataPos % align) % align;
            while (pad > 0 && pad < 6) pad += align;
        }
        Bytes lh(30, 0);
        int flags = z.flags & 0x0800;
        p32(lh, 0, 0x04034b50u); p16(lh, 4, 20); p16(lh, 6, flags); p16(lh, 8, method);
        p16(lh, 10, z.time); p16(lh, 12, z.date);
        p32(lh, 14, crc); p32(lh, 18, (uint32_t)slen); p32(lh, 22, usize);
        p16(lh, 26, (int)nameLen); p16(lh, 28, (int)pad);
        uint32_t localOff = (uint32_t)dst.size();
        app(dst, lh);
        dst.insert(dst.end(), z.name.begin(), z.name.end());
        Bytes extra2(pad, 0);
        if (pad > 0) { p16(extra2, 0, 0xD935); p16(extra2, 2, (int)pad - 4); p16(extra2, 4, align > 4096 ? 4096 : align); }
        app(dst, extra2);
        dst.insert(dst.end(), stored, stored + slen);
        Bytes cd(46, 0);
        p32(cd, 0, 0x02014b50u); p16(cd, 4, 0x0314); p16(cd, 6, 20); p16(cd, 8, flags); p16(cd, 10, method);
        p16(cd, 12, z.time); p16(cd, 14, z.date);
        p32(cd, 16, crc); p32(cd, 20, (uint32_t)slen); p32(cd, 24, usize);
        p16(cd, 28, (int)nameLen);
        p32(cd, 38, z.fresh ? 0 : z.extAttr); p32(cd, 42, localOff);
        app(cdAll, cd);
        cdAll.insert(cdAll.end(), z.name.begin(), z.name.end());
        count++;
        return true;
    };
    for (auto& z : in) {
        const std::string& n = z.name;
        if (!n.empty() && n.back() == '/') continue;
        if (n.compare(0, 9, "META-INF/") == 0 && (endsWith(n, ".SF") || endsWith(n, ".RSA") || endsWith(n, ".DSA") || endsWith(n, ".EC") || n == "META-INF/MANIFEST.MF")) continue;
        if (n == "assets/forge_runtime.exe" || n == "assets/apk_sign_key.pk8" || n == "assets/apk_sign_cert.der") continue;
        auto it = repl.find(n);
        if (it != repl.end()) { ZEntry u = it->second; repl.erase(it); if (!writeEntry(u)) return false; }
        else if (!writeEntry(z)) return false;
    }
    for (auto& r : repl) if (!writeEntry(r.second)) return false;
    if (count > 65000) { err = "Demasiados archivos"; return false; }
    uint32_t cdOff = (uint32_t)dst.size();
    app(dst, cdAll);
    uint32_t cdEnd = (uint32_t)dst.size();
    Bytes eocd(22, 0);
    p32(eocd, 0, 0x06054b50u); p16(eocd, 8, (int)count); p16(eocd, 10, (int)count);
    p32(eocd, 12, cdEnd - cdOff); p32(eocd, 16, cdOff);
    app(dst, eocd);

    // ---- firma v2
    const size_t CHUNK = 1 << 20;
    Bytes dg;
    uint32_t chunks = 0;
    auto range = [&](size_t a, size_t b) {
        for (size_t p = a; p < b; p += CHUNK) {
            size_t n = std::min(CHUNK, b - p);
            Sha s;
            uint8_t hd[5] = {0xa5, (uint8_t)n, (uint8_t)(n >> 8), (uint8_t)(n >> 16), (uint8_t)(n >> 24)};
            s.update(hd, 5);
            s.update(&dst[p], n);
            app(dg, s.finish());
            chunks++;
        }
    };
    range(0, cdOff); range(cdOff, cdEnd); range(cdEnd, dst.size());
    Sha ts;
    uint8_t th[5] = {0x5a, (uint8_t)chunks, (uint8_t)(chunks >> 8), (uint8_t)(chunks >> 16), (uint8_t)(chunks >> 24)};
    ts.update(th, 5);
    ts.update(dg.data(), dg.size());
    Bytes top = ts.finish();

    // clave publica (SubjectPublicKeyInfo) dentro del certificado
    Bytes spki;
    {
        Tlv cert, tbs;
        if (!tlv(certDer, 0, cert) || cert.tag != 0x30 || !tlv(certDer, cert.pos + cert.hdr, tbs) || tbs.tag != 0x30) { err = "Certificado invalido"; return false; }
        size_t p = tbs.pos + tbs.hdr;
        Tlv x;
        if (!tlv(certDer, p, x)) { err = "Certificado invalido"; return false; }
        if (x.tag == 0xA0) { p = x.pos + x.hdr + x.len; }
        for (int i = 0; i < 5; i++) {  // serie, algoritmo, emisor, validez, sujeto
            if (!tlv(certDer, p, x)) { err = "Certificado invalido"; return false; }
            p = x.pos + x.hdr + x.len;
        }
        if (!tlv(certDer, p, x) || x.tag != 0x30) { err = "Certificado invalido"; return false; }
        spki.assign(certDer.begin() + x.pos, certDer.begin() + x.pos + x.hdr + x.len);
    }
    Bytes digestItem = lp(cat({le32(0x0103), lp(top)}));
    Bytes digests = lp(digestItem);
    Bytes certs = lp(lp(certDer));
    Bytes signedData = cat({digests, certs, lp(Bytes())});
    Bytes sig = rsaSignSha256(pk8, signedData.data(), signedData.size());
    if (sig.empty()) { err = "No se pudo firmar (clave invalida)"; return false; }
    Bytes sigs = lp(lp(cat({le32(0x0103), lp(sig)})));
    Bytes signer = cat({lp(signedData), sigs, lp(spki)});
    Bytes signers = lp(lp(signer));
    Bytes pair;
    put64(pair, 4 + signers.size());
    put32(pair, 0x7109871au);
    app(pair, signers);
    uint64_t blockSize = pair.size() + 8 + 16;
    Bytes blk;
    put64(blk, blockSize);
    app(blk, pair);
    put64(blk, blockSize);
    const char* magic = "APK Sig Block 42";
    blk.insert(blk.end(), magic, magic + 16);

    out.assign(dst.begin(), dst.begin() + cdOff);
    app(out, blk);
    out.insert(out.end(), dst.begin() + cdOff, dst.begin() + cdEnd);
    Bytes e2(dst.begin() + cdEnd, dst.end());
    p32(e2, 16, cdOff + (uint32_t)blk.size());
    app(out, e2);
    return true;
}

}  // namespace forge
