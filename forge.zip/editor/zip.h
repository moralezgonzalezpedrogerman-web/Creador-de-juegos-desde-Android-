#pragma once
#include <cstdint>
#include <map>
#include <string>
#include <vector>

namespace forge {

// Lector minimo de .zip (almacenado y deflate). Las claves son el nombre del archivo en minusculas, sin carpetas.
using ResMap = std::map<std::string, std::vector<uint8_t>>;
bool unzipAll(const std::vector<uint8_t>& zip, ResMap& out, std::string& err);

// Descomprime un flujo deflate crudo (RFC 1951).
bool inflateRaw(const uint8_t* src, size_t n, std::vector<uint8_t>& out, size_t maxOut);

}  // namespace forge
