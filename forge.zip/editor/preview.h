#pragma once
#include "scene.h"
#include "model.h"
#include <cstdint>
#include <vector>

namespace forge {

// Dibuja una miniatura (N x N, RGBA, fondo transparente) de un modelo .fmdl con un rasterizador pequeno en CPU:
// sirve en cualquier plataforma y no usa la GPU. Usa la textura del modelo si existe.
bool modelPreviewRGBA(const std::vector<uint8_t>& fmdl, const Files& assets, int N, std::vector<uint8_t>& rgba);


struct ModelData;
// Igual pero con los vertices que se le den (para ver un modelo deformado por su esqueleto) y el ángulo de vista.
bool meshRaster(const ModelData& m, const std::vector<float>& verts8, const Files& assets, int N, float yawA, float pitchA, std::vector<uint8_t>& rgba);

}  // namespace forge
