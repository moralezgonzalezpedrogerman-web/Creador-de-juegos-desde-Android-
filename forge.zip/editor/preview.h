#pragma once
#include "scene.h"
#include <cstdint>
#include <vector>

namespace forge {

// Dibuja una miniatura (N x N, RGBA, fondo transparente) de un modelo .fmdl con un rasterizador pequeno en CPU:
// sirve en cualquier plataforma y no usa la GPU. Usa la textura del modelo si existe.
bool modelPreviewRGBA(const std::vector<uint8_t>& fmdl, const Files& assets, int N, std::vector<uint8_t>& rgba);

}  // namespace forge
