// Paginas del editor (como Pocket Code): Proyecto -> Escenas -> Escena -> Objeto (Scripts / Apariencias / Sonidos),
// editor de bloques con arrastrar y soltar, paleta de bloques por categorias y editor de formulas.
#include "editor.h"
#include "formula.h"
#include "fsutil.h"

#include "imgui.h"
#include "misc/cpp/imgui_stdlib.h"

#include <algorithm>
#include <cmath>
#include <cstdio>

namespace forge {

namespace {

ImVec4 catRGB(Cat c, float k = 1.f) {
    float r = .5f, g = .5f, b = .5f;
    switch (c) {
        case Cat::Eventos: r = .82f; g = .35f; b = .10f; break;
        case Cat::Control: r = .97f; g = .62f; b = .35f; break;
        case Cat::Movimiento: r = .29f; g = .51f; b = .78f; break;
        case Cat::Sonido: r = .45f; g = .30f; b = .65f; break;
        case Cat::Apariencia: r = .36f; g = .62f; b = .28f; break;
        case Cat::Datos: r = .93f; g = .25f; b = .31f; break;
        case Cat::Forge3D: r = .15f; g = .60f; b = .62f; break;
    }
    return ImVec4(r * k, g * k, b * k, 1.f);
}
ImU32 col32(const ImVec4& v) { return ImGui::ColorConvertFloat4ToU32(v); }

std::string shorten(const std::string& s, size_t n = 22) {
    if (s.size() <= n) return s;
    size_t k = n;
    while (k > 0 && ((unsigned char)s[k] & 0xC0) == 0x80) k--;  // no cortar un caracter UTF-8
    return s.substr(0, k) + "..";
}

struct Tok { int type; std::string s; };  // 0 palabra, 1 formula (s = "0".."2"), 2 texto {t}
std::vector<Tok> tokenize(const char* title) {
    std::vector<Tok> v;
    std::string w;
    auto flush = [&]() { if (!w.empty()) { v.push_back({0, w}); w.clear(); } };
    for (const char* p = title; *p; p++) {
        if (*p == ' ') { flush(); continue; }
        if (*p == '{') {
            flush();
            std::string k;
            p++;
            while (*p && *p != '}') k += *p++;
            if (k == "t") v.push_back({2, ""});
            else v.push_back({1, k});
            if (!*p) break;
            continue;
        }
        w += *p;
    }
    flush();
    return v;
}

std::string plainTitle(const OpInfo& in) {
    std::string out;
    for (auto& t : tokenize(in.title)) {
        if (!out.empty()) out += ' ';
        if (t.type == 0) out += t.s;
        else if (t.type == 2) out += in.t && *in.t ? in.t : "...";
        else {
            const char* f = t.s == "0" ? in.f0 : t.s == "1" ? in.f1 : in.f2;
            out += f && *f ? f : "0";
        }
    }
    return out;
}

struct PreviewEnv : FormulaEnv {
    bool lookup(const std::string&, const std::vector<Val>&, Val&) override { return false; }
};

bool gHandle = false;  // un asa de bloque esta pulsada (no desplazar la lista)

}  // namespace

namespace {
struct Preset { int id; const char* name; const char* sub; int group; };  // group: 0 diseno, 1 enemigos, 2 objetos, 3 puertas, 4 niveles
const Preset kPresets[] = {
    {0, "Cubo", "diseño", 0}, {1, "Suelo", "diseño", 0}, {2, "Pared", "diseño", 0}, {3, "Ítem", "decoración", 0},
    {4, "Luz", "lámpara", 0}, {5, "Modelo 3D", "importar", 0}, {25, "Inicio jugador", "dónde empieza", 0},
    {10, "Enemigo", "te persigue", 1}, {11, "Monstruo", "grande y fuerte", 1},
    {12, "Arma", "da munición", 2}, {13, "Munición", "+10 balas", 2}, {14, "Botiquín", "+25 vida", 2},
    {15, "Llave", "la recoges", 2}, {16, "Interruptor", "envía mensaje", 2}, {24, "Cartel", "muestra texto", 2},
    {17, "Puerta horiz.", "se abre al tocar", 3}, {18, "Puerta vert.", "se abre al tocar", 3},
    {19, "Destruible horiz.", "se rompe a tiros", 3}, {20, "Destruible vert.", "se rompe a tiros", 3},
    {21, "Fin de nivel", "cambia de escena", 4}, {22, "Teleport inicio", "te lleva al fin", 4}, {23, "Teleport fin", "destino", 4},
};
Block mkB(Op op, const char* t = "", const char* a = "", const char* b = "", const char* c = "") {
    Block k;
    k.op = op; k.t = t; k.f[0] = a; k.f[1] = b; k.f[2] = c;
    return k;
}
std::string num(float v) {
    char b[32];
    snprintf(b, sizeof b, "%.2f", v);
    std::string s = b;
    while (s.size() > 1 && s.back() == '0') s.pop_back();
    if (!s.empty() && s.back() == '.') s.pop_back();
    return s;
}
}  // namespace

// ---------------------------------------------------------------- bloques (logica)
bool Editor::blockRange(const std::vector<Block>& B, int i, int& end) {
    if (i < 0 || i >= (int)B.size()) return false;
    int k = opInfo(B[i].op).indent;
    if (k == 2) {
        end = i + 1;
        while (end < (int)B.size() && opInfo(B[end].op).indent != 2) end++;
        return true;
    }
    if (k == 1) {
        int d = 0;
        for (int j = i; j < (int)B.size(); j++) {
            int q = opInfo(B[j].op).indent;
            if (q == 1) d++;
            else if (q == -1 && --d == 0) { end = j + 1; return true; }
        }
        end = (int)B.size();
        return true;
    }
    if (k == 0) { end = i + 1; return true; }
    return false;  // cierres y "de lo contrario" no se mueven solos
}

bool Editor::moveRange(std::vector<Block>& B, int from, int to) {
    int e;
    if (!blockRange(B, from, e)) return false;
    if (to < 0 || to > (int)B.size() || (to >= from && to <= e)) return false;
    std::vector<Block> g(B.begin() + from, B.begin() + e);
    B.erase(B.begin() + from, B.begin() + e);
    int t = to > from ? to - (e - from) : to;
    B.insert(B.begin() + t, g.begin(), g.end());
    return true;
}

int Editor::addBlock(Obj& o, Op op) {
    auto make = [](Op x) {
        const OpInfo& in = opInfo(x);
        Block b;
        b.op = x;
        b.t = in.t ? in.t : "";
        b.f[0] = in.f0 ? in.f0 : "";
        b.f[1] = in.f1 ? in.f1 : "";
        b.f[2] = in.f2 ? in.f2 : "";
        return b;
    };
    if (o.blocks.empty() && !isHat(op)) o.blocks.push_back(make(Op::WhenStart));
    int idx = (int)o.blocks.size();
    o.blocks.push_back(make(op));
    if (op == Op::If) {
        o.blocks.push_back(make(Op::Else));
        o.blocks.push_back(make(Op::EndIf));
    } else if (op == Op::Repeat || op == Op::Forever) {
        o.blocks.push_back(make(Op::LoopEnd));
    }
    markDirty();
    return idx;
}

// ---------------------------------------------------------------- ayudantes de pagina
bool Editor::tapped() const { return dragAcc_ < ImGui::GetFontSize() * 0.6f; }

void Editor::dragScroll() {
    bool skip = gHandle;
    gHandle = false;
    float fs = ImGui::GetFontSize();
    if (ImGui::GetDragDropPayload()) {  // al arrastrar un bloque, desplazar cerca de los bordes
        ImVec2 m = ImGui::GetIO().MousePos, p = ImGui::GetWindowPos(), s = ImGui::GetWindowSize();
        if (m.x >= p.x && m.x <= p.x + s.x) {
            if (m.y < p.y + fs * 2.5f) ImGui::SetScrollY(ImGui::GetScrollY() - fs * 0.6f);
            else if (m.y > p.y + s.y - fs * 2.5f) ImGui::SetScrollY(ImGui::GetScrollY() + fs * 0.6f);
        }
        return;
    }
    static ImGuiID active = 0;
    static float vel = 0;
    ImGuiID me = ImGui::GetID("##dragscroll");
    // AllowWhenBlockedByActiveItem: se puede arrastrar empezando sobre un boton (antes no deslizaba)
    bool inside = ImGui::IsWindowHovered(ImGuiHoveredFlags_AllowWhenBlockedByActiveItem);
    if (!skip && inside && ImGui::IsMouseDragging(0, fs * 0.6f)) {
        float dy = ImGui::GetIO().MouseDelta.y;
        ImGui::SetScrollY(ImGui::GetScrollY() - dy);
        vel = dy;
        active = me;
        return;
    }
    if (active == me && !ImGui::IsMouseDown(0)) {  // un poco de inercia al soltar
        if (std::fabs(vel) > 0.6f) { ImGui::SetScrollY(ImGui::GetScrollY() - vel); vel *= 0.92f; }
        else { vel = 0; active = 0; }
    }
}

bool Editor::beginPage(const char* id) {
    ImGui::SetNextWindowPos(ImVec2(0, 0));
    ImGui::SetNextWindowSize(ImVec2((float)w_, (float)h_));
    ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(0, 0));
    ImGui::PushStyleVar(ImGuiStyleVar_WindowBorderSize, 0.f);
    bool ok = ImGui::Begin(id, nullptr,
                           ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoResize |
                               ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoBringToFrontOnFocus |
                               ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NoScrollWithMouse |
                               ImGuiWindowFlags_NoSavedSettings);
    ImGui::PopStyleVar(2);
    return ok;
}

void Editor::endPage() { ImGui::End(); }

bool Editor::topBar(const std::string& title, bool* back, bool* menu) {
    float fs = ImGui::GetFontSize();
    ImVec2 p = ImGui::GetCursorScreenPos();
    float bh = fs * 2.8f;
    ImGui::GetWindowDrawList()->AddRectFilled(p, ImVec2(p.x + w_, p.y + bh), IM_COL32(34, 44, 68, 255));
    if (back) *back = false;
    if (menu) *menu = false;
    ImGui::SetCursorScreenPos(ImVec2(p.x + fs * 0.4f, p.y + fs * 0.4f));
    if (back) {
        if (ImGui::Button("<", ImVec2(fs * 2.f, fs * 2.f))) *back = true;
        ImGui::SameLine();
    }
    ImGui::SetCursorScreenPos(ImVec2(ImGui::GetCursorScreenPos().x + fs * 0.3f, p.y + fs * 0.4f + (fs * 2.f - fs) * 0.5f));
    ImGui::TextUnformatted(shorten(title, 28).c_str());
    if (menu) {
        ImGui::SetCursorScreenPos(ImVec2(p.x + w_ - fs * 2.6f, p.y + fs * 0.4f));
        if (ImGui::Button("...", ImVec2(fs * 2.2f, fs * 2.f))) *menu = true;
    }
    ImGui::SetCursorScreenPos(ImVec2(p.x, p.y + bh + fs * 0.2f));
    return true;
}

void Editor::fab(bool* play, bool* plus) {
    float fs = ImGui::GetFontSize();
    if (play) *play = false;
    if (plus) *plus = false;
    ImGui::SetNextWindowPos(ImVec2((float)w_ - fs * 0.8f, (float)h_ - fs * 0.8f), ImGuiCond_Always, ImVec2(1.f, 1.f));
    ImGui::SetNextWindowBgAlpha(0.f);
    ImGui::Begin("##fab", nullptr,
                 ImGuiWindowFlags_NoDecoration | ImGuiWindowFlags_AlwaysAutoResize | ImGuiWindowFlags_NoMove |
                     ImGuiWindowFlags_NoSavedSettings | ImGuiWindowFlags_NoNav | ImGuiWindowFlags_NoBackground);
    if (play) {
        ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(0.20f, 0.60f, 0.30f, 1.f));
        if (ImGui::Button("Jugar", ImVec2(fs * 4.5f, fs * 3.f))) *play = true;
        ImGui::PopStyleColor();
        if (plus) ImGui::SameLine();
    }
    if (plus) {
        ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(0.20f, 0.45f, 0.85f, 1.f));
        if (ImGui::Button("+", ImVec2(fs * 3.f, fs * 3.f))) *plus = true;
        ImGui::PopStyleColor();
    }
    ImGui::End();
}

void Editor::thumb(Renderer* r, const Obj& o, float size) {
    ImVec2 p = ImGui::GetCursorScreenPos();
    ImGui::Dummy(ImVec2(size, size));
    ImDrawList* dl = ImGui::GetWindowDrawList();
    ImU32 c = IM_COL32((int)(o.color[0] * 255), (int)(o.color[1] * 255), (int)(o.color[2] * 255), 255);
    dl->AddRectFilled(p, ImVec2(p.x + size, p.y + size), o.bg || o.kind != Kind::Light ? c : IM_COL32(255, 220, 120, 255), 6.f);
    std::string name = !o.tex.empty() ? o.tex : (!o.looks.empty() ? o.looks[0] : "");
    if (r && !name.empty()) {
        int tw = 1, th = 1;
        unsigned tid = r->textureId(edit_, name, &tw, &th);
        if (tid) {
            float k = std::min(size / tw, size / th);
            float iw = tw * k, ih = th * k;
            ImVec2 a(p.x + (size - iw) * 0.5f, p.y + (size - ih) * 0.5f);
            dl->AddImage((ImTextureID)(intptr_t)tid, a, ImVec2(a.x + iw, a.y + ih));
        }
    }
}

std::vector<std::string> Editor::varNames(const Obj& o) const {
    std::vector<std::string> v = edit_.proj.globalVars;
    for (auto& s : o.localVars) v.push_back(s);
    return v;
}

std::vector<std::string> Editor::messageNames() const {
    std::vector<std::string> v;
    for (auto& s : edit_.proj.scenes)
        for (auto& o : s.objs)
            for (auto& b : o.blocks)
                if ((b.op == Op::WhenReceive || b.op == Op::Broadcast || b.op == Op::BroadcastWait) && !b.t.empty() &&
                    std::find(v.begin(), v.end(), b.t) == v.end())
                    v.push_back(b.t);
    if (v.empty()) v.push_back("mensaje1");
    std::sort(v.begin(), v.end());
    return v;
}

void Editor::applyRename() {
    if (!renameBuf_.empty()) {
        if (renameWhat_ == 1 && renameIdx_ >= 0 && renameIdx_ < (int)edit_.proj.scenes.size()) {
            std::string old = edit_.proj.scenes[renameIdx_].name;
            edit_.proj.scenes[renameIdx_].name = renameBuf_;
            for (auto& s : edit_.proj.scenes)  // los bloques "Iniciar escena" siguen apuntando bien
                for (auto& o : s.objs)
                    for (auto& b : o.blocks)
                        if (b.op == Op::StartScene && b.t == old) b.t = renameBuf_;
            markDirty();
        } else if (renameWhat_ == 2 && hasScene() && renameIdx_ >= 0 && renameIdx_ < (int)scene().objs.size()) {
            scene().objs[renameIdx_].name = renameBuf_;
            markDirty();
        }
    }
    renameWhat_ = 0;
}

void Editor::renameUI() {
    if (renameWhat_ <= 0) return;
    if (host_.prompt) {  // Android: directo al cuadro de texto nativo
        if (!promptActive_) {
            promptActive_ = true;
            promptDst_ = &renameBuf_;
            host_.prompt(renameWhat_ == 1 ? "Nombre de la escena" : "Nombre del objeto", renameBuf_);
        }
        return;
    }
    if (!ImGui::IsPopupOpen("Renombrar")) ImGui::OpenPopup("Renombrar");
    float fs = ImGui::GetFontSize();
    ImGui::SetNextWindowPos(ImVec2(w_ * 0.5f, h_ * 0.3f), ImGuiCond_Always, ImVec2(0.5f, 0.f));
    if (ImGui::BeginPopupModal("Renombrar", nullptr, ImGuiWindowFlags_AlwaysAutoResize)) {
        textInput("##n", "Nombre", renameBuf_, nullptr, fs * 14.f);
        bool ok = ImGui::Button("Aceptar", ImVec2(fs * 6.f, 0));
        ImGui::SameLine();
        bool no = ImGui::Button("Cancelar", ImVec2(fs * 6.f, 0));
        if (ok) applyRename();
        if (no) renameWhat_ = 0;
        if (ok || no) ImGui::CloseCurrentPopup();
        ImGui::EndPopup();
    }
}

void Editor::projectMenu() {
    float fs = ImGui::GetFontSize();
    if (projMenu_) { ImGui::OpenPopup("##proj"); projMenu_ = false; }
    ImGui::SetNextWindowPos(ImVec2((float)w_ - fs * 0.4f, fs * 3.2f), ImGuiCond_Always, ImVec2(1.f, 0.f));
    if (ImGui::BeginPopup("##proj")) {
        if (ImGui::MenuItem("Guardar")) saveProject();
        if (ImGui::MenuItem("Archivos (imágenes, sonidos, modelos)")) showAssets = true;
        if (ImGui::MenuItem("Botones y arma")) showHud = true;
        if (hasScene() && scene().is3d && ImGui::MenuItem("Mundo (cielo y luz)")) showWorld = true;
        ImGui::Separator();
        if (ImGui::MenuItem("Exportar juego (APK, EXE, paquete)...")) showExport_ = true;
        ImGui::Separator();
        if (ImGui::MenuItem("Cerrar proyecto")) { ImGui::CloseCurrentPopup(); ImGui::EndPopup(); if (dirty_) saveProject(); closeProject(); return; }
        ImGui::EndPopup();
    }
}

void Editor::objectMenuItems(int idx) {
    if (!hasScene() || idx < 0 || idx >= (int)scene().objs.size()) return;
    Scene& S = scene();
    Obj& o = S.objs[idx];
    if (ImGui::MenuItem("Renombrar")) { renameWhat_ = 2; renameIdx_ = idx; renameBuf_ = o.name; }
    if (!o.bg) {
        if (ImGui::MenuItem("Duplicar")) {
            Obj c = o;
            c.name = uniqueName(o.name);
            c.pos.x += S.is3d ? 1.f : 40.f;
            S.objs.push_back(c);
            markDirty();
        }
        static int confirm = -1;
        if (confirm == idx) {
            if (ImGui::MenuItem("Confirmar: eliminar")) {
                S.objs.erase(S.objs.begin() + idx);
                sel_ = -1;
                confirm = -1;
                markDirty();
            }
        } else if (ImGui::MenuItem("Eliminar", nullptr, false, true)) {
            confirm = idx;
        }
    }
}

void Editor::newObjectMenu() {
    float fs = ImGui::GetFontSize();
    bool is3d = hasScene() && scene().is3d;
    if (plusOpen_) {
        if (is3d) grid3dOpen_ = true;
        else ImGui::OpenPopup("##plus");
        plusOpen_ = false;
    }
    if (is3d && grid3dOpen_) {  // cuadricula "Objeto nuevo" como en FPS Creator
        modalOpen("Objeto nuevo");
        ImGui::SetNextWindowPos(ImVec2(w_ * 0.5f, h_ * 0.5f), ImGuiCond_Always, ImVec2(0.5f, 0.5f));
        ImGui::SetNextWindowSize(ImVec2(w_ * 0.96f, h_ * 0.94f));
        if (ImGui::BeginPopupModal("Objeto nuevo", nullptr,
                                   ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoCollapse |
                                       ImGuiWindowFlags_NoSavedSettings | ImGuiWindowFlags_NoScrollbar |
                                       ImGuiWindowFlags_NoScrollWithMouse)) {
            bool close = false;
            ImGui::TextUnformatted("OBJETO NUEVO");
            ImGui::SameLine(ImGui::GetContentRegionAvail().x - fs * 6.f);
            if (ImGui::Button("Cancelar", ImVec2(fs * 6.f, 0)) && tapped()) close = true;
            ImGui::Separator();
            ImGui::BeginChild("##grid", ImVec2(0, 0), false, ImGuiWindowFlags_NoScrollbar);
            dragScroll();
            static const char* groups[] = {"DISEÑO", "ENEMIGOS", "OBJETOS", "PUERTAS Y PAREDES", "NIVEL"};
            static const ImVec4 gcol[] = {{0.30f, 0.34f, 0.55f, 1}, {0.60f, 0.20f, 0.20f, 1}, {0.20f, 0.50f, 0.30f, 1},
                                          {0.60f, 0.40f, 0.15f, 1}, {0.25f, 0.45f, 0.60f, 1}};
            float aw = ImGui::GetContentRegionAvail().x;
            int cols = 5;
            float tw = (aw - ImGui::GetStyle().ItemSpacing.x * (cols - 1) - fs * 0.3f) / cols;
            int pick = -1;
            for (int g = 0; g < 5; g++) {
                ImGui::Spacing();
                ImGui::TextDisabled("%s", groups[g]);
                int n = 0;
                for (auto& pr : kPresets) {
                    if (pr.group != g) continue;
                    if (n % cols) ImGui::SameLine();
                    n++;
                    ImGui::PushID(pr.id);
                    ImGui::PushStyleColor(ImGuiCol_Button, gcol[g]);
                    std::string lab = std::string(pr.name) + "\n" + pr.sub;
                    if (ImGui::Button(lab.c_str(), ImVec2(tw, fs * 4.2f)) && tapped()) pick = pr.id;
                    ImGui::PopStyleColor();
                    ImGui::PopID();
                }
            }
            ImGui::Dummy(ImVec2(1, fs * 3.f));
            ImGui::EndChild();
            if (pick >= 0) {
                if (pick == 5) { grid3dOpen_ = false; ImGui::CloseCurrentPopup(); plusOpen_ = false; modelsOpen_ = true; }
                else { addPreset(pick); close = true; }
            }
            if (close) { grid3dOpen_ = false; ImGui::CloseCurrentPopup(); }
            ImGui::EndPopup();
        } else {
            grid3dOpen_ = false;
        }
    }
    if (modelsOpen_) { ImGui::OpenPopup("##models"); modelsOpen_ = false; }
    ImGui::SetNextWindowPos(ImVec2(w_ * 0.5f, h_ * 0.5f), ImGuiCond_Always, ImVec2(0.5f, 0.5f));
    if (ImGui::BeginPopup("##models")) {
        ImGui::TextDisabled("Modelo 3D");
        if (ImGui::Button("+ Importar modelo nuevo (obj, glb, gltf, fbx)", ImVec2(fs * 22.f, fs * 2.4f)) && tapped()) {
            pendingNewModel_ = true;
            if (host_.pickFile) host_.pickFile();
            ImGui::CloseCurrentPopup();
        }
        ImGui::TextDisabled("Si tu modelo es .blend, expórtalo a .glb desde Blender.");
        ImGui::Separator();
        auto models = assetsOf(2);
        if (models.empty()) ImGui::TextDisabled("Aún no hay modelos importados");
        for (auto& m : models)
            if (ImGui::Button(m.c_str(), ImVec2(fs * 22.f, fs * 2.2f)) && tapped()) { addObject(Kind::Model, m); ImGui::CloseCurrentPopup(); }
        ImGui::EndPopup();
    }
    if (is3d) return;
    ImGui::SetNextWindowPos(ImVec2((float)w_ - fs * 0.8f, (float)h_ - fs * 4.4f), ImGuiCond_Always, ImVec2(1.f, 1.f));
    if (ImGui::BeginPopup("##plus")) {
        ImGui::TextDisabled("Objeto nuevo");
        ImGui::Separator();
        if (ImGui::MenuItem("Cuadro de color")) addObject(Kind::Cube);
        if (ImGui::MenuItem("Seleccionar una imagen...")) { pendingNewObj_ = true; if (host_.pickFile) host_.pickFile(); }
        if (ImGui::BeginMenu("Biblioteca (imágenes del proyecto)")) {
            auto imgs = assetsOf(0);
            if (imgs.empty()) ImGui::TextDisabled("Aún no hay imágenes");
            for (auto& m : imgs)
                if (ImGui::MenuItem(m.c_str())) {
                    addObject(Kind::Cube);
                    if (Obj* o = selObj()) { o->tex = m; o->color[0] = o->color[1] = o->color[2] = 1.f; }
                }
            ImGui::EndMenu();
        }
        if (ImGui::MenuItem("Objeto vacío (sin imagen)")) {
            addObject(Kind::Cube);
            if (Obj* o = selObj()) { o->visible = false; o->name = uniqueName("Vacio"); }
        }
        ImGui::Separator();
        ImGui::TextDisabled("Dibujar, foto y mochila: próximamente");
        ImGui::EndPopup();
    }
}

// ---------------------------------------------------------------- objetos de juego (como "Creating a new object" de FPS Creator)
void Editor::addPreset(int id) {
    if (!hasScene()) return;
    Scene& S = scene();
    Project& P = edit_.proj;
    auto ensure = [&](const char* g) {
        if (std::find(P.globalVars.begin(), P.globalVars.end(), g) == P.globalVars.end()) P.globalVars.push_back(g);
    };
    switch (id) {
        case 0: addObject(Kind::Cube); return;
        case 1: addObject(Kind::Floor); return;
        case 2: addObject(Kind::Wall); return;
        case 3: addObject(Kind::Item); return;
        case 4: addObject(Kind::Light); return;
        case 5: grid3dOpen_ = false; ImGui::OpenPopup("##models"); return;
        case 25: {
            S.start = {std::round(target_.x), 0.05f, std::round(target_.z)};
            markDirty();
            toast("El jugador empezará aquí");
            return;
        }
    }
    Kind k = Kind::Cube;
    if (id == 12 || id == 13 || id == 14 || id == 15 || id == 21 || id == 22 || id == 23) k = Kind::Item;
    if (id >= 17 && id <= 20) k = Kind::Wall;
    addObject(k);
    Obj* o = selObj();
    if (!o) return;
    auto col = [&](float r, float g, float b) { o->color[0] = r; o->color[1] = g; o->color[2] = b; };
    auto rest = [&](float h) { o->pos.y = h * 0.5f + 0.02f; };
    auto name = [&](const char* n) { o->name = uniqueName(n); };
    o->tex.clear();
    switch (id) {
        case 10: case 11: {  // enemigo / monstruo
            bool mon = id == 11;
            name(mon ? "Monstruo" : "Enemigo");
            o->scale = mon ? V3{1.4f, 2.4f, 1.4f} : V3{0.8f, 1.8f, 0.8f};
            rest(o->scale.y);
            if (mon) col(0.5f, 0.2f, 0.7f); else col(0.8f, 0.15f, 0.15f);
            o->solid = true; o->spin = false;
            ensure("vida"); ensure("puntos");
            AiCfg& a = o->ai;
            a = AiCfg();
            a.type = mon ? AiType::Melee : AiType::Shooter;
            a.hp = mon ? 6.f : 3.f;
            a.speed = mon ? 3.f : 2.f;
            a.dmg = mon ? 10.f : 5.f;
            a.rate = mon ? 0.9f : 1.4f;
            a.reach = mon ? 1.8f : 1.3f;
            a.anim[kIdle].bob = 0.03f;
            a.anim[kWalk].bob = 0.1f; a.anim[kWalk].sway = 6.f;
            a.anim[kAttack].lunge = mon ? 0.5f : 0.15f; a.anim[kAttack].squash = 0.6f;
            a.anim[kHurt].sway = 15.f; a.anim[kHurt].squash = -0.5f;
            o->blocks.clear();
            break;
        }
        case 12: case 13: case 14: case 15: {  // recogibles
            ensure("vida"); ensure("municion"); ensure("llave");
            o->solid = false; o->spin = true;
            if (id == 12) {
                name("Arma"); o->scale = {0.7f, 0.25f, 0.25f}; col(0.55f, 0.55f, 0.65f);
                o->blocks = {mkB(Op::WhenCollide, "Jugador"), mkB(Op::ChangeVar, "municion", "15"),
                             mkB(Op::Say, "", "Arma recogida (+15 munición)"), mkB(Op::Destroy)};
            } else if (id == 13) {
                name("Municion"); o->scale = {0.4f, 0.3f, 0.3f}; col(0.9f, 0.7f, 0.2f);
                o->blocks = {mkB(Op::WhenCollide, "Jugador"), mkB(Op::ChangeVar, "municion", "10"),
                             mkB(Op::Say, "", "+10 munición"), mkB(Op::Destroy)};
            } else if (id == 14) {
                name("Botiquin"); o->scale = {0.5f, 0.4f, 0.5f}; col(0.95f, 0.95f, 0.95f);
                o->blocks = {mkB(Op::WhenCollide, "Jugador"), mkB(Op::ChangeVar, "vida", "25"),
                             mkB(Op::If, "", "\"vida\" > 100"), mkB(Op::SetVar, "vida", "100"), mkB(Op::Else), mkB(Op::EndIf),
                             mkB(Op::Say, "", "+25 vida"), mkB(Op::Destroy)};
            } else {
                name("Llave"); o->scale = {0.3f, 0.3f, 0.5f}; col(1.f, 0.82f, 0.1f);
                o->blocks = {mkB(Op::WhenCollide, "Jugador"), mkB(Op::SetVar, "llave", "1"),
                             mkB(Op::Say, "", "¡Tienes la llave!"), mkB(Op::Destroy)};
            }
            o->pos.y = o->scale.y * 0.5f + 0.6f;
            break;
        }
        case 16:  // interruptor
            name("Interruptor");
            o->scale = {0.4f, 0.8f, 0.25f}; rest(o->scale.y); col(0.8f, 0.2f, 0.2f);
            o->blocks = {mkB(Op::WhenInteract), mkB(Op::Broadcast, "interruptor1"), mkB(Op::Say, "", "Interruptor activado")};
            break;
        case 24:  // cartel
            name("Cartel");
            o->scale = {1.0f, 0.7f, 0.1f}; o->pos.y = 1.3f; col(0.85f, 0.7f, 0.45f);
            o->blocks = {mkB(Op::WhenInteract), mkB(Op::Say, "", "Escribe aquí tu mensaje")};
            break;
        case 17: case 18: {  // puertas
            ensure("llave");
            name(id == 17 ? "PuertaH" : "PuertaV");
            o->scale = {3.f, 2.6f, 0.3f}; o->yaw = id == 17 ? 0.f : 90.f; rest(o->scale.y); col(0.55f, 0.35f, 0.2f);
            o->solid = true; o->spin = false;
            o->blocks = {mkB(Op::WhenInteract), mkB(Op::SetSolid, "", "0"),
                         mkB(Op::Repeat, "", "20"), mkB(Op::ChangeY, "", "0.13"), mkB(Op::Wait, "", "0.02"), mkB(Op::LoopEnd),
                         mkB(Op::Wait, "", "3"),
                         mkB(Op::Repeat, "", "20"), mkB(Op::ChangeY, "", "-0.13"), mkB(Op::Wait, "", "0.02"), mkB(Op::LoopEnd),
                         mkB(Op::SetSolid, "", "1")};
            break;
        }
        case 19: case 20:  // destruibles
            name(id == 19 ? "DestruibleH" : "DestruibleV");
            o->scale = {3.f, 2.6f, 0.4f}; o->yaw = id == 19 ? 0.f : 90.f; rest(o->scale.y); col(0.6f, 0.6f, 0.65f);
            o->solid = true; o->spin = false;
            o->localVars = {"salud"};
            o->blocks = {mkB(Op::WhenStart), mkB(Op::SetVar, "salud", "3"),
                         mkB(Op::WhenShot), mkB(Op::ChangeVar, "salud", "-1"),
                         mkB(Op::If, "", "\"salud\" <= 0"), mkB(Op::BreakApart, "", "10"), mkB(Op::Else), mkB(Op::EndIf)};
            break;
        case 21: {  // fin de nivel
            name("FinNivel");
            o->scale = {1.4f, 2.2f, 1.4f}; o->pos.y = 1.1f; col(0.2f, 0.85f, 0.35f);
            o->solid = false; o->spin = true;
            std::string next = S.name;
            for (size_t i = 0; i + 1 < P.scenes.size(); i++) if (&P.scenes[i] == &S) next = P.scenes[i + 1].name;
            o->blocks = {mkB(Op::WhenCollide, "Jugador"), mkB(Op::Say, "", "¡Nivel completado!"), mkB(Op::StartScene, next.c_str())};
            break;
        }
        case 22: case 23: {  // teletransportes
            bool ini = id == 22;
            name(ini ? "TeleportInicio" : "TeleportFin");
            o->scale = {1.2f, 0.2f, 1.2f}; o->pos.y = 0.12f; o->solid = false; o->spin = false;
            if (ini) col(0.2f, 0.8f, 0.9f); else col(0.7f, 0.3f, 0.9f);
            if (ini) o->blocks = {mkB(Op::WhenCollide, "Jugador"), mkB(Op::TeleportPlayer, "", num(S.start.x).c_str(), "0.05", num(S.start.z).c_str())};
            // une inicio y fin si ya existen los dos
            Obj *a = nullptr, *b = nullptr;
            for (auto& x : S.objs) {
                if (x.name.rfind("TeleportInicio", 0) == 0) a = &x;
                if (x.name.rfind("TeleportFin", 0) == 0) b = &x;
            }
            if (a && b && a->blocks.size() >= 2) {
                a->blocks[1].f[0] = num(b->pos.x);
                a->blocks[1].f[1] = num(b->pos.y + 0.05f);
                a->blocks[1].f[2] = num(b->pos.z);
            }
            break;
        }
    }
    markDirty();
}

// ---------------------------------------------------------------- pagina: escenas del proyecto
void Editor::pageScenes(Renderer* r) {
    if (r) r->clear(w_, h_, 0.09f, 0.10f, 0.14f);
    float fs = ImGui::GetFontSize();
    beginPage("##scenes");
    bool back, menu;
    topBar(name_.empty() ? "Proyecto" : name_, &back, &menu);
    if (back) { if (dirty_) saveProject(); ImGui::End(); closeProject(); return; }
    if (menu) projMenu_ = true;

    ImGui::BeginChild("##list", ImVec2(0, 0), false, ImGuiWindowFlags_NoScrollbar);
    dragScroll();
    ImGui::Indent(fs * 0.6f);
    ImGui::TextDisabled("Escenas  (mantén presionada una y deslízala para cambiar el orden)");
    float bw = (float)w_ - fs * 1.2f;
    int act = -1, actKind = 0;
    const bool reordering = sceneHold_ >= 0;
    int dropTo = -1;
    sceneRows_.resize(edit_.proj.scenes.size());
    if (reordering) {
        gHandle = true;  // mientras se mueve una escena la lista no se desliza
        ImVec2 m = ImGui::GetIO().MousePos, wp = ImGui::GetWindowPos(), ws = ImGui::GetWindowSize();
        if (m.y < wp.y + fs * 3.f) ImGui::SetScrollY(ImGui::GetScrollY() - fs * 0.5f);
        else if (m.y > wp.y + ws.y - fs * 3.f) ImGui::SetScrollY(ImGui::GetScrollY() + fs * 0.5f);
        for (int j = 0; j < (int)sceneRows_.size(); j++)
            if (m.y >= sceneRows_[j].first && m.y < sceneRows_[j].second) dropTo = j;
    }
    for (int i = 0; i < (int)edit_.proj.scenes.size(); i++) {
        Scene& s = edit_.proj.scenes[i];
        ImGui::PushID(i);
        std::string lab = s.name + (i == 0 ? "   (inicio)" : "") + (s.is3d ? "   [3D]" : "   [2D]") + "   " + std::to_string(s.objs.size()) + " obj.";
        bool held = reordering && sceneHold_ == i;
        if (held) ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(0.16f, 0.62f, 0.55f, 1.f));
        bool hit = ImGui::Button(lab.c_str(), ImVec2(bw - fs * 3.f, fs * 2.8f));
        if (held) ImGui::PopStyleColor();
        ImVec2 rmin = ImGui::GetItemRectMin(), rmax = ImGui::GetItemRectMax();
        sceneRows_[i] = {rmin.y, rmax.y + ImGui::GetStyle().ItemSpacing.y};
        if (reordering && dropTo == i && sceneHold_ != i)  // linea que marca donde caera
            ImGui::GetWindowDrawList()->AddRectFilled(ImVec2(rmin.x, sceneHold_ < i ? rmax.y : rmin.y - 3.f), ImVec2(rmax.x, sceneHold_ < i ? rmax.y + 3.f : rmin.y), IM_COL32(46, 217, 189, 255), 2.f);
        if (!reordering && ImGui::IsItemActive() && ImGui::GetIO().MouseDownDuration[0] > 0.45f && dragAcc_ < fs * 0.6f) {
            sceneHold_ = i;  // pulsacion larga: empieza a mover esta escena
            if (host_.vibrate) host_.vibrate(0.03f);
        }
        if (hit && tapped() && !reordering) { setScene(i); page_ = Page::SceneHome; }
        ImGui::SameLine();
        if (ImGui::Button("...", ImVec2(fs * 2.6f, fs * 2.8f)) && tapped()) ImGui::OpenPopup("m");
        if (ImGui::BeginPopup("m")) {
            if (ImGui::MenuItem("Renombrar")) { renameWhat_ = 1; renameIdx_ = i; renameBuf_ = s.name; }
            if (ImGui::MenuItem("Duplicar")) { act = i; actKind = 1; }
            if (i > 0 && ImGui::MenuItem("Subir (mover antes)")) { act = i; actKind = 3; }
            if (i + 1 < (int)edit_.proj.scenes.size() && ImGui::MenuItem("Bajar (mover después)")) { act = i; actKind = 4; }
            if (edit_.proj.scenes.size() > 1 && ImGui::MenuItem("Eliminar")) { act = i; actKind = 2; }
            ImGui::EndPopup();
        }
        ImGui::PopID();
    }
    ImGui::Dummy(ImVec2(1, fs * 5.f));
    ImGui::Unindent(fs * 0.6f);
    ImGui::EndChild();

    if (sceneHold_ >= 0 && !ImGui::IsMouseDown(0)) {  // al soltar: la escena se mueve a la fila donde quedo
        int from = sceneHold_, to = dropTo;
        sceneHold_ = -1;
        if (to >= 0 && to != from && from < (int)edit_.proj.scenes.size()) {
            auto& v = edit_.proj.scenes;
            std::string cur = sceneIdx_ >= 0 && sceneIdx_ < (int)v.size() ? v[sceneIdx_].name : "";
            Scene moved = std::move(v[from]);
            v.erase(v.begin() + from);
            v.insert(v.begin() + to, std::move(moved));
            for (int j = 0; j < (int)v.size(); j++) if (v[j].name == cur) sceneIdx_ = j;
            edit_.bindScene(sceneIdx_);
            markDirty();
        }
    }
    if (act >= 0 && actKind == 1) {
        Scene c = edit_.proj.scenes[act];
        c.name += "_copia";
        edit_.proj.scenes.push_back(c);
        markDirty();
    } else if (act >= 0 && (actKind == 3 || actKind == 4)) {
        int j = actKind == 3 ? act - 1 : act + 1;
        std::swap(edit_.proj.scenes[act], edit_.proj.scenes[j]);
        if (sceneIdx_ == act) sceneIdx_ = j;
        else if (sceneIdx_ == j) sceneIdx_ = act;
        markDirty();
    } else if (act >= 0 && actKind == 2) {
        edit_.proj.scenes.erase(edit_.proj.scenes.begin() + act);
        setScene(0);
        markDirty();
    }
    renameUI();
    projectMenu();
    if (plusOpen_) { ImGui::OpenPopup("##newscene"); plusOpen_ = false; }
    ImGui::SetNextWindowPos(ImVec2((float)w_ - fs * 0.8f, (float)h_ - fs * 4.4f), ImGuiCond_Always, ImVec2(1.f, 1.f));
    if (ImGui::BeginPopup("##newscene")) {
        if (ImGui::MenuItem("Escena 2D (menús, juegos planos)")) addScene(false);
        if (ImGui::MenuItem("Escena 3D (niveles en primera persona)")) addScene(true);
        ImGui::EndPopup();
    }
    endPage();
    bool pl = false, pu = false;
    fab(&pl, &pu);
    if (pu) plusOpen_ = true;
    if (pl) startPlay();
    assetsWin();
    hudWin(r);
}

// ---------------------------------------------------------------- pagina: una escena (fondo y objetos)
void Editor::pageSceneHome(Renderer* r) {
    if (!hasScene()) { page_ = Page::Scenes; return; }
    if (r) r->clear(w_, h_, 0.09f, 0.10f, 0.14f);
    float fs = ImGui::GetFontSize();
    Scene& S = scene();
    beginPage("##scene");
    bool back, menu;
    topBar(S.name + (S.is3d ? "  [3D]" : "  [2D]"), &back, &menu);
    if (back) { page_ = Page::Scenes; sel_ = -1; }
    if (menu) projMenu_ = true;

    ImGui::BeginChild("##objs", ImVec2(0, 0), false, ImGuiWindowFlags_NoScrollbar);
    dragScroll();
    ImGui::Indent(fs * 0.6f);
    float bw = (float)w_ - fs * 1.2f;
    float row = fs * 3.2f;

    // Fondo (2D) o mundo (3D)
    ImGui::TextDisabled(S.is3d ? "Mundo" : "Fondo");
    if (S.is3d) {
        if (ImGui::Button("Cielo, luz y sombras", ImVec2(bw, fs * 2.6f)) && tapped()) showWorld = true;
    } else {
        for (int i = 0; i < (int)S.objs.size(); i++) {
            if (!S.objs[i].bg) continue;
            ImGui::PushID(i);
            thumb(r, S.objs[i], row);
            ImGui::SameLine();
            if (ImGui::Button(S.objs[i].name.c_str(), ImVec2(bw - row - fs * 0.5f, row)) && tapped()) openObject(i);
            ImGui::PopID();
        }
    }
    ImGui::Spacing();
    ImGui::TextDisabled("Actores y objetos");
    int act = -1;
    for (int i = 0; i < (int)S.objs.size(); i++) {
        if (S.objs[i].bg) continue;
        ImGui::PushID(i);
        thumb(r, S.objs[i], row);
        ImGui::SameLine();
        std::string lab = S.objs[i].name + (S.objs[i].visible ? "" : "  (oculto)") + "\n" +
                          std::to_string(S.objs[i].blocks.size()) + " bloques";
        if (ImGui::Button(lab.c_str(), ImVec2(bw - row - fs * 3.2f, row)) && tapped()) openObject(i);
        ImGui::SameLine();
        if (ImGui::Button("...", ImVec2(fs * 2.6f, row)) && tapped()) ImGui::OpenPopup("m");
        if (ImGui::BeginPopup("m")) { objectMenuItems(i); ImGui::EndPopup(); }
        ImGui::PopID();
    }
    (void)act;
    ImGui::Spacing();
    if (ImGui::Button("Editar la escena (ver y colocar objetos)", ImVec2(bw, fs * 2.6f)) && tapped()) {
        resetView();
        page_ = Page::Viewport;
    }
    ImGui::Dummy(ImVec2(1, fs * 5.f));
    ImGui::Unindent(fs * 0.6f);
    ImGui::EndChild();

    renameUI();
    projectMenu();
    newObjectMenu();
    endPage();
    bool pl = false, pu = false;
    fab(&pl, &pu);
    if (pu) plusOpen_ = true;
    if (pl) startPlay();
    worldWin();
    assetsWin();
    hudWin(r);
}

// ---------------------------------------------------------------- pagina: objeto (Scripts / Apariencias / Sonidos)
void Editor::pageObject(Renderer* r) {
    Obj* o = currentObj();
    if (!o) { page_ = Page::SceneHome; return; }
    // la escena se ve de fondo; el programa del objeto es una ventana flotante (las demas ventanas se cierran)
    if (r && hasScene()) {
        EditorView ev = view();
        r->render(edit_, w_, h_, &ev);
    } else if (r) {
        r->clear(w_, h_, 0.09f, 0.10f, 0.14f);
    }
    showObjs = showProps = showWorld = showHud = showAssets = false;
    float fs = ImGui::GetFontSize();
    ImGui::SetNextWindowPos(ImVec2(w_ * 0.36f, fs * 0.6f), ImGuiCond_FirstUseEver);
    ImGui::SetNextWindowSize(ImVec2(w_ * 0.62f, h_ * 0.94f), ImGuiCond_FirstUseEver);
    ImGui::SetNextWindowSizeConstraints(ImVec2(fs * 16.f, fs * 14.f), ImVec2((float)w_, (float)h_));
    bool open = true;
    std::string title = "Programa de: " + o->name + "###objwin";
    bool modal = false;
    if (ImGui::Begin(title.c_str(), &open, ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoSavedSettings |
                                             ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NoScrollWithMouse)) {
        if (ImGui::Button("Renombrar") && tapped()) { renameWhat_ = 2; renameIdx_ = sel_; renameBuf_ = o->name; }
        ImGui::SameLine();
        if (ImGui::Button("Ver escena") && tapped()) { resetView(); page_ = Page::Viewport; }
        ImGui::SameLine();
        bool doPlay = ImGui::Button("Jugar") && tapped();
        if (tab_ == 0) {
            ImGui::SameLine();
            ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(0.20f, 0.45f, 0.85f, 1.f));
            if (ImGui::Button("+ Añadir bloque") && tapped()) pal_ = -1;
            ImGui::PopStyleColor();
        }
        const char* names[3] = {"Scripts", "Apariencias", "Sonidos"};
        float tw = ImGui::GetContentRegionAvail().x / 3.f;
        for (int i = 0; i < 3; i++) {
            if (i) ImGui::SameLine(0, 0);
            ImGui::PushStyleColor(ImGuiCol_Button, tab_ == i ? ImVec4(0.20f, 0.45f, 0.85f, 1.f) : ImVec4(0.18f, 0.20f, 0.28f, 1.f));
            if (ImGui::Button(names[i], ImVec2(tw, fs * 2.2f)) && tapped()) tab_ = i;
            ImGui::PopStyleColor();
        }
        ImGui::BeginChild("##content", ImVec2(0, 0), false, ImGuiWindowFlags_NoScrollbar);
        dragScroll();
        ImGui::Indent(fs * 0.3f);
        if (tab_ == 0) scriptsTab(*o);
        else if (tab_ == 1) looksTab(*o, r);
        else soundsTab(*o);
        ImGui::Unindent(fs * 0.3f);
        ImGui::EndChild();
        renameUI();
        if (tab_ == 0) {  // ventanas emergentes: formulas, elegir texto, paleta de bloques
            if (fe_.open) { formulaPage(*o); modal = true; }
            else if (te_.open) { choosePage(*o); modal = true; }
            else if (pal_ != -2) { palettePage(*o); modal = true; }
        }
        if (doPlay) { ImGui::End(); startPlay(); return; }
    }
    ImGui::End();
    (void)modal;
    if (!open) { fe_.open = te_.open = false; pal_ = -2; page_ = Page::SceneHome; }
}

// ---------------------------------------------------------------- pestana Scripts
void Editor::scriptsTab(Obj& o) {
    float fs = ImGui::GetFontSize();
    ImDrawList* dl = ImGui::GetWindowDrawList();
    std::vector<Block>& B = o.blocks;
    int pFrom = -1, pTo = -1, delIdx = -1, dupIdx = -1;

    if (B.empty()) {
        ImGui::Spacing();
        ImGui::TextWrapped("Este objeto no tiene bloques. Toca + para añadir (empieza con un bloque de evento, por ejemplo \"Cuando se inicie la escena\").");
    }
    int depth = 0;
    const float pad = fs * 0.35f;
    const float step = fs * 1.1f;
    std::vector<ImVec4> openCols;  // color de cada bucle / "si" abierto (rieles de la izquierda)
    ImVec4 prevCol(1, 1, 1, 1);
    if (!B.empty()) ImGui::Dummy(ImVec2(1, fs * 0.5f));
    for (int i = 0; i < (int)B.size(); i++) {
        Block& b = B[i];
        const OpInfo& in = opInfo(b.op);
        int k = in.indent;
        if (k == 2) openCols.clear();
        int lvl = (k == 2) ? 0 : ((k == -1 || k == 3) ? depth - 1 : depth);
        if (lvl < 0) lvl = 0;
        if (k == 2) depth = 0;
        else if (k == -1) depth = std::max(0, depth - 1);
        else if (k == 1) depth++;
        float ind = lvl * fs * 1.1f;

        ImGui::PushID(i);
        float availX = ImGui::GetContentRegionAvail().x;
        float rowX = ImGui::GetCursorScreenPos().x;
        float xr = rowX + availX - pad;
        dl->ChannelsSplit(2);
        dl->ChannelsSetCurrent(1);
        ImGui::BeginGroup();
        ImGui::Indent(ind + pad);
        ImGui::Dummy(ImVec2(1, fs * 0.1f));
        bool first = true;
        bool draggable = (k == 2 || k == 0 || k == 1);
        if (draggable) {
            ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(1, 1, 1, 0.22f));
            ImGui::Button("=", ImVec2(fs * 1.7f, fs * 1.7f));
            ImGui::PopStyleColor();
            if (ImGui::IsItemActive()) gHandle = true;
            if (ImGui::IsItemDeactivated() && ImGui::IsItemHovered() && tapped() && !ImGui::GetDragDropPayload()) ImGui::OpenPopup("bm");
            if (ImGui::BeginDragDropSource(ImGuiDragDropFlags_SourceAllowNullID)) {
                ImGui::SetDragDropPayload("BLK", &i, sizeof(int));
                ImGui::Text("%s", plainTitle(in).c_str());
                ImGui::EndDragDropSource();
            }
            first = false;
        }
        // textos y campos
        for (auto& t : tokenize(in.title)) {
            std::string lab;
            float wd;
            if (t.type == 0) {
                wd = ImGui::CalcTextSize(t.s.c_str()).x;
            } else {
                lab = t.type == 2 ? (b.t.empty() ? "(elegir)" : shorten(b.t))
                                  : (b.f[t.s[0] - '0'].empty() ? " " : shorten(b.f[t.s[0] - '0']));
                wd = ImGui::CalcTextSize(lab.c_str()).x + ImGui::GetStyle().FramePadding.x * 2.f;
            }
            if (!first) {
                float x2 = ImGui::GetItemRectMax().x + ImGui::GetStyle().ItemSpacing.x + wd;
                if (x2 < xr) ImGui::SameLine();
            } else {
                first = false;
            }
            if (t.type == 0) {
                ImGui::AlignTextToFramePadding();
                ImGui::TextUnformatted(t.s.c_str());
            } else {
                ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(1, 1, 1, 0.28f));
                ImGui::PushStyleColor(ImGuiCol_ButtonHovered, ImVec4(1, 1, 1, 0.40f));
                ImGui::PushStyleColor(ImGuiCol_ButtonActive, ImVec4(1, 1, 1, 0.50f));
                ImGui::PushID(t.type == 2 ? 9 : t.s[0] - '0');
                bool hit = ImGui::Button(lab.c_str());
                ImGui::PopID();
                ImGui::PopStyleColor(3);
                if (hit && tapped()) {
                    if (t.type == 2) { te_.open = true; te_.blk = i; te_.buf = b.t; }
                    else { fe_.open = true; fe_.blk = i; fe_.field = t.s[0] - '0'; fe_.buf = b.f[fe_.field]; formulaList_ = 0; }
                }
            }
        }
        if (ImGui::BeginPopup("bm")) {
            ImGui::PushTextWrapPos(fs * 22.f);
            ImGui::TextUnformatted(in.help);
            ImGui::PopTextWrapPos();
            ImGui::Separator();
            if (ImGui::MenuItem("Duplicar")) dupIdx = i;
            if (ImGui::MenuItem("Eliminar")) delIdx = i;
            ImGui::EndPopup();
        }
        ImGui::Dummy(ImVec2(1, fs * 0.1f));
        ImGui::Unindent(ind + pad);
        ImGui::EndGroup();
        ImVec2 mn = ImGui::GetItemRectMin(), mx = ImGui::GetItemRectMax();
        if (ImGui::BeginDragDropTarget()) {
            if (const ImGuiPayload* pl = ImGui::AcceptDragDropPayload("BLK")) { pFrom = *(const int*)pl->Data; pTo = i; }
            ImGui::EndDragDropTarget();
        }
        dl->ChannelsSetCurrent(0);
        bool isHatB = (k == 2);
        bool connected = i > 0 && !isHatB;
        bool nextHat = i + 1 >= (int)B.size() || isHat(B[i + 1].op);
        ImVec4 c = catRGB(in.cat, 1.f);
        if (k == -1 && !openCols.empty()) c = openCols.back();
        float rx0 = mn.x - pad, rx1 = xr + pad;
        for (int j = 0; j < lvl && j < (int)openCols.size(); j++) {  // rieles de los bucles que contienen a este bloque
            ImVec4 rc = openCols[j];
            dl->AddRectFilled(ImVec2(rowX + j * step, mn.y), ImVec2(rowX + (j + 1) * step, mx.y + 1.f), col32(rc));
            dl->AddRectFilled(ImVec2(rowX + j * step, mn.y), ImVec2(rowX + j * step + 2.f, mx.y + 1.f), IM_COL32(0, 0, 0, 50));
        }
        ImDrawFlags fl = ImDrawFlags_RoundCornersNone;
        float rr = 0.f;
        if (isHatB) { fl = nextHat ? ImDrawFlags_RoundCornersAll : ImDrawFlags_RoundCornersTop; rr = 14.f; }
        else if (k == -1 || nextHat) { fl = ImDrawFlags_RoundCornersBottom; rr = 8.f; }
        dl->AddRectFilled(ImVec2(rx0, mn.y), ImVec2(rx1, mx.y), col32(c), rr, fl);
        dl->AddLine(ImVec2(rx0 + 2.f, mx.y - 0.5f), ImVec2(rx1 - 2.f, mx.y - 0.5f), IM_COL32(0, 0, 0, 60), 1.f);
        if (isHatB) {  // sombrero: la joroba de arriba muestra que aqui empieza un guion nuevo
            dl->AddRectFilled(ImVec2(rx0 + fs * 0.8f, mn.y - fs * 0.32f), ImVec2(rx0 + fs * 4.f, mn.y + 2.f), col32(c), 10.f, ImDrawFlags_RoundCornersTop);
        } else if (connected) {  // pieza que encaja con el bloque de arriba
            ImVec2 a0(rx0 + fs * 0.8f, mn.y), a1(rx0 + fs * 2.6f, mn.y + fs * 0.26f);
            dl->AddRectFilled(a0, a1, IM_COL32(0, 0, 0, 70), 3.f, ImDrawFlags_RoundCornersBottom);
            dl->AddRectFilled(ImVec2(a0.x + 2.f, a0.y), ImVec2(a1.x - 2.f, a1.y - 2.f), col32(prevCol), 3.f, ImDrawFlags_RoundCornersBottom);
        }
        if (k == 1) openCols.push_back(c);
        if (k == -1 && !openCols.empty()) openCols.pop_back();
        prevCol = c;
        dl->ChannelsMerge();
        ImGui::PopID();
        if (!nextHat) ImGui::SetCursorPosY(ImGui::GetCursorPosY() - ImGui::GetStyle().ItemSpacing.y);  // bloques pegados
        else ImGui::Dummy(ImVec2(1, fs * 1.2f));                                                        // entre guiones
    }
    // zona final: soltar aqui = al final de la lista
    ImGui::Dummy(ImVec2(ImGui::GetContentRegionAvail().x, fs * 3.f));
    if (ImGui::BeginDragDropTarget()) {
        if (const ImGuiPayload* pl = ImGui::AcceptDragDropPayload("BLK")) { pFrom = *(const int*)pl->Data; pTo = (int)B.size(); }
        ImGui::EndDragDropTarget();
    }
    ImGui::Dummy(ImVec2(1, fs * 4.f));

    if (pFrom >= 0 && pFrom < (int)B.size()) {
        bool okDrop = true;
        if (isHat(B[pFrom].op) && pTo < (int)B.size() && !isHat(B[pTo].op)) okDrop = false;  // los guiones solo entre guiones
        if (okDrop && moveRange(B, pFrom, pTo)) markDirty();
    }
    if (dupIdx >= 0 && dupIdx < (int)B.size()) {
        int e;
        if (blockRange(B, dupIdx, e)) {
            std::vector<Block> g(B.begin() + dupIdx, B.begin() + e);
            B.insert(B.begin() + e, g.begin(), g.end());
            markDirty();
        }
    }
    if (delIdx >= 0 && delIdx < (int)B.size()) {
        int e;
        if (blockRange(B, delIdx, e)) {
            B.erase(B.begin() + delIdx, B.begin() + e);
            markDirty();
        }
    }
}

// ---------------------------------------------------------------- texto (teclado del telefono)
bool Editor::textInput(const char* id, const char* title, std::string& s, const char* hint, float width) {
    if (width <= 0.f) width = ImGui::GetContentRegionAvail().x;
    if (host_.prompt) {  // Android: cuadro de texto nativo con el teclado del telefono
        bool empty = s.empty();
        std::string lab = shorten(empty ? (hint ? hint : "(toca para escribir)") : s, 60) + "##" + id;
        ImGui::PushStyleVar(ImGuiStyleVar_ButtonTextAlign, ImVec2(0.f, 0.5f));
        ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(0.10f, 0.12f, 0.18f, 1.f));
        if (empty) ImGui::PushStyleColor(ImGuiCol_Text, ImVec4(1, 1, 1, 0.45f));
        bool hit = ImGui::Button(lab.c_str(), ImVec2(width, 0));
        if (empty) ImGui::PopStyleColor();
        ImGui::PopStyleColor();
        ImGui::PopStyleVar();
        if (hit && tapped() && !promptActive_) {
            promptDst_ = &s;
            promptActive_ = true;
            host_.prompt(title ? title : "", s);
        }
        return false;
    }
    ImGui::SetNextItemWidth(width);
    return ImGui::InputTextWithHint(id, hint ? hint : "", &s);
}

void Editor::onText(const std::string& text, bool ok) {
    std::string* d = promptDst_;
    promptDst_ = nullptr;
    promptActive_ = false;
    if (!d) return;
    float* pn = promptNum_;
    promptNum_ = nullptr;
    if (ok) {
        *d = text;
        markDirty();
        if (d == &numBuf_ && pn) {  // numero escrito con el teclado
            std::string t = text;
            for (auto& c : t) if (c == ',') c = '.';
            char* end = nullptr;
            float val = strtof(t.c_str(), &end);
            if (end != t.c_str()) *pn = std::max(promptLo_, std::min(promptHi_, val));
        }
        if (d == &renameBuf_ && renameWhat_ > 0) applyRename();
    } else if (d == &renameBuf_) {
        renameWhat_ = 0;
    }
}

void Editor::modalOpen(const char* name) {
    if (!ImGui::IsPopupOpen(name)) ImGui::OpenPopup(name);
}

// ---------------------------------------------------------------- paleta de bloques (ventana emergente)
void Editor::palettePage(Obj& o) {
    float fs = ImGui::GetFontSize();
    modalOpen("Bloques");
    ImGui::SetNextWindowPos(ImVec2(w_ * 0.5f, h_ * 0.5f), ImGuiCond_Always, ImVec2(0.5f, 0.5f));
    ImGui::SetNextWindowSize(ImVec2(w_ * 0.92f, h_ * 0.92f));
    if (!ImGui::BeginPopupModal("Bloques", nullptr,
                                ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoCollapse |
                                    ImGuiWindowFlags_NoSavedSettings | ImGuiWindowFlags_NoScrollbar |
                                    ImGuiWindowFlags_NoScrollWithMouse)) {
        pal_ = -2;
        return;
    }
    static const Cat cats[] = {Cat::Eventos, Cat::Control, Cat::Movimiento, Cat::Sonido, Cat::Apariencia, Cat::Datos, Cat::Forge3D};
    bool searching = !palSearch_.empty();
    bool close = false;
    float bw0 = ImGui::GetContentRegionAvail().x;
    if (pal_ >= 0 || searching) {
        if (ImGui::Button("< Categorías", ImVec2(fs * 7.f, fs * 2.2f)) && tapped()) { pal_ = -1; palSearch_.clear(); }
        ImGui::SameLine();
    }
    textInput("##s", "Buscar bloque", palSearch_, "Buscar bloque", bw0 - fs * 6.f - (pal_ >= 0 || searching ? fs * 7.6f : 0.f));
    ImGui::SameLine();
    if (ImGui::Button("Cerrar", ImVec2(fs * 5.f, 0)) && tapped()) close = true;
    ImGui::Separator();
    ImGui::BeginChild("##pl", ImVec2(0, 0), false, ImGuiWindowFlags_NoScrollbar);
    dragScroll();
    float bw = ImGui::GetContentRegionAvail().x - fs * 0.3f;
    int pick = -1;
    if (pal_ == -1 && !searching) {
        ImGui::TextDisabled("Categorías");
        for (int i = 0; i < 7; i++) {
            ImGui::PushStyleColor(ImGuiCol_Button, catRGB(cats[i]));
            ImGui::PushStyleColor(ImGuiCol_ButtonHovered, catRGB(cats[i], 1.15f));
            ImGui::PushStyleColor(ImGuiCol_ButtonActive, catRGB(cats[i], 0.8f));
            if (ImGui::Button(catName(cats[i]), ImVec2(bw, fs * 3.f)) && tapped()) pal_ = i;
            ImGui::PopStyleColor(3);
        }
    } else {
        std::string q = normName(palSearch_);
        if (!searching) ImGui::TextColored(catRGB(cats[pal_]), "%s", catName(cats[pal_]));
        for (int i = 0; i < (int)Op::Count; i++) {
            const OpInfo& in = opInfo((Op)i);
            if (searching) {
                if (normName(plainTitle(in)).find(q) == std::string::npos && normName(in.help).find(q) == std::string::npos) continue;
            } else if (in.cat != cats[pal_]) {
                continue;
            }
            ImGui::PushID(i);
            ImGui::PushStyleColor(ImGuiCol_Button, catRGB(in.cat));
            ImGui::PushStyleColor(ImGuiCol_ButtonHovered, catRGB(in.cat, 1.15f));
            ImGui::PushStyleColor(ImGuiCol_ButtonActive, catRGB(in.cat, 0.8f));
            if (ImGui::Button(plainTitle(in).c_str(), ImVec2(bw, fs * 2.6f)) && tapped()) pick = i;
            ImGui::PopStyleColor(3);
            ImGui::PushTextWrapPos(ImGui::GetCursorPosX() + bw);
            ImGui::TextDisabled("%s", in.help);
            ImGui::PopTextWrapPos();
            ImGui::Spacing();
            ImGui::PopID();
        }
    }
    ImGui::Dummy(ImVec2(1, fs * 3.f));
    ImGui::EndChild();
    if (pick >= 0) {
        addBlock(o, (Op)pick);
        palSearch_.clear();
        close = true;
    }
    if (close) { ImGui::CloseCurrentPopup(); pal_ = -2; }
    ImGui::EndPopup();
}

// ---------------------------------------------------------------- editor de formulas (ventana emergente)
void Editor::formulaPage(Obj& o) {
    float fs = ImGui::GetFontSize();
    if (fe_.blk < 0 || fe_.blk >= (int)o.blocks.size()) { fe_.open = false; return; }
    Block& b = o.blocks[fe_.blk];
    modalOpen("Fórmula");
    ImGui::SetNextWindowPos(ImVec2(w_ * 0.5f, h_ * 0.5f), ImGuiCond_Always, ImVec2(0.5f, 0.5f));
    ImGui::SetNextWindowSize(ImVec2(w_ * 0.96f, h_ * 0.94f));
    if (!ImGui::BeginPopupModal("Fórmula", nullptr,
                                ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoCollapse |
                                    ImGuiWindowFlags_NoSavedSettings | ImGuiWindowFlags_NoScrollbar |
                                    ImGuiWindowFlags_NoScrollWithMouse)) {
        fe_.open = false;
        return;
    }
    float total = ImGui::GetContentRegionAvail().x;
    float lw = total * 0.48f;
    bool ok = false, cancel = false;

    // ---- izquierda: formula, resultado, teclado
    ImGui::BeginChild("##fl", ImVec2(lw, 0), false, ImGuiWindowFlags_NoScrollbar);
    ImGui::TextDisabled("Toca la fórmula para escribir con el teclado del teléfono");
    textInput("##f", "Fórmula", fe_.buf, "(vacía)", lw - fs * 0.3f);
    PreviewEnv env;
    if (!formulaValid(fe_.buf)) {
        ImGui::TextColored(ImVec4(1.f, 0.6f, 0.4f, 1.f), "No es una fórmula válida: se usará como texto.");
    } else {
        Val v = evalFormula(fe_.buf, &env);
        ImGui::Text("= %s", shorten(v.txt(), 40).c_str());
    }
    ImGui::Spacing();
    float kw = (lw - fs * 0.3f - ImGui::GetStyle().ItemSpacing.x * 3.f) / 4.f, kh = fs * 2.0f;
    auto key = [&](const char* label, const char* ins, bool last = false) {
        if (ImGui::Button(label, ImVec2(kw, kh)) && tapped()) fe_.buf += ins;
        if (!last) ImGui::SameLine();
    };
    key("7", "7"); key("8", "8"); key("9", "9"); key("/", " / ", true);
    key("4", "4"); key("5", "5"); key("6", "6"); key("*", " * ", true);
    key("1", "1"); key("2", "2"); key("3", "3"); key("-", " - ", true);
    key("0", "0"); key(".", "."); key(",", ", "); key("+", " + ", true);
    key("(", "("); key(")", ")"); key("=", " = "); key("^", "^", true);
    key("<", " < "); key(">", " > "); key("y", " y "); key("o", " o ", true);
    key("no", "no "); key("'Abc'", "'texto'");
    if (ImGui::Button("<-", ImVec2(kw, kh)) && tapped()) {
        while (!fe_.buf.empty() && ((unsigned char)fe_.buf.back() & 0xC0) == 0x80) fe_.buf.pop_back();
        if (!fe_.buf.empty()) fe_.buf.pop_back();
    }
    ImGui::SameLine();
    if (ImGui::Button("Borrar", ImVec2(kw, kh)) && tapped()) fe_.buf.clear();
    ImGui::Spacing();
    ok = ImGui::Button("Aceptar", ImVec2((lw - fs * 0.3f) * 0.5f - 3.f, fs * 2.4f)) && tapped();
    ImGui::SameLine();
    cancel = ImGui::Button("Cancelar", ImVec2((lw - fs * 0.3f) * 0.5f - 3.f, fs * 2.4f)) && tapped();
    ImGui::EndChild();

    // ---- derecha: Funciones / Objeto / Dispositivo / Logica / Datos
    ImGui::SameLine();
    ImGui::BeginChild("##fr", ImVec2(0, 0), false, ImGuiWindowFlags_NoScrollbar);
    static const char* tabs[5] = {"Funciones", "Objeto", "Dispositivo", "Lógica", "Datos"};
    float rw = ImGui::GetContentRegionAvail().x;
    float tw = (rw - ImGui::GetStyle().ItemSpacing.x * 2.f) / 3.f;
    for (int i = 0; i < 5; i++) {
        if (i % 3) ImGui::SameLine();
        bool on = formulaList_ == i;
        ImGui::PushStyleColor(ImGuiCol_Button, on ? ImVec4(0.20f, 0.50f, 0.95f, 1.f) : ImVec4(0.30f, 0.34f, 0.48f, 1.f));
        if (ImGui::Button(tabs[i], ImVec2(tw, fs * 2.2f)) && tapped()) formulaList_ = i;
        ImGui::PopStyleColor();
    }
    ImGui::Separator();
    ImGui::BeginChild("##flist", ImVec2(0, 0), false, ImGuiWindowFlags_NoScrollbar);
    dragScroll();
    float aw = ImGui::GetContentRegionAvail().x - fs * 0.3f;
    auto inGroup = [&](const std::string& g) {
        switch (formulaList_) {
            case 0: return g == "MATEMÁTICAS" || g == "STRINGS (CADENAS)" || g == "FECHA Y HORA" || g == "3D";
            case 1: return g == "PROPIEDADES DE ASPECTO" || g == "PROPIEDADES DE MOVIMIENTO";
            case 2: return g == "SENSORES DEL DISPOSITIVO" || g == "DETECCIÓN DEL TACTO";
            case 3: return g == "OPERADORES LÓGICOS (BOOLEANOS)" || g == "OPERADOR DE COMPARACIÓN";
        }
        return false;
    };
    auto addGlobalVar = [&](const std::string& nm) {
        if (nm.empty()) return;
        auto all = varNames(o);
        if (std::find(all.begin(), all.end(), nm) == all.end()) { edit_.proj.globalVars.push_back(nm); markDirty(); }
        fe_.buf += "\"" + nm + "\"";
    };
    std::string cur;
    if (formulaList_ == 4) {
        ImGui::TextDisabled("Variables (toca una para insertarla)");
        auto vars = varNames(o);
        if (vars.empty()) ImGui::TextDisabled("Aún no hay variables.");
        for (auto& v : vars) {
            ImGui::PushID(v.c_str());
            bool local = std::find(o.localVars.begin(), o.localVars.end(), v) != o.localVars.end();
            std::string lab = v + (local ? "   (solo este objeto)" : "");
            if (ImGui::Button(shorten(lab, 40).c_str(), ImVec2(aw, fs * 2.2f)) && tapped()) fe_.buf += "\"" + v + "\"";
            ImGui::PopID();
        }
        ImGui::Spacing();
        if (host_.prompt) {
            if (newVarOpen_ && !promptActive_) { addGlobalVar(newVarName_); newVarOpen_ = false; newVarName_.clear(); }
            if (ImGui::Button("+ Variable nueva", ImVec2(aw, fs * 2.4f)) && tapped() && !promptActive_) {
                newVarName_.clear();
                newVarOpen_ = true;
                promptActive_ = true;
                promptDst_ = &newVarName_;
                host_.prompt("Nombre de la variable", "");
            }
        } else {
            textInput("##nvf", "Nombre de la variable", newVarName_, "nombre de la variable", aw);
            if (ImGui::Button("+ Variable nueva", ImVec2(aw, fs * 2.4f)) && tapped()) { addGlobalVar(newVarName_); newVarName_.clear(); }
        }
    } else {
        int n = 0;
        for (auto& f : formulaFunctions()) {
            if (!inGroup(f.group)) continue;
            if (cur != f.group) { cur = f.group; ImGui::Spacing(); ImGui::TextDisabled("%s", f.group); }
            ImGui::PushID(n++);
            if (ImGui::Button(f.label, ImVec2(aw, fs * 2.1f)) && tapped()) fe_.buf += f.label;
            ImGui::PopID();
        }
    }
    ImGui::Dummy(ImVec2(1, fs * 2.f));
    ImGui::EndChild();
    ImGui::EndChild();

    if (ok) { b.f[fe_.field] = fe_.buf; markDirty(); }
    if (ok || cancel) { fe_.open = false; ImGui::CloseCurrentPopup(); }
    ImGui::EndPopup();
}

// ---------------------------------------------------------------- elegir texto (ventana emergente)
void Editor::choosePage(Obj& o) {
    float fs = ImGui::GetFontSize();
    if (te_.blk < 0 || te_.blk >= (int)o.blocks.size()) { te_.open = false; return; }
    Block& b = o.blocks[te_.blk];
    modalOpen("Elegir");
    ImGui::SetNextWindowPos(ImVec2(w_ * 0.5f, h_ * 0.5f), ImGuiCond_Always, ImVec2(0.5f, 0.5f));
    ImGui::SetNextWindowSize(ImVec2(std::min((float)w_ * 0.92f, fs * 30.f), h_ * 0.92f));
    if (!ImGui::BeginPopupModal("Elegir", nullptr,
                                ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoCollapse |
                                    ImGuiWindowFlags_NoSavedSettings | ImGuiWindowFlags_NoScrollbar |
                                    ImGuiWindowFlags_NoScrollWithMouse)) {
        te_.open = false;
        return;
    }
    std::vector<std::string> items;
    const char* what = "Elegir";
    bool isVar = false, free = false;
    switch (b.op) {
        case Op::WhenReceive: case Op::Broadcast: case Op::BroadcastWait:
            items = messageNames(); what = "Mensaje"; free = true; break;
        case Op::WhenCollide: case Op::WhenNear: case Op::PointTowards: case Op::GoToObject: case Op::MoveTowards:
            what = "Objeto";
            if (hasScene() && scene().is3d) items.push_back("Jugador");
            if (hasScene()) for (auto& x : scene().objs) if (&x != &o) items.push_back(x.name);
            break;
        case Op::SetCamera:
            what = "Vista de cámara";
            items = {"Primera persona", "Cámara al hombro", "Cámara fija"};
            break;
        case Op::SetFx:
            what = "Partículas";
            items = {"encender", "apagar"};
            break;
        case Op::SetScreenFx:
            what = "Efecto de pantalla";
            items = {"Ninguno", "VHS", "Cámara de video", "Visión nocturna", "Película vieja"};
            break;
        case Op::PlayAnim:
            what = "Animación";
            items = {"quieto", "caminar", "atacar", "daño"};
            break;
        case Op::PlaySoundWait:
            what = "Sonido o música";
            items = assetsOf(1);
            break;
        case Op::StartSound:
            what = "Sonido";
            items = o.sounds;
            for (auto& a : assetsOf(1)) if (std::find(items.begin(), items.end(), a) == items.end()) items.push_back(a);
            break;
        case Op::Music: what = "Música"; items = assetsOf(1); break;
        case Op::SetLook:
            what = "Apariencia";
            items = o.looks;
            if (!o.tex.empty()) items.insert(items.begin(), o.tex);
            break;
        case Op::StartScene: what = "Escena"; for (auto& s : edit_.proj.scenes) items.push_back(s.name); break;
        case Op::SetVar: case Op::ChangeVar: case Op::ShowVar: case Op::HideVar:
            what = "Variable"; items = varNames(o); isVar = true; break;
        default: free = true; break;
    }
    ImGui::TextDisabled("%s", what);
    ImGui::SameLine(ImGui::GetContentRegionAvail().x - fs * 5.f);
    bool done = ImGui::Button("Cerrar", ImVec2(fs * 5.f, 0)) && tapped();
    ImGui::Separator();
    ImGui::BeginChild("##cl", ImVec2(0, 0), false, ImGuiWindowFlags_NoScrollbar);
    dragScroll();
    float aw = ImGui::GetContentRegionAvail().x - fs * 0.3f;
    for (int i = 0; i < (int)items.size(); i++) {
        ImGui::PushID(i);
        if (ImGui::Button(shorten(items[i], 34).c_str(), ImVec2(aw, fs * 2.4f)) && tapped()) { b.t = items[i]; done = true; markDirty(); }
        ImGui::PopID();
    }
    if (items.empty() && !isVar) ImGui::TextDisabled("(no hay nada que elegir todavía)");
    ImGui::Spacing();
    if (isVar) {
        ImGui::TextDisabled("Variable nueva");
        if (host_.prompt && newVarOpen_ && !promptActive_) {  // el nombre ya llego del cuadro de texto
            newVarOpen_ = false;
            if (!newVarName_.empty()) {
                auto all = varNames(o);
                if (std::find(all.begin(), all.end(), newVarName_) == all.end()) {
                    if (newVarLocal_) o.localVars.push_back(newVarName_);
                    else edit_.proj.globalVars.push_back(newVarName_);
                }
                b.t = newVarName_;
                newVarName_.clear();
                done = true;
                markDirty();
            }
        }
        ImGui::Checkbox("Solo para este objeto", &newVarLocal_);
        if (host_.prompt) {
            if (ImGui::Button("+ Crear variable nueva", ImVec2(aw, fs * 2.4f)) && tapped() && !promptActive_) {
                newVarName_.clear();
                newVarOpen_ = true;
                promptActive_ = true;
                promptDst_ = &newVarName_;
                host_.prompt("Nombre de la variable", "");
            }
        } else {
            textInput("##nv", "Nombre de la variable", newVarName_, "nombre de la variable", aw);
            if (ImGui::Button("Crear variable", ImVec2(aw, fs * 2.4f)) && tapped() && !newVarName_.empty()) {
                auto all = varNames(o);
                if (std::find(all.begin(), all.end(), newVarName_) == all.end()) {
                    if (newVarLocal_) o.localVars.push_back(newVarName_);
                    else edit_.proj.globalVars.push_back(newVarName_);
                }
                b.t = newVarName_;
                newVarName_.clear();
                done = true;
                markDirty();
            }
        }
    } else if (free) {
        ImGui::TextDisabled(b.op == Op::Note ? "Escribe la nota" : "Nuevo");
        textInput("##t", b.op == Op::Note ? "Nota" : "Nombre", te_.buf, "(toca para escribir)", aw);
        if (ImGui::Button("Usar este texto", ImVec2(aw, fs * 2.4f)) && tapped()) { b.t = te_.buf; done = true; markDirty(); }
    }
    ImGui::Dummy(ImVec2(1, fs * 2.f));
    ImGui::EndChild();
    if (done) { te_.open = false; ImGui::CloseCurrentPopup(); }
    ImGui::EndPopup();
}

// ---------------------------------------------------------------- pestana Apariencias
void Editor::looksTab(Obj& o, Renderer* r) {
    float fs = ImGui::GetFontSize();
    float aw = ImGui::GetContentRegionAvail().x - fs * 0.5f;
    ImGui::Spacing();
    ImGui::TextDisabled("Aspecto principal");
    thumb(r, o, fs * 5.f);
    ImGui::SameLine();
    ImGui::BeginGroup();
    ImGui::Text("%s", o.tex.empty() ? "(solo color)" : shorten(o.tex, 24).c_str());
    if (ImGui::Checkbox("Sin color (transparente)", &o.noColor)) markDirty();
    if (!o.noColor && ImGui::ColorEdit3("Color", o.color, ImGuiColorEditFlags_NoInputs)) markDirty();
    if (!o.tex.empty()) {
        bool stretch = !o.texTile;
        if (ImGui::Checkbox("Estirar la imagen a toda la cara", &stretch)) { o.texTile = !stretch; markDirty(); }
    }
    ImGui::EndGroup();
    if (ImGui::Button("Imagen principal...", ImVec2(aw, fs * 2.3f)) && tapped()) ImGui::OpenPopup("mainimg");
    if (ImGui::BeginPopup("mainimg")) {
        if (ImGui::MenuItem("(sin imagen)")) { o.tex.clear(); markDirty(); }
        for (auto& a : assetsOf(0)) if (ImGui::MenuItem(a.c_str(), nullptr, a == o.tex)) { o.tex = a; markDirty(); }
        ImGui::EndPopup();
    }
    ImGui::Spacing();
    ImGui::TextDisabled("Más apariencias (para \"Cambiar apariencia a\" y \"Siguiente apariencia\")");
    int del = -1;
    float th = fs * 3.2f;
    for (int i = 0; i < (int)o.looks.size(); i++) {
        ImGui::PushID(i);
        Obj tmp;
        tmp.tex = o.looks[i];
        thumb(r, tmp, th);
        ImGui::SameLine();
        ImGui::AlignTextToFramePadding();
        ImGui::Text("%d. %s", i + 1, shorten(o.looks[i], 26).c_str());
        ImGui::SameLine(aw - fs * 2.6f);
        if (ImGui::Button("x", ImVec2(fs * 2.4f, th * 0.8f)) && tapped()) del = i;
        ImGui::PopID();
    }
    if (del >= 0) { o.looks.erase(o.looks.begin() + del); markDirty(); }
    if (o.looks.empty()) ImGui::TextDisabled("(ninguna)");
    ImGui::Spacing();
    if (ImGui::Button("Importar imagen...", ImVec2(aw, fs * 2.4f)) && tapped()) { if (host_.pickFile) host_.pickFile(); }
    if (ImGui::Button("Elegir de los archivos", ImVec2(aw, fs * 2.4f)) && tapped()) ImGui::OpenPopup("addlook");
    if (ImGui::BeginPopup("addlook")) {
        auto imgs = assetsOf(0);
        if (imgs.empty()) ImGui::TextDisabled("No hay imágenes en el proyecto");
        for (auto& a : imgs) if (ImGui::MenuItem(a.c_str())) { o.looks.push_back(a); markDirty(); }
        ImGui::EndPopup();
    }
    ImGui::Dummy(ImVec2(1, fs * 3.f));
}

// ---------------------------------------------------------------- pestana Sonidos
void Editor::soundsTab(Obj& o) {
    float fs = ImGui::GetFontSize();
    float aw = ImGui::GetContentRegionAvail().x - fs * 0.5f;
    ImGui::Spacing();
    ImGui::TextDisabled("Sonidos de este objeto");
    int del = -1;
    for (int i = 0; i < (int)o.sounds.size(); i++) {
        ImGui::PushID(i);
        ImGui::AlignTextToFramePadding();
        ImGui::Text("%d. %s", i + 1, shorten(o.sounds[i], 22).c_str());
        ImGui::SameLine(aw - fs * 9.f);
        if (ImGui::Button("Probar", ImVec2(fs * 5.f, fs * 2.2f)) && tapped() && audio_) audio_->play(o.sounds[i]);
        ImGui::SameLine();
        if (ImGui::Button("x", ImVec2(fs * 2.4f, fs * 2.2f)) && tapped()) del = i;
        ImGui::PopID();
    }
    if (del >= 0) { o.sounds.erase(o.sounds.begin() + del); markDirty(); }
    if (o.sounds.empty()) ImGui::TextDisabled("(ninguno)");
    ImGui::Spacing();
    if (ImGui::Button("Importar sonido...", ImVec2(aw, fs * 2.4f)) && tapped()) { if (host_.pickFile) host_.pickFile(); }
    if (ImGui::Button("Elegir de los archivos", ImVec2(aw, fs * 2.4f)) && tapped()) ImGui::OpenPopup("addsnd");
    if (ImGui::BeginPopup("addsnd")) {
        auto snds = assetsOf(1);
        if (snds.empty()) ImGui::TextDisabled("No hay audios en el proyecto");
        for (auto& a : snds) if (ImGui::MenuItem(a.c_str())) { o.sounds.push_back(a); markDirty(); }
        ImGui::EndPopup();
    }
    ImGui::Dummy(ImVec2(1, fs * 3.f));
}

}  // namespace forge
