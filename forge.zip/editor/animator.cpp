// Editor de animación con esqueleto: se dibujan palos y puntos sobre el modelo y el modelo se deforma con ellos.
#include "editor.h"
#include "importer.h"
#include "preview.h"
#include "renderer.h"
#include "imgui.h"
#include <algorithm>
#include <cmath>
#include <cstring>

namespace forge {

static const float kZoom = 0.62f;  // el modelo (cubo unitario) ocupa 0.62 del lienzo

static bool endsWith(const std::string& s, const char* e) {
    size_t n = std::strlen(e);
    return s.size() >= n && s.compare(s.size() - n, n, e) == 0;
}

void Editor::animLoadModel() {
    animMdOk_ = false;
    auto a = edit_.proj.assets.find(animRig_.model);
    if (a != edit_.proj.assets.end() && modelRead(a->second.data(), a->second.size(), animMd_) && animMd_.idx.size() >= 3) animMdOk_ = true;
    animWDirty_ = animImgDirty_ = true;
}

void Editor::openAnimEditor(const std::string& name) {
    animOpen_ = true;
    animTab_ = 0; animView_ = 0; animSel_ = -1; animClip_ = 0; animKey_ = -1; animT_ = 0;
    animPlay_ = false; animAdd_ = false;
    animRig_ = Rig();
    animName_ = name;
    Files& A = edit_.proj.assets;
    if (!name.empty()) {
        auto a = A.find(name);
        if (a != A.end()) rigRead(std::string(a->second.begin(), a->second.end()), animRig_);
    } else {
        std::string base = "esqueleto";
        animName_ = base + ".fanim";
        for (int i = 2; A.count(animName_); i++) animName_ = base + std::to_string(i) + ".fanim";
    }
    if (animRig_.model.empty()) {
        Obj* o = selObj();
        if (o && o->kind == Kind::Model && !o->model.empty()) animRig_.model = o->model;
        else {
            auto m = assetsOf(2);
            if (!m.empty()) animRig_.model = m[0];
        }
    }
    animPose_ = rigRestPose(animRig_);
    animLoadModel();
}

bool Editor::animSave() {
    if (animName_.empty()) animName_ = "esqueleto.fanim";
    if (!endsWith(animName_, ".fanim")) animName_ += ".fanim";
    std::string t = rigWrite(animRig_);
    edit_.proj.assets[animName_] = std::vector<uint8_t>(t.begin(), t.end());
    assetDirty_.insert(animName_);
    edit_.clearRigCache();
    markDirty();
    toast("Animación guardada: " + animName_);
    return true;
}

// Mantiene las poses del mismo tamaño que la lista de huesos.
void Editor::animFixSizes() {
    size_t n = animRig_.bones.size();
    animPose_.rot.resize(n);
    for (auto& c : animRig_.clips)
        for (auto& k : c.keys) k.pose.rot.resize(n);
    animWDirty_ = animImgDirty_ = true;
}

// Animaciones básicas (quieto, caminar, atacar) para el esqueleto humano automático.
void Editor::animPresets() {
    Rig& R = animRig_;
    auto id = [&](const char* n) { return rigFindBone(R, n); };
    int muslo[2] = {id("muslo_i"), id("muslo_d")}, hombro[2] = {id("hombro_i"), id("hombro_d")}, codo[2] = {id("codo_i"), id("codo_d")};
    int rodilla[2] = {id("rodilla_i"), id("rodilla_d")}, pecho = id("pecho"), cadera = id("cadera");
    size_t nb = R.bones.size();
    auto key = [&](RigClip& c, float t, float swing, float lift) {
        RigKey k;
        k.t = t;
        k.pose.rot.assign(nb, Quat());
        for (int s = 0; s < 2; s++) {
            float sg = s ? -1.f : 1.f;
            if (muslo[s] >= 0) k.pose.rot[muslo[s]] = qFromEulerDeg(swing * sg, 0, 0);
            if (hombro[s] >= 0) k.pose.rot[hombro[s]] = qFromEulerDeg(-swing * sg * 0.8f, 0, 0);
            if (rodilla[s] >= 0) k.pose.rot[rodilla[s]] = qFromEulerDeg(std::max(0.f, -swing * sg) * 0.8f, 0, 0);
        }
        k.pose.root.y = lift;
        c.keys.push_back(k);
    };
    auto addClip = [&](RigClip c) {
        int ex = rigFindClip(R, c.name);
        if (ex >= 0) R.clips[ex] = c; else R.clips.push_back(c);
    };
    RigClip walk; walk.name = "caminar"; walk.len = 0.9f;
    key(walk, 0.f, 32.f, 0.f); key(walk, 0.225f, 0.f, 0.012f); key(walk, 0.45f, -32.f, 0.f); key(walk, 0.675f, 0.f, 0.012f);
    addClip(walk);
    RigClip idle; idle.name = "quieto"; idle.len = 2.4f;
    {
        for (int i = 0; i < 3; i++) {
            RigKey k; k.t = i * 0.8f; k.pose.rot.assign(nb, Quat());
            float a = i == 1 ? 3.f : 0.f;
            if (pecho >= 0) k.pose.rot[pecho] = qFromEulerDeg(a, 0, 0);
            if (cadera >= 0 && i == 1) k.pose.root.y = 0.006f;
            idle.keys.push_back(k);
        }
    }
    addClip(idle);
    RigClip atk; atk.name = "atacar"; atk.len = 0.6f; atk.loop = false;
    {
        RigKey a, b, c;
        a.t = 0.f; b.t = 0.2f; c.t = 0.6f;
        for (RigKey* k : {&a, &b, &c}) k->pose.rot.assign(nb, Quat());
        if (hombro[1] >= 0) {
            a.pose.rot[hombro[1]] = qFromEulerDeg(40, 0, 0);
            b.pose.rot[hombro[1]] = qFromEulerDeg(-100, 0, 0);
        }
        if (codo[1] >= 0) b.pose.rot[codo[1]] = qFromEulerDeg(-20, 0, 0);
        if (pecho >= 0) { a.pose.rot[pecho] = qFromEulerDeg(-8, 0, 0); b.pose.rot[pecho] = qFromEulerDeg(12, 0, 0); }
        atk.keys = {a, b, c};
    }
    addClip(atk);
    animFixSizes();
}

// Esqueleto humano ajustado al tamaño del modelo.
static void humanoid(Rig& R, const std::vector<float>& v) {
    float mn[3] = {1e9f, 1e9f, 1e9f}, mx[3] = {-1e9f, -1e9f, -1e9f};
    for (size_t i = 0; i + 7 < v.size(); i += 8)
        for (int c = 0; c < 3; c++) { mn[c] = std::min(mn[c], v[i + c]); mx[c] = std::max(mx[c], v[i + c]); }
    if (v.size() < 8) { mn[0] = mn[1] = mn[2] = -0.5f; mx[0] = mx[1] = mx[2] = 0.5f; }
    float H = std::max(0.1f, mx[1] - mn[1]), cx = (mn[0] + mx[0]) * 0.5f, cz = (mn[2] + mx[2]) * 0.5f, y0 = mn[1];
    auto P = [&](float fx, float fy) { return V3{cx + fx * H, y0 + fy * H, cz}; };
    R.bones.clear();
    auto add = [&](const char* n, int par, V3 h) { R.bones.push_back({n, par, h}); return (int)R.bones.size() - 1; };
    int cad = add("cadera", -1, P(0, 0.52f));
    int col = add("columna", cad, P(0, 0.62f));
    int pec = add("pecho", col, P(0, 0.72f));
    int cue = add("cuello", pec, P(0, 0.84f));
    add("cabeza", cue, P(0, 0.89f));
    for (int s = 0; s < 2; s++) {
        float sg = s ? 1.f : -1.f;
        const char* sf = s ? "_d" : "_i";
        int ho = add((std::string("hombro") + sf).c_str(), pec, P(sg * 0.14f, 0.80f));
        int co = add((std::string("codo") + sf).c_str(), ho, P(sg * 0.18f, 0.62f));
        add((std::string("mano") + sf).c_str(), co, P(sg * 0.19f, 0.46f));
        int mu = add((std::string("muslo") + sf).c_str(), cad, P(sg * 0.07f, 0.50f));
        int ro = add((std::string("rodilla") + sf).c_str(), mu, P(sg * 0.07f, 0.27f));
        add((std::string("pie") + sf).c_str(), ro, P(sg * 0.07f, 0.05f));
    }
}

void Editor::animWin() {
    if (!animOpen_) return;
    float fs = ImGui::GetFontSize();
    ImGui::SetNextWindowPos(ImVec2(0, 0));
    ImGui::SetNextWindowSize(ImVec2((float)w_, (float)h_));
    if (!ImGui::Begin("Editor de animación", &animOpen_, ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoScrollbar |
                                                             ImGuiWindowFlags_NoScrollWithMouse | ImGuiWindowFlags_NoSavedSettings)) {
        ImGui::End();
        return;
    }
    Rig& R = animRig_;
    bool wide = w_ >= h_;
    float panelW = wide ? fs * 19.f : 0.f;
    auto bonesChanged = [&]() { animWDirty_ = animImgDirty_ = true; };

    // =========================== panel de herramientas
    ImGui::BeginChild("##atools", wide ? ImVec2(panelW, 0) : ImVec2(0, h_ * 0.46f), true, ImGuiWindowFlags_NoScrollbar);
    textInput("##aname", "Nombre", animName_, "esqueleto.fanim");
    if (ImGui::Button("Guardar", ImVec2(0, fs * 2.2f)) && tapped()) animSave();
    ImGui::SameLine();
    if (ImGui::Button("Guardar y cerrar", ImVec2(0, fs * 2.2f)) && tapped()) { animSave(); animOpen_ = false; }
    static const char* tabs[3] = {"Esqueleto", "Poses", "Animar"};
    float tw = ImGui::GetContentRegionAvail().x / 3.f;
    for (int i = 0; i < 3; i++) {
        if (i) ImGui::SameLine(0, 0);
        ImGui::PushStyleColor(ImGuiCol_Button, animTab_ == i ? ImVec4(0.12f, 0.62f, 0.56f, 1.f) : ImVec4(0.18f, 0.20f, 0.28f, 1.f));
        if (ImGui::Button(tabs[i], ImVec2(tw, fs * 2.4f)) && tapped()) { animTab_ = i; animAdd_ = false; animPlay_ = false; animImgDirty_ = true; }
        ImGui::PopStyleColor();
    }
    ImGui::BeginChild("##atab", ImVec2(0, 0), false, ImGuiWindowFlags_NoScrollbar);
    dragScroll();

    if (animTab_ == 0) {
        ImGui::TextWrapped("1) Elige el modelo.  2) Dibuja el esqueleto: toca el lienzo para poner puntos (cada punto nuevo se une con un palo al punto elegido).  3) Pasa a Poses.");
        if (assetCombo("Modelo", R.model, 2, nullptr)) { animLoadModel(); }
        ImGui::PushStyleColor(ImGuiCol_Button, animAdd_ ? ImVec4(0.85f, 0.55f, 0.15f, 1.f) : ImVec4(0.18f, 0.40f, 0.75f, 1.f));
        if (ImGui::Button(animAdd_ ? "Dibujando: toca el lienzo (toca aquí para parar)" : "Dibujar puntos y palos", ImVec2(-1, fs * 2.4f)) && tapped()) animAdd_ = !animAdd_;
        ImGui::PopStyleColor();
        if (ImGui::Button("Esqueleto humano automático", ImVec2(-1, fs * 2.2f)) && tapped() && animMdOk_) {
            humanoid(R, animMd_.v);
            R.clips.clear();
            animSel_ = -1;
            animFixSizes();
            toast("Esqueleto creado. Muévelo con el dedo para ajustarlo al modelo.");
        }
        if (ImGui::Button("Borrar todo el esqueleto", ImVec2(-1, fs * 2.2f)) && tapped()) { R.bones.clear(); R.clips.clear(); animSel_ = -1; animFixSizes(); }
        numField("Dureza de las juntas", R.stiff, 1.f, 8.f, "%.1f");
        if (animSel_ >= 0 && animSel_ < (int)R.bones.size()) {
            RigBone& b = R.bones[animSel_];
            ImGui::SeparatorText("Punto elegido");
            textInput("##bname", "Nombre del punto", b.name, "hueso");
            int cur = b.parent;
            std::string pl = cur >= 0 ? R.bones[cur].name : "(ninguno: es la raíz)";
            ImGui::Text("Unido a: %s", pl.c_str());
            if (ImGui::BeginCombo("Unir a", "elegir...")) {
                if (ImGui::Selectable("(ninguno)", cur < 0)) { b.parent = -1; bonesChanged(); }
                for (int i = 0; i < animSel_; i++)
                    if (ImGui::Selectable(R.bones[i].name.c_str(), cur == i)) { b.parent = i; bonesChanged(); }
                ImGui::EndCombo();
            }
            if (ImGui::Button("Borrar este punto", ImVec2(-1, fs * 2.2f)) && tapped()) {
                int d = animSel_;
                int np = R.bones[d].parent;
                for (auto& bb : R.bones) { if (bb.parent == d) bb.parent = np; }
                for (auto& bb : R.bones) if (bb.parent > d) bb.parent--;
                R.bones.erase(R.bones.begin() + d);
                for (auto& c : R.clips) for (auto& k : c.keys) if ((int)k.pose.rot.size() > d) k.pose.rot.erase(k.pose.rot.begin() + d);
                if ((int)animPose_.rot.size() > d) animPose_.rot.erase(animPose_.rot.begin() + d);
                animSel_ = -1;
                animFixSizes();
            }
        }
        ImGui::SeparatorText("Puntos");
        for (int i = 0; i < (int)R.bones.size(); i++) {
            ImGui::PushID(i);
            if (ImGui::Selectable(R.bones[i].name.c_str(), animSel_ == i)) animSel_ = i;
            ImGui::PopID();
        }
    } else if (animTab_ == 1) {
        ImGui::TextWrapped("Arrastra un punto del lienzo para girar el palo al que está unido. El modelo se estira y se dobla con él. La raíz mueve todo el cuerpo.");
        if (R.bones.empty()) ImGui::TextColored(ImVec4(1, 0.7f, 0.3f, 1), "Primero dibuja el esqueleto en la pestaña Esqueleto.");
        if (animSel_ >= 0 && animSel_ < (int)R.bones.size() && animSel_ < (int)animPose_.rot.size()) {
            ImGui::SeparatorText(R.bones[animSel_].name.c_str());
            float ex, ey, ez;
            qToEulerDeg(animPose_.rot[animSel_], ex, ey, ez);
            bool ch = false;
            ch |= numField("Girar X", ex, -180.f, 180.f, "%.0f");
            ch |= numField("Girar Y", ey, -180.f, 180.f, "%.0f");
            ch |= numField("Girar Z", ez, -180.f, 180.f, "%.0f");
            if (ch) { animPose_.rot[animSel_] = qFromEulerDeg(ex, ey, ez); animImgDirty_ = true; }
            if (ImGui::Button("Enderezar este punto", ImVec2(-1, fs * 2.2f)) && tapped()) { animPose_.rot[animSel_] = Quat(); animImgDirty_ = true; }
        }
        ImGui::SeparatorText("Todo el cuerpo");
        bool ch = false;
        ch |= numField("Mover X", animPose_.root.x, -0.5f, 0.5f, "%.2f");
        ch |= numField("Mover Y", animPose_.root.y, -0.5f, 0.5f, "%.2f");
        ch |= numField("Mover Z", animPose_.root.z, -0.5f, 0.5f, "%.2f");
        if (ch) animImgDirty_ = true;
        if (ImGui::Button("Pose de reposo", ImVec2(-1, fs * 2.2f)) && tapped()) { animPose_ = rigRestPose(R); animImgDirty_ = true; }
        ImGui::TextDisabled("Cuando te guste la pose, ve a Animar y ponla como fotograma.");
        ImGui::SeparatorText("Puntos");
        for (int i = 0; i < (int)R.bones.size(); i++) {
            ImGui::PushID(1000 + i);
            if (ImGui::Selectable(R.bones[i].name.c_str(), animSel_ == i)) animSel_ = i;
            ImGui::PopID();
        }
    } else {
        // ------------------------------------------------ Animar
        if (R.bones.empty()) ImGui::TextColored(ImVec4(1, 0.7f, 0.3f, 1), "Primero dibuja el esqueleto en la pestaña Esqueleto.");
        ImGui::SeparatorText("Animaciones");
        for (int i = 0; i < (int)R.clips.size(); i++) {
            if (i) ImGui::SameLine();
            ImGui::PushStyleColor(ImGuiCol_Button, animClip_ == i ? ImVec4(0.12f, 0.62f, 0.56f, 1.f) : ImVec4(0.18f, 0.20f, 0.28f, 1.f));
            if (ImGui::Button((R.clips[i].name + "##c" + std::to_string(i)).c_str(), ImVec2(0, fs * 2.2f)) && tapped()) { animClip_ = i; animKey_ = -1; animT_ = 0; animPlay_ = false; }
            ImGui::PopStyleColor();
        }
        if (ImGui::Button("+ Nueva animación", ImVec2(0, fs * 2.2f)) && tapped() && !R.bones.empty()) {
            RigClip c;
            c.name = "animacion" + std::to_string(R.clips.size() + 1);
            R.clips.push_back(c);
            animClip_ = (int)R.clips.size() - 1; animKey_ = -1; animT_ = 0;
        }
        ImGui::SameLine();
        if (ImGui::Button("Crear caminar / quieto / atacar", ImVec2(0, fs * 2.2f)) && tapped()) { animPresets(); toast("Listo: caminar, quieto y atacar (para el esqueleto humano automático)"); }
        if (animClip_ >= 0 && animClip_ < (int)R.clips.size()) {
            RigClip& C = R.clips[animClip_];
            ImGui::SeparatorText("Esta animación");
            textInput("##cname", "Nombre", C.name, "animacion");
            numField("Duración (s)", C.len, 0.1f, 20.f, "%.2f");
            ImGui::Checkbox("Se repite (bucle)", &C.loop);
            if (ImGui::Button(animPlay_ ? "Parar" : "Reproducir", ImVec2(fs * 8.f, fs * 2.4f)) && tapped()) { animPlay_ = !animPlay_; animImgDirty_ = true; }
            ImGui::SameLine();
            if (ImGui::Button("Borrar animación", ImVec2(0, fs * 2.4f)) && tapped()) {
                R.clips.erase(R.clips.begin() + animClip_);
                animClip_ = std::max(0, animClip_ - 1); animKey_ = -1; animPlay_ = false;
                ImGui::EndChild(); ImGui::EndChild(); ImGui::End();
                return;
            }
            // línea de tiempo
            ImVec2 p = ImGui::GetCursorScreenPos();
            float bw = ImGui::GetContentRegionAvail().x, bh = fs * 2.6f;
            ImGui::InvisibleButton("##timeline", ImVec2(bw, bh));
            ImDrawList* dl = ImGui::GetWindowDrawList();
            dl->AddRectFilled(p, ImVec2(p.x + bw, p.y + bh), IM_COL32(28, 33, 45, 255), 6.f);
            for (int i = 0; i < (int)C.keys.size(); i++) {
                float x = p.x + (C.len > 0 ? C.keys[i].t / C.len : 0) * bw;
                dl->AddCircleFilled(ImVec2(x, p.y + bh * 0.5f), fs * 0.5f, animKey_ == i ? IM_COL32(255, 170, 40, 255) : IM_COL32(60, 200, 190, 255));
            }
            float cx = p.x + (C.len > 0 ? std::min(1.f, animT_ / C.len) : 0) * bw;
            dl->AddLine(ImVec2(cx, p.y), ImVec2(cx, p.y + bh), IM_COL32(255, 255, 255, 220), 2.f);
            if (ImGui::IsItemActive()) {
                float f = std::max(0.f, std::min(1.f, (ImGui::GetIO().MousePos.x - p.x) / bw));
                animT_ = f * C.len;
                animPlay_ = false;
                if (ImGui::IsMouseClicked(0)) {  // si tocas un fotograma, se elige
                    animKey_ = -1;
                    for (int i = 0; i < (int)C.keys.size(); i++)
                        if (std::fabs(p.x + C.keys[i].t / std::max(0.01f, C.len) * bw - ImGui::GetIO().MousePos.x) < fs * 0.9f) { animKey_ = i; animT_ = C.keys[i].t; }
                }
                if (animKey_ >= 0 && animKey_ < (int)C.keys.size() && std::fabs(C.keys[animKey_].t - animT_) < 0.001f) animPose_ = C.keys[animKey_].pose;
                else animPose_ = rigSample(R, C, animT_);
                animPose_.rot.resize(R.bones.size());
                animImgDirty_ = true;
            }
            ImGui::Text("Tiempo: %.2f s", animT_);
            if (ImGui::Button("Poner la pose actual como fotograma aquí", ImVec2(-1, fs * 2.4f)) && tapped() && !R.bones.empty()) {
                RigKey k;
                k.t = animT_;
                k.pose = animPose_;
                k.pose.rot.resize(R.bones.size());
                bool rep = false;
                for (auto& e : C.keys) if (std::fabs(e.t - k.t) < 0.02f) { e.pose = k.pose; rep = true; }
                if (!rep) C.keys.push_back(k);
                std::stable_sort(C.keys.begin(), C.keys.end(), [](const RigKey& a, const RigKey& b) { return a.t < b.t; });
                animKey_ = -1;
                for (int i = 0; i < (int)C.keys.size(); i++) if (std::fabs(C.keys[i].t - animT_) < 0.02f) animKey_ = i;
            }
            if (animKey_ >= 0 && animKey_ < (int)C.keys.size()) {
                RigKey& K = C.keys[animKey_];
                ImGui::SeparatorText("Fotograma elegido");
                if (numField("Momento (s)", K.t, 0.f, C.len, "%.2f")) animT_ = K.t;
                if (ImGui::Button("Cargar su pose", ImVec2(0, fs * 2.2f)) && tapped()) { animPose_ = K.pose; animPose_.rot.resize(R.bones.size()); animImgDirty_ = true; }
                ImGui::SameLine();
                if (ImGui::Button("Actualizar con la pose actual", ImVec2(0, fs * 2.2f)) && tapped()) { K.pose = animPose_; K.pose.rot.resize(R.bones.size()); }
                if (ImGui::Button("Borrar fotograma", ImVec2(-1, fs * 2.2f)) && tapped()) { C.keys.erase(C.keys.begin() + animKey_); animKey_ = -1; }
            }
            std::stable_sort(C.keys.begin(), C.keys.end(), [](const RigKey& a, const RigKey& b) { return a.t < b.t; });
        }
        ImGui::SeparatorText("Importar");
        ImGui::TextWrapped("Trae animaciones de un archivo .glb, .gltf o .fbx. Se asignan a los puntos del esqueleto por su nombre (o crean el esqueleto si el archivo trae el modelo).");
        if (ImGui::Button("Importar animaciones de un archivo...", ImVec2(-1, fs * 2.4f)) && tapped() && host_.pickFile) {
            animImportPending_ = true;
            host_.pickFile();
        }
    }
    ImGui::Dummy(ImVec2(1, fs * 2.f));
    ImGui::EndChild();
    ImGui::EndChild();
    if (wide) ImGui::SameLine();

    // =========================== lienzo
    ImVec2 av = ImGui::GetContentRegionAvail();
    float Q = std::max(fs * 8.f, std::min(av.x, av.y - fs * 3.f));
    ImGui::BeginGroup();
    for (int i = 0; i < 2; i++) {
        if (i) ImGui::SameLine();
        ImGui::PushStyleColor(ImGuiCol_Button, animView_ == i ? ImVec4(0.12f, 0.62f, 0.56f, 1.f) : ImVec4(0.18f, 0.20f, 0.28f, 1.f));
        if (ImGui::Button(i ? "Vista de lado" : "Vista de frente", ImVec2(fs * 9.f, fs * 2.2f)) && tapped()) { animView_ = i; animImgDirty_ = true; }
        ImGui::PopStyleColor();
    }
    ImVec2 org = ImGui::GetCursorScreenPos();
    ImGui::InvisibleButton("##acanvas", ImVec2(Q, Q));
    ImDrawList* dl = ImGui::GetWindowDrawList();
    dl->AddRectFilled(org, ImVec2(org.x + Q, org.y + Q), IM_COL32(24, 28, 38, 255), 8.f);
    for (int g = 1; g < 10; g++) {
        float o = Q * g / 10.f;
        dl->AddLine(ImVec2(org.x + o, org.y), ImVec2(org.x + o, org.y + Q), IM_COL32(255, 255, 255, g == 5 ? 36 : 14));
        dl->AddLine(ImVec2(org.x, org.y + o), ImVec2(org.x + Q, org.y + o), IM_COL32(255, 255, 255, g == 5 ? 36 : 14));
    }

    // pose que se muestra
    RigPose shown = (animTab_ == 0) ? rigRestPose(R) : animPose_;
    shown.rot.resize(R.bones.size());
    if (animPlay_ && animTab_ == 2 && animClip_ >= 0 && animClip_ < (int)R.clips.size()) {
        RigClip& C = R.clips[animClip_];
        animT_ += ImGui::GetIO().DeltaTime;
        if (animT_ > C.len) animT_ = C.loop ? std::fmod(animT_, std::max(0.05f, C.len)) : (animPlay_ = false, C.len);
        shown = rigSample(R, C, animT_);
        shown.rot.resize(R.bones.size());
        animPose_ = shown;
        animImgDirty_ = true;
    }
    // imagen del modelo (deformado)
    if (animMdOk_ && rend_) {
        if (animImgDirty_) {
            std::vector<float> verts = animMd_.v;
            if (!R.bones.empty()) {
                if (animWDirty_) { rigComputeWeights(R, animMd_.v, animW_); animWDirty_ = false; }
                std::vector<float> mats;
                rigSkinMatrices(R, shown, mats);
                rigSkin(animMd_.v, animW_, mats, verts);
            }
            if (meshRaster(animMd_, verts, edit_.proj.assets, 256, animView_ ? 1.5707963f : 0.f, 0.f, animPx_)) rend_->updateRGBA("::animprev", 256, 256, animPx_.data());
            animImgDirty_ = false;
        }
        unsigned id = rend_->rawTexture("::animprev");
        if (id) dl->AddImage((ImTextureID)(intptr_t)id, org, ImVec2(org.x + Q, org.y + Q), ImVec2(0, 0), ImVec2(1, 1), IM_COL32(255, 255, 255, animTab_ == 0 ? 150 : 255));
    } else if (!animMdOk_) {
        dl->AddText(ImVec2(org.x + fs, org.y + fs), IM_COL32(255, 200, 120, 255), "Elige un modelo 3D en la pestaña Esqueleto");
    }
    // esqueleto: palos y puntos
    std::vector<V3> pj;
    rigJointPositions(R, shown, pj);
    auto toS = [&](V3 p) {
        float h = animView_ ? p.z : p.x;
        return ImVec2(org.x + (0.5f + h * kZoom) * Q, org.y + (0.5f - p.y * kZoom) * Q);
    };
    for (size_t i = 0; i < R.bones.size(); i++)
        if (R.bones[i].parent >= 0) dl->AddLine(toS(pj[R.bones[i].parent]), toS(pj[i]), IM_COL32(40, 220, 200, 255), 4.f);
    for (size_t i = 0; i < R.bones.size(); i++) {
        ImVec2 s = toS(pj[i]);
        bool sel = animSel_ == (int)i;
        dl->AddCircleFilled(s, fs * (sel ? 0.8f : 0.6f), sel ? IM_COL32(255, 170, 40, 255) : IM_COL32(255, 255, 255, 255));
        dl->AddCircle(s, fs * (sel ? 0.8f : 0.6f), IM_COL32(10, 20, 30, 255), 0, 2.f);
        if (R.bones[i].parent < 0) dl->AddCircle(s, fs * 1.0f, IM_COL32(255, 90, 90, 255), 0, 2.f);
    }

    // toques sobre el lienzo
    static int dragJ = -1;
    if (ImGui::IsItemActive() && !animPlay_) {
        ImVec2 m = ImGui::GetIO().MousePos;
        float u = (m.x - org.x) / Q, v = (m.y - org.y) / Q;
        float mh = (u - 0.5f) / kZoom, my = (0.5f - v) / kZoom;  // medidas del modelo
        if (ImGui::IsMouseClicked(0)) {
            dragJ = -1;
            float best = fs * 1.6f;
            for (size_t i = 0; i < R.bones.size(); i++) {
                ImVec2 s = toS(pj[i]);
                float d = std::sqrt((s.x - m.x) * (s.x - m.x) + (s.y - m.y) * (s.y - m.y));
                if (d < best) { best = d; dragJ = (int)i; }
            }
            if (dragJ >= 0) animSel_ = dragJ;
            else if (animTab_ == 0 && animAdd_) {
                RigBone b;
                b.name = "punto" + std::to_string(R.bones.size() + 1);
                b.parent = (animSel_ >= 0 && animSel_ < (int)R.bones.size()) ? animSel_ : -1;
                V3 base = b.parent >= 0 ? R.bones[b.parent].head : V3{0, 0, 0};
                b.head = animView_ ? V3{base.x, my, mh} : V3{mh, my, base.z};
                R.bones.push_back(b);
                animSel_ = (int)R.bones.size() - 1;
                animFixSizes();
                dragJ = -1;
            }
        }
        if (dragJ >= 0 && ImGui::IsMouseDragging(0, 2.f) && dragJ < (int)R.bones.size()) {
            if (animTab_ == 0) {
                V3& hd = R.bones[dragJ].head;
                hd.y = my;
                if (animView_) hd.z = mh; else hd.x = mh;
                bonesChanged();
            } else {
                int P = R.bones[dragJ].parent;
                if (P < 0) {  // la raíz mueve todo el cuerpo
                    V3 cur = pj[dragJ];
                    float ch = animView_ ? cur.z : cur.x;
                    float dh = mh - ch, dv = my - cur.y;
                    if (animView_) animPose_.root.z += dh; else animPose_.root.x += dh;
                    animPose_.root.y += dv;
                } else {
                    float ah = (animView_ ? pj[dragJ].z : pj[dragJ].x) - (animView_ ? pj[P].z : pj[P].x), av2 = pj[dragJ].y - pj[P].y;
                    float bh = mh - (animView_ ? pj[P].z : pj[P].x), bv = my - pj[P].y;
                    if (std::sqrt(bh * bh + bv * bv) > 0.01f && std::sqrt(ah * ah + av2 * av2) > 0.001f) {
                        float th = std::atan2(ah * bv - av2 * bh, ah * bh + av2 * bv);
                        V3 axis = animView_ ? V3{-1, 0, 0} : V3{0, 0, 1};
                        Quat Qd = qAxisAngle(axis, th);
                        std::vector<Quat> rw;
                        rigWorldRots(R, animPose_, rw);
                        int pp = R.bones[P].parent;
                        Quat rpp = pp >= 0 ? rw[pp] : Quat();
                        Quat delta = qMul(qInv(rpp), qMul(Qd, rpp));
                        animPose_.rot.resize(R.bones.size());
                        animPose_.rot[P] = qNorm(qMul(delta, animPose_.rot[P]));
                    }
                }
                animImgDirty_ = true;
            }
        }
    } else {
        dragJ = -1;
    }
    ImGui::EndGroup();
    ImGui::End();
}

}  // namespace forge
