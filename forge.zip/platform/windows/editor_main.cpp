// Editor completo de P-Maker para Windows (el mismo editor que en Android; raton y teclado en vez de dedos).
//   raton izquierdo = 1 dedo | boton derecho + arrastrar = 2 dedos (mover) | rueda = acercar / alejar
#define GLFW_INCLUDE_NONE
#include <GLFW/glfw3.h>

#include <algorithm>
#include <chrono>
#include <memory>
#include <cstdio>
#include <atomic>
#include <map>
#include <mutex>
#include <string>
#include <thread>
#include <utility>
#include "apkbuild.h"

#include "audio.h"
#include "editor.h"
#include "gl.h"
#include "imgui.h"
#include "imgui_impl_glfw.h"
#include "imgui_impl_opengl3.h"
#include "renderer.h"

#ifdef _WIN32
#include <windows.h>
#include <commdlg.h>
#include <shlobj.h>
#endif

using namespace forge;

static void* getProc(const char* n) { return (void*)glfwGetProcAddress(n); }

static bool readFile(const std::string& path, std::vector<uint8_t>& out) {
    FILE* f = fopen(path.c_str(), "rb");
    if (!f) return false;
    fseek(f, 0, SEEK_END);
    long long n = (long long)_ftelli64(f);
    fseek(f, 0, SEEK_SET);
    out.resize((size_t)n);
    bool ok = fread(out.data(), 1, (size_t)n, f) == (size_t)n;
    fclose(f);
    return ok;
}

static std::string exeDir() {
#ifdef _WIN32
    char buf[MAX_PATH];
    if (GetModuleFileNameA(nullptr, buf, MAX_PATH)) {
        std::string s = buf;
        size_t k = s.find_last_of("\\/");
        return k == std::string::npos ? "." : s.substr(0, k);
    }
#endif
    return ".";
}

static std::string documentsDir() {
#ifdef _WIN32
    char buf[MAX_PATH];
    if (SUCCEEDED(SHGetFolderPathA(nullptr, CSIDL_PERSONAL, nullptr, 0, buf))) return std::string(buf) + "\\P-Maker";
#endif
    return "P-Maker";
}

struct App {
    std::unique_ptr<Editor> editor;
    Audio audio;
    GLFWwindow* win = nullptr;
    std::vector<std::pair<std::string, std::string>> pending;  // archivos elegidos
};

int main() {
    if (!glfwInit()) return 1;
    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
    glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);
    glfwWindowHint(GLFW_DEPTH_BITS, 24);
    GLFWwindow* win = glfwCreateWindow(1280, 760, "P-Maker code333", nullptr, nullptr);
    if (!win) { glfwTerminate(); return 1; }
    glfwMakeContextCurrent(win);
    glfwSwapInterval(1);
    if (!forgeLoadGL(getProc)) { fprintf(stderr, "No se pudo cargar OpenGL 3.3\n"); return 1; }

    Renderer rend;
    if (!rend.init(1024)) { fprintf(stderr, "No se pudo iniciar el renderizador\n"); return 1; }

    IMGUI_CHECKVERSION();
    ImGui::CreateContext();
    ImGuiIO& io = ImGui::GetIO();
    io.IniFilename = nullptr;
    float cs = 1.f, csy = 1.f;
    glfwGetWindowContentScale(win, &cs, &csy);
    float sc = std::max(1.f, cs);
    ImFontConfig fc;
    fc.SizePixels = 17.f * sc;
    io.Fonts->AddFontDefault(&fc);
    applyTheme();
    ImGui::GetStyle().ScaleAllSizes(sc);
    ImGui_ImplGlfw_InitForOpenGL(win, true);
    ImGui_ImplOpenGL3_Init("#version 330 core");

    App app;
    app.win = win;
    app.audio.init();
    EditorHost h;
    h.dataDir = documentsDir();
#ifdef _WIN32
    CreateDirectoryA(h.dataDir.c_str(), nullptr);
    h.pickFile = [&app]() {
        char file[MAX_PATH] = "";
        OPENFILENAMEA o = {};
        o.lStructSize = sizeof o;
        o.lpstrFile = file;
        o.nMaxFile = MAX_PATH;
        o.lpstrFilter = "Todos los archivos\0*.*\0";
        o.Flags = OFN_FILEMUSTEXIST | OFN_PATHMUSTEXIST | OFN_NOCHANGEDIR;
        if (GetOpenFileNameA(&o)) app.pending.push_back({file, file});
    };
    h.saveOut = [](const std::string& name, const std::string& path) {
        char file[MAX_PATH];
        snprintf(file, sizeof file, "%s", name.c_str());
        OPENFILENAMEA o = {};
        o.lStructSize = sizeof o;
        o.lpstrFile = file;
        o.nMaxFile = MAX_PATH;
        o.lpstrFilter = "Todos los archivos\0*.*\0";
        o.Flags = OFN_OVERWRITEPROMPT | OFN_NOCHANGEDIR;
        if (GetSaveFileNameA(&o)) CopyFileA(path.c_str(), file, FALSE);
    };
#endif
    // forge_runtime.exe viaja junto al editor: se pega al juego para exportar el .exe
    h.loadRuntime = [](std::vector<uint8_t>& out) { return readFile(exeDir() + "\\forge_runtime.exe", out); };
    // Crear el APK instalable desde Windows: usa la plantilla (forge_template.apk) y la clave que viajan junto al editor.
    {
        static std::mutex apkMu;
        static std::string apkStatus;
        static std::atomic<bool> apkRunning{false};
        std::string tplPath = exeDir() + "\\forge_template.apk";
        std::vector<uint8_t> probe;
        FILE* tf = fopen(tplPath.c_str(), "rb");
        bool haveTpl = tf != nullptr;
        if (tf) fclose(tf);
        if (haveTpl) {
            h.buildApkStatus = []() { std::lock_guard<std::mutex> l(apkMu); return apkStatus; };
            h.buildApk = [tplPath](const std::string& packPath, const std::string& label, const std::string& appId, const std::string& iconPath,
                                   const std::string& verName, const std::string& outName, int orient, int verCode) {
                { std::lock_guard<std::mutex> l(apkMu); apkStatus.clear(); }
                if (apkRunning.exchange(true)) return;
                std::string outDir = documentsDir() + "\\export", dir = exeDir();
                std::thread([=]() {
                    std::string res;
                    try {
                        std::vector<uint8_t> tpl, pack, icon, key, cert, out;
                        if (!readFile(tplPath, tpl)) throw std::string("No se puede leer forge_template.apk (debe estar junto al editor)");
                        if (!readFile(packPath, pack)) throw std::string("No se puede leer el juego");
                        if (!iconPath.empty()) readFile(iconPath, icon);
                        if (!readFile(dir + "\\apk_sign_key.pk8", key) || !readFile(dir + "\\apk_sign_cert.der", cert))
                            throw std::string("Faltan apk_sign_key.pk8 / apk_sign_cert.der junto al editor");
                        ApkConfig c;
                        c.label = label; c.appId = appId; c.verName = verName; c.verCode = verCode; c.orient = orient;
                        std::map<std::string, std::vector<uint8_t>> extra;
                        extra["assets/game.pack"] = pack;
                        extra["assets/standalone"] = {'1'};
                        std::string err;
                        bool ic = false;
                        if (!apkBuild(tpl, extra, icon, c, key, cert, out, &ic, err)) throw err;
                        std::string path = outDir + "\\" + outName;
                        FILE* f = fopen(path.c_str(), "wb");
                        if (!f || fwrite(out.data(), 1, out.size(), f) != out.size()) { if (f) fclose(f); throw std::string("No se pudo escribir el APK"); }
                        fclose(f);
                        res = "OK:" + path;
                        if (!icon.empty() && !ic) res += "|AVISO: no se encontro el icono en la plantilla; se dejo el de P-Maker";
                    } catch (const std::string& e) { res = "ERROR:" + e; }
                    catch (...) { res = "ERROR:fallo inesperado"; }
                    { std::lock_guard<std::mutex> l(apkMu); apkStatus = res; }
                    apkRunning = false;
                }).detach();
            };
        }
    }
    app.editor.reset(new Editor(h));
    app.editor->init(&app.audio);

    auto prev = std::chrono::steady_clock::now();
    bool leftDown = false, rightDown = false;
    double lastX = 0, lastY = 0;
    float wheelAcc = 0;
    glfwSetScrollCallback(win, [](GLFWwindow* w, double dx, double dy) {
        ImGui_ImplGlfw_ScrollCallback(w, dx, dy);
        float* acc = (float*)glfwGetWindowUserPointer(w);
        if (acc) *acc += (float)dy;
    });
    glfwSetWindowUserPointer(win, &wheelAcc);

    while (!glfwWindowShouldClose(win)) {
        glfwPollEvents();
        int w, hh;
        glfwGetFramebufferSize(win, &w, &hh);
        if (w <= 0 || hh <= 0) continue;
        auto now = std::chrono::steady_clock::now();
        float dt = std::chrono::duration<float>(now - prev).count();
        prev = now;
        if (dt > 0.1f) dt = 0.1f;

        // archivos elegidos
        for (auto& f : app.pending) {
            std::vector<uint8_t> data;
            if (readFile(f.second, data)) app.editor->onFile(f.first, std::move(data));
        }
        app.pending.clear();

        // el raton hace de dedos para el editor
        PlayControls& ctl = app.editor->controls();
        double mx, my;
        glfwGetCursorPos(win, &mx, &my);
        int64_t t = (int64_t)(glfwGetTime() * 1000.0);
        bool L = glfwGetMouseButton(win, GLFW_MOUSE_BUTTON_LEFT) == GLFW_PRESS;
        bool R = glfwGetMouseButton(win, GLFW_MOUSE_BUTTON_RIGHT) == GLFW_PRESS;
        if (R && !rightDown) { ctl.begin(0, (float)mx, (float)my, t); ctl.begin(1, (float)mx + 40.f, (float)my, t); }
        else if (R) { ctl.move(0, (float)mx, (float)my); ctl.move(1, (float)mx + 40.f, (float)my); }
        else if (rightDown) { ctl.end(0, t); ctl.end(1, t); }
        rightDown = R;
        if (!R) {
            if (L && !leftDown) ctl.begin(0, (float)mx, (float)my, t);
            else if (L) ctl.move(0, (float)mx, (float)my);
            else if (leftDown) ctl.end(0, t);
            leftDown = L;
        } else leftDown = false;
        if (wheelAcc != 0.f && !io.WantCaptureMouse) {  // rueda = pellizco
            float cx = (float)mx, cy = (float)my, d = 60.f, d2 = d * (wheelAcc > 0 ? 1.25f : 0.8f);
            ctl.begin(0, cx - d, cy, t); ctl.begin(1, cx + d, cy, t);
            ctl.move(0, cx - d2, cy); ctl.move(1, cx + d2, cy);
            ctl.end(0, t); ctl.end(1, t);
        }
        wheelAcc = 0.f;
        (void)lastX; (void)lastY;

        ImGui_ImplOpenGL3_NewFrame();
        ImGui_ImplGlfw_NewFrame();
        ImGui::NewFrame();
        app.editor->frame(&rend, w, hh, dt);
        ImGui::Render();
        glViewport(0, 0, w, hh);
        ImGui_ImplOpenGL3_RenderDrawData(ImGui::GetDrawData());
        glfwSwapBuffers(win);
    }
    if (app.editor && app.editor->dirty()) app.editor->saveProject();
    app.editor.reset();
    app.audio.shutdown();
    ImGui_ImplOpenGL3_Shutdown();
    ImGui_ImplGlfw_Shutdown();
    ImGui::DestroyContext();
    glfwDestroyWindow(win);
    glfwTerminate();
    return 0;
}
