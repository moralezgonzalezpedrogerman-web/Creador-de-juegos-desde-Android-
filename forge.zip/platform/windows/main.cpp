// Runtime de Windows. Un juego exportado es este mismo .exe con el paquete del
// proyecto pegado al final: al arrancar se lee a si mismo y ejecuta el juego.
#define GLFW_INCLUDE_NONE
#include <GLFW/glfw3.h>

#include <chrono>
#include <cstdio>
#include <string>
#include <utility>

#include "audio.h"
#include "game.h"
#include "imgui.h"
#include "imgui_impl_glfw.h"
#include "imgui_impl_opengl3.h"
#include "pack.h"
#include "playview.h"
#include "renderer.h"

#ifdef _WIN32
#include <windows.h>
#endif

using namespace forge;

static bool readFile(const char* path, std::vector<uint8_t>& out) {
    FILE* f = fopen(path, "rb");
    if (!f) return false;
    fseek(f, 0, SEEK_END);
    long n = ftell(f);
    fseek(f, 0, SEEK_SET);
    out.resize((size_t)n);
    bool ok = fread(out.data(), 1, (size_t)n, f) == (size_t)n;
    fclose(f);
    return ok;
}

static void* getProc(const char* n) { return (void*)glfwGetProcAddress(n); }

int main(int argc, char** argv) {
    std::string self = argc > 0 ? argv[0] : "";
#ifdef _WIN32
    char buf[MAX_PATH];
    if (GetModuleFileNameA(nullptr, buf, MAX_PATH)) self = buf;
#endif

    Project proj;
    std::vector<uint8_t> pk;
    // 1) paquete pegado al propio .exe  2) archivo .pack pasado como argumento  3) demo
    if (extractFromExe(self, pk) || (argc > 1 && readFile(argv[1], pk))) {
        Files files;
        std::string err;
        if (!packRead(pk.data(), pk.size(), files) || !loadProject(files, proj, err)) {
            fprintf(stderr, "Proyecto invalido: %s\n", err.c_str());
            return 1;
        }
    } else {
        loadDemo(proj);
    }

    if (!glfwInit()) return 1;
    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
    glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);
    glfwWindowHint(GLFW_DEPTH_BITS, 16);
    const ExportCfg& ec = proj.exportCfg;
    std::string title = ec.winTitle.empty() ? proj.name : ec.winTitle;
    GLFWmonitor* mon = ec.fullscreen ? glfwGetPrimaryMonitor() : nullptr;
    int ww = ec.winW, wh = ec.winH;
    if (mon) {
        const GLFWvidmode* vm = glfwGetVideoMode(mon);
        if (vm) { ww = vm->width; wh = vm->height; }
    }
    GLFWwindow* win = glfwCreateWindow(ww, wh, title.c_str(), mon, nullptr);
    if (!win) { glfwTerminate(); return 1; }
    glfwMakeContextCurrent(win);
    glfwSwapInterval(1);
    if (!forgeLoadGL(getProc)) { fprintf(stderr, "No se pudo cargar OpenGL 3.3\n"); return 1; }

    Renderer rend;
    if (!rend.init(1024)) { fprintf(stderr, "No se pudo iniciar el renderizador\n"); return 1; }

    IMGUI_CHECKVERSION();
    ImGui::CreateContext();
    ImGui::GetIO().IniFilename = nullptr;
    ImGui::StyleColorsDark();
    ImGui_ImplGlfw_InitForOpenGL(win, true);
    ImGui_ImplOpenGL3_Init("#version 330 core");

    Audio audio;
    audio.init();
    PlayView pv;
    pv.audio = &audio;
    pv.showButtons = false;  // en PC se juega con teclado y raton
    pv.start(std::move(proj));

    bool lastMode = false, firstMode = true, prevClick = false;
    double lx = 0, ly = 0;
    auto prev = std::chrono::steady_clock::now();

    while (!glfwWindowShouldClose(win)) {
        glfwPollEvents();
        if (glfwGetKey(win, GLFW_KEY_ESCAPE) == GLFW_PRESS) break;

        int ww, wh;
        glfwGetFramebufferSize(win, &ww, &wh);
        double mx, my;
        glfwGetCursorPos(win, &mx, &my);

        bool is3d = pv.game.sc && pv.game.sc->is3d;
        if (firstMode || is3d != lastMode) {
            glfwSetInputMode(win, GLFW_CURSOR, is3d ? GLFW_CURSOR_DISABLED : GLFW_CURSOR_NORMAL);
            glfwGetCursorPos(win, &mx, &my);
            lx = mx; ly = my;
            lastMode = is3d;
            firstMode = false;
        }

        Input in;
        auto key = [&](int k) { return glfwGetKey(win, k) == GLFW_PRESS; };
        in.moveX = (key(GLFW_KEY_D) || key(GLFW_KEY_RIGHT) ? 1.f : 0.f) - (key(GLFW_KEY_A) || key(GLFW_KEY_LEFT) ? 1.f : 0.f);
        in.moveY = (key(GLFW_KEY_W) || key(GLFW_KEY_UP) ? 1.f : 0.f) - (key(GLFW_KEY_S) || key(GLFW_KEY_DOWN) ? 1.f : 0.f);
        in.jump = key(GLFW_KEY_SPACE);
        in.lookX = (float)(mx - lx) * 0.0025f;
        in.lookY = (float)(my - ly) * 0.0025f;
        lx = mx; ly = my;
        bool click = glfwGetMouseButton(win, GLFW_MOUSE_BUTTON_LEFT) == GLFW_PRESS;
        bool interact = key(GLFW_KEY_E);
        static bool prevE = false;
        in.shoot = click && is3d;
        in.tap = (click && !prevClick && !is3d) || (interact && !prevE);
        prevClick = click;
        prevE = interact;
        in.tapX = is3d ? 0.5f : (ww > 0 ? (float)(mx / ww) : 0.5f);
        in.tapY = is3d ? 0.5f : (wh > 0 ? (float)(my / wh) : 0.5f);

        auto now = std::chrono::steady_clock::now();
        float dt = std::chrono::duration<float>(now - prev).count();
        prev = now;
        if (dt > 0.1f) dt = 0.1f;

        ImGui_ImplOpenGL3_NewFrame();
        ImGui_ImplGlfw_NewFrame();
        ImGui::NewFrame();
        pv.frame(&rend, ww, wh, dt, &in);
        ImGui::Render();
        ImGui_ImplOpenGL3_RenderDrawData(ImGui::GetDrawData());
        glfwSwapBuffers(win);
    }
    audio.shutdown();
    ImGui_ImplOpenGL3_Shutdown();
    ImGui_ImplGlfw_Shutdown();
    ImGui::DestroyContext();
    glfwTerminate();
    return 0;
}
