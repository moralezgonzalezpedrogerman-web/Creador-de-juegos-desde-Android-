# Forge

Creador de juegos para Android con motor propio en C++ (sin Unity/Godot).

- **Editor por páginas** (como Pocket Code): Proyecto → Escenas → Escena (Fondo + Actores y objetos) → Objeto con pestañas Scripts / Apariencias / Sonidos.
- **Bloques en español** (Eventos, Control, Movimiento, Sonido, Apariencia, Datos + extras 3D), se ordenan **arrastrando** el asa `=`; tocar el asa da ayuda, duplicar y eliminar.
- **Editor de fórmulas** con teclado de calculadora y listas Funciones / Objeto / Dispositivo / Lógica / Datos.
- Escenas **2D** (menús, juegos planos) y **3D** (niveles en primera persona), que pueden alternarse con "Iniciar escena".
- Exporta a APK (GitHub Actions) y a .exe (el .exe se arma dentro de la app).

## Compilar
Sube a tu repositorio solo `forge.zip` y `.github/workflows/build.yml`; el workflow descomprime y compila (pruebas, runtime de Windows y APK).

## Pruebas locales
`cmake -S tests -B build-tests && cmake --build build-tests && ctest --test-dir build-tests`

## Pendiente
Editor 3D de rejilla estilo FPS Creator, pintor de texturas, listas, lápiz, cámara y sensores en los bloques.

## Novedades (v4)
- Bloques dibujados como piezas conectadas (sombrero, rieles en bucles y "si", espacio entre guiones).
- Bloques nuevos: reproducir sonido y esperar, cambiar vista de cámara, esperar hasta, detener guion, disparar al jugador, quitar vida, velocidad y salto del jugador, reproducir animación, mover al azar.
- Jugador como objeto editable (se mueve en el editor): cámara en primera persona, al hombro o fija (colocable), cuerpo, arma 2D/3D y proyectil (bala, imagen o modelo).
- Enemigo (dispara) y monstruo (cuerpo a cuerpo) con IA: modelo 3D o sprites por acción (quieto, caminar, atacar, daño) y mini animación.
- Colisión de modelos importados con rejilla 64³ fusionada en cajas: casas huecas se pueden recorrer.
