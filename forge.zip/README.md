# Forge

Creador de juegos para Android con motor propio en C++ (sin Unity/Godot).

- **Editor por páginas** (como Pocket Code): Proyecto → Escenas → Escena (Fondo + Actores y objetos) → Objeto con pestañas Scripts / Apariencias / Sonidos.
- **Bloques en español** (Eventos, Control, Movimiento, Sonido, Apariencia, Datos + extras 3D), se ordenan **arrastrando** el asa `=`; tocar el asa da ayuda, duplicar y eliminar.
- **Editor de fórmulas** con teclado de calculadora y listas Funciones / Objeto / Dispositivo / Lógica / Datos.
- Escenas **2D** (menús, juegos planos) y **3D** (niveles en primera persona), que pueden alternarse con "Iniciar escena".
- Exporta a APK (GitHub Actions) y a .exe (el .exe se arma dentro de la app).

## Compilar
Sube a tu repositorio solo `forge.zip` y `.github/workflows/build.yml`; el workflow descomprime y compila (pruebas, runtime de Windows y APK).

## Pruebas locales
`cmake -S tests -B build-tests && cmake --build build-tests && ctest --test-dir build-tests`

## Pendiente
Editor 3D de rejilla estilo FPS Creator, pintor de texturas, listas, lápiz, cámara y sensores en los bloques.

## Novedades (v4)
- Bloques dibujados como piezas conectadas (sombrero, rieles en bucles y "si", espacio entre guiones).
- Bloques nuevos: reproducir sonido y esperar, cambiar vista de cámara, esperar hasta, detener guion, disparar al jugador, quitar vida, velocidad y salto del jugador, reproducir animación, mover al azar.
- Jugador como objeto editable (se mueve en el editor): cámara en primera persona, al hombro o fija (colocable), cuerpo, arma 2D/3D y proyectil (bala, imagen o modelo).
- Enemigo (dispara) y monstruo (cuerpo a cuerpo) con IA: modelo 3D o sprites por acción (quieto, caminar, atacar, daño) y mini animación.
- Colisión de modelos importados con rejilla 64³ fusionada en cajas: casas huecas se pueden recorrer.

## Novedades (v5)
- Tema visual nuevo; importar `.pack` desde la lista de proyectos; escenas reordenables con pulsación larga.
- Miniaturas en todos los selectores de imagen y modelo 3D (los modelos se dibujan con un rasterizador propio en CPU).
- Clones, romper en pedazos, ir/mover hacia un objeto, sacudir pantalla, detener todo.
- Partículas (humo, fuego, chispas, nieve, energía) con color de inicio y fin; ráfagas y bloque encender/apagar.
- Capa de la cámara por escena: imágenes fijas y efectos (VHS, cámara de video, visión nocturna, película vieja) o propios.
- Editor de texturas (lápiz, borrador, cubeta, gotero, espejo, deshacer) que guarda PNG.
- Exportar juego: nombre, paquete, versión, orientación e icono del APK (se compila con GitHub Actions: `game_dir`), opciones de ventana del .exe y paquetes para compilar después.

## Novedades v6
- Eventos nuevos: *Cuando el jugador dispare*, *Cuando se presione el botón X*, *Cuando se mueva (objeto)*, *Cuando el jugador se mueva / salte / reciba daño*.
- Botones en pantalla con acción "Solo bloques": solo lanzan el evento de bloques.
- Objetos bloqueables (botón Libre/Bloq en la ventana Objetos): no se seleccionan ni se mueven tocando la escena.
- El jugador tiene animaciones por estado e imágenes planas (sprites) como los enemigos.
- Diseño de bloques propio (tarjetas oscuras con barra de color).
- Pantalla de inicio blanca con el logo en los juegos exportados (APK y .exe) y fondo con imágenes en el menú de proyectos.
- Editor de fórmulas: Aceptar/Cancelar fijos arriba.

## Novedades v7
- **Editor de animación** (Archivos → Animaciones → Editar): dibujas el esqueleto con círculos y palos sobre el modelo; al mover los huesos la malla 3D se estira (skinning). Poses, clips con línea de tiempo, presets.
- **Importar animaciones** glTF/GLB y FBX (BVH pendiente).
- **Editor de texturas** en pestaña grande.
- **Selectores** de texturas/modelos/archivos en cuadrícula grande con vista previa real.
- **Terreno deformable** (montañas arriba/abajo, aplanar, suavizar) con colisión que sigue la forma.
- Comando **ir al jugador** (2D y 3D), reproducir/detener animación.
- **APK instalable ya compilado** desde la app (se mantiene "Exportar sin compilar").
- Android: pestañas fijas y contenido que se desliza con el dedo.

## Novedades v8
- **Mundo** (ventana Mundo): ambientación (por defecto / amarillento / azulado, suaves), clima (niebla, lluvia, tormenta de arena, nieve, personalizado con cantidad y color) y calidad general (baja/media/alta). Reflejos opcionales por objeto (apagados por defecto).
- **Bloques nuevos**: mientras…, repetir hasta…, fijar objetivo / quitar objetivo (3D), y de video (reproducir, pausar, reanudar, ciclo, N veces, reiniciar, detener).
- **Armas**: de fuego, cuerpo a cuerpo, arrojadiza y granada (opcionales); empezar con ella o recogerla del suelo (objeto con "Da esta arma"); balas por cargador, balas iniciales, disparo infinito, retroceso, recarga (botón RECARGAR / tecla R), cambio de arma (botón ARMA / tecla Q).
- **Giro del modelo** (enemigos y jugador): gira hacia donde camina o siempre al frente; distancia de cámara al hombro; ajuste de posición/giro/tamaño del modelo del jugador.
- **Fórmulas**: las funciones son fichas; solo se editan sus parámetros con la calculadora; el teclado sale solo con "abc"; borrar quita la función completa.
- **Animador**: zoom (+/−/rueda), mover la vista arrastrando, esqueleto humano también para la vista de lado; "Elegir animación" / "Crear animación" donde se eligen modelos de enemigos, monstruos y jugador.
- **Video**: importar (Archivos → Videos), verlo en cualquier objeto. Android: MediaPlayer (sonido) + cuadros por MediaMetadataRetriever. Windows: sin reproductor todavía.
- **Importar modelos pesados** en segundo plano con pantalla de carga y porcentaje.
- **Android**: la música se pausa al salir; botones de volumen funcionan; ventanas fijas (una a la vez) que se deslizan con el dedo.

## v8.1
- **Editor para Windows**: GitHub Actions ahora sube el artefacto `P-Maker-Windows` (pmaker_editor.exe + forge_runtime.exe). Ratón izquierdo = 1 dedo, botón derecho = 2 dedos (mover), rueda = acercar. Los proyectos van a Documentos\P-Maker.
- Importación de archivos grandes en Android: el archivo se copia por partes a un archivo temporal (hasta 1.5 GB) y se muestra "Leyendo el archivo…"; barra de progreso hasta 100% real.
- Textos largos: las etiquetas de casillas, barras, colores y listas ahora bajan de renglón en vez de cortarse.

## v9
- Animaciones nuevas (esqueleto humano): agachado, caminar agachado, correr (normal / pistola / arma larga), apuntar (pistola / arma larga), atacar con espada y cuchillo, golpear, sostener y lanzar, cubrirse, saltar, recibir daño, morir, recargar.
- Vegetación pintada con el dedo (realista, animada, lowpoly, textura propia), color y viento editables.
- Reflejos con menos blanco, niebla con color propio, clima realista (opcional), cantidad hasta 3x, agua/mar, modo RTX (apagado por defecto).
- Cámara fija con 3 modos, arma visible en tercera persona, bloques "no salir de la pantalla" (2D), "fijar objetivo: todas las entidades".
- Botón grande "Cerrar" en las ventanas, botones que bajan de renglón en vez de cortarse, "Invertir lado" en el editor de animación, menos lag al mover huesos.
- Importación: se recoge en cualquier pantalla (ya no se queda en 100%).
