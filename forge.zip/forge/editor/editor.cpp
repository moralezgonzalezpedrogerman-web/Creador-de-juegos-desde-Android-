#include "editor.h"
#include "fsutil.h"
#include "importer.h"
#include "pack.h"

#include "imgui.h"
#include "misc/cpp/imgui_stdlib.h"

#include <algorithm>
#include <cmath>
#include <cstdio>

namespace forge {

// ---------------------------------------------------------------- ayudantes de interfaz
namespace {

std::string lower(std::string s) {
    for (auto& c : s) c = (char)tolower((unsigned char)c);
    return s;
}
bool ends(const std::string& s, const char* e) {
    std::string l = lower(s);
    size_t n = strlen(e);
    return l.size() >= n && l.compare(l.size() - n, n, e) == 0;
}
std::string sanitize(const std::string& in) {
    std::string o;
    for (char c : in) {
        if (isalnum((unsigned char)c) || c == '_' || c == '-') o += c;
        else if (c == ' ') o += '_';
    }
    return o;
}

bool Combo(const char* label, std::string& cur, const std::vector<std::string>& items, const char* none = nullptr) {
    bool ch = false;
    const char* preview = cur.empty() ? (none ? none : "(ninguno)") : cur.c_str();
    if (ImGui::BeginCombo(label, preview)) {
        if (none && ImGui::Selectable(none, cur.empty())) { cur.clear(); ch = true; }
        for (auto& it : items)
            if (ImGui::Selectable(it.c_str(), it == cur)) { cur = it; ch = true; }
        ImGui::EndCombo();
    }
    return ch;
}

// [-] valor [+] : arrastrar o tocar; los botones dan precision sin teclado.
bool Stepper(const char* label, float& v, float step) {
    bool ch = false;
    ImGui::PushID(label);
    float fs = ImGui::GetFontSize();
    ImGui::AlignTextToFramePadding();
    ImGui::TextUnformatted(label);
    ImGui::SameLine(fs * 4.5f);
    if (ImGui::Button("-")) { v -= step; ch = true; }
    ImGui::SameLine();
    ImGui::SetNextItemWidth(fs * 5.f);
    if (ImGui::DragFloat("##v", &v, step * 0.25f, 0, 0, "%.2f")) ch = true;
    ImGui::SameLine();
    if (ImGui::Button("+")) { v += step; ch = true; }
    ImGui::PopID();
    return ch;
}

}  // namespace

// ---------------------------------------------------------------- general
void Editor::init(Audio* audio) {
    audio_ = audio;
    listProjects();
}

void Editor::listProjects() { projList_ = fs::list(host_.dataDir + "/projects", true); }

Obj* Editor::selObj() {
    if (!hasScene() || sel_ < 0 || sel_ >= (int)scene().objs.size()) return nullptr;
    return &scene().objs[sel_];
}

std::string Editor::uniqueName(const std::string& base) {
    Scene& S = scene();
    auto used = [&](const std::string& n) { for (auto& o : S.objs) if (o.name == n) return true; return false; };
    if (!used(base)) return base;
    for (int i = 2;; i++) {
        std::string n = base + "_" + std::to_string(i);
        if (!used(n)) return n;
    }
}

void Editor::resetView() {
    if (!hasScene()) return;
    Scene& S = scene();
    if (S.is3d) { target_ = V3{S.start.x, 0.f, S.start.z}; dist_ = 14.f; yaw_ = 0.6f; pitch_ = 0.55f; }
    else { cx_ = cy_ = 0; h2d_ = kView2DHeight; }
}

void Editor::setScene(int i) {
    if (i < 0 || i >= (int)edit_.proj.scenes.size()) return;
    sceneIdx_ = i;
    sel_ = -1;
    edit_.bindScene(i);
    resetView();
}

std::vector<std::string> Editor::assetsOf(int kind) const {
    std::vector<std::string> v;
    for (auto& a : edit_.proj.assets) {
        bool img = ends(a.first, ".png") || ends(a.first, ".jpg") || ends(a.first, ".jpeg");
        bool snd = Audio::isAudioFile(a.first);
        bool mdl = ends(a.first, ".fmdl");
        if ((kind == 0 && img) || (kind == 1 && snd) || (kind == 2 && mdl)) v.push_back(a.first);
    }
    return v;
}

// ---------------------------------------------------------------- proyectos
bool Editor::newProject(const std::string& nm, bool demo) {
    std::string n = sanitize(nm);
    if (n.empty()) { toast("Escribe un nombre válido (letras, números, _ o -)"); return false; }
    if (fs::exists(host_.dataDir + "/projects/" + n)) { toast("Ya existe un proyecto con ese nombre"); return false; }
    Project p;
    if (demo) {
        loadDemo(p);
    } else {
        Scene s;
        s.name = "Nivel1";
        Obj fl; fl.kind = Kind::Floor; fl.name = "Suelo"; fl.pos = {0, -0.1f, 0}; fl.scale = {40, 0.2f, 40};
        fl.color[0] = 0.45f; fl.color[1] = 0.62f; fl.color[2] = 0.40f;
        Obj lt; lt.kind = Kind::Light; lt.name = "Luz"; lt.pos = {0, 3, 0}; lt.scale = {12, 1, 1}; lt.solid = false;
        lt.color[0] = 1.f; lt.color[1] = 0.8f; lt.color[2] = 0.6f;
        s.objs = {fl, lt};
        s.start = {0, 0.05f, 6};
        p.scenes.push_back(s);
    }
    p.name = n;
    edit_ = Game();
    edit_.proj = std::move(p);
    name_ = n;
    sceneIdx_ = 0;
    sel_ = -1;
    edit_.bindScene(0);
    resetView();
    assetDirty_.clear();
    for (auto& a : edit_.proj.assets) assetDirty_.insert(a.first);
    if (audio_) audio_->setAssets(edit_.proj.assets);
    screen_ = Screen::Edit;
    page_ = Page::Scenes;
    dirty_ = true;
    saveProject();
    listProjects();
    return true;
}

bool Editor::openProject(const std::string& nm) {
    std::string dir = host_.dataDir + "/projects/" + nm;
    Files files;
    std::vector<uint8_t> b;
    if (!fs::read(dir + "/project.forge", b)) { toast("No se pudo abrir el proyecto"); return false; }
    files["project.forge"] = b;
    for (auto& f : fs::list(dir + "/assets", false)) {
        std::vector<uint8_t> d;
        if (fs::read(dir + "/assets/" + f, d)) files[f] = std::move(d);
    }
    Project p;
    std::string err;
    if (!loadProject(files, p, err)) { toast("Proyecto dañado: " + err); return false; }
    edit_ = Game();
    edit_.proj = std::move(p);
    name_ = nm;
    sceneIdx_ = 0;
    sel_ = -1;
    edit_.bindScene(0);
    resetView();
    assetDirty_.clear();
    dirty_ = false;
    if (audio_) audio_->setAssets(edit_.proj.assets);
    screen_ = Screen::Edit;
    page_ = Page::Scenes;
    return true;
}

bool Editor::saveProject() {
    if (name_.empty()) return false;
    std::string dir = host_.dataDir + "/projects/" + name_;
    if (!fs::mkdirs(dir + "/assets")) { toast("No se pudo crear la carpeta del proyecto"); return false; }
    std::string t = writeProject(edit_.proj);
    if (!fs::write(dir + "/project.forge", (const uint8_t*)t.data(), t.size())) { toast("No se pudo guardar"); return false; }
    for (auto& a : edit_.proj.assets) {
        std::string path = dir + "/assets/" + a.first;
        if (assetDirty_.count(a.first) || !fs::exists(path)) fs::write(path, a.second.data(), a.second.size());
    }
    for (auto& f : fs::list(dir + "/assets", false))  // quitar los borrados
        if (!edit_.proj.assets.count(f)) fs::remove(dir + "/assets/" + f);
    assetDirty_.clear();
    dirty_ = false;
    toast("Guardado");
    return true;
}

void Editor::closeProject() {
    if (dirty_) saveProject();
    if (audio_) audio_->stopMusic();
    screen_ = Screen::Projects;
    page_ = Page::Scenes;
    name_.clear();
    listProjects();
}

bool Editor::buildPack(std::vector<uint8_t>& out) {
    Files f = edit_.proj.assets;
    std::string t = writeProject(edit_.proj);
    f["project.forge"] = std::vector<uint8_t>(t.begin(), t.end());
    return packWrite(f, out);
}

bool Editor::buildExe(std::vector<uint8_t>& out, std::string& err) {
    std::vector<uint8_t> rt, pk;
    if (!host_.loadRuntime || !host_.loadRuntime(rt)) {
        err = "Esta app no incluye el runtime de Windows: compílala con GitHub Actions";
        return false;
    }
    buildPack(pk);
    if (!forge::exportExe(rt, pk, out)) { err = "El runtime incluido no es un .exe válido"; return false; }
    return true;
}

void Editor::doExportExe() {
    if (dirty_) saveProject();
    std::vector<uint8_t> out;
    std::string err;
    if (!buildExe(out, err)) { toast(err); return; }
    std::string dir = host_.dataDir + "/export";
    fs::mkdirs(dir);
    std::string path = dir + "/" + name_ + ".exe";
    if (!fs::write(path, out.data(), out.size())) { toast("No se pudo escribir el .exe"); return; }
    if (host_.saveOut) host_.saveOut(name_ + ".exe", path);
    toast("Elige dónde guardar el .exe");
}

void Editor::doExportPack() {
    if (dirty_) saveProject();
    std::vector<uint8_t> out;
    buildPack(out);
    std::string dir = host_.dataDir + "/export";
    fs::mkdirs(dir);
    std::string path = dir + "/" + name_ + ".pack";
    if (!fs::write(path, out.data(), out.size())) { toast("No se pudo escribir el paquete"); return; }
    if (host_.saveOut) host_.saveOut(name_ + ".pack", path);
    toast("Elige dónde guardar el paquete (.pack)");
}

void Editor::onFile(const std::string& rawName, std::vector<uint8_t> data) {
    if (screen_ != Screen::Edit) { toast("Abre un proyecto para importar archivos"); return; }
    std::string name = rawName;
    size_t sl = name.find_last_of("/\\");
    if (sl != std::string::npos) name = name.substr(sl + 1);
    for (auto& c : name) if (c == ' ') c = '_';
    Files& A = edit_.proj.assets;
    if (ends(name, ".png") || ends(name, ".jpg") || ends(name, ".jpeg")) {
        A[name] = std::move(data);
        assetDirty_.insert(name);
        toast("Imagen importada: " + name);
        if (pendingNewObj_ && hasScene()) {
            pendingNewObj_ = false;
            addObject(Kind::Cube);
            if (Obj* n = selObj()) {
                n->tex = name;
                n->color[0] = n->color[1] = n->color[2] = 1.f;
                n->name = uniqueName(name.substr(0, name.find_last_of('.')));
            }
        } else if (page_ == Page::Object && tab_ == 1) {
            if (Obj* n = selObj()) n->looks.push_back(name);
        }
    } else if (Audio::isAudioFile(name)) {
        A[name] = std::move(data);
        assetDirty_.insert(name);
        if (audio_) audio_->setAssets(A);
        toast("Audio importado: " + name);
        if (page_ == Page::Object && tab_ == 2) {
            if (Obj* n = selObj()) n->sounds.push_back(name);
        }
    } else if (isModelFile(name)) {
        std::set<std::string> before;
        for (auto& a : A) before.insert(a.first);
        std::string model, err;
        if (!importModel(name, data, A, model, err)) { toast("No se pudo importar: " + err); return; }
        for (auto& a : A) if (!before.count(a.first)) assetDirty_.insert(a.first);
        toast("Modelo importado: " + model + " (Añadir > Modelo 3D)");
    } else {
        toast("Formato no compatible. Usa png, jpg, mp3, wav, flac, obj, glb, gltf o fbx");
        return;
    }
    markDirty();
}

// ---------------------------------------------------------------- objetos y escenas
void Editor::addObject(Kind k, const std::string& modelName) {
    if (!hasScene()) return;
    Scene& S = scene();
    Obj o;
    o.kind = k;
    float gx = std::round(target_.x), gz = std::round(target_.z);
    V3 at = S.is3d ? V3{gx, 0, gz} : V3{std::round(cx_), std::round(cy_), 0};
    std::string base = "Objeto";
    switch (k) {
        case Kind::Cube:
            base = S.is3d ? "Cubo" : "Objeto";
            o.pos = S.is3d ? V3{at.x, 0.5f, at.z} : V3{at.x, at.y, 0};
            o.scale = S.is3d ? V3{1, 1, 1} : V3{200, 200, 1};
            if (!S.is3d) { o.color[0] = 0.95f; o.color[1] = 0.55f; o.color[2] = 0.15f; o.solid = false; o.yaw = 90; }
            break;
        case Kind::Floor:
            base = "Suelo"; o.pos = {at.x, -0.1f, at.z}; o.scale = {10, 0.2f, 10};
            o.color[0] = 0.45f; o.color[1] = 0.62f; o.color[2] = 0.40f;
            break;
        case Kind::Wall:
            base = "Pared"; o.pos = {at.x, 1.5f, at.z}; o.scale = {4, 3, 0.5f};
            o.color[0] = o.color[1] = 0.8f; o.color[2] = 0.86f;
            break;
        case Kind::Item:
            base = "Item"; o.pos = {at.x, 1.f, at.z}; o.scale = {0.5f, 0.5f, 0.5f}; o.solid = false; o.spin = true;
            o.color[0] = 1.f; o.color[1] = 0.8f; o.color[2] = 0.1f;
            break;
        case Kind::Light:
            base = "Luz"; o.pos = {at.x, 3.f, at.z}; o.scale = {12, 1, 1}; o.solid = false;
            o.color[0] = 1.f; o.color[1] = 0.8f; o.color[2] = 0.6f;
            break;
        case Kind::Model:
            base = "Modelo"; o.pos = {at.x, 1.f, at.z}; o.scale = {2, 2, 2}; o.model = modelName;
            break;
        case Kind::Player: return;
    }
    o.name = uniqueName(base);
    S.objs.push_back(o);
    sel_ = (int)S.objs.size() - 1;
    markDirty();
}

void Editor::addScene(bool is3d) {
    Scene s;
    s.is3d = is3d;
    int n = (int)edit_.proj.scenes.size() + 1;
    auto taken = [&](const std::string& nm) { for (auto& x : edit_.proj.scenes) if (x.name == nm) return true; return false; };
    std::string base = is3d ? "Nivel" : "Menu";
    std::string nm = base + std::to_string(n);
    for (int i = n; taken(nm); i++) nm = base + std::to_string(i + 1);
    s.name = nm;
    if (is3d) {
        Obj fl; fl.kind = Kind::Floor; fl.name = "Suelo"; fl.pos = {0, -0.1f, 0}; fl.scale = {40, 0.2f, 40};
        fl.color[0] = 0.45f; fl.color[1] = 0.62f; fl.color[2] = 0.40f;
        s.objs.push_back(fl);
        s.start = {0, 0.05f, 6};
    } else {
        s.skyTop[0] = 0.10f; s.skyTop[1] = 0.12f; s.skyTop[2] = 0.25f;
        s.skyBot[0] = 0.20f; s.skyBot[1] = 0.25f; s.skyBot[2] = 0.45f;
        Obj bg; bg.name = "Fondo"; bg.bg = true; bg.solid = false; bg.layer = -1000; bg.yaw = 90;
        bg.color[0] = 0.20f; bg.color[1] = 0.25f; bg.color[2] = 0.45f;
        s.objs.push_back(bg);
    }
    edit_.proj.scenes.push_back(s);
    setScene((int)edit_.proj.scenes.size() - 1);
    markDirty();
}

void Editor::startPlay() {
    if (edit_.proj.scenes.empty()) return;
    if (dirty_) saveProject();
    play_.audio = audio_;
    play_.showButtons = true;
    play_.onVibrate = host_.vibrate;
    play_.onSpeak = host_.speak;
    play_.onFlash = host_.flash;
    play_.start(edit_.proj);  // copia: el juego no altera lo que estas editando
    screen_ = Screen::Play;
}

void Editor::stopPlay() {
    if (audio_) { audio_->stopMusic(); audio_->setAssets(edit_.proj.assets); }
    play_.ctl.hud = nullptr;
    play_.ctl.reset();
    screen_ = Screen::Edit;
}

// ---------------------------------------------------------------- camara y seleccion
EditorView Editor::view() const {
    EditorView ev;
    ev.sel = sel_;
    ev.target = target_;
    ev.cx = cx_; ev.cy = cy_; ev.h2d = h2d_;
    V3 dir{std::sin(yaw_) * std::cos(pitch_), std::sin(pitch_), std::cos(yaw_) * std::cos(pitch_)};
    ev.eye = target_ + dir * dist_;
    ev.fwd = norm(target_ - ev.eye);
    return ev;
}

void Editor::rayAt(float x, float y, const EditorView& ev, V3& o, V3& d) const {
    float aspect = h_ > 0 ? (float)w_ / (float)h_ : 1.f;
    float ty = std::tan(1.2217f * 0.5f), tx = ty * aspect;
    float nx = (x / (float)w_) * 2.f - 1.f, ny = 1.f - (y / (float)h_) * 2.f;
    V3 r = norm(cross(ev.fwd, V3{0, 1, 0})), u = cross(r, ev.fwd);
    o = ev.eye;
    d = norm(ev.fwd + r * (nx * tx) + u * (ny * ty));
}

int Editor::pick(float x, float y, const EditorView& ev) {
    if (!hasScene()) return -1;
    Scene& S = scene();
    if (S.is3d) {
        V3 o, d;
        rayAt(x, y, ev, o, d);
        float best = 1e9f;
        int hit = -1;
        for (int i = 0; i < (int)S.objs.size(); i++) {
            const Obj& ob = S.objs[i];
            if (ob.kind == Kind::Player || !ob.visible || !ob.alive) continue;
            V3 half = ob.kind == Kind::Light ? V3{0.25f, 0.25f, 0.25f} : ob.scale * 0.5f;
            float t;
            if (rayBox(o, d, ob.pos, half, t) && t < best) { best = t; hit = i; }
        }
        return hit;
    }
    float aspect = h_ > 0 ? (float)w_ / (float)h_ : 1.f;
    float wx = cx_ + (x / (float)w_ - 0.5f) * h2d_ * aspect, wy = cy_ + (0.5f - y / (float)h_) * h2d_;
    for (int i = (int)S.objs.size() - 1; i >= 0; i--) {
        const Obj& ob = S.objs[i];
        if (!ob.visible) continue;
        if (std::fabs(wx - ob.pos.x) <= ob.scale.x * 0.5f && std::fabs(wy - ob.pos.y) <= ob.scale.y * 0.5f) return i;
    }
    return -1;
}

// Gestos sobre la vista: 1 dedo gira la camara (o arrastra el objeto seleccionado),
// 2 dedos acercan y desplazan, toque corto selecciona.
void Editor::gestures() {
    ImGuiIO& io = ImGui::GetIO();
    auto& P = play_.ctl.p;
    int ids[2], n = 0;
    for (int i = 0; i < 10 && n < 2; i++) if (P[i].down) ids[n++] = i;
    int total = play_.ctl.downCount();

    if (total == 0) {
        if (prevN_ == 1 && gestOk_ && moveAcc_ < 20.f && hasScene()) sel_ = pick(lastX_, lastY_, view());
        prevN_ = 0;
        dragObj_ = false;
        return;
    }
    if (prevN_ == 0) { gestOk_ = !io.WantCaptureMouse; moveAcc_ = 0; dragObj_ = false; }
    if (!gestOk_ || !hasScene()) { prevN_ = n; return; }

    EditorView ev = view();
    Scene& S = scene();
    float aspect = h_ > 0 ? (float)w_ / (float)h_ : 1.f;

    if (n == 1) {
        float x = P[ids[0]].lx, y = P[ids[0]].ly;
        if (prevN_ != 1) {
            lastX_ = x; lastY_ = y;
            Obj* o = selObj();
            if (prevN_ == 0 && o && pick(x, y, ev) == sel_) {  // el dedo empieza sobre el objeto seleccionado
                dragObj_ = true;
                if (S.is3d) {
                    V3 ro, rd;
                    rayAt(x, y, ev, ro, rd);
                    if (std::fabs(rd.y) > 1e-4f) {
                        float t = (o->pos.y - ro.y) / rd.y;
                        V3 hit = ro + rd * t;
                        grab_ = V3{hit.x - o->pos.x, 0, hit.z - o->pos.z};
                    } else grab_ = V3();
                } else {
                    float wx = cx_ + (x / (float)w_ - 0.5f) * h2d_ * aspect, wy = cy_ + (0.5f - y / (float)h_) * h2d_;
                    grab_ = V3{wx - o->pos.x, wy - o->pos.y, 0};
                }
            }
        }
        float dx = x - lastX_, dy = y - lastY_;
        lastX_ = x; lastY_ = y;
        moveAcc_ += std::fabs(dx) + std::fabs(dy);
        float sn = S.is3d ? snap_ : (snap_ > 0.f ? snap_ * 40.f : 0.f);
        auto snapv = [&](float v) { return sn > 0.f ? std::round(v / sn) * sn : v; };
        if (dragObj_) {
            Obj* o = selObj();
            if (o && moveAcc_ > 14.f) {
                if (S.is3d) {
                    V3 ro, rd;
                    rayAt(x, y, ev, ro, rd);
                    if (std::fabs(rd.y) > 1e-4f) {
                        float t = (o->pos.y - ro.y) / rd.y;
                        if (t > 0) {
                            V3 hit = ro + rd * t;
                            o->pos.x = snapv(hit.x - grab_.x);
                            o->pos.z = snapv(hit.z - grab_.z);
                            markDirty();
                        }
                    }
                } else {
                    float wx = cx_ + (x / (float)w_ - 0.5f) * h2d_ * aspect, wy = cy_ + (0.5f - y / (float)h_) * h2d_;
                    o->pos.x = snapv(wx - grab_.x);
                    o->pos.y = snapv(wy - grab_.y);
                    markDirty();
                }
            }
        } else if (S.is3d) {
            yaw_ -= dx * 0.006f;
            pitch_ = std::max(-1.4f, std::min(1.45f, pitch_ + dy * 0.006f));
        } else {
            float k = h2d_ / (float)h_;
            cx_ -= dx * k;
            cy_ += dy * k;
        }
    } else if (n == 2) {
        Ptr &a = P[ids[0]], &b = P[ids[1]];
        float mx = (a.lx + b.lx) * 0.5f, my = (a.ly + b.ly) * 0.5f;
        float dist = std::sqrt((a.lx - b.lx) * (a.lx - b.lx) + (a.ly - b.ly) * (a.ly - b.ly));
        if (prevN_ != 2) {
            lastX_ = mx; lastY_ = my; lastDist_ = dist;
            moveAcc_ = 1000.f;  // ya no es un toque
        } else {
            if (lastDist_ > 1.f && dist > 1.f) {
                float k = lastDist_ / dist;
                if (S.is3d) dist_ = std::max(2.f, std::min(120.f, dist_ * k));
                else h2d_ = std::max(100.f, std::min(6000.f, h2d_ * k));
            }
            float dx = mx - lastX_, dy = my - lastY_;
            if (S.is3d) {
                V3 r = norm(cross(ev.fwd, V3{0, 1, 0})), u = cross(r, ev.fwd);
                target_ = target_ - r * (dx * dist_ * 0.0016f) + u * (dy * dist_ * 0.0016f);
            } else {
                float k = h2d_ / (float)h_;
                cx_ -= dx * k;
                cy_ += dy * k;
            }
            lastX_ = mx; lastY_ = my; lastDist_ = dist;
        }
    }
    prevN_ = n;
}

// ---------------------------------------------------------------- frame
void Editor::frame(Renderer* r, int w, int h, float dt) {
    w_ = w; h_ = h;
    play_.ctl.w = w;
    play_.ctl.h = h;
    if (toastT_ > 0) toastT_ -= dt;
    switch (screen_) {
        case Screen::Projects: projectsUI(r); break;
        case Screen::Edit: editFrame(r, dt); break;
        case Screen::Play: playFrame(r, dt); break;
    }
    toastUI();
}

void Editor::toastUI() {
    if (toastT_ <= 0 || toast_.empty()) return;
    float fs = ImGui::GetFontSize();
    ImGui::SetNextWindowPos(ImVec2(w_ * 0.5f, h_ - fs * 2.f), ImGuiCond_Always, ImVec2(0.5f, 1.f));
    ImGui::SetNextWindowBgAlpha(0.85f);
    ImGui::Begin("##toast", nullptr,
                 ImGuiWindowFlags_NoDecoration | ImGuiWindowFlags_NoInputs | ImGuiWindowFlags_AlwaysAutoResize |
                     ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoNav | ImGuiWindowFlags_NoFocusOnAppearing);
    ImGui::TextUnformatted(toast_.c_str());
    ImGui::End();
}

void Editor::projectsUI(Renderer* r) {
    if (r) r->clear(w_, h_, 0.08f, 0.09f, 0.13f);
    float fs = ImGui::GetFontSize();
    ImGui::SetNextWindowPos(ImVec2(0, 0));
    ImGui::SetNextWindowSize(ImVec2((float)w_, (float)h_));
    ImGui::Begin("Proyectos", nullptr,
                 ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoResize |
                     ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoBringToFrontOnFocus);
    ImGui::SetWindowFontScale(1.3f);
    ImGui::TextUnformatted("Forge - tus juegos");
    ImGui::SetWindowFontScale(1.f);
    ImGui::TextDisabled("Crea escenas 3D como FPS Creator y programa con bloques como Pocket Code.");
    ImGui::Separator();
    if (projList_.empty()) ImGui::TextDisabled("Todavía no tienes proyectos. Crea uno abajo.");
    std::string del;
    for (auto& n : projList_) {
        ImGui::PushID(n.c_str());
        if (ImGui::Button(n.c_str(), ImVec2(fs * 14, 0))) { std::string copy = n; ImGui::PopID(); openProject(copy); return ImGui::End(); }
        ImGui::SameLine();
        if (ImGui::Button("Borrar")) ImGui::OpenPopup("del");
        if (ImGui::BeginPopup("del")) {
            ImGui::Text("¿Borrar \"%s\" para siempre?", n.c_str());
            if (ImGui::Button("Sí, borrar")) { del = n; ImGui::CloseCurrentPopup(); }
            ImGui::SameLine();
            if (ImGui::Button("Cancelar")) ImGui::CloseCurrentPopup();
            ImGui::EndPopup();
        }
        ImGui::PopID();
    }
    if (!del.empty()) { fs::removeTree(host_.dataDir + "/projects/" + del); listProjects(); }
    ImGui::Separator();
    ImGui::SetNextItemWidth(fs * 14);
    ImGui::InputText("Nombre del proyecto", &newName_);
    if (ImGui::Button("Nuevo vacío")) newProject(newName_, false);
    ImGui::SameLine();
    if (ImGui::Button("Nuevo con la demo")) newProject(newName_, true);
    ImGui::End();
}

void Editor::playFrame(Renderer* r, float dt) {
    play_.frame(r, w_, h_, dt);
    ImGui::SetNextWindowPos(ImVec2(10, 10));
    ImGui::SetNextWindowBgAlpha(0.5f);
    ImGui::Begin("##play", nullptr,
                 ImGuiWindowFlags_NoDecoration | ImGuiWindowFlags_AlwaysAutoResize | ImGuiWindowFlags_NoMove |
                     ImGuiWindowFlags_NoSavedSettings);
    if (ImGui::Button("Detener")) stopPlay();
    ImGui::End();
}

void Editor::editFrame(Renderer* r, float dt) {
    if (!hasScene() && !edit_.proj.scenes.empty()) setScene(0);
    play_.ctl.hud = nullptr;
    edit_.time += dt;
    if (ImGui::IsMouseClicked(0)) dragAcc_ = 0;
    if (ImGui::IsMouseDown(0)) dragAcc_ += std::fabs(ImGui::GetIO().MouseDelta.x) + std::fabs(ImGui::GetIO().MouseDelta.y);
    if (page_ == Page::Scenes) { pageScenes(r); return; }
    if (page_ == Page::SceneHome) { pageSceneHome(r); return; }
    if (page_ == Page::Object) { pageObject(r); return; }
    menuBar();
    if (screen_ != Screen::Edit) return;  // el menu pudo cerrar el proyecto o iniciar el juego
    gestures();
    if (r && hasScene()) {
        EditorView ev = view();
        r->render(edit_, w_, h_, &ev);
    }
    if (showHud && hasScene()) {
        Hud preview;
        preview.setup(edit_.proj);
        preview.draw(ImGui::GetBackgroundDrawList(), edit_, r, w_, h_, true);
    }
    objectsWin();
    propsWin();
    worldWin();
    hudWin(r);
    assetsWin();

    if (!selObj()) {
        float fs = ImGui::GetFontSize();
        ImGui::GetBackgroundDrawList()->AddText(ImVec2(fs * 0.6f, h_ - fs * 1.6f), IM_COL32(255, 255, 255, 160),
                                                "Arrastra para girar - dos dedos: zoom y mover - toca un objeto para seleccionarlo");
    }
}

// ---------------------------------------------------------------- menu
void Editor::menuBar() {
    if (!ImGui::BeginMainMenuBar()) return;
    bool doPlay = false, doClose = false;
    if (ImGui::MenuItem("< Escena")) { page_ = Page::SceneHome; ImGui::EndMainMenuBar(); return; }
    if (ImGui::BeginMenu("Proyecto")) {
        if (ImGui::MenuItem("Guardar")) saveProject();
        if (ImGui::MenuItem("Exportar como .exe (Windows)")) doExportExe();
        if (ImGui::MenuItem("Exportar paquete (.pack)")) doExportPack();
        ImGui::Separator();
        if (ImGui::MenuItem("Cerrar proyecto")) doClose = true;
        ImGui::EndMenu();
    }
    if (hasScene() && ImGui::BeginMenu(("Escena: " + scene().name).c_str())) {
        for (int i = 0; i < (int)edit_.proj.scenes.size(); i++) {
            auto& s = edit_.proj.scenes[i];
            if (ImGui::MenuItem((s.name + (s.is3d ? "  (3D)" : "  (2D)")).c_str(), nullptr, i == sceneIdx_)) { setScene(i); break; }
        }
        ImGui::Separator();
        if (ImGui::MenuItem("Nueva escena 3D")) addScene(true);
        if (ImGui::MenuItem("Nueva escena 2D")) addScene(false);
        ImGui::EndMenu();
    }
    if (ImGui::BeginMenu("Añadir")) {
        bool is3d = hasScene() && scene().is3d;
        if (ImGui::MenuItem(is3d ? "Cubo" : "Cuadro / botón")) addObject(Kind::Cube);
        if (is3d) {
            if (ImGui::MenuItem("Suelo")) addObject(Kind::Floor);
            if (ImGui::MenuItem("Pared")) addObject(Kind::Wall);
            if (ImGui::MenuItem("Item")) addObject(Kind::Item);
            if (ImGui::MenuItem("Luz")) addObject(Kind::Light);
            if (ImGui::BeginMenu("Modelo 3D")) {
                auto models = assetsOf(2);
                if (models.empty()) ImGui::TextDisabled("Importa uno en Archivos");
                for (auto& m : models) if (ImGui::MenuItem(m.c_str())) addObject(Kind::Model, m);
                ImGui::EndMenu();
            }
        }
        ImGui::EndMenu();
    }
    if (ImGui::BeginMenu("Ventanas")) {
        ImGui::MenuItem("Objetos", nullptr, &showObjs);
        ImGui::MenuItem("Propiedades", nullptr, &showProps);
            ImGui::MenuItem("Mundo (cielo y luz)", nullptr, &showWorld);
        ImGui::MenuItem("Botones y arma", nullptr, &showHud);
        ImGui::MenuItem("Archivos", nullptr, &showAssets);
        ImGui::EndMenu();
    }
    if (ImGui::MenuItem("JUGAR")) doPlay = true;
    if (dirty_) { ImGui::TextDisabled(" (sin guardar)"); }
    ImGui::EndMainMenuBar();
    if (doClose) closeProject();
    else if (doPlay) startPlay();
}

// ---------------------------------------------------------------- ventanas
static void placeWindow(float x, float y, float w, float h) {
    ImGui::SetNextWindowPos(ImVec2(x, y), ImGuiCond_FirstUseEver);
    ImGui::SetNextWindowSize(ImVec2(w, h), ImGuiCond_FirstUseEver);
}

void Editor::objectsWin() {
    if (!showObjs || !hasScene()) return;
    float fs = ImGui::GetFontSize(), top = ImGui::GetFrameHeight() + 6.f;
    placeWindow(6, top, fs * 14.f, h_ * 0.5f);
    if (ImGui::Begin("Objetos", &showObjs)) {
        Scene& S = scene();
        for (int i = 0; i < (int)S.objs.size(); i++) {
            const Obj& o = S.objs[i];
            static const char tags[] = {'C', 'S', 'P', 'I', 'M', 'L', 'J'};
            std::string lab = std::string("[") + tags[(int)o.kind] + "] " + o.name + (o.visible ? "" : " (oculto)");
            ImGui::PushID(i);
            if (ImGui::Selectable(lab.c_str(), sel_ == i)) sel_ = i;
            ImGui::PopID();
        }
        if (S.objs.empty()) ImGui::TextDisabled("Escena vacía. Usa el menú Añadir.");
        ImGui::Separator();
        ImGui::SetNextItemWidth(fs * 5.f);
        ImGui::DragFloat("Rejilla", &snap_, 0.05f, 0.f, 2.f, "%.2f");
    }
    ImGui::End();
}

void Editor::propsWin() {
    if (!showProps || !hasScene()) return;
    float fs = ImGui::GetFontSize(), top = ImGui::GetFrameHeight() + 6.f;
    placeWindow(w_ - fs * 21.f - 6.f, top, fs * 21.f, h_ * 0.75f);
    if (ImGui::Begin("Propiedades", &showProps)) {
        Scene& S = scene();
        Obj* o = selObj();
        if (!o) {
            ImGui::TextDisabled("Toca un objeto en la escena o en la lista.");
        } else {
            bool ch = false;
            ch |= ImGui::InputText("Nombre", &o->name);
            const char* kinds[] = {"Cubo", "Suelo", "Pared", "Item", "Modelo", "Luz", "Jugador"};
            ImGui::Text("Tipo: %s", kinds[(int)o->kind]);
            ImGui::SeparatorText("Posición");
            float st = S.is3d ? 0.5f : 10.f;
            ch |= Stepper("X", o->pos.x, st);
            ch |= Stepper("Y", o->pos.y, st);
            if (S.is3d) ch |= Stepper("Z", o->pos.z, 0.5f);
            if (o->kind == Kind::Light) {
                ImGui::SeparatorText("Luz");
                ch |= Stepper("Alcance", o->scale.x, 1.f);
                ch |= ImGui::ColorEdit3("Color de luz", o->color);
            } else {
                ImGui::SeparatorText("Tamaño y giro");
                ch |= Stepper("Ancho", o->scale.x, st);
                ch |= Stepper("Alto", o->scale.y, st);
                if (S.is3d) ch |= Stepper("Fondo", o->scale.z, 0.5f);
                ch |= Stepper(S.is3d ? "Giro" : "Dirección", o->yaw, 15.f);
                ImGui::SeparatorText("Apariencia");
                ch |= ImGui::ColorEdit3("Color", o->color);
                ch |= Combo("Textura", o->tex, assetsOf(0), "(sin textura)");
                if (o->kind == Kind::Model) ch |= Combo("Modelo", o->model, assetsOf(2), "(cubo)");
                ch |= ImGui::Checkbox("Sólido (se puede chocar)", &o->solid);
                ch |= ImGui::Checkbox("Visible al empezar", &o->visible);
                ch |= ImGui::Checkbox("Gira sobre sí mismo", &o->spin);
            }
            if (ch) markDirty();
            ImGui::Separator();
            if (ImGui::Button("Programar (bloques)")) { page_ = Page::Object; tab_ = 0; }
            ImGui::SameLine();
            if (ImGui::Button("Duplicar")) {
                Obj c = *o;
                c.name = uniqueName(o->name);
                c.pos.x += 1.f;
                S.objs.push_back(c);
                sel_ = (int)S.objs.size() - 1;
                markDirty();
                o = nullptr;
            }
            if (o) {
                ImGui::SameLine();
                if (ImGui::Button("Eliminar")) {
                    S.objs.erase(S.objs.begin() + sel_);
                    sel_ = -1;
                    markDirty();
                    o = nullptr;
                }
            }
            if (o && !S.is3d) {  // en 2D el orden de la lista es el orden de capas
                if (ImGui::Button("Subir capa") && sel_ + 1 < (int)S.objs.size()) { std::swap(S.objs[sel_], S.objs[sel_ + 1]); sel_++; markDirty(); }
                ImGui::SameLine();
                if (ImGui::Button("Bajar capa") && sel_ > 0) { std::swap(S.objs[sel_], S.objs[sel_ - 1]); sel_--; markDirty(); }
            }
        }
    }
    ImGui::End();
}

void Editor::worldWin() {
    if (!showWorld || !hasScene()) return;
    float fs = ImGui::GetFontSize(), top = ImGui::GetFrameHeight() + 6.f;
    placeWindow(w_ - fs * 22.f - 6.f, top, fs * 22.f, h_ * 0.8f);
    if (ImGui::Begin("Mundo", &showWorld)) {
        Scene& S = scene();
        bool ch = false;
        ch |= ImGui::InputText("Nombre de la escena", &S.name);
        bool was3d = S.is3d;
        if (ImGui::Checkbox("Escena 3D (si no, es 2D)", &S.is3d)) { ch = true; if (was3d != S.is3d) resetView(); }
        if (S.is3d) {
            ImGui::SeparatorText("Cielo");
            ch |= ImGui::ColorEdit3("Arriba", S.skyTop);
            ch |= ImGui::ColorEdit3("Horizonte y niebla", S.skyBot);
            ImGui::SeparatorText("Sol y luz");
            V3 d = norm(S.sunDir);
            float el = std::asin(std::max(-1.f, std::min(1.f, -d.y))), az = std::atan2(-d.x, -d.z);
            bool sc = false;
            sc |= ImGui::SliderAngle("Altura del sol", &el, 5.f, 89.f);
            sc |= ImGui::SliderAngle("Dirección", &az, -180.f, 180.f);
            if (sc) {
                S.sunDir = V3{-std::cos(el) * std::sin(az), -std::sin(el), -std::cos(el) * std::cos(az)};
                ch = true;
            }
            ch |= ImGui::ColorEdit3("Color del sol", S.sun);
            ch |= ImGui::SliderFloat("Luz ambiente", &S.ambient, 0.f, 1.f);
            ch |= ImGui::SliderFloat("Niebla", &S.fog, 0.f, 0.08f, "%.3f");
            ImGui::SeparatorText("Jugador");
            ch |= ImGui::DragFloat3("Inicio x y z", &S.start.x, 0.1f);
            if (ImGui::Button("Inicio = centro de la vista")) { S.start = V3{target_.x, 0.05f, target_.z}; ch = true; }
        } else {
            ch |= ImGui::ColorEdit3("Fondo", S.skyBot);
        }
        ImGui::Separator();
        if (edit_.proj.scenes.size() > 1 && ImGui::Button("Borrar esta escena")) ImGui::OpenPopup("delscene");
        if (ImGui::BeginPopup("delscene")) {
            ImGui::TextUnformatted("¿Borrar la escena y todos sus objetos?");
            if (ImGui::Button("Sí, borrar")) {
                edit_.proj.scenes.erase(edit_.proj.scenes.begin() + sceneIdx_);
                setScene(std::min(sceneIdx_, (int)edit_.proj.scenes.size() - 1));
                ch = true;
                ImGui::CloseCurrentPopup();
            }
            ImGui::SameLine();
            if (ImGui::Button("Cancelar")) ImGui::CloseCurrentPopup();
            ImGui::EndPopup();
        }
        if (ch) markDirty();
    }
    ImGui::End();
}

void Editor::hudWin(Renderer*) {
    if (!showHud) return;
    Project& P = edit_.proj;
    float fs = ImGui::GetFontSize(), top = ImGui::GetFrameHeight() + 6.f;
    placeWindow(w_ - fs * 23.f - 6.f, top, fs * 23.f, h_ * 0.85f);
    if (ImGui::Begin("Botones y arma", &showHud)) {
        bool ch = false;
        ImGui::SeparatorText("Botones en pantalla (escenas 3D)");
        int mode = P.hudDefault ? 0 : (P.hud.empty() ? 2 : 1);
        int nm = mode;
        ImGui::RadioButton("Por defecto: saltar y disparar", &nm, 0);
        ImGui::RadioButton("Personalizados", &nm, 1);
        ImGui::RadioButton("Ninguno (en blanco)", &nm, 2);
        if (nm != mode) {
            if (nm == 0) P.hudDefault = true;
            else if (nm == 1) { P.hudDefault = false; if (P.hud.empty()) P.hud = defaultHud(); }
            else { P.hudDefault = false; P.hud.clear(); }
            ch = true;
        }
        if (!P.hudDefault && !P.hud.empty()) {
            int del = -1;
            for (int i = 0; i < (int)P.hud.size(); i++) {
                HudBtn& b = P.hud[i];
                ImGui::PushID(i);
                if (ImGui::TreeNodeEx(b.label.c_str(), ImGuiTreeNodeFlags_DefaultOpen)) {
                    ch |= ImGui::InputText("Texto", &b.label);
                    int a = (int)b.act;
                    if (ImGui::Combo("Acción", &a, "Nada\0Saltar\0Disparar\0Interactuar\0")) { b.act = (HudAct)a; ch = true; }
                    ch |= ImGui::SliderFloat("Posición X", &b.x, 0.f, 1.f);
                    ch |= ImGui::SliderFloat("Posición Y", &b.y, 0.f, 1.f);
                    ch |= ImGui::SliderFloat("Tamaño", &b.r, 0.03f, 0.25f);
                    ch |= ImGui::ColorEdit3("Color", b.color);
                    if (ImGui::Button("Quitar botón")) del = i;
                    ImGui::TreePop();
                }
                ImGui::PopID();
            }
            if (del >= 0) { P.hud.erase(P.hud.begin() + del); ch = true; }
        }
        if (!P.hudDefault) {
            if (ImGui::Button("+ Añadir botón")) {
                HudBtn b;
                b.label = "Botón";
                b.act = HudAct::Interact;
                P.hud.push_back(b);
                ch = true;
            }
            ImGui::SameLine();
            if (ImGui::Button("Copiar los de por defecto")) { P.hud = defaultHud(); ch = true; }
        }
        ImGui::SeparatorText("Arma en primera persona");
        ch |= ImGui::Checkbox("Arma activada (se puede disparar)", &P.weapon.enabled);
        ch |= Combo("Sprite", P.weapon.tex, assetsOf(0), "(arma básica)");
        ch |= ImGui::SliderFloat("Tamaño", &P.weapon.scale, 0.1f, 1.2f);
        ch |= ImGui::SliderFloat("Mover X", &P.weapon.ox, -0.5f, 0.5f);
        ch |= ImGui::SliderFloat("Mover Y", &P.weapon.oy, -0.3f, 0.5f);
        ch |= ImGui::SliderFloat("Segundos entre disparos", &P.weapon.rate, 0.05f, 2.f);
        ch |= ImGui::SliderFloat("Alcance", &P.weapon.range, 5.f, 200.f);
        ImGui::SeparatorText("Pantalla");
        ch |= ImGui::Checkbox("Mostrar variables (contadores)", &P.showVars);
        ImGui::TextDisabled("La vista previa se ve sobre la escena 3D. Los disparos activan el evento \"Al recibir un disparo\".");
        if (ch) markDirty();
    }
    ImGui::End();
}

void Editor::assetsWin() {
    if (!showAssets) return;
    float fs = ImGui::GetFontSize(), top = ImGui::GetFrameHeight() + 6.f;
    placeWindow(6, top, fs * 22.f, h_ * 0.7f);
    if (ImGui::Begin("Archivos", &showAssets)) {
        if (ImGui::Button("Importar archivo...")) { if (host_.pickFile) host_.pickFile(); }
        ImGui::TextDisabled("Imágenes png/jpg, audio mp3/wav/flac, modelos obj/glb/gltf/fbx.");
        ImGui::TextDisabled("Para el disparo usa un archivo llamado \"disparo\" (p. ej. disparo.wav).");
        ImGui::Separator();
        size_t total = 0;
        std::string del;
        for (auto& a : edit_.proj.assets) {
            total += a.second.size();
            ImGui::PushID(a.first.c_str());
            ImGui::Text("%s  (%.0f KB)", a.first.c_str(), a.second.size() / 1024.0);
            if (Audio::isAudioFile(a.first) && audio_) {
                ImGui::SameLine();
                if (ImGui::SmallButton("Probar")) audio_->play(a.first);
            }
            ImGui::SameLine();
            if (ImGui::SmallButton("Borrar")) del = a.first;
            ImGui::PopID();
        }
        if (edit_.proj.assets.empty()) ImGui::TextDisabled("Sin archivos todavía.");
        ImGui::Separator();
        ImGui::Text("Total: %.1f MB", total / (1024.0 * 1024.0));
        if (!del.empty()) {
            edit_.proj.assets.erase(del);
            if (audio_) audio_->setAssets(edit_.proj.assets);
            markDirty();
        }
    }
    ImGui::End();
}

}  // namespace forge
