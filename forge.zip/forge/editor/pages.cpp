// Paginas del editor (como Pocket Code): Proyecto -> Escenas -> Escena -> Objeto (Scripts / Apariencias / Sonidos),
// editor de bloques con arrastrar y soltar, paleta de bloques por categorias y editor de formulas.
#include "editor.h"
#include "formula.h"
#include "fsutil.h"

#include "imgui.h"
#include "misc/cpp/imgui_stdlib.h"

#include <algorithm>
#include <cmath>
#include <cstdio>

namespace forge {

namespace {

ImVec4 catRGB(Cat c, float k = 1.f) {
    float r = .5f, g = .5f, b = .5f;
    switch (c) {
        case Cat::Eventos: r = .82f; g = .35f; b = .10f; break;
        case Cat::Control: r = .97f; g = .62f; b = .35f; break;
        case Cat::Movimiento: r = .29f; g = .51f; b = .78f; break;
        case Cat::Sonido: r = .45f; g = .30f; b = .65f; break;
        case Cat::Apariencia: r = .36f; g = .62f; b = .28f; break;
        case Cat::Datos: r = .93f; g = .25f; b = .31f; break;
        case Cat::Forge3D: r = .15f; g = .60f; b = .62f; break;
    }
    return ImVec4(r * k, g * k, b * k, 1.f);
}
ImU32 col32(const ImVec4& v) { return ImGui::ColorConvertFloat4ToU32(v); }

std::string shorten(const std::string& s, size_t n = 22) {
    if (s.size() <= n) return s;
    size_t k = n;
    while (k > 0 && ((unsigned char)s[k] & 0xC0) == 0x80) k--;  // no cortar un caracter UTF-8
    return s.substr(0, k) + "..";
}

struct Tok { int type; std::string s; };  // 0 palabra, 1 formula (s = "0".."2"), 2 texto {t}
std::vector<Tok> tokenize(const char* title) {
    std::vector<Tok> v;
    std::string w;
    auto flush = [&]() { if (!w.empty()) { v.push_back({0, w}); w.clear(); } };
    for (const char* p = title; *p; p++) {
        if (*p == ' ') { flush(); continue; }
        if (*p == '{') {
            flush();
            std::string k;
            p++;
            while (*p && *p != '}') k += *p++;
            if (k == "t") v.push_back({2, ""});
            else v.push_back({1, k});
            if (!*p) break;
            continue;
        }
        w += *p;
    }
    flush();
    return v;
}

std::string plainTitle(const OpInfo& in) {
    std::string out;
    for (auto& t : tokenize(in.title)) {
        if (!out.empty()) out += ' ';
        if (t.type == 0) out += t.s;
        else if (t.type == 2) out += in.t && *in.t ? in.t : "...";
        else {
            const char* f = t.s == "0" ? in.f0 : t.s == "1" ? in.f1 : in.f2;
            out += f && *f ? f : "0";
        }
    }
    return out;
}

struct PreviewEnv : FormulaEnv {
    bool lookup(const std::string&, const std::vector<Val>&, Val&) override { return false; }
};

bool gHandle = false;  // un asa de bloque esta pulsada (no desplazar la lista)

}  // namespace

// ---------------------------------------------------------------- bloques (logica)
bool Editor::blockRange(const std::vector<Block>& B, int i, int& end) {
    if (i < 0 || i >= (int)B.size()) return false;
    int k = opInfo(B[i].op).indent;
    if (k == 2) {
        end = i + 1;
        while (end < (int)B.size() && opInfo(B[end].op).indent != 2) end++;
        return true;
    }
    if (k == 1) {
        int d = 0;
        for (int j = i; j < (int)B.size(); j++) {
            int q = opInfo(B[j].op).indent;
            if (q == 1) d++;
            else if (q == -1 && --d == 0) { end = j + 1; return true; }
        }
        end = (int)B.size();
        return true;
    }
    if (k == 0) { end = i + 1; return true; }
    return false;  // cierres y "de lo contrario" no se mueven solos
}

bool Editor::moveRange(std::vector<Block>& B, int from, int to) {
    int e;
    if (!blockRange(B, from, e)) return false;
    if (to < 0 || to > (int)B.size() || (to >= from && to <= e)) return false;
    std::vector<Block> g(B.begin() + from, B.begin() + e);
    B.erase(B.begin() + from, B.begin() + e);
    int t = to > from ? to - (e - from) : to;
    B.insert(B.begin() + t, g.begin(), g.end());
    return true;
}

int Editor::addBlock(Obj& o, Op op) {
    auto make = [](Op x) {
        const OpInfo& in = opInfo(x);
        Block b;
        b.op = x;
        b.t = in.t ? in.t : "";
        b.f[0] = in.f0 ? in.f0 : "";
        b.f[1] = in.f1 ? in.f1 : "";
        b.f[2] = in.f2 ? in.f2 : "";
        return b;
    };
    if (o.blocks.empty() && !isHat(op)) o.blocks.push_back(make(Op::WhenStart));
    int idx = (int)o.blocks.size();
    o.blocks.push_back(make(op));
    if (op == Op::If) {
        o.blocks.push_back(make(Op::Else));
        o.blocks.push_back(make(Op::EndIf));
    } else if (op == Op::Repeat || op == Op::Forever) {
        o.blocks.push_back(make(Op::LoopEnd));
    }
    markDirty();
    return idx;
}

// ---------------------------------------------------------------- ayudantes de pagina
bool Editor::tapped() const { return dragAcc_ < 12.f; }

void Editor::dragScroll() {
    bool skip = gHandle;
    gHandle = false;
    float fs = ImGui::GetFontSize();
    if (ImGui::GetDragDropPayload()) {  // al arrastrar un bloque, desplazar cerca de los bordes
        ImVec2 m = ImGui::GetIO().MousePos, p = ImGui::GetWindowPos(), s = ImGui::GetWindowSize();
        if (m.x >= p.x && m.x <= p.x + s.x) {
            if (m.y < p.y + fs * 2.5f) ImGui::SetScrollY(ImGui::GetScrollY() - fs * 0.6f);
            else if (m.y > p.y + s.y - fs * 2.5f) ImGui::SetScrollY(ImGui::GetScrollY() + fs * 0.6f);
        }
        return;
    }
    if (skip || !ImGui::IsWindowHovered()) return;
    if (ImGui::IsMouseDragging(0, 12.f)) ImGui::SetScrollY(ImGui::GetScrollY() - ImGui::GetIO().MouseDelta.y);
}

bool Editor::beginPage(const char* id) {
    ImGui::SetNextWindowPos(ImVec2(0, 0));
    ImGui::SetNextWindowSize(ImVec2((float)w_, (float)h_));
    ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(0, 0));
    ImGui::PushStyleVar(ImGuiStyleVar_WindowBorderSize, 0.f);
    bool ok = ImGui::Begin(id, nullptr,
                           ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoResize |
                               ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoBringToFrontOnFocus |
                               ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NoScrollWithMouse |
                               ImGuiWindowFlags_NoSavedSettings);
    ImGui::PopStyleVar(2);
    return ok;
}

void Editor::endPage() { ImGui::End(); }

bool Editor::topBar(const std::string& title, bool* back, bool* menu) {
    float fs = ImGui::GetFontSize();
    ImVec2 p = ImGui::GetCursorScreenPos();
    float bh = fs * 2.8f;
    ImGui::GetWindowDrawList()->AddRectFilled(p, ImVec2(p.x + w_, p.y + bh), IM_COL32(34, 44, 68, 255));
    if (back) *back = false;
    if (menu) *menu = false;
    ImGui::SetCursorScreenPos(ImVec2(p.x + fs * 0.4f, p.y + fs * 0.4f));
    if (back) {
        if (ImGui::Button("<", ImVec2(fs * 2.f, fs * 2.f))) *back = true;
        ImGui::SameLine();
    }
    ImGui::SetCursorScreenPos(ImVec2(ImGui::GetCursorScreenPos().x + fs * 0.3f, p.y + fs * 0.4f + (fs * 2.f - fs) * 0.5f));
    ImGui::TextUnformatted(shorten(title, 28).c_str());
    if (menu) {
        ImGui::SetCursorScreenPos(ImVec2(p.x + w_ - fs * 2.6f, p.y + fs * 0.4f));
        if (ImGui::Button("...", ImVec2(fs * 2.2f, fs * 2.f))) *menu = true;
    }
    ImGui::SetCursorScreenPos(ImVec2(p.x, p.y + bh + fs * 0.2f));
    return true;
}

void Editor::fab(bool* play, bool* plus) {
    float fs = ImGui::GetFontSize();
    if (play) *play = false;
    if (plus) *plus = false;
    ImGui::SetNextWindowPos(ImVec2((float)w_ - fs * 0.8f, (float)h_ - fs * 0.8f), ImGuiCond_Always, ImVec2(1.f, 1.f));
    ImGui::SetNextWindowBgAlpha(0.f);
    ImGui::Begin("##fab", nullptr,
                 ImGuiWindowFlags_NoDecoration | ImGuiWindowFlags_AlwaysAutoResize | ImGuiWindowFlags_NoMove |
                     ImGuiWindowFlags_NoSavedSettings | ImGuiWindowFlags_NoNav | ImGuiWindowFlags_NoBackground);
    if (play) {
        ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(0.20f, 0.60f, 0.30f, 1.f));
        if (ImGui::Button("Jugar", ImVec2(fs * 4.5f, fs * 3.f))) *play = true;
        ImGui::PopStyleColor();
        if (plus) ImGui::SameLine();
    }
    if (plus) {
        ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(0.20f, 0.45f, 0.85f, 1.f));
        if (ImGui::Button("+", ImVec2(fs * 3.f, fs * 3.f))) *plus = true;
        ImGui::PopStyleColor();
    }
    ImGui::End();
}

void Editor::thumb(Renderer* r, const Obj& o, float size) {
    ImVec2 p = ImGui::GetCursorScreenPos();
    ImGui::Dummy(ImVec2(size, size));
    ImDrawList* dl = ImGui::GetWindowDrawList();
    ImU32 c = IM_COL32((int)(o.color[0] * 255), (int)(o.color[1] * 255), (int)(o.color[2] * 255), 255);
    dl->AddRectFilled(p, ImVec2(p.x + size, p.y + size), o.bg || o.kind != Kind::Light ? c : IM_COL32(255, 220, 120, 255), 6.f);
    std::string name = !o.tex.empty() ? o.tex : (!o.looks.empty() ? o.looks[0] : "");
    if (r && !name.empty()) {
        int tw = 1, th = 1;
        unsigned tid = r->textureId(edit_, name, &tw, &th);
        if (tid) {
            float k = std::min(size / tw, size / th);
            float iw = tw * k, ih = th * k;
            ImVec2 a(p.x + (size - iw) * 0.5f, p.y + (size - ih) * 0.5f);
            dl->AddImage((ImTextureID)(intptr_t)tid, a, ImVec2(a.x + iw, a.y + ih));
        }
    }
}

std::vector<std::string> Editor::varNames(const Obj& o) const {
    std::vector<std::string> v = edit_.proj.globalVars;
    for (auto& s : o.localVars) v.push_back(s);
    return v;
}

std::vector<std::string> Editor::messageNames() const {
    std::vector<std::string> v;
    for (auto& s : edit_.proj.scenes)
        for (auto& o : s.objs)
            for (auto& b : o.blocks)
                if ((b.op == Op::WhenReceive || b.op == Op::Broadcast || b.op == Op::BroadcastWait) && !b.t.empty() &&
                    std::find(v.begin(), v.end(), b.t) == v.end())
                    v.push_back(b.t);
    if (v.empty()) v.push_back("mensaje1");
    std::sort(v.begin(), v.end());
    return v;
}

void Editor::renameUI() {
    if (renameWhat_ > 0 && !ImGui::IsPopupOpen("Renombrar")) ImGui::OpenPopup("Renombrar");
    float fs = ImGui::GetFontSize();
    ImGui::SetNextWindowPos(ImVec2(w_ * 0.5f, h_ * 0.3f), ImGuiCond_Always, ImVec2(0.5f, 0.f));
    if (ImGui::BeginPopupModal("Renombrar", nullptr, ImGuiWindowFlags_AlwaysAutoResize)) {
        ImGui::SetNextItemWidth(fs * 14.f);
        ImGui::InputText("##n", &renameBuf_);
        bool ok = ImGui::Button("Aceptar", ImVec2(fs * 6.f, 0));
        ImGui::SameLine();
        bool no = ImGui::Button("Cancelar", ImVec2(fs * 6.f, 0));
        if (ok && !renameBuf_.empty()) {
            if (renameWhat_ == 1 && renameIdx_ >= 0 && renameIdx_ < (int)edit_.proj.scenes.size()) {
                std::string old = edit_.proj.scenes[renameIdx_].name;
                edit_.proj.scenes[renameIdx_].name = renameBuf_;
                for (auto& s : edit_.proj.scenes)  // los bloques "Iniciar escena" siguen apuntando bien
                    for (auto& o : s.objs)
                        for (auto& b : o.blocks)
                            if (b.op == Op::StartScene && b.t == old) b.t = renameBuf_;
                markDirty();
            } else if (renameWhat_ == 2 && hasScene() && renameIdx_ >= 0 && renameIdx_ < (int)scene().objs.size()) {
                scene().objs[renameIdx_].name = renameBuf_;
                markDirty();
            }
        }
        if (ok || no) { renameWhat_ = 0; ImGui::CloseCurrentPopup(); }
        ImGui::EndPopup();
    }
}

void Editor::projectMenu() {
    float fs = ImGui::GetFontSize();
    if (projMenu_) { ImGui::OpenPopup("##proj"); projMenu_ = false; }
    ImGui::SetNextWindowPos(ImVec2((float)w_ - fs * 0.4f, fs * 3.2f), ImGuiCond_Always, ImVec2(1.f, 0.f));
    if (ImGui::BeginPopup("##proj")) {
        if (ImGui::MenuItem("Guardar")) saveProject();
        if (ImGui::MenuItem("Archivos (imágenes, sonidos, modelos)")) showAssets = true;
        if (ImGui::MenuItem("Botones y arma")) showHud = true;
        if (hasScene() && scene().is3d && ImGui::MenuItem("Mundo (cielo y luz)")) showWorld = true;
        ImGui::Separator();
        if (ImGui::MenuItem("Exportar como .exe (Windows)")) doExportExe();
        if (ImGui::MenuItem("Exportar paquete (.pack)")) doExportPack();
        ImGui::Separator();
        if (ImGui::MenuItem("Cerrar proyecto")) { ImGui::CloseCurrentPopup(); ImGui::EndPopup(); if (dirty_) saveProject(); closeProject(); return; }
        ImGui::EndPopup();
    }
}

void Editor::objectMenuItems(int idx) {
    if (!hasScene() || idx < 0 || idx >= (int)scene().objs.size()) return;
    Scene& S = scene();
    Obj& o = S.objs[idx];
    if (ImGui::MenuItem("Renombrar")) { renameWhat_ = 2; renameIdx_ = idx; renameBuf_ = o.name; }
    if (!o.bg) {
        if (ImGui::MenuItem("Duplicar")) {
            Obj c = o;
            c.name = uniqueName(o.name);
            c.pos.x += S.is3d ? 1.f : 40.f;
            S.objs.push_back(c);
            markDirty();
        }
        static int confirm = -1;
        if (confirm == idx) {
            if (ImGui::MenuItem("Confirmar: eliminar")) {
                S.objs.erase(S.objs.begin() + idx);
                sel_ = -1;
                confirm = -1;
                markDirty();
            }
        } else if (ImGui::MenuItem("Eliminar", nullptr, false, true)) {
            confirm = idx;
        }
    }
}

void Editor::newObjectMenu() {
    float fs = ImGui::GetFontSize();
    if (plusOpen_) { ImGui::OpenPopup("##plus"); plusOpen_ = false; }
    ImGui::SetNextWindowPos(ImVec2((float)w_ - fs * 0.8f, (float)h_ - fs * 4.4f), ImGuiCond_Always, ImVec2(1.f, 1.f));
    if (ImGui::BeginPopup("##plus")) {
        bool is3d = hasScene() && scene().is3d;
        ImGui::TextDisabled("Objeto nuevo");
        ImGui::Separator();
        if (is3d) {
            if (ImGui::MenuItem("Cubo")) addObject(Kind::Cube);
            if (ImGui::MenuItem("Suelo")) addObject(Kind::Floor);
            if (ImGui::MenuItem("Pared")) addObject(Kind::Wall);
            if (ImGui::MenuItem("Item (coleccionable)")) addObject(Kind::Item);
            if (ImGui::MenuItem("Luz")) addObject(Kind::Light);
            if (ImGui::BeginMenu("Modelo 3D (biblioteca)")) {
                auto models = assetsOf(2);
                if (models.empty()) ImGui::TextDisabled("Importa uno desde Archivos");
                for (auto& m : models) if (ImGui::MenuItem(m.c_str())) addObject(Kind::Model, m);
                ImGui::EndMenu();
            }
            if (ImGui::MenuItem("Importar modelo 3D...")) { if (host_.pickFile) host_.pickFile(); }
        } else {
            if (ImGui::MenuItem("Cuadro de color")) addObject(Kind::Cube);
            if (ImGui::MenuItem("Seleccionar una imagen...")) { pendingNewObj_ = true; if (host_.pickFile) host_.pickFile(); }
            if (ImGui::BeginMenu("Biblioteca (imágenes del proyecto)")) {
                auto imgs = assetsOf(0);
                if (imgs.empty()) ImGui::TextDisabled("Aún no hay imágenes");
                for (auto& m : imgs)
                    if (ImGui::MenuItem(m.c_str())) {
                        addObject(Kind::Cube);
                        if (Obj* o = selObj()) { o->tex = m; o->color[0] = o->color[1] = o->color[2] = 1.f; }
                    }
                ImGui::EndMenu();
            }
        }
        if (ImGui::MenuItem("Objeto vacío (sin imagen)")) {
            addObject(Kind::Cube);
            if (Obj* o = selObj()) { o->visible = false; o->name = uniqueName("Vacio"); }
        }
        ImGui::Separator();
        ImGui::TextDisabled("Dibujar, foto y mochila: próximamente");
        ImGui::EndPopup();
    }
}

// ---------------------------------------------------------------- pagina: escenas del proyecto
void Editor::pageScenes(Renderer* r) {
    if (r) r->clear(w_, h_, 0.09f, 0.10f, 0.14f);
    float fs = ImGui::GetFontSize();
    beginPage("##scenes");
    bool back, menu;
    topBar(name_.empty() ? "Proyecto" : name_, &back, &menu);
    if (back) { if (dirty_) saveProject(); ImGui::End(); closeProject(); return; }
    if (menu) projMenu_ = true;

    ImGui::BeginChild("##list", ImVec2(0, 0), false, ImGuiWindowFlags_NoScrollbar);
    dragScroll();
    ImGui::Indent(fs * 0.6f);
    ImGui::TextDisabled("Escenas");
    float bw = (float)w_ - fs * 1.2f;
    int act = -1, actKind = 0;
    for (int i = 0; i < (int)edit_.proj.scenes.size(); i++) {
        Scene& s = edit_.proj.scenes[i];
        ImGui::PushID(i);
        std::string lab = s.name + (s.is3d ? "   [3D]" : "   [2D]") + "   " + std::to_string(s.objs.size()) + " obj.";
        if (ImGui::Button(lab.c_str(), ImVec2(bw - fs * 3.f, fs * 2.8f)) && tapped()) { setScene(i); page_ = Page::SceneHome; }
        ImGui::SameLine();
        if (ImGui::Button("...", ImVec2(fs * 2.6f, fs * 2.8f)) && tapped()) ImGui::OpenPopup("m");
        if (ImGui::BeginPopup("m")) {
            if (ImGui::MenuItem("Renombrar")) { renameWhat_ = 1; renameIdx_ = i; renameBuf_ = s.name; }
            if (ImGui::MenuItem("Duplicar")) { act = i; actKind = 1; }
            if (edit_.proj.scenes.size() > 1 && ImGui::MenuItem("Eliminar")) { act = i; actKind = 2; }
            ImGui::EndPopup();
        }
        ImGui::PopID();
    }
    ImGui::Dummy(ImVec2(1, fs * 5.f));
    ImGui::Unindent(fs * 0.6f);
    ImGui::EndChild();

    if (act >= 0 && actKind == 1) {
        Scene c = edit_.proj.scenes[act];
        c.name += "_copia";
        edit_.proj.scenes.push_back(c);
        markDirty();
    } else if (act >= 0 && actKind == 2) {
        edit_.proj.scenes.erase(edit_.proj.scenes.begin() + act);
        setScene(0);
        markDirty();
    }
    renameUI();
    projectMenu();
    if (plusOpen_) { ImGui::OpenPopup("##newscene"); plusOpen_ = false; }
    ImGui::SetNextWindowPos(ImVec2((float)w_ - fs * 0.8f, (float)h_ - fs * 4.4f), ImGuiCond_Always, ImVec2(1.f, 1.f));
    if (ImGui::BeginPopup("##newscene")) {
        if (ImGui::MenuItem("Escena 2D (menús, juegos planos)")) addScene(false);
        if (ImGui::MenuItem("Escena 3D (niveles en primera persona)")) addScene(true);
        ImGui::EndPopup();
    }
    endPage();
    bool pl = false, pu = false;
    fab(&pl, &pu);
    if (pu) plusOpen_ = true;
    if (pl) startPlay();
    assetsWin();
    hudWin(r);
}

// ---------------------------------------------------------------- pagina: una escena (fondo y objetos)
void Editor::pageSceneHome(Renderer* r) {
    if (!hasScene()) { page_ = Page::Scenes; return; }
    if (r) r->clear(w_, h_, 0.09f, 0.10f, 0.14f);
    float fs = ImGui::GetFontSize();
    Scene& S = scene();
    beginPage("##scene");
    bool back, menu;
    topBar(S.name + (S.is3d ? "  [3D]" : "  [2D]"), &back, &menu);
    if (back) { page_ = Page::Scenes; sel_ = -1; }
    if (menu) projMenu_ = true;

    ImGui::BeginChild("##objs", ImVec2(0, 0), false, ImGuiWindowFlags_NoScrollbar);
    dragScroll();
    ImGui::Indent(fs * 0.6f);
    float bw = (float)w_ - fs * 1.2f;
    float row = fs * 3.2f;

    // Fondo (2D) o mundo (3D)
    ImGui::TextDisabled(S.is3d ? "Mundo" : "Fondo");
    if (S.is3d) {
        if (ImGui::Button("Cielo, luz y sombras", ImVec2(bw, fs * 2.6f)) && tapped()) showWorld = true;
    } else {
        for (int i = 0; i < (int)S.objs.size(); i++) {
            if (!S.objs[i].bg) continue;
            ImGui::PushID(i);
            thumb(r, S.objs[i], row);
            ImGui::SameLine();
            if (ImGui::Button(S.objs[i].name.c_str(), ImVec2(bw - row - fs * 0.5f, row)) && tapped()) openObject(i);
            ImGui::PopID();
        }
    }
    ImGui::Spacing();
    ImGui::TextDisabled("Actores y objetos");
    int act = -1;
    for (int i = 0; i < (int)S.objs.size(); i++) {
        if (S.objs[i].bg) continue;
        ImGui::PushID(i);
        thumb(r, S.objs[i], row);
        ImGui::SameLine();
        std::string lab = S.objs[i].name + (S.objs[i].visible ? "" : "  (oculto)") + "\n" +
                          std::to_string(S.objs[i].blocks.size()) + " bloques";
        if (ImGui::Button(lab.c_str(), ImVec2(bw - row - fs * 3.2f, row)) && tapped()) openObject(i);
        ImGui::SameLine();
        if (ImGui::Button("...", ImVec2(fs * 2.6f, row)) && tapped()) ImGui::OpenPopup("m");
        if (ImGui::BeginPopup("m")) { objectMenuItems(i); ImGui::EndPopup(); }
        ImGui::PopID();
    }
    (void)act;
    ImGui::Spacing();
    if (ImGui::Button("Editar la escena (ver y colocar objetos)", ImVec2(bw, fs * 2.6f)) && tapped()) {
        resetView();
        page_ = Page::Viewport;
    }
    ImGui::Dummy(ImVec2(1, fs * 5.f));
    ImGui::Unindent(fs * 0.6f);
    ImGui::EndChild();

    renameUI();
    projectMenu();
    newObjectMenu();
    endPage();
    bool pl = false, pu = false;
    fab(&pl, &pu);
    if (pu) plusOpen_ = true;
    if (pl) startPlay();
    worldWin();
    assetsWin();
    hudWin(r);
}

// ---------------------------------------------------------------- pagina: objeto (Scripts / Apariencias / Sonidos)
void Editor::pageObject(Renderer* r) {
    Obj* o = currentObj();
    if (!o) { page_ = Page::SceneHome; return; }
    if (r) r->clear(w_, h_, 0.09f, 0.10f, 0.14f);
    float fs = ImGui::GetFontSize();
    beginPage("##obj");
    bool back, menu;
    topBar(o->name, &back, &menu);
    bool sub = fe_.open || te_.open || pal_ != -2;
    if (back) {
        if (sub) { fe_.open = te_.open = false; pal_ = -2; }
        else page_ = Page::SceneHome;
    }
    if (menu) ImGui::OpenPopup("##om");
    if (ImGui::BeginPopup("##om")) {
        if (ImGui::MenuItem("Renombrar")) { renameWhat_ = 2; renameIdx_ = sel_; renameBuf_ = o->name; }
        if (ImGui::MenuItem("Ver en la escena")) { resetView(); page_ = Page::Viewport; }
        if (ImGui::MenuItem("Jugar")) { ImGui::EndPopup(); ImGui::End(); startPlay(); return; }
        ImGui::EndPopup();
    }
    if (!sub) {
        const char* names[3] = {"Scripts", "Apariencias", "Sonidos"};
        float tw = (float)w_ / 3.f;
        for (int i = 0; i < 3; i++) {
            if (i) ImGui::SameLine(0, 0);
            ImGui::PushStyleColor(ImGuiCol_Button, tab_ == i ? ImVec4(0.20f, 0.45f, 0.85f, 1.f) : ImVec4(0.18f, 0.20f, 0.28f, 1.f));
            if (ImGui::Button(names[i], ImVec2(tw, fs * 2.4f)) && tapped()) tab_ = i;
            ImGui::PopStyleColor();
        }
    }
    ImGui::BeginChild("##content", ImVec2(0, 0), false, ImGuiWindowFlags_NoScrollbar);
    dragScroll();
    ImGui::Indent(fs * 0.5f);
    if (tab_ == 0) scriptsTab(*o);
    else if (tab_ == 1) looksTab(*o, r);
    else soundsTab(*o);
    ImGui::Unindent(fs * 0.5f);
    ImGui::EndChild();
    renameUI();
    endPage();
    if (!sub && tab_ == 0) {
        bool pl = false, pu = false;
        fab(&pl, &pu);
        if (pu) pal_ = -1;
        if (pl) startPlay();
    } else if (!sub) {
        bool pl = false;
        fab(&pl, nullptr);
        if (pl) startPlay();
    }
    assetsWin();
}

// ---------------------------------------------------------------- pestana Scripts
void Editor::scriptsTab(Obj& o) {
    if (pal_ != -2) { palettePage(o); return; }
    if (fe_.open) { formulaPage(o); return; }
    if (te_.open) { choosePage(o); return; }
    float fs = ImGui::GetFontSize();
    ImDrawList* dl = ImGui::GetWindowDrawList();
    std::vector<Block>& B = o.blocks;
    int pFrom = -1, pTo = -1, delIdx = -1, dupIdx = -1;

    if (B.empty()) {
        ImGui::Spacing();
        ImGui::TextWrapped("Este objeto no tiene bloques. Toca + para añadir (empieza con un bloque de evento, por ejemplo \"Cuando se inicie la escena\").");
    }
    int depth = 0;
    const float pad = fs * 0.35f;
    for (int i = 0; i < (int)B.size(); i++) {
        Block& b = B[i];
        const OpInfo& in = opInfo(b.op);
        int k = in.indent;
        int lvl = (k == 2) ? 0 : ((k == -1 || k == 3) ? depth - 1 : depth);
        if (lvl < 0) lvl = 0;
        if (k == 2) depth = 0;
        else if (k == -1) depth = std::max(0, depth - 1);
        else if (k == 1) depth++;
        float ind = lvl * fs * 1.1f;

        ImGui::PushID(i);
        float availX = ImGui::GetContentRegionAvail().x;
        float rowX = ImGui::GetCursorScreenPos().x;
        float xr = rowX + availX - pad;
        dl->ChannelsSplit(2);
        dl->ChannelsSetCurrent(1);
        ImGui::BeginGroup();
        ImGui::Indent(ind + pad);
        ImGui::Dummy(ImVec2(1, fs * 0.1f));
        bool first = true;
        bool draggable = (k == 2 || k == 0 || k == 1);
        if (draggable) {
            ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(1, 1, 1, 0.22f));
            ImGui::Button("=", ImVec2(fs * 1.7f, fs * 1.7f));
            ImGui::PopStyleColor();
            if (ImGui::IsItemActive()) gHandle = true;
            if (ImGui::IsItemDeactivated() && ImGui::IsItemHovered() && tapped() && !ImGui::GetDragDropPayload()) ImGui::OpenPopup("bm");
            if (ImGui::BeginDragDropSource(ImGuiDragDropFlags_SourceAllowNullID)) {
                ImGui::SetDragDropPayload("BLK", &i, sizeof(int));
                ImGui::Text("%s", plainTitle(in).c_str());
                ImGui::EndDragDropSource();
            }
            first = false;
        }
        // textos y campos
        for (auto& t : tokenize(in.title)) {
            std::string lab;
            float wd;
            if (t.type == 0) {
                wd = ImGui::CalcTextSize(t.s.c_str()).x;
            } else {
                lab = t.type == 2 ? (b.t.empty() ? "(elegir)" : shorten(b.t))
                                  : (b.f[t.s[0] - '0'].empty() ? " " : shorten(b.f[t.s[0] - '0']));
                wd = ImGui::CalcTextSize(lab.c_str()).x + ImGui::GetStyle().FramePadding.x * 2.f;
            }
            if (!first) {
                float x2 = ImGui::GetItemRectMax().x + ImGui::GetStyle().ItemSpacing.x + wd;
                if (x2 < xr) ImGui::SameLine();
            } else {
                first = false;
            }
            if (t.type == 0) {
                ImGui::AlignTextToFramePadding();
                ImGui::TextUnformatted(t.s.c_str());
            } else {
                ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(1, 1, 1, 0.28f));
                ImGui::PushStyleColor(ImGuiCol_ButtonHovered, ImVec4(1, 1, 1, 0.40f));
                ImGui::PushStyleColor(ImGuiCol_ButtonActive, ImVec4(1, 1, 1, 0.50f));
                ImGui::PushID(t.type == 2 ? 9 : t.s[0] - '0');
                bool hit = ImGui::Button(lab.c_str());
                ImGui::PopID();
                ImGui::PopStyleColor(3);
                if (hit && tapped()) {
                    if (t.type == 2) { te_.open = true; te_.blk = i; te_.buf = b.t; }
                    else { fe_.open = true; fe_.blk = i; fe_.field = t.s[0] - '0'; fe_.buf = b.f[fe_.field]; formulaList_ = 0; }
                }
            }
        }
        if (ImGui::BeginPopup("bm")) {
            ImGui::PushTextWrapPos(fs * 22.f);
            ImGui::TextUnformatted(in.help);
            ImGui::PopTextWrapPos();
            ImGui::Separator();
            if (ImGui::MenuItem("Duplicar")) dupIdx = i;
            if (ImGui::MenuItem("Eliminar")) delIdx = i;
            ImGui::EndPopup();
        }
        ImGui::Dummy(ImVec2(1, fs * 0.1f));
        ImGui::Unindent(ind + pad);
        ImGui::EndGroup();
        ImVec2 mn = ImGui::GetItemRectMin(), mx = ImGui::GetItemRectMax();
        if (ImGui::BeginDragDropTarget()) {
            if (const ImGuiPayload* pl = ImGui::AcceptDragDropPayload("BLK")) { pFrom = *(const int*)pl->Data; pTo = i; }
            ImGui::EndDragDropTarget();
        }
        dl->ChannelsSetCurrent(0);
        ImVec4 c = catRGB(in.cat, k == 2 ? 0.9f : 1.f);
        dl->AddRectFilled(ImVec2(mn.x - pad + 0.f, mn.y), ImVec2(xr + pad, mx.y), col32(c), k == 2 ? 14.f : 8.f,
                          k == 2 ? ImDrawFlags_RoundCornersTop : ImDrawFlags_RoundCornersAll);
        if (k == 2) dl->AddRectFilled(ImVec2(mn.x - pad, mx.y - 3.f), ImVec2(xr + pad, mx.y), col32(catRGB(in.cat, 0.65f)));
        dl->ChannelsMerge();
        ImGui::PopID();
        ImGui::Dummy(ImVec2(1, 3.f));
    }
    // zona final: soltar aqui = al final de la lista
    ImGui::Dummy(ImVec2(ImGui::GetContentRegionAvail().x, fs * 3.f));
    if (ImGui::BeginDragDropTarget()) {
        if (const ImGuiPayload* pl = ImGui::AcceptDragDropPayload("BLK")) { pFrom = *(const int*)pl->Data; pTo = (int)B.size(); }
        ImGui::EndDragDropTarget();
    }
    ImGui::Dummy(ImVec2(1, fs * 4.f));

    if (pFrom >= 0 && pFrom < (int)B.size()) {
        bool okDrop = true;
        if (isHat(B[pFrom].op) && pTo < (int)B.size() && !isHat(B[pTo].op)) okDrop = false;  // los guiones solo entre guiones
        if (okDrop && moveRange(B, pFrom, pTo)) markDirty();
    }
    if (dupIdx >= 0 && dupIdx < (int)B.size()) {
        int e;
        if (blockRange(B, dupIdx, e)) {
            std::vector<Block> g(B.begin() + dupIdx, B.begin() + e);
            B.insert(B.begin() + e, g.begin(), g.end());
            markDirty();
        }
    }
    if (delIdx >= 0 && delIdx < (int)B.size()) {
        int e;
        if (blockRange(B, delIdx, e)) {
            B.erase(B.begin() + delIdx, B.begin() + e);
            markDirty();
        }
    }
}

// ---------------------------------------------------------------- paleta de bloques
void Editor::palettePage(Obj& o) {
    float fs = ImGui::GetFontSize();
    if (ImGui::Button("< Volver", ImVec2(fs * 5.f, fs * 2.2f)) && tapped()) { pal_ = -2; return; }
    ImGui::SameLine();
    ImGui::SetNextItemWidth(ImGui::GetContentRegionAvail().x - fs * 0.5f);
    ImGui::InputTextWithHint("##s", "Buscar bloque", &palSearch_);
    float bw = ImGui::GetContentRegionAvail().x - fs * 0.5f;
    bool searching = !palSearch_.empty();
    if (pal_ == -1 && !searching) {
        ImGui::Spacing();
        ImGui::TextDisabled("Categorías");
        static const Cat cats[] = {Cat::Eventos, Cat::Control, Cat::Movimiento, Cat::Sonido, Cat::Apariencia, Cat::Datos, Cat::Forge3D};
        for (int i = 0; i < 7; i++) {
            ImGui::PushStyleColor(ImGuiCol_Button, catRGB(cats[i]));
            ImGui::PushStyleColor(ImGuiCol_ButtonHovered, catRGB(cats[i], 1.15f));
            ImGui::PushStyleColor(ImGuiCol_ButtonActive, catRGB(cats[i], 0.8f));
            if (ImGui::Button(catName(cats[i]), ImVec2(bw, fs * 3.f)) && tapped()) pal_ = i;
            ImGui::PopStyleColor(3);
        }
        return;
    }
    static const Cat cats[] = {Cat::Eventos, Cat::Control, Cat::Movimiento, Cat::Sonido, Cat::Apariencia, Cat::Datos, Cat::Forge3D};
    std::string q = normName(palSearch_);
    if (!searching) {
        ImGui::Spacing();
        ImGui::TextColored(catRGB(cats[pal_]), "%s", catName(cats[pal_]));
    }
    ImGui::Spacing();
    int pick = -1;
    for (int i = 0; i < (int)Op::Count; i++) {
        const OpInfo& in = opInfo((Op)i);
        if (searching) {
            if (normName(plainTitle(in)).find(q) == std::string::npos && normName(in.help).find(q) == std::string::npos) continue;
        } else if (in.cat != cats[pal_]) {
            continue;
        }
        ImGui::PushID(i);
        ImGui::PushStyleColor(ImGuiCol_Button, catRGB(in.cat));
        ImGui::PushStyleColor(ImGuiCol_ButtonHovered, catRGB(in.cat, 1.15f));
        ImGui::PushStyleColor(ImGuiCol_ButtonActive, catRGB(in.cat, 0.8f));
        ImGui::PushTextWrapPos(ImGui::GetCursorPosX() + bw - fs);
        if (ImGui::Button(plainTitle(in).c_str(), ImVec2(bw, fs * 2.6f)) && tapped()) pick = i;
        ImGui::PopTextWrapPos();
        ImGui::PopStyleColor(3);
        ImGui::PushTextWrapPos(ImGui::GetCursorPosX() + bw);
        ImGui::TextDisabled("%s", in.help);
        ImGui::PopTextWrapPos();
        ImGui::Spacing();
        ImGui::PopID();
    }
    ImGui::Dummy(ImVec2(1, fs * 3.f));
    if (pick >= 0) {
        addBlock(o, (Op)pick);
        pal_ = -2;
        palSearch_.clear();
    }
}

// ---------------------------------------------------------------- editor de formulas
void Editor::formulaPage(Obj& o) {
    float fs = ImGui::GetFontSize();
    if (fe_.blk < 0 || fe_.blk >= (int)o.blocks.size()) { fe_.open = false; return; }
    Block& b = o.blocks[fe_.blk];
    float aw = ImGui::GetContentRegionAvail().x - fs * 0.5f;

    ImGui::TextDisabled("Editor de fórmulas");
    ImGui::SetNextItemWidth(aw);
    ImGui::InputText("##f", &fe_.buf);
    PreviewEnv env;
    if (!formulaValid(fe_.buf)) {
        ImGui::TextColored(ImVec4(1.f, 0.6f, 0.4f, 1.f), "No es una fórmula válida: se usará como texto.");
    } else {
        Val v = evalFormula(fe_.buf, &env);
        ImGui::Text("= %s", shorten(v.txt(), 40).c_str());
    }
    // teclado de calculadora
    float kw = (aw - fs * 0.6f) / 4.f, kh = fs * 2.3f;
    auto key = [&](const char* label, const char* ins, bool last = false) {
        if (ImGui::Button(label, ImVec2(kw, kh)) && tapped()) fe_.buf += ins;
        if (!last) ImGui::SameLine();
    };
    key("7", "7"); key("8", "8"); key("9", "9"); key("/", " / ", true);
    key("4", "4"); key("5", "5"); key("6", "6"); key("*", " * ", true);
    key("1", "1"); key("2", "2"); key("3", "3"); key("-", " - ", true);
    key("0", "0"); key(".", "."); key(",", ", "); key("+", " + ", true);
    key("(", "("); key(")", ")"); key("=", " = "); key("^", "^", true);
    key("<", " < "); key(">", " > "); key("y", " y "); key("o", " o ", true);
    key("no", "no "); key("'Abc'", "'texto'");
    if (ImGui::Button("<-", ImVec2(kw, kh)) && tapped()) {
        while (!fe_.buf.empty() && ((unsigned char)fe_.buf.back() & 0xC0) == 0x80) fe_.buf.pop_back();
        if (!fe_.buf.empty()) fe_.buf.pop_back();
    }
    ImGui::SameLine();
    if (ImGui::Button("Borrar", ImVec2(kw, kh)) && tapped()) fe_.buf.clear();
    ImGui::Spacing();
    bool ok = ImGui::Button("Aceptar", ImVec2(aw * 0.5f - fs * 0.2f, fs * 2.6f)) && tapped();
    ImGui::SameLine();
    bool no = ImGui::Button("Cancelar", ImVec2(aw * 0.5f - fs * 0.2f, fs * 2.6f)) && tapped();
    if (ok) { b.f[fe_.field] = fe_.buf; markDirty(); }
    if (ok || no) { fe_.open = false; return; }

    // listas: Funciones / Objeto / Dispositivo / Lógica / Datos
    ImGui::Spacing();
    static const char* tabs[5] = {"Funciones", "Objeto", "Dispositivo", "Lógica", "Datos"};
    float tw = aw / 5.f;
    for (int i = 0; i < 5; i++) {
        if (i) ImGui::SameLine(0, 0);
        ImGui::PushStyleColor(ImGuiCol_Button, formulaList_ == i ? ImVec4(0.20f, 0.45f, 0.85f, 1.f) : ImVec4(0.18f, 0.20f, 0.28f, 1.f));
        if (ImGui::Button(tabs[i], ImVec2(tw, fs * 2.1f)) && tapped()) formulaList_ = i;
        ImGui::PopStyleColor();
    }
    auto inGroup = [&](const std::string& g) {
        switch (formulaList_) {
            case 0: return g == "MATEMÁTICAS" || g == "STRINGS (CADENAS)" || g == "FECHA Y HORA" || g == "3D";
            case 1: return g == "PROPIEDADES DE ASPECTO" || g == "PROPIEDADES DE MOVIMIENTO";
            case 2: return g == "SENSORES DEL DISPOSITIVO" || g == "DETECCIÓN DEL TACTO";
            case 3: return g == "OPERADORES LÓGICOS (BOOLEANOS)" || g == "OPERADOR DE COMPARACIÓN";
        }
        return false;
    };
    ImGui::Spacing();
    std::string cur;
    if (formulaList_ == 4) {
        auto vars = varNames(o);
        if (vars.empty()) ImGui::TextDisabled("No hay variables. Crea una con un bloque de Datos.");
        for (auto& v : vars) {
            ImGui::PushID(v.c_str());
            if (ImGui::Button(shorten(v, 30).c_str(), ImVec2(aw, fs * 2.2f)) && tapped()) fe_.buf += "\"" + v + "\"";
            ImGui::PopID();
        }
    } else {
        int n = 0;
        for (auto& f : formulaFunctions()) {
            if (!inGroup(f.group)) continue;
            if (cur != f.group) { cur = f.group; ImGui::Spacing(); ImGui::TextDisabled("%s", f.group); }
            ImGui::PushID(n++);
            if (ImGui::Button(f.label, ImVec2(aw, fs * 2.1f)) && tapped()) fe_.buf += f.label;
            ImGui::PopID();
        }
    }
    ImGui::Dummy(ImVec2(1, fs * 2.f));
}

// ---------------------------------------------------------------- elegir texto (mensaje, objeto, sonido, variable...)
void Editor::choosePage(Obj& o) {
    float fs = ImGui::GetFontSize();
    if (te_.blk < 0 || te_.blk >= (int)o.blocks.size()) { te_.open = false; return; }
    Block& b = o.blocks[te_.blk];
    float aw = ImGui::GetContentRegionAvail().x - fs * 0.5f;
    std::vector<std::string> items;
    const char* what = "Elegir";
    bool isVar = false, free = false;
    switch (b.op) {
        case Op::WhenReceive: case Op::Broadcast: case Op::BroadcastWait:
            items = messageNames(); what = "Mensaje"; free = true; break;
        case Op::WhenCollide: case Op::WhenNear: case Op::PointTowards:
            what = "Objeto";
            if (hasScene()) for (auto& x : scene().objs) if (&x != &o) items.push_back(x.name);
            break;
        case Op::StartSound:
            what = "Sonido";
            items = o.sounds;
            for (auto& a : assetsOf(1)) if (std::find(items.begin(), items.end(), a) == items.end()) items.push_back(a);
            break;
        case Op::Music: what = "Música"; items = assetsOf(1); break;
        case Op::SetLook:
            what = "Apariencia";
            items = o.looks;
            if (!o.tex.empty()) items.insert(items.begin(), o.tex);
            break;
        case Op::StartScene: what = "Escena"; for (auto& s : edit_.proj.scenes) items.push_back(s.name); break;
        case Op::SetVar: case Op::ChangeVar: case Op::ShowVar: case Op::HideVar:
            what = "Variable"; items = varNames(o); isVar = true; break;
        default: free = true; break;
    }
    ImGui::TextDisabled("%s", what);
    bool done = false;
    for (int i = 0; i < (int)items.size(); i++) {
        ImGui::PushID(i);
        if (ImGui::Button(shorten(items[i], 34).c_str(), ImVec2(aw, fs * 2.4f)) && tapped()) { b.t = items[i]; done = true; markDirty(); }
        ImGui::PopID();
    }
    if (items.empty() && !isVar) ImGui::TextDisabled("(no hay nada que elegir todavía)");
    ImGui::Spacing();
    if (isVar) {
        ImGui::TextDisabled("Variable nueva");
        ImGui::SetNextItemWidth(aw);
        ImGui::InputTextWithHint("##nv", "nombre de la variable", &newVarName_);
        ImGui::Checkbox("Solo para este objeto", &newVarLocal_);
        if (ImGui::Button("Crear variable", ImVec2(aw, fs * 2.4f)) && tapped() && !newVarName_.empty()) {
            auto all = varNames(o);
            if (std::find(all.begin(), all.end(), newVarName_) == all.end()) {
                if (newVarLocal_) o.localVars.push_back(newVarName_);
                else edit_.proj.globalVars.push_back(newVarName_);
            }
            b.t = newVarName_;
            newVarName_.clear();
            done = true;
            markDirty();
        }
    } else if (free) {
        ImGui::TextDisabled(b.op == Op::Note ? "Escribe la nota" : "Nuevo");
        ImGui::SetNextItemWidth(aw);
        ImGui::InputText("##t", &te_.buf);
        if (ImGui::Button("Aceptar", ImVec2(aw, fs * 2.4f)) && tapped()) { b.t = te_.buf; done = true; markDirty(); }
    }
    ImGui::Spacing();
    if (ImGui::Button("Cancelar", ImVec2(aw, fs * 2.2f)) && tapped()) done = true;
    if (done) te_.open = false;
    ImGui::Dummy(ImVec2(1, fs * 2.f));
}

// ---------------------------------------------------------------- pestana Apariencias
void Editor::looksTab(Obj& o, Renderer* r) {
    float fs = ImGui::GetFontSize();
    float aw = ImGui::GetContentRegionAvail().x - fs * 0.5f;
    ImGui::Spacing();
    ImGui::TextDisabled("Aspecto principal");
    thumb(r, o, fs * 5.f);
    ImGui::SameLine();
    ImGui::BeginGroup();
    ImGui::Text("%s", o.tex.empty() ? "(solo color)" : shorten(o.tex, 24).c_str());
    if (ImGui::ColorEdit3("Color", o.color, ImGuiColorEditFlags_NoInputs)) markDirty();
    ImGui::EndGroup();
    if (ImGui::Button("Imagen principal...", ImVec2(aw, fs * 2.3f)) && tapped()) ImGui::OpenPopup("mainimg");
    if (ImGui::BeginPopup("mainimg")) {
        if (ImGui::MenuItem("(sin imagen)")) { o.tex.clear(); markDirty(); }
        for (auto& a : assetsOf(0)) if (ImGui::MenuItem(a.c_str(), nullptr, a == o.tex)) { o.tex = a; markDirty(); }
        ImGui::EndPopup();
    }
    ImGui::Spacing();
    ImGui::TextDisabled("Más apariencias (para \"Cambiar apariencia a\" y \"Siguiente apariencia\")");
    int del = -1;
    float th = fs * 3.2f;
    for (int i = 0; i < (int)o.looks.size(); i++) {
        ImGui::PushID(i);
        Obj tmp;
        tmp.tex = o.looks[i];
        thumb(r, tmp, th);
        ImGui::SameLine();
        ImGui::AlignTextToFramePadding();
        ImGui::Text("%d. %s", i + 1, shorten(o.looks[i], 26).c_str());
        ImGui::SameLine(aw - fs * 2.6f);
        if (ImGui::Button("x", ImVec2(fs * 2.4f, th * 0.8f)) && tapped()) del = i;
        ImGui::PopID();
    }
    if (del >= 0) { o.looks.erase(o.looks.begin() + del); markDirty(); }
    if (o.looks.empty()) ImGui::TextDisabled("(ninguna)");
    ImGui::Spacing();
    if (ImGui::Button("Importar imagen...", ImVec2(aw, fs * 2.4f)) && tapped()) { if (host_.pickFile) host_.pickFile(); }
    if (ImGui::Button("Elegir de los archivos", ImVec2(aw, fs * 2.4f)) && tapped()) ImGui::OpenPopup("addlook");
    if (ImGui::BeginPopup("addlook")) {
        auto imgs = assetsOf(0);
        if (imgs.empty()) ImGui::TextDisabled("No hay imágenes en el proyecto");
        for (auto& a : imgs) if (ImGui::MenuItem(a.c_str())) { o.looks.push_back(a); markDirty(); }
        ImGui::EndPopup();
    }
    ImGui::Dummy(ImVec2(1, fs * 3.f));
}

// ---------------------------------------------------------------- pestana Sonidos
void Editor::soundsTab(Obj& o) {
    float fs = ImGui::GetFontSize();
    float aw = ImGui::GetContentRegionAvail().x - fs * 0.5f;
    ImGui::Spacing();
    ImGui::TextDisabled("Sonidos de este objeto");
    int del = -1;
    for (int i = 0; i < (int)o.sounds.size(); i++) {
        ImGui::PushID(i);
        ImGui::AlignTextToFramePadding();
        ImGui::Text("%d. %s", i + 1, shorten(o.sounds[i], 22).c_str());
        ImGui::SameLine(aw - fs * 9.f);
        if (ImGui::Button("Probar", ImVec2(fs * 5.f, fs * 2.2f)) && tapped() && audio_) audio_->play(o.sounds[i]);
        ImGui::SameLine();
        if (ImGui::Button("x", ImVec2(fs * 2.4f, fs * 2.2f)) && tapped()) del = i;
        ImGui::PopID();
    }
    if (del >= 0) { o.sounds.erase(o.sounds.begin() + del); markDirty(); }
    if (o.sounds.empty()) ImGui::TextDisabled("(ninguno)");
    ImGui::Spacing();
    if (ImGui::Button("Importar sonido...", ImVec2(aw, fs * 2.4f)) && tapped()) { if (host_.pickFile) host_.pickFile(); }
    if (ImGui::Button("Elegir de los archivos", ImVec2(aw, fs * 2.4f)) && tapped()) ImGui::OpenPopup("addsnd");
    if (ImGui::BeginPopup("addsnd")) {
        auto snds = assetsOf(1);
        if (snds.empty()) ImGui::TextDisabled("No hay audios en el proyecto");
        for (auto& a : snds) if (ImGui::MenuItem(a.c_str())) { o.sounds.push_back(a); markDirty(); }
        ImGui::EndPopup();
    }
    ImGui::Dummy(ImVec2(1, fs * 3.f));
}

}  // namespace forge
