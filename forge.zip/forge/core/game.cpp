#include "game.h"
#include <algorithm>
#include <cmath>
#include <ctime>

namespace forge {

static const float kRad = 3.14159265f / 180.f;

static bool solidKind(Kind k) {
    return k == Kind::Cube || k == Kind::Floor || k == Kind::Wall || k == Kind::Model;
}

bool Game::hasHat(const Obj& o, Op hat) const {
    for (auto& b : o.blocks) if (b.op == hat) return true;
    return false;
}

V3 Game::forward() const {
    return {std::sin(yaw) * std::cos(pitch), std::sin(pitch), -std::cos(yaw) * std::cos(pitch)};
}

// ---------------------------------------------------------------- carga
static void compileObj(const std::vector<Block>& B, std::vector<int>& match, std::vector<int>& hats) {
    int n = (int)B.size();
    match.assign(n, n);
    hats.clear();
    struct S { int idx; Op op; };
    std::vector<S> st;
    for (int i = 0; i < n; i++) {
        Op op = B[i].op;
        if (isHat(op)) { hats.push_back(i); st.clear(); continue; }
        if (op == Op::Forever || op == Op::Repeat || op == Op::If) st.push_back({i, op});
        else if (op == Op::Else) {
            if (!st.empty() && st.back().op == Op::If) { match[st.back().idx] = i; st.back() = {i, Op::Else}; }
        } else if (op == Op::EndIf) {
            if (!st.empty() && (st.back().op == Op::If || st.back().op == Op::Else)) { match[st.back().idx] = i; st.pop_back(); }
        } else if (op == Op::LoopEnd) {
            if (!st.empty() && (st.back().op == Op::Forever || st.back().op == Op::Repeat)) {
                match[st.back().idx] = i;
                match[i] = st.back().idx;
                st.pop_back();
            }
        }
    }
}

void Game::load(Project p) {
    proj = std::move(p);
    sc = nullptr;
    vars.clear();
    shown.clear();
    runners_.clear();
    shootCd = recoil = flash = 0;
    gravX_ = 0; gravY_ = -10;
    volume = 100;
    if (!proj.scenes.empty()) enterScene(proj.scenes[0].name);
}

void Game::bindScene(int idx) {
    if (idx < 0 || idx >= (int)proj.scenes.size()) { sc = nullptr; return; }
    sc = &proj.scenes[idx];
}

void Game::enterScene(const std::string& name) {
    Scene* found = nullptr;
    for (auto& s : proj.scenes) if (s.name == name) { found = &s; break; }
    if (!found) return;
    sc = found;
    runners_.clear();
    near_.assign(sc->objs.size(), 0);
    base_.clear();
    cmp_.assign(sc->objs.size(), Compiled());
    st_.assign(sc->objs.size(), ObjState());
    for (size_t i = 0; i < sc->objs.size(); i++) {
        Obj& o = sc->objs[i];
        base_.push_back(o.scale);
        compileObj(o.blocks, cmp_[i].match, cmp_[i].hats);
        st_[i].hatState.assign(o.blocks.size(), 0);
        if (!o.looks.empty()) {
            auto it = std::find(o.looks.begin(), o.looks.end(), o.tex);
            st_[i].look = it == o.looks.end() ? 0 : (int)(it - o.looks.begin());
        }
    }
    pos = sc->start;
    vel = V3();
    yaw = 0;
    pitch = 0;
    for (size_t i = 0; i < sc->objs.size(); i++) fireHat((int)i, Op::WhenStart);
}

// ---------------------------------------------------------------- guiones
int Game::startScript(int obj, int hatIdx) {
    for (auto& r : runners_)
        if (r.obj == obj && r.hat == hatIdx && !r.done) {  // reinicia el guion
            r.pc = hatIdx + 1; r.loops.clear(); r.wait = 0; r.gT = 0; r.waitIds.clear();
            return r.id;
        }
    Runner r;
    r.id = nextId_++;
    r.obj = obj;
    r.hat = hatIdx;
    r.pc = hatIdx + 1;
    const auto& hats = cmp_[obj].hats;
    int total = (int)sc->objs[obj].blocks.size();
    r.end = total;
    for (int h : hats) if (h > hatIdx) { r.end = h; break; }
    runners_.push_back(std::move(r));
    return runners_.back().id;
}

void Game::fireHat(int obj, Op hat) {
    if (obj < 0 || obj >= (int)cmp_.size()) return;
    const auto& B = sc->objs[obj].blocks;
    for (int h : cmp_[obj].hats) if (B[h].op == hat) startScript(obj, h);
}

void Game::broadcast(const std::string& msg, std::vector<int>* ids) {
    for (size_t i = 0; i < sc->objs.size(); i++) {
        const auto& B = sc->objs[i].blocks;
        for (int h : cmp_[i].hats)
            if (B[h].op == Op::WhenReceive && B[h].t == msg) {
                int id = startScript((int)i, h);
                if (ids) ids->push_back(id);
            }
    }
}

int Game::findObj(const std::string& name) const {
    if (!sc) return -1;
    std::string k = normName(name);
    for (size_t i = 0; i < sc->objs.size(); i++) if (normName(sc->objs[i].name) == k) return (int)i;
    return -1;
}

bool Game::overlap(const Obj& a, const Obj& b) const {
    if (std::fabs(a.pos.x - b.pos.x) * 2 >= a.scale.x + b.scale.x) return false;
    if (std::fabs(a.pos.y - b.pos.y) * 2 >= a.scale.y + b.scale.y) return false;
    if (sc && sc->is3d && std::fabs(a.pos.z - b.pos.z) * 2 >= a.scale.z + b.scale.z) return false;
    return true;
}

// ---------------------------------------------------------------- variables y formulas
Val Game::getVar(const std::string& name, int obj) {
    std::string k = vkey(name);
    if (obj >= 0 && obj < (int)st_.size()) {
        auto it = st_[obj].locals.find(k);
        if (it != st_[obj].locals.end()) return it->second;
    }
    auto it = vars.find(k);
    return it == vars.end() ? Val(0.0) : it->second;
}

void Game::setVar(const std::string& name, Val v, int obj) {
    std::string k = vkey(name);
    if (obj >= 0 && obj < (int)st_.size()) {
        for (auto& lv : sc->objs[obj].localVars)
            if (vkey(lv) == k) { st_[obj].locals[k] = v; return; }
    }
    vars[k] = v;
}

Val Game::eval(const std::string& f, int obj) {
    int prev = cur_;
    cur_ = obj;
    Val v = evalFormula(f, this);
    cur_ = prev;
    return v;
}

bool Game::lookup(const std::string& nameIn, const std::vector<Val>& a, Val& out) {
    bool quoted = !nameIn.empty() && nameIn[0] == '"';
    std::string n = quoted ? nameIn.substr(1) : nameIn;
    int o = cur_;
    Obj* ob = (sc && o >= 0 && o < (int)sc->objs.size()) ? &sc->objs[o] : nullptr;
    ObjState* os = (ob && o < (int)st_.size()) ? &st_[o] : nullptr;
    auto N = [&](size_t i) { return i < a.size() ? a[i].num() : 0.0; };
    auto S = [&](size_t i) { return i < a.size() ? a[i].txt() : std::string(); };

    if (quoted) {  // variable explicita
        out = getVar(n, o);
        return true;
    }
    bool is3 = sc && sc->is3d;
    float sw = stageW(), sh = kView2DHeight;
    auto touchX = [&](int i) { return (in_.touch[i].x - 0.5f) * sw; };
    auto touchY = [&](int i) { return (0.5f - in_.touch[i].y) * sh; };
    auto nthTouch = [&](int k) {  // k = 1..: indice del k-esimo dedo actual
        int c = 0;
        for (int i = 0; i < 10; i++) if (in_.touch[i].down && ++c == k) return i;
        return -1;
    };
    auto objByArg = [&](size_t i) { return findObj(S(i)); };
    auto objPos = [&](int idx, V3& p) {
        if (idx >= 0) { p = sc->objs[idx].pos; return true; }
        return false;
    };

    // --- propiedades del objeto
    if (ob) {
        if (n == "get_object_name") { out = Val::text(ob->name); return true; }
        if (n == "direccion" || n == "direccion de la mirada") { out = ob->yaw; return true; }
        if (n == "transparencia") { out = ob->transp; return true; }
        if (n == "brillo") { out = ob->bright; return true; }
        if (n == "color") { out = ob->hue; return true; }
        if (n == "numero_fondo") { out = os->look + 1; return true; }
        if (n == "nombre_fondo") { out = Val::text(os->look < (int)ob->looks.size() ? ob->looks[os->look] : ""); return true; }
        if (n == "numero de fondos") { out = (double)ob->looks.size(); return true; }
        if (n == "posicion x") { out = ob->pos.x; return true; }
        if (n == "posicion y") { out = ob->pos.y; return true; }
        if (n == "tamano") { out = os->sizePct; return true; }
        if (n == "width") { out = ob->scale.x; return true; }
        if (n == "height") { out = ob->scale.y; return true; }
        if (n == "capa") { out = ob->layer; return true; }
        if (n == "velocidad x") { out = os->vel.x; return true; }
        if (n == "velocidad y") { out = os->vel.y; return true; }
        if (n == "velocidad angular") { out = os->spin; return true; }
        if (n == "tocar_objeto" || n == "touches_object_by_name") {
            int j = objByArg(0);
            out = (j >= 0 && j != o && sc->objs[j].alive && sc->objs[j].visible && overlap(*ob, sc->objs[j])) ? 1 : 0;
            return true;
        }
        if (n == "tocar_bordes") {
            out = (!is3 && (std::fabs(ob->pos.x) + ob->scale.x * .5f > sw * .5f || std::fabs(ob->pos.y) + ob->scale.y * .5f > sh * .5f)) ? 1 : 0;
            return true;
        }
        if (n == "tocar_dedos") {
            bool hit = false;
            if (!is3)
                for (int i = 0; i < 10; i++)
                    if (in_.touch[i].down && std::fabs(touchX(i) - ob->pos.x) <= ob->scale.x * .5f &&
                        std::fabs(touchY(i) - ob->pos.y) <= ob->scale.y * .5f) hit = true;
            out = hit ? 1 : 0;
            return true;
        }
        if (n == "toca el color" || n == "color toca el color") { out = 0; return true; }
    }

    // --- dispositivo
    if (n == "volumen") { out = volume; return true; }
    if (n == "stage width") { out = sw; return true; }
    if (n == "stage height") { out = sh; return true; }
    if (n == "micro volume" || n == "micro frequency") { out = 0; return true; }
    if (n == "local server ip") { out = Val::text(""); return true; }
    if (n == "local server port") { out = 0; return true; }
    if (n == "battery percentage") { out = dev.battery; return true; }
    if (n == "connected to internet") { out = dev.online; return true; }
    if (n == "cpu architecture") { out = Val::text("arm64"); return true; }
    if (n == "fps") { out = fps_; return true; }
    if (n == "clipboard_text") { out = Val::text(dev.clipboard); return true; }
    if (n == "keyboard_height") { out = dev.keyboardH; return true; }
    if (n == "color a x y" || n == "color es igual a color con % tolerancia") { out = 0; return true; }
    if (n == "acceleracion x") { out = dev.accel[0]; return true; }
    if (n == "acceleracion y") { out = dev.accel[1]; return true; }
    if (n == "acceleracion_z") { out = dev.accel[2]; return true; }
    if (n == "inclinacion x") { out = std::atan2(dev.accel[0], dev.accel[2] == 0 ? 9.8f : dev.accel[2]) / kRad; return true; }
    if (n == "inclinacion y") { out = std::atan2(dev.accel[1], dev.accel[2] == 0 ? 9.8f : dev.accel[2]) / kRad; return true; }
    if (n == "direccion_compass") { out = dev.compass; return true; }
    if (n == "latitud") { out = dev.lat; return true; }
    if (n == "longitud") { out = dev.lon; return true; }
    if (n == "precision_localizacion") { out = dev.acc; return true; }
    if (n == "altitud") { out = dev.alt; return true; }
    if (n == "idioma del usuario") { out = Val::text(dev.lang); return true; }

    // --- toques
    if (n == "toque pantalla x" || n == "toque pantalla y" || n == "pantalla_tocada") {
        int i = a.empty() ? -1 : (int)N(0) - 1;
        if (a.empty()) { for (int k = 9; k >= 0; k--) if (in_.touch[k].down) { i = k; break; } }
        if (n == "pantalla_tocada") out = (i >= 0 && i < 10 && in_.touch[i].down) ? 1 : 0;
        else if (i < 0 || i > 9) out = 0;
        else out = n == "toque pantalla x" ? touchX(i) : touchY(i);
        return true;
    }
    if (n == "ultimo_indice_de_toque_pantalla") { int last = 0; for (int k = 0; k < 10; k++) if (in_.touch[k].down) last = k + 1; out = last; return true; }
    if (n == "numero de toques actuales") { int c = 0; for (auto& t : in_.touch) c += t.down; out = c; return true; }
    if (n == "indice del toque actual") { out = nthTouch((int)N(0)) + 1; return true; }

    // --- fecha y hora
    if (n == "cronometro") { out = time; return true; }
    if (n == "ano" || n == "mes" || n == "dia" || n == "dia de la semana" || n == "hora" || n == "minuto" || n == "segundo") {
        std::time_t t = std::time(nullptr);
        std::tm* tm = std::localtime(&t);
        out = n == "ano" ? tm->tm_year + 1900 : n == "mes" ? tm->tm_mon + 1 : n == "dia" ? tm->tm_mday
              : n == "dia de la semana" ? (tm->tm_wday == 0 ? 7 : tm->tm_wday) : n == "hora" ? tm->tm_hour
              : n == "minuto" ? tm->tm_min : tm->tm_sec;
        return true;
    }

    // --- 3D
    if (n == "delta-time") { out = 1.0 / std::max(1.f, fps_); return true; }
    if (n.compare(0, 3, "3d ") == 0 && a.size() >= 1) {
        std::string what = n.substr(3);
        if (what == "distance between") {
            V3 p, q;
            if (objPos(objByArg(0), p) && objPos(objByArg(1), q)) out = len(p - q); else out = 0;
            return true;
        }
        int j = objByArg(0);
        if (j < 0) { out = 0; return true; }
        const Obj& t = sc->objs[j];
        if (what == "position x") out = t.pos.x; else if (what == "position y") out = t.pos.y; else if (what == "position z") out = t.pos.z;
        else if (what == "rotation y") out = t.yaw; else if (what == "rotation x" || what == "rotation z") out = 0;
        else if (what == "scale x") out = t.scale.x; else if (what == "scale y") out = t.scale.y; else if (what == "scale z") out = t.scale.z;
        else if (what == "velocity x") out = st_[j].vel.x; else if (what == "velocity y") out = st_[j].vel.y; else if (what == "velocity z") out = st_[j].vel.z;
        else return false;
        return true;
    }
    if (n == "object touches object") {
        int i = objByArg(0), j = objByArg(1);
        out = (i >= 0 && j >= 0 && overlap(sc->objs[i], sc->objs[j])) ? 1 : 0;
        return true;
    }
    if (n.compare(0, 7, "camera ") == 0) {
        std::string w = n.substr(7);
        V3 e = is3 ? eye() : V3(), f = is3 ? forward() : V3();
        if (w == "position x") out = e.x; else if (w == "position y") out = e.y; else if (w == "position z") out = e.z;
        else if (w == "direction x") out = f.x; else if (w == "direction y") out = f.y; else if (w == "direction z") out = f.z;
        else if (w == "rotation x") out = pitch / kRad; else if (w == "rotation y") out = yaw / kRad; else if (w == "rotation z") out = 0;
        else return false;
        return true;
    }

    // --- variables sin comillas
    std::string k = vkey(n);
    if (a.empty()) {
        if (os && os->locals.count(k)) { out = os->locals[k]; return true; }
        auto it = vars.find(k);
        if (it != vars.end()) { out = it->second; return true; }
        if (ob) for (auto& lv : ob->localVars) if (vkey(lv) == k) { out = 0; return true; }
    }
    return false;
}

// ---------------------------------------------------------------- mundo 3D
bool Game::blocked(V3 p) const {
    const float hw = 0.3f, h = 1.7f, eps = 1e-4f;
    for (auto& o : sc->objs) {
        if (!o.alive || !o.visible || !o.solid || !solidKind(o.kind)) continue;
        if (p.x + hw <= o.pos.x - o.scale.x * .5f + eps || p.x - hw >= o.pos.x + o.scale.x * .5f - eps) continue;
        if (p.y + h <= o.pos.y - o.scale.y * .5f + eps || p.y >= o.pos.y + o.scale.y * .5f - eps) continue;
        if (p.z + hw <= o.pos.z - o.scale.z * .5f + eps || p.z - hw >= o.pos.z + o.scale.z * .5f - eps) continue;
        return true;
    }
    return false;
}

void Game::tap3D() {
    V3 e = eye(), d = forward();
    float best = 4.f;
    int hit = -1;
    for (size_t i = 0; i < sc->objs.size(); i++) {
        auto& o = sc->objs[i];
        if (!o.alive || !o.visible) continue;
        if (!(hasHat(o, Op::WhenTap) || (o.solid && solidKind(o.kind)))) continue;
        float t;
        if (rayBox(e, d, o.pos, o.scale * .5f, t) && t < best) { best = t; hit = (int)i; }
    }
    if (hit >= 0) fireHat(hit, Op::WhenTap);
}

void Game::shoot3D() {
    V3 e = eye(), d = forward();
    float best = proj.weapon.range;
    int hit = -1;
    for (size_t i = 0; i < sc->objs.size(); i++) {
        auto& o = sc->objs[i];
        if (!o.alive || !o.visible) continue;
        if (!(hasHat(o, Op::WhenShot) || (o.solid && solidKind(o.kind)))) continue;
        float t;
        if (rayBox(e, d, o.pos, o.scale * .5f, t) && t < best) { best = t; hit = (int)i; }
    }
    if (hit >= 0) fireHat(hit, Op::WhenShot);
}

void Game::tap2D(float x, float y) {
    float wx = (x - .5f) * stageW(), wy = (.5f - y) * kView2DHeight;
    int best = -1, bestLayer = -1000000;
    for (int i = 0; i < (int)sc->objs.size(); i++) {
        auto& o = sc->objs[i];
        if (!o.alive || !o.visible) continue;
        if (!o.bg && !(std::fabs(wx - o.pos.x) <= o.scale.x * .5f && std::fabs(wy - o.pos.y) <= o.scale.y * .5f)) continue;
        int layer = o.bg ? -1000000 + 1 : o.layer;
        if (layer >= bestLayer && hasHat(o, Op::WhenTap)) { best = i; bestLayer = layer; }
    }
    if (best >= 0) fireHat(best, Op::WhenTap);
}

// ---------------------------------------------------------------- fisica sencilla
void Game::physics(float dt) {
    bool is3 = sc->is3d;
    float ps = is3 ? 1.f : 100.f;
    for (size_t i = 0; i < sc->objs.size(); i++) {
        Obj& o = sc->objs[i];
        ObjState& s = st_[i];
        if (!o.alive) continue;
        if (o.phys == Phys::Dynamic) {
            s.vel.x += gravX_ * ps * dt;
            s.vel.y += gravY_ * ps * dt;
            for (int axis = 0; axis < (is3 ? 3 : 2); axis++) {
                float* p = axis == 0 ? &o.pos.x : axis == 1 ? &o.pos.y : &o.pos.z;
                float* v = axis == 0 ? &s.vel.x : axis == 1 ? &s.vel.y : &s.vel.z;
                float old = *p;
                *p += *v * dt;
                for (size_t j = 0; j < sc->objs.size(); j++) {
                    if (j == i) continue;
                    const Obj& q = sc->objs[j];
                    bool solidWorld = is3 && q.solid && solidKind(q.kind);
                    if (!q.alive || !q.visible || (q.phys == Phys::None && !solidWorld)) continue;
                    if (!overlap(o, q)) continue;
                    *p = old;
                    float e = (o.bounce + q.bounce) * 0.5f;
                    *v = -*v * e;
                    if (std::fabs(*v) < 2.f * ps * 0.05f) *v = 0;
                    float fr = std::min(1.f, (o.friction + q.friction) * 0.5f) * dt * 10.f;
                    if (axis == 1) { s.vel.x *= (1.f - fr); s.vel.z *= (1.f - fr); }
                    else s.vel.y *= (1.f - fr);
                    break;
                }
            }
            if (!is3 && o.pos.y < -50000) o.alive = false;
        }
        if (s.spin != 0) o.yaw += s.spin * dt;
    }
}

void Game::checkConditions() {
    for (size_t i = 0; i < sc->objs.size(); i++) {
        Obj& o = sc->objs[i];
        if (!o.alive) continue;
        for (int h : cmp_[i].hats) {
            const Block& b = o.blocks[h];
            if (b.op == Op::WhenTrue) {
                bool now = eval(b.f[0], (int)i).truthy();
                if (now && !st_[i].hatState[h]) startScript((int)i, h);
                st_[i].hatState[h] = now;
            } else if (b.op == Op::WhenCollide) {
                bool now = false;
                std::string k = normName(b.t);
                if (sc->is3d && (k == "jugador" || k == "player")) {
                    V3 d = o.pos - V3{pos.x, pos.y + 0.85f, pos.z};
                    now = std::fabs(d.x) < o.scale.x * .5f + 0.3f && std::fabs(d.y) < o.scale.y * .5f + 0.85f &&
                          std::fabs(d.z) < o.scale.z * .5f + 0.3f;
                } else {
                    int j = findObj(b.t);
                    now = j >= 0 && j != (int)i && sc->objs[j].alive && sc->objs[j].visible && overlap(o, sc->objs[j]);
                }
                if (now && !st_[i].hatState[h]) startScript((int)i, h);
                st_[i].hatState[h] = now;
            }
        }
    }
}

// ---------------------------------------------------------------- bucle principal
void Game::update(float dt, const Input& in, float aspect) {
    if (aspect > 0.1f) aspect_ = aspect;
    in_ = in;
    if (!pending_.empty()) {
        std::string n = pending_;
        pending_.clear();
        enterScene(n);
    }
    if (!sc) return;
    dt = std::min(dt, 0.05f);
    if (dt > 0) fps_ = fps_ * 0.9f + (1.f / dt) * 0.1f;
    time += dt;
    if (sayT > 0) sayT -= dt;

    if (sc->is3d) {
        yaw += in.lookX;
        pitch = std::max(-1.5f, std::min(1.5f, pitch - in.lookY));
        V3 f{std::sin(yaw), 0, -std::cos(yaw)}, r{std::cos(yaw), 0, std::sin(yaw)};
        V3 w = f * in.moveY + r * in.moveX;
        float l = len(w);
        if (l > 1) w = w * (1.f / l);
        vel.x = w.x * 4.5f;
        vel.z = w.z * 4.5f;
        vel.y -= 20.f * dt;
        if (in.jump && ground) vel.y = 7.f;

        V3 p = pos;
        p.x += vel.x * dt; if (blocked(p)) p.x = pos.x;
        p.z += vel.z * dt; if (blocked(p)) p.z = pos.z;
        V3 q = p;
        q.y += vel.y * dt;
        ground = false;
        if (blocked(q)) { if (vel.y < 0) ground = true; vel.y = 0; }
        else p.y = q.y;
        pos = p;
        if (pos.y < -60) { pos = sc->start; vel = V3(); }

        for (size_t i = 0; i < sc->objs.size(); i++) {  // "Cuando el jugador se acerque"
            auto& o = sc->objs[i];
            if (!o.alive || !hasHat(o, Op::WhenNear)) continue;
            float dx = o.pos.x - pos.x, dz = o.pos.z - pos.z, dy = o.pos.y - (pos.y + 1.f);
            bool isNear = std::sqrt(dx * dx + dz * dz) < 1.2f + .5f * std::max(o.scale.x, o.scale.z) && std::fabs(dy) < 3.f;
            if (isNear && !near_[i]) fireHat((int)i, Op::WhenNear);
            near_[i] = isNear;
        }
        if (in.tap) tap3D();

        shootCd = std::max(0.f, shootCd - dt);
        recoil = std::max(0.f, recoil - dt * 6.f);
        flash = std::max(0.f, flash - dt);
        if (in.shoot && shootCd <= 0 && proj.weapon.enabled) {
            shootCd = proj.weapon.rate;
            recoil = 1.f;
            flash = 0.07f;
            if (onSound) onSound("disparo");
            shoot3D();
        }
    } else if (in.tap) {
        tap2D(in.tapX, in.tapY);
    }

    physics(dt);
    checkConditions();
    for (size_t i = 0; i < runners_.size(); i++) step(runners_[i], dt);
    runners_.erase(std::remove_if(runners_.begin(), runners_.end(), [](const Runner& r) { return r.done; }), runners_.end());
}

// ---------------------------------------------------------------- interprete de bloques
static float wrap360(float d) {
    d = std::fmod(d, 360.f);
    if (d > 180.f) d -= 360.f;
    if (d <= -180.f) d += 360.f;
    return d;
}

void Game::step(Runner& r, float dt) {
    Obj& o = sc->objs[r.obj];
    ObjState& s = st_[r.obj];
    const auto& B = o.blocks;
    const auto& M = cmp_[r.obj].match;
    int self = r.obj;

    if (!r.waitIds.empty()) {
        r.waitIds.erase(std::remove_if(r.waitIds.begin(), r.waitIds.end(), [&](int id) {
            for (auto& q : runners_) if (q.id == id && !q.done) return false;
            return true;
        }), r.waitIds.end());
        if (!r.waitIds.empty()) return;
    }
    if (r.gT > 0) {
        r.gE += dt;
        float t = std::min(1.f, r.gE / r.gT);
        o.pos = r.gFrom + (r.gTo - r.gFrom) * t;
        if (r.gE < r.gT) return;
        r.gT = 0;
    }
    if (r.wait > 0) {
        r.wait -= dt;
        if (r.wait > 0) return;
    }
    bool is3 = sc->is3d;
    int budget = 512;
    while (budget-- > 0) {
        if (r.pc >= r.end) { r.done = true; return; }
        int idx = r.pc;
        const Block& b = B[r.pc++];
        auto F = [&](int k) { return (float)num(b.f[k], self); };
        switch (b.op) {
            // eventos: nunca se ejecutan dentro de un guion
            case Op::WhenStart: case Op::WhenTap: case Op::WhenReceive: case Op::WhenCollide: case Op::WhenTrue:
            case Op::WhenShot: case Op::WhenNear: break;

            // control
            case Op::Wait: r.wait = std::max(0.f, F(0)); if (r.wait > 0) return; break;
            case Op::Broadcast: broadcast(b.t, nullptr); break;
            case Op::BroadcastWait: {
                std::vector<int> ids;
                broadcast(b.t, &ids);
                r.waitIds = ids;
                if (!ids.empty()) return;
                break;
            }
            case Op::Forever: r.loops.push_back({idx, -1}); break;
            case Op::Repeat: {
                int n = (int)F(0);
                if (n <= 0) r.pc = M[idx] + 1;
                else r.loops.push_back({idx, n});
                break;
            }
            case Op::LoopEnd:
                if (!r.loops.empty()) {
                    Loop& l = r.loops.back();
                    if (l.remaining == -1 || --l.remaining > 0) { r.pc = l.start + 1; return; }
                    r.loops.pop_back();
                }
                break;
            case Op::Note: break;
            case Op::If:
                if (!eval(b.f[0], self).truthy()) r.pc = M[idx] + 1;
                break;
            case Op::Else: r.pc = M[idx] + 1; break;
            case Op::EndIf: break;
            case Op::StartScene: pending_ = b.t; r.done = true; return;

            // movimiento
            case Op::PlaceAt: o.pos.x = F(0); o.pos.y = F(1); break;
            case Op::SetX: o.pos.x = F(0); break;
            case Op::SetY: o.pos.y = F(0); break;
            case Op::ChangeX: o.pos.x += F(0); break;
            case Op::ChangeY: o.pos.y += F(0); break;
            case Op::PlaceAt3: o.pos = {F(0), F(1), F(2)}; break;
            case Op::SetZ: o.pos.z = F(0); break;
            case Op::ChangeZ: o.pos.z += F(0); break;
            case Op::Move: {
                float st = F(0), a = o.yaw * kRad;
                o.pos.x += st * std::sin(a);
                if (is3) o.pos.z -= st * std::cos(a); else o.pos.y += st * std::cos(a);
                break;
            }
            case Op::TurnLeft: o.yaw = wrap360(o.yaw - F(0)); break;
            case Op::TurnRight: o.yaw = wrap360(o.yaw + F(0)); break;
            case Op::PointDir: o.yaw = wrap360(F(0)); break;
            case Op::PointTowards: {
                int j = findObj(b.t);
                if (j >= 0) {
                    V3 d = sc->objs[j].pos - o.pos;
                    o.yaw = std::atan2(d.x, is3 ? -d.z : d.y) / kRad;
                }
                break;
            }
            case Op::BounceEdge:
                if (!is3) {
                    float hw = stageW() * .5f, hh = kView2DHeight * .5f;
                    if (o.pos.x + o.scale.x * .5f > hw) { o.pos.x = hw - o.scale.x * .5f; o.yaw = wrap360(-o.yaw); }
                    else if (o.pos.x - o.scale.x * .5f < -hw) { o.pos.x = -hw + o.scale.x * .5f; o.yaw = wrap360(-o.yaw); }
                    if (o.pos.y + o.scale.y * .5f > hh) { o.pos.y = hh - o.scale.y * .5f; o.yaw = wrap360(180.f - o.yaw); }
                    else if (o.pos.y - o.scale.y * .5f < -hh) { o.pos.y = -hh + o.scale.y * .5f; o.yaw = wrap360(180.f - o.yaw); }
                }
                break;
            case Op::GlideTo: {
                float secs = F(0);
                V3 to{F(1), F(2), o.pos.z};
                if (secs <= 0) o.pos = to;
                else { r.gFrom = o.pos; r.gTo = to; r.gT = secs; r.gE = 0; return; }
                break;
            }
            case Op::GoBack: o.layer -= (int)F(0); break;
            case Op::GoFront: {
                int mx = o.layer;
                for (auto& q : sc->objs) if (!q.bg) mx = std::max(mx, q.layer);
                o.layer = mx + 1;
                break;
            }
            case Op::Vibrate: if (onVibrate) onVibrate(F(0)); break;
            case Op::PhysDynamic: o.phys = Phys::Dynamic; break;
            case Op::PhysStatic: o.phys = Phys::Static; break;
            case Op::PhysNone: o.phys = Phys::None; s.vel = V3(); break;
            case Op::SetForce: s.vel.x = F(0); s.vel.y = F(1); break;
            case Op::SpinLeft: s.spin = -F(0); break;
            case Op::SpinRight: s.spin = F(0); break;
            case Op::SetGravity: gravX_ = F(0); gravY_ = F(1); break;
            case Op::SetMass: o.mass = std::max(0.f, F(0)); break;
            case Op::SetBounce: o.bounce = std::max(0.f, F(0) / 100.f); break;
            case Op::SetFriction: o.friction = std::max(0.f, F(0) / 100.f); break;

            // sonido
            case Op::StartSound: if (onSound) onSound(b.t); break;
            case Op::StopSounds: if (onStopSounds) onStopSounds(); if (onMusic) onMusic("", false); break;
            case Op::SetVolume: volume = std::max(0.f, std::min(100.f, F(0))); if (onVolume) onVolume(volume / 100.f); break;
            case Op::ChangeVolume: volume = std::max(0.f, std::min(100.f, volume + F(0))); if (onVolume) onVolume(volume / 100.f); break;
            case Op::Speak: {
                std::string t = eval(b.f[0], self).txt();
                say = t; sayT = 3.f;
                if (onSpeak) onSpeak(t);
                break;
            }
            case Op::Music: if (onMusic) onMusic(b.t, true); break;

            // apariencia
            case Op::NextLook:
                if (!o.looks.empty()) { s.look = (s.look + 1) % (int)o.looks.size(); o.tex = o.looks[s.look]; }
                break;
            case Op::SetLook: {
                auto it = std::find(o.looks.begin(), o.looks.end(), b.t);
                if (it != o.looks.end()) { s.look = (int)(it - o.looks.begin()); o.tex = *it; }
                break;
            }
            case Op::SetSize: s.sizePct = std::max(0.f, F(0)); o.scale = base_[self] * (s.sizePct / 100.f); break;
            case Op::ChangeSize: s.sizePct = std::max(0.f, s.sizePct + F(0)); o.scale = base_[self] * (s.sizePct / 100.f); break;
            case Op::Show: o.visible = true; break;
            case Op::Hide: o.visible = false; break;
            case Op::SetTransp: o.transp = std::max(0.f, std::min(100.f, F(0))); break;
            case Op::ChangeTransp: o.transp = std::max(0.f, std::min(100.f, o.transp + F(0))); break;
            case Op::SetBright: o.bright = std::max(0.f, F(0)); break;
            case Op::ChangeBright: o.bright = std::max(0.f, o.bright + F(0)); break;
            case Op::ClearFx: o.transp = 0; o.bright = 100; o.hue = 0; break;
            case Op::Flash: if (onFlash) onFlash(F(0) != 0); break;
            case Op::ChangeColor: o.hue = std::fmod(o.hue + F(0), 200.f); if (o.hue < 0) o.hue += 200.f; break;
            case Op::Say: say = eval(b.f[0], self).txt(); sayT = 3.f; break;
            case Op::Destroy: o.alive = false; break;

            // datos
            case Op::SetVar: setVar(b.t, eval(b.f[0], self), self); break;
            case Op::ChangeVar: setVar(b.t, Val(getVar(b.t, self).num() + num(b.f[0], self)), self); break;
            case Op::ShowVar: shown[b.t] = {F(0), F(1)}; break;
            case Op::HideVar: shown.erase(b.t); break;
            case Op::Count: break;
        }
    }
}

}  // namespace forge
