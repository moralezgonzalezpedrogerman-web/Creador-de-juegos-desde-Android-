#pragma once
#include "vec.h"
#include <cstdint>
#include <map>
#include <string>
#include <vector>

namespace forge {

enum class Kind { Cube, Floor, Wall, Item, Model, Light, Player };

// ---------------------------------------------------------------- bloques (como Pocket Code)
// Los bloques de un objeto son una lista PLANA. Un bloque de evento (sombrero) empieza un guion y termina
// en el siguiente evento. Los bucles y los "si" se cierran con bloques propios (Fin del bucle, Fin del si).
enum class Op : int {
    // Eventos
    WhenStart, WhenTap, WhenReceive, WhenCollide, WhenTrue, WhenShot, WhenNear,
    // Control
    Wait, BroadcastWait, Broadcast, Forever, Repeat, LoopEnd, Note, If, Else, EndIf, StartScene,
    // Movimiento
    PlaceAt, SetX, SetY, ChangeX, ChangeY, BounceEdge, Move, TurnLeft, TurnRight, PointDir, PointTowards,
    GlideTo, GoBack, GoFront, Vibrate,
    PhysDynamic, PhysStatic, PhysNone, SetForce, SpinLeft, SpinRight, SetGravity, SetMass, SetBounce, SetFriction,
    PlaceAt3, SetZ, ChangeZ,
    // Sonido
    StartSound, StopSounds, SetVolume, ChangeVolume, Speak, Music,
    // Apariencia
    NextLook, SetSize, ChangeSize, Show, Hide, SetTransp, ChangeTransp, SetBright, ChangeBright, ClearFx,
    SetLook, Flash, ChangeColor, Say, Destroy,
    // Datos
    SetVar, ChangeVar, ShowVar, HideVar,
    // Extras 3D (juego en primera persona)
    WhenInteract, SetSolid, TeleportPlayer, MoveToPlayer,
    Count
};

enum class Cat { Eventos, Control, Movimiento, Sonido, Apariencia, Datos, Forge3D };

// Descripcion de un bloque para el editor y el archivo del proyecto.
// title: texto con huecos {0} {1} {2} (formulas) y {t} (texto: nombre de mensaje, objeto, sonido, variable...).
struct OpInfo {
    Op op;
    const char* key;    // nombre en el archivo
    Cat cat;
    const char* title;
    const char* help;
    const char* t;      // valores por defecto: texto y formulas
    const char* f0;
    const char* f1;
    const char* f2;
    int indent;         // +1 abre, -1 cierra, 0 normal; 2 = evento (sombrero)
};
const OpInfo& opInfo(Op op);
const OpInfo* opInfoByKey(const std::string& key);
const char* catName(Cat c);
bool isHat(Op op);

struct Block {
    Op op = Op::Wait;
    std::string t;       // texto (mensaje, nombre de objeto/sonido/variable/apariencia/escena)
    std::string f[3];    // formulas
};

enum class Phys { None, Dynamic, Static };

struct Obj {
    std::string name = "objeto";
    Kind kind = Kind::Cube;
    V3 pos, scale{1, 1, 1};
    float yaw = 0;      // direccion en grados (2D: 90 = derecha, 0 = arriba; 3D: 0 = hacia -Z)
    float color[3] = {1, 1, 1};
    std::string tex;    // asset png/jpg actual ("" = sin textura)
    std::string model;  // asset .fmdl (modelo 3D importado)
    bool solid = true, visible = true, alive = true, spin = false;
    std::vector<Block> blocks;          // guiones (lista plana)
    std::vector<std::string> looks;     // apariencias (assets de imagen)
    std::vector<std::string> sounds;    // sonidos (assets de audio)
    std::vector<std::string> localVars; // variables solo de este objeto
    Phys phys = Phys::None;
    float mass = 1.f, bounce = 0.5f, friction = 0.2f;
    float transp = 0.f, bright = 100.f, hue = 0.f;  // efectos: transparencia %, brillo %, color
    int layer = 0;                      // orden de dibujo en 2D
    bool bg = false;                    // es el "Fondo" de una escena 2D
};

struct Scene {
    std::string name = "main";
    bool is3d = true;
    V3 sunDir{-0.4f, -1.f, -0.3f};
    float sun[3] = {1.f, 0.95f, 0.85f};
    float skyTop[3] = {0.25f, 0.45f, 0.8f};
    float skyBot[3] = {0.75f, 0.85f, 0.95f};
    float ambient = 0.35f;
    float fog = 0.012f;
    V3 start{0, 0.05f, 0};
    std::vector<Obj> objs;
};

// Botones tactiles en pantalla (escenas 3D).
enum class HudAct { None, Jump, Shoot, Interact };
struct HudBtn {
    std::string label = "OK";
    float x = 0.5f, y = 0.5f, r = 0.08f;  // centro (0..1) y radio (fraccion del alto)
    HudAct act = HudAct::None;
    float color[3] = {1, 1, 1};
};

// Arma en primera persona.
struct Weapon {
    bool enabled = true;
    std::string tex;      // sprite (asset png/jpg); vacio = arma basica dibujada
    float scale = 0.5f;   // alto del sprite (fraccion del alto de pantalla)
    float ox = 0, oy = 0; // desplazamiento (fraccion de pantalla)
    float rate = 0.25f;   // segundos entre disparos
    float range = 60.f;
};

using Files = std::map<std::string, std::vector<uint8_t>>;

struct Project {
    std::string name = "juego";
    std::vector<Scene> scenes;
    Files assets;  // texturas, sonidos, modelos
    bool hudDefault = true;       // true = botones por defecto (saltar y disparar)
    std::vector<HudBtn> hud;      // botones propios (si hudDefault == false; vacio = sin botones)
    Weapon weapon;
    bool showVars = false;
    std::vector<std::string> globalVars;  // variables para todos los objetos y escenas
};

std::vector<HudBtn> defaultHud();

bool loadProject(const Files& files, Project& out, std::string& err);
std::string writeProject(const Project& p);  // genera project.forge
bool loadDemo(Project& out);

const char* kindName(Kind k);

}  // namespace forge
