#include "formula.h"
#include <algorithm>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <memory>
#include <random>
#include <unordered_map>

namespace forge {

// ------------------------------------------------------------------ Val
static bool looksNumeric(const std::string& s, double& v) {
    if (s.empty()) return false;
    char* e = nullptr;
    v = strtod(s.c_str(), &e);
    while (e && *e == ' ') e++;
    return e && *e == 0 && e != s.c_str();
}

double Val::num() const {
    if (!str) return n;
    double v = 0;
    return looksNumeric(s, v) ? v : 0.0;
}

static std::string fmtNum(double v) {
    char b[64];
    if (std::fabs(v) < 1e15 && v == std::floor(v)) snprintf(b, sizeof b, "%lld", (long long)v);
    else snprintf(b, sizeof b, "%.6g", v);
    return b;
}

std::string Val::txt() const { return str ? s : fmtNum(n); }

// ------------------------------------------------------------------ catalogo
static const std::vector<FuncDef> kFuncs = {
    {"MATEMÁTICAS", "sen(0)"}, {"MATEMÁTICAS", "coseno(0)"}, {"MATEMÁTICAS", "tan(0)"}, {"MATEMÁTICAS", "ln(0)"},
    {"MATEMÁTICAS", "log(0)"}, {"MATEMÁTICAS", "Pi"}, {"MATEMÁTICAS", "raiz cuadrada(4)"},
    {"MATEMÁTICAS", "valor aleatorio desde hasta(0,1)"}, {"MATEMÁTICAS", "ABS(0)"}, {"MATEMÁTICAS", "redondear(1.6)"},
    {"MATEMÁTICAS", "round to(123.456, 1)"}, {"MATEMÁTICAS", "mod(1,1)"}, {"MATEMÁTICAS", "arcsen(0.5)"},
    {"MATEMÁTICAS", "arccos(0)"}, {"MATEMÁTICAS", "arctan(1)"}, {"MATEMÁTICAS", "arctangent2(-1, 0)"},
    {"MATEMÁTICAS", "exp(0)"}, {"MATEMÁTICAS", "potencia(2,3)"}, {"MATEMÁTICAS", "suelo(0.7)"},
    {"MATEMÁTICAS", "techo(0.3)"}, {"MATEMÁTICAS", "to hex(175)"}, {"MATEMÁTICAS", "from hex('AF')"},
    {"MATEMÁTICAS", "máximo de(0,1)"}, {"MATEMÁTICAS", "mínimo de(7,2)"}, {"MATEMÁTICAS", "clamp(-2,2,10)"},

    {"STRINGS (CADENAS)", "longitud('Hola mundo')"}, {"STRINGS (CADENAS)", "letra(1, 'Hola mundo')"},
    {"STRINGS (CADENAS)", "subtext(3,5,'hello world')"}, {"STRINGS (CADENAS)", "upper case('aboudna')"},
    {"STRINGS (CADENAS)", "lower case('SIGMA')"}, {"STRINGS (CADENAS)", "reverse('olleH')"},
    {"STRINGS (CADENAS)", "unir('hola',' mundo')"}, {"STRINGS (CADENAS)", "unir('hola',' mundo','!')"},
    {"STRINGS (CADENAS)", "replace('pandas love bamboo','love','eat')"},
    {"STRINGS (CADENAS)", "string contains('bats are cutest!','cute')"}, {"STRINGS (CADENAS)", "repeat text('ab', 10)"},
    {"STRINGS (CADENAS)", "random string(15)"}, {"STRINGS (CADENAS)", "levenshtein distance('panda', 'lavanda')"},
    {"STRINGS (CADENAS)", "join numbers(1,1)"},

    {"SENSORES DEL DISPOSITIVO", "volumen"}, {"SENSORES DEL DISPOSITIVO", "tocar_dedos"},
    {"SENSORES DEL DISPOSITIVO", "stage width"}, {"SENSORES DEL DISPOSITIVO", "stage height"},
    {"SENSORES DEL DISPOSITIVO", "micro volume"}, {"SENSORES DEL DISPOSITIVO", "micro frequency"},
    {"SENSORES DEL DISPOSITIVO", "local server ip"}, {"SENSORES DEL DISPOSITIVO", "local server port"},
    {"SENSORES DEL DISPOSITIVO", "battery percentage"}, {"SENSORES DEL DISPOSITIVO", "connected to internet"},
    {"SENSORES DEL DISPOSITIVO", "cpu architecture"}, {"SENSORES DEL DISPOSITIVO", "FPS"},
    {"SENSORES DEL DISPOSITIVO", "clipboard_text"}, {"SENSORES DEL DISPOSITIVO", "keyboard_height"},
    {"SENSORES DEL DISPOSITIVO", "color a x y(100,200)"},
    {"SENSORES DEL DISPOSITIVO", "color es igual a color con % tolerancia('#ff0000','#fe0000',1)"},
    {"SENSORES DEL DISPOSITIVO", "acceleracion x"}, {"SENSORES DEL DISPOSITIVO", "acceleracion y"},
    {"SENSORES DEL DISPOSITIVO", "acceleracion_z"}, {"SENSORES DEL DISPOSITIVO", "inclinacion x"},
    {"SENSORES DEL DISPOSITIVO", "inclinacion y"}, {"SENSORES DEL DISPOSITIVO", "dirección_compass"},
    {"SENSORES DEL DISPOSITIVO", "latitud"}, {"SENSORES DEL DISPOSITIVO", "longitud"},
    {"SENSORES DEL DISPOSITIVO", "precision_localizacion"}, {"SENSORES DEL DISPOSITIVO", "altitud"},
    {"SENSORES DEL DISPOSITIVO", "idioma del usuario"},

    {"DETECCIÓN DEL TACTO", "toque pantalla x"}, {"DETECCIÓN DEL TACTO", "toque pantalla y"},
    {"DETECCIÓN DEL TACTO", "pantalla_tocada"}, {"DETECCIÓN DEL TACTO", "toque pantalla x(1)"},
    {"DETECCIÓN DEL TACTO", "toque pantalla y(1)"}, {"DETECCIÓN DEL TACTO", "pantalla_tocada(1)"},
    {"DETECCIÓN DEL TACTO", "ultimo_indice_de_toque_pantalla"}, {"DETECCIÓN DEL TACTO", "número de toques actuales"},
    {"DETECCIÓN DEL TACTO", "índice del toque actual(1)"},

    {"FECHA Y HORA", "cronómetro"}, {"FECHA Y HORA", "año"}, {"FECHA Y HORA", "mes"}, {"FECHA Y HORA", "día"},
    {"FECHA Y HORA", "día de la semana"}, {"FECHA Y HORA", "hora"}, {"FECHA Y HORA", "minuto"},
    {"FECHA Y HORA", "segundo"},

    {"PROPIEDADES DE ASPECTO", "get_object_name"}, {"PROPIEDADES DE ASPECTO", "dirección de la mirada"},
    {"PROPIEDADES DE ASPECTO", "transparencia"}, {"PROPIEDADES DE ASPECTO", "brillo"},
    {"PROPIEDADES DE ASPECTO", "color"}, {"PROPIEDADES DE ASPECTO", "numero_fondo"},
    {"PROPIEDADES DE ASPECTO", "nombre_fondo"}, {"PROPIEDADES DE ASPECTO", "número de fondos"},
    {"PROPIEDADES DE ASPECTO", "color toca el color('#ff0000','#00ff00')"},

    {"PROPIEDADES DE MOVIMIENTO", "posición x"}, {"PROPIEDADES DE MOVIMIENTO", "posición y"},
    {"PROPIEDADES DE MOVIMIENTO", "tamaño"}, {"PROPIEDADES DE MOVIMIENTO", "width"},
    {"PROPIEDADES DE MOVIMIENTO", "height"}, {"PROPIEDADES DE MOVIMIENTO", "dirección"},
    {"PROPIEDADES DE MOVIMIENTO", "capa"}, {"PROPIEDADES DE MOVIMIENTO", "tocar_objeto('Nombre')"},
    {"PROPIEDADES DE MOVIMIENTO", "tocar_bordes"}, {"PROPIEDADES DE MOVIMIENTO", "tocar_dedos"},
    {"PROPIEDADES DE MOVIMIENTO", "touches_object_by_name('Nombre')"},
    {"PROPIEDADES DE MOVIMIENTO", "velocidad x"}, {"PROPIEDADES DE MOVIMIENTO", "velocidad y"},
    {"PROPIEDADES DE MOVIMIENTO", "velocidad angular"}, {"PROPIEDADES DE MOVIMIENTO", "toca el color('#ff0000')"},

    {"OPERADORES LÓGICOS (BOOLEANOS)", "y"}, {"OPERADORES LÓGICOS (BOOLEANOS)", "o"},
    {"OPERADORES LÓGICOS (BOOLEANOS)", "no"}, {"OPERADORES LÓGICOS (BOOLEANOS)", "verdadero"},
    {"OPERADORES LÓGICOS (BOOLEANOS)", "falso"},
    {"OPERADOR DE COMPARACIÓN", "="}, {"OPERADOR DE COMPARACIÓN", "≠"}, {"OPERADOR DE COMPARACIÓN", "<"},
    {"OPERADOR DE COMPARACIÓN", "≤"}, {"OPERADOR DE COMPARACIÓN", ">"}, {"OPERADOR DE COMPARACIÓN", "≥"},

    {"3D", "delta-time()"}, {"3D", "3D position x('objeto')"}, {"3D", "3D position y('objeto')"},
    {"3D", "3D position z('objeto')"}, {"3D", "3D rotation x('objeto')"}, {"3D", "3D rotation y('objeto')"},
    {"3D", "3D rotation z('objeto')"}, {"3D", "3D scale x('objeto')"}, {"3D", "3D scale y('objeto')"},
    {"3D", "3D scale z('objeto')"}, {"3D", "3D velocity X('objeto')"}, {"3D", "3D velocity Y('objeto')"},
    {"3D", "3D velocity Z('objeto')"}, {"3D", "3D distance between('objeto 1', 'objeto 2')"},
    {"3D", "object touches object('Objeto 1', 'Objeto 2')"}, {"3D", "camera position X()"},
    {"3D", "camera position Y()"}, {"3D", "camera position Z()"}, {"3D", "camera direction X()"},
    {"3D", "camera direction Y()"}, {"3D", "camera direction Z()"}, {"3D", "camera rotation X()"},
    {"3D", "camera rotation Y()"}, {"3D", "camera rotation Z()"}, {"3D", "direction X from angle(60)"},
    {"3D", "direction Y from angle(60)"}, {"3D", "angle from direction(0.6, 1)"},
};

const std::vector<FuncDef>& formulaFunctions() { return kFuncs; }

// ------------------------------------------------------------------ normalizacion
std::string normName(const std::string& in) {
    std::string out;
    for (size_t i = 0; i < in.size(); i++) {
        unsigned char c = (unsigned char)in[i];
        if (c == 0xC3 && i + 1 < in.size()) {
            unsigned char d = (unsigned char)in[i + 1];
            char r = 0;
            switch (d) {
                case 0xA1: case 0x81: r = 'a'; break;
                case 0xA9: case 0x89: r = 'e'; break;
                case 0xAD: case 0x8D: r = 'i'; break;
                case 0xB3: case 0x93: r = 'o'; break;
                case 0xBA: case 0x9A: case 0xBC: case 0x9C: r = 'u'; break;
                case 0xB1: case 0x91: r = 'n'; break;
            }
            if (r) { out += r; i++; continue; }
        }
        out += (char)((c >= 'A' && c <= 'Z') ? c + 32 : c);
    }
    return out;
}

// nombre de funcion de una etiqueta: "valor aleatorio desde hasta(0,1)" -> "valor aleatorio desde hasta"
static std::string labelName(const char* label) {
    std::string s = label;
    size_t p = s.find('(');
    if (p != std::string::npos) s = s.substr(0, p);
    return normName(s);
}

static const std::vector<std::string>& registry() {
    static std::vector<std::string> names = [] {
        std::vector<std::string> v;
        for (auto& f : kFuncs) {
            std::string n = labelName(f.label);
            if (n.empty() || n == "y" || n == "o" || n == "no" || !(std::isalnum((unsigned char)n[0]) || n[0] == '_')) continue;
            if (std::find(v.begin(), v.end(), n) == v.end()) v.push_back(n);
        }
        std::sort(v.begin(), v.end(), [](const std::string& a, const std::string& b) { return a.size() > b.size(); });
        return v;
    }();
    return names;
}

// ------------------------------------------------------------------ tokens
enum class T { Num, Str, Id, QId, Op, LP, RP, Comma, End, Bad };
enum Opr { ADD, SUB, MUL, DIV, POW, EQ, NE, LT, LE, GT, GE, AND, OR, NOT };

struct Tok {
    T t = T::End;
    double n = 0;
    std::string s;
    int op = 0;
};

static bool isWordCh(char c) { return std::isalnum((unsigned char)c) || c == '_'; }

static std::vector<Tok> lex(const std::string& src) {
    // normalizar con mapa hacia el texto original (para conservar los textos entre comillas)
    std::string ns;
    std::vector<size_t> map;
    for (size_t i = 0; i < src.size(); i++) {
        unsigned char c = (unsigned char)src[i];
        std::string piece;
        size_t adv = 1;
        if (c == 0xE2 && i + 2 < src.size() && (unsigned char)src[i + 1] == 0x89) {
            unsigned char d = (unsigned char)src[i + 2];
            if (d == 0xA0) { piece = "!="; adv = 3; }
            else if (d == 0xA4) { piece = "<="; adv = 3; }
            else if (d == 0xA5) { piece = ">="; adv = 3; }
        } else if (c == 0xC3 && i + 1 < src.size() && (unsigned char)src[i + 1] == 0xB7) { piece = "/"; adv = 2; }
        else if (c == 0xC3 && i + 1 < src.size() && (unsigned char)src[i + 1] == 0x97) { piece = "*"; adv = 2; }
        if (piece.empty()) {
            std::string one = normName(src.substr(i, c == 0xC3 && i + 1 < src.size() ? 2 : 1));
            if (c == 0xC3 && i + 1 < src.size() && one.size() == 1) adv = 2;
            else if (c == 0xC3) one = src.substr(i, 1);
            piece = one.empty() ? src.substr(i, 1) : one;
        }
        for (char ch : piece) { ns += ch; map.push_back(i); }
        i += adv - 1;
    }
    map.push_back(src.size());

    std::vector<Tok> out;
    size_t p = 0;
    auto push = [&](T t, const std::string& s = "", double n = 0, int op = 0) {
        Tok k; k.t = t; k.s = s; k.n = n; k.op = op; out.push_back(k);
    };
    while (p < ns.size()) {
        char c = ns[p];
        if (c == ' ' || c == '\t' || c == '\n' || c == '\r') { p++; continue; }
        // nombres del catalogo (pueden tener espacios o empezar con 3D)
        if (std::isalpha((unsigned char)c) || c == '_' || std::isdigit((unsigned char)c)) {
            bool matched = false;
            for (auto& name : registry()) {
                if (ns.compare(p, name.size(), name) == 0 &&
                    (p + name.size() >= ns.size() || !isWordCh(ns[p + name.size()]) || !isWordCh(name.back()))) {
                    push(T::Id, name);
                    p += name.size();
                    matched = true;
                    break;
                }
            }
            if (matched) continue;
        }
        if (std::isdigit((unsigned char)c) || (c == '.' && p + 1 < ns.size() && std::isdigit((unsigned char)ns[p + 1]))) {
            size_t q = p;
            while (q < ns.size() && (std::isdigit((unsigned char)ns[q]) || ns[q] == '.')) q++;
            push(T::Num, "", atof(ns.substr(p, q - p).c_str()));
            p = q;
            continue;
        }
        if (c == '\'' || c == '"') {
            size_t q = ns.find(c, p + 1);
            if (q == std::string::npos) { push(T::Bad); break; }
            std::string orig = src.substr(map[p + 1], map[q] - map[p + 1]);
            push(c == '\'' ? T::Str : T::QId, c == '\'' ? orig : normName(orig));
            if (c == '"') out.back().n = 0;
            p = q + 1;
            continue;
        }
        if (std::isalpha((unsigned char)c) || c == '_') {
            size_t q = p;
            while (q < ns.size() && (isWordCh(ns[q]) || ns[q] == '.')) q++;
            std::string w = ns.substr(p, q - p);
            if (w == "y") push(T::Op, "", 0, AND);
            else if (w == "o") push(T::Op, "", 0, OR);
            else if (w == "no") push(T::Op, "", 0, NOT);
            else push(T::Id, w);
            p = q;
            continue;
        }
        p++;
        switch (c) {
            case '+': push(T::Op, "", 0, ADD); break;
            case '-': push(T::Op, "", 0, SUB); break;
            case '*': push(T::Op, "", 0, MUL); break;
            case '/': push(T::Op, "", 0, DIV); break;
            case '^': push(T::Op, "", 0, POW); break;
            case '(': push(T::LP); break;
            case ')': push(T::RP); break;
            case ',': push(T::Comma); break;
            case '=': if (p < ns.size() && ns[p] == '=') p++; push(T::Op, "", 0, EQ); break;
            case '!': if (p < ns.size() && ns[p] == '=') { p++; push(T::Op, "", 0, NE); } else push(T::Bad); break;
            case '<':
                if (p < ns.size() && ns[p] == '=') { p++; push(T::Op, "", 0, LE); }
                else if (p < ns.size() && ns[p] == '>') { p++; push(T::Op, "", 0, NE); }
                else push(T::Op, "", 0, LT);
                break;
            case '>': if (p < ns.size() && ns[p] == '=') { p++; push(T::Op, "", 0, GE); } else push(T::Op, "", 0, GT); break;
            default: push(T::Bad);
        }
    }
    push(T::End);
    return out;
}

// ------------------------------------------------------------------ arbol
struct Node;
using NP = std::shared_ptr<Node>;
struct Node {
    enum K { Num, Str, Id, QId, Call, Un, Bin } k = Num;
    double n = 0;
    std::string s;
    int op = 0;
    bool paren = false;
    std::vector<NP> a;
};

struct Parser {
    std::vector<Tok> t;
    size_t i = 0;
    bool ok = true;

    const Tok& cur() const { return t[i]; }
    bool isOp(int o) const { return cur().t == T::Op && cur().op == o; }

    NP mk(Node::K k) { auto n = std::make_shared<Node>(); n->k = k; return n; }

    NP orExpr() {
        NP l = andExpr();
        while (ok && isOp(OR)) { i++; NP r = andExpr(); NP n = mk(Node::Bin); n->op = OR; n->a = {l, r}; l = n; }
        return l;
    }
    NP andExpr() {
        NP l = cmpExpr();
        while (ok && isOp(AND)) { i++; NP r = cmpExpr(); NP n = mk(Node::Bin); n->op = AND; n->a = {l, r}; l = n; }
        return l;
    }
    NP cmpExpr() {
        NP l = addExpr();
        while (ok && cur().t == T::Op && cur().op >= EQ && cur().op <= GE) {
            int o = cur().op; i++;
            NP r = addExpr(); NP n = mk(Node::Bin); n->op = o; n->a = {l, r}; l = n;
        }
        return l;
    }
    NP addExpr() {
        NP l = mulExpr();
        while (ok && (isOp(ADD) || isOp(SUB))) {
            int o = cur().op; i++;
            NP r = mulExpr(); NP n = mk(Node::Bin); n->op = o; n->a = {l, r}; l = n;
        }
        return l;
    }
    NP mulExpr() {
        NP l = powExpr();
        while (ok && (isOp(MUL) || isOp(DIV))) {
            int o = cur().op; i++;
            NP r = powExpr(); NP n = mk(Node::Bin); n->op = o; n->a = {l, r}; l = n;
        }
        return l;
    }
    NP powExpr() {
        NP l = unary();
        if (ok && isOp(POW)) { i++; NP r = powExpr(); NP n = mk(Node::Bin); n->op = POW; n->a = {l, r}; return n; }
        return l;
    }
    NP unary() {
        if (isOp(SUB) || isOp(NOT) || isOp(ADD)) {
            int o = cur().op; i++;
            NP e = unary();
            if (o == ADD) return e;
            NP n = mk(Node::Un); n->op = o; n->a = {e}; return n;
        }
        return primary();
    }
    NP primary() {
        const Tok& k = cur();
        if (k.t == T::Num) { NP n = mk(Node::Num); n->n = k.n; i++; return n; }
        if (k.t == T::Str) { NP n = mk(Node::Str); n->s = k.s; i++; return n; }
        if (k.t == T::QId) { NP n = mk(Node::QId); n->s = k.s; i++; return n; }
        if (k.t == T::LP) {
            i++;
            NP e = orExpr();
            if (cur().t != T::RP) { ok = false; return e; }
            i++;
            return e;
        }
        if (k.t == T::Id) {
            NP n = mk(Node::Id);
            n->s = k.s;
            i++;
            if (cur().t == T::LP) {
                i++;
                n->k = Node::Call;
                n->paren = true;
                if (cur().t != T::RP) {
                    for (;;) {
                        n->a.push_back(orExpr());
                        if (!ok) return n;
                        if (cur().t == T::Comma) { i++; continue; }
                        break;
                    }
                }
                if (cur().t != T::RP) { ok = false; return n; }
                i++;
            }
            return n;
        }
        ok = false;
        return mk(Node::Num);
    }
};

static std::unordered_map<std::string, NP>& cache() {
    static std::unordered_map<std::string, NP> c;
    return c;
}

static NP compile(const std::string& src) {
    auto& c = cache();
    auto it = c.find(src);
    if (it != c.end()) return it->second;
    Parser p;
    p.t = lex(src);
    NP root;
    bool bad = false;
    for (auto& k : p.t) if (k.t == T::Bad) bad = true;
    if (!bad && p.t.size() > 1) {
        root = p.orExpr();
        if (!p.ok || p.cur().t != T::End) root = nullptr;
    }
    if (c.size() > 4096) c.clear();
    c[src] = root;
    return root;
}

bool formulaValid(const std::string& src) {
    bool allSpace = true;
    for (char ch : src) if (ch != ' ') allSpace = false;
    return allSpace || compile(src) != nullptr;
}

// ------------------------------------------------------------------ evaluacion
static std::mt19937& rng() {
    static std::mt19937 r(std::random_device{}());
    return r;
}

static const double kPi = 3.14159265358979323846;
static double rad(double d) { return d * kPi / 180.0; }
static double deg(double r) { return r * 180.0 / kPi; }

static int levenshtein(const std::string& a, const std::string& b) {
    std::vector<int> prev(b.size() + 1), cur(b.size() + 1);
    for (size_t j = 0; j <= b.size(); j++) prev[j] = (int)j;
    for (size_t i = 1; i <= a.size(); i++) {
        cur[0] = (int)i;
        for (size_t j = 1; j <= b.size(); j++)
            cur[j] = std::min({prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + (a[i - 1] == b[j - 1] ? 0 : 1)});
        prev = cur;
    }
    return prev[b.size()];
}

static bool builtinFn(const std::string& n, const std::vector<Val>& a, Val& out) {
    auto N = [&](size_t i) { return i < a.size() ? a[i].num() : 0.0; };
    auto S = [&](size_t i) { return i < a.size() ? a[i].txt() : std::string(); };
    if (n == "sen") out = std::sin(rad(N(0)));
    else if (n == "coseno") out = std::cos(rad(N(0)));
    else if (n == "tan") out = std::tan(rad(N(0)));
    else if (n == "ln") out = N(0) > 0 ? std::log(N(0)) : 0;
    else if (n == "log") out = N(0) > 0 ? std::log10(N(0)) : 0;
    else if (n == "raiz cuadrada") out = N(0) >= 0 ? std::sqrt(N(0)) : 0;
    else if (n == "valor aleatorio desde hasta") {
        double lo = std::min(N(0), N(1)), hi = std::max(N(0), N(1));
        bool ints = lo == std::floor(lo) && hi == std::floor(hi);
        if (ints) out = (double)std::uniform_int_distribution<long long>((long long)lo, (long long)hi)(rng());
        else out = std::uniform_real_distribution<double>(lo, hi)(rng());
    }
    else if (n == "abs") out = std::fabs(N(0));
    else if (n == "redondear") out = std::floor(N(0) + 0.5);
    else if (n == "round to") { double m = std::pow(10.0, N(1)); out = std::floor(N(0) * m + 0.5) / m; }
    else if (n == "mod") { double b = N(1); out = b == 0 ? 0 : N(0) - b * std::floor(N(0) / b); }
    else if (n == "arcsen") out = deg(std::asin(std::max(-1.0, std::min(1.0, N(0)))));
    else if (n == "arccos") out = deg(std::acos(std::max(-1.0, std::min(1.0, N(0)))));
    else if (n == "arctan") out = deg(std::atan(N(0)));
    else if (n == "arctangent2") out = deg(std::atan2(N(0), N(1)));
    else if (n == "exp") out = std::exp(N(0));
    else if (n == "potencia") out = std::pow(N(0), N(1));
    else if (n == "suelo") out = std::floor(N(0));
    else if (n == "techo") out = std::ceil(N(0));
    else if (n == "to hex") { char b[32]; snprintf(b, sizeof b, "%llX", (unsigned long long)N(0)); out = Val::text(b); }
    else if (n == "from hex") out = (double)strtoull(S(0).c_str(), nullptr, 16);
    else if (n == "maximo de") out = std::max(N(0), N(1));
    else if (n == "minimo de") out = std::min(N(0), N(1));
    else if (n == "clamp") out = std::max(std::min(N(1), N(2)), std::min(N(0), std::max(N(1), N(2))));
    else if (n == "pi") out = kPi;
    else if (n == "verdadero") out = 1;
    else if (n == "falso") out = 0;
    else if (n == "longitud") out = (double)S(0).size();
    else if (n == "letra") { int i = (int)N(0); std::string s = S(1); out = Val::text(i >= 1 && i <= (int)s.size() ? s.substr(i - 1, 1) : ""); }
    else if (n == "subtext") {
        int st = (int)N(0), ln = (int)N(1);
        std::string s = S(2);
        if (st < 1) st = 1;
        out = Val::text(st <= (int)s.size() && ln > 0 ? s.substr(st - 1, ln) : "");
    }
    else if (n == "upper case") { std::string s = S(0); for (auto& c : s) c = (char)std::toupper((unsigned char)c); out = Val::text(s); }
    else if (n == "lower case") { std::string s = S(0); for (auto& c : s) c = (char)std::tolower((unsigned char)c); out = Val::text(s); }
    else if (n == "reverse") { std::string s = S(0); std::reverse(s.begin(), s.end()); out = Val::text(s); }
    else if (n == "unir") { std::string s; for (auto& v : a) s += v.txt(); out = Val::text(s); }
    else if (n == "replace") {
        std::string s = S(0), f = S(1), r = S(2);
        if (!f.empty()) {
            size_t p = 0;
            while ((p = s.find(f, p)) != std::string::npos) { s.replace(p, f.size(), r); p += r.size(); }
        }
        out = Val::text(s);
    }
    else if (n == "string contains") out = S(0).find(S(1)) != std::string::npos ? 1 : 0;
    else if (n == "repeat text") { std::string s, t = S(0); for (int i = 0; i < (int)N(1) && i < 1000; i++) s += t; out = Val::text(s); }
    else if (n == "random string") {
        std::string s;
        for (int i = 0; i < (int)N(0) && i < 1000; i++) s += (char)('a' + std::uniform_int_distribution<int>(0, 25)(rng()));
        out = Val::text(s);
    }
    else if (n == "levenshtein distance") out = levenshtein(S(0), S(1));
    else if (n == "join numbers") out = Val::text(fmtNum(N(0)) + fmtNum(N(1)));
    else if (n == "direction x from angle") out = std::sin(rad(N(0)));
    else if (n == "direction y from angle") out = std::cos(rad(N(0)));
    else if (n == "angle from direction") out = deg(std::atan2(N(0), N(1)));
    else return false;
    return true;
}

static Val evalNode(const Node& nd, FormulaEnv* env, int depth);

static Val evalBin(const Node& nd, FormulaEnv* env, int depth) {
    Val l = evalNode(*nd.a[0], env, depth + 1);
    if (nd.op == AND) { if (!l.truthy()) return 0; return evalNode(*nd.a[1], env, depth + 1).truthy() ? 1 : 0; }
    if (nd.op == OR) { if (l.truthy()) return 1; return evalNode(*nd.a[1], env, depth + 1).truthy() ? 1 : 0; }
    Val r = evalNode(*nd.a[1], env, depth + 1);
    switch (nd.op) {
        case ADD: return l.num() + r.num();
        case SUB: return l.num() - r.num();
        case MUL: return l.num() * r.num();
        case DIV: return r.num() == 0 ? 0.0 : l.num() / r.num();
        case POW: return std::pow(l.num(), r.num());
    }
    double a, b;
    bool numeric = (!l.str || looksNumeric(l.s, a)) && (!r.str || looksNumeric(r.s, b));
    int c;
    if (numeric) {
        double x = l.num(), y = r.num();
        c = std::fabs(x - y) < 1e-9 ? 0 : (x < y ? -1 : 1);
    } else {
        int cmp = l.txt().compare(r.txt());
        c = cmp < 0 ? -1 : cmp > 0 ? 1 : 0;
    }
    switch (nd.op) {
        case EQ: return c == 0 ? 1 : 0;
        case NE: return c != 0 ? 1 : 0;
        case LT: return c < 0 ? 1 : 0;
        case LE: return c <= 0 ? 1 : 0;
        case GT: return c > 0 ? 1 : 0;
        case GE: return c >= 0 ? 1 : 0;
    }
    return 0;
}

static Val evalNode(const Node& nd, FormulaEnv* env, int depth) {
    if (depth > 64) return 0;
    switch (nd.k) {
        case Node::Num: return nd.n;
        case Node::Str: return Val::text(nd.s);
        case Node::Un: {
            Val v = evalNode(*nd.a[0], env, depth + 1);
            return nd.op == SUB ? Val(-v.num()) : Val(v.truthy() ? 0.0 : 1.0);
        }
        case Node::Bin: return evalBin(nd, env, depth);
        case Node::QId: {  // "variable"
            Val out;
            if (env && env->lookup(std::string("\"") + nd.s, {}, out)) return out;
            return Val::text(nd.s);
        }
        case Node::Id:
        case Node::Call: {
            std::vector<Val> args;
            for (auto& c : nd.a) args.push_back(evalNode(*c, env, depth + 1));
            Val out;
            if (builtinFn(nd.s, args, out)) return out;
            if (env && env->lookup(nd.s, args, out)) return out;
            return Val::text(nd.s);  // desconocido: se toma como texto
        }
    }
    return 0;
}

Val evalFormula(const std::string& src, FormulaEnv* env) {
    bool blank = true;
    for (char c : src) if (c != ' ') blank = false;
    if (blank) return Val(0.0);
    NP root = compile(src);
    if (!root) return Val::text(src);  // no es formula: se usa como texto
    return evalNode(*root, env, 0);
}

}  // namespace forge
