// Capa Android: NativeActivity + EGL/OpenGL ES 3 + ImGui. Dos modos:
//  - Editor (por defecto): la app Forge para crear juegos.
//  - Juego independiente: si el APK trae los assets "standalone" y "game.pack", solo ejecuta ese juego.
#include <EGL/egl.h>
#include <android/asset_manager.h>
#include <android/configuration.h>
#include <android/log.h>
#include <android_native_app_glue.h>
#include <jni.h>

#include <algorithm>
#include <chrono>
#include <deque>
#include <memory>
#include <mutex>
#include <utility>

#include "audio.h"
#include "editor.h"
#include "imgui.h"
#include "imgui_impl_android.h"
#include "imgui_impl_opengl3.h"
#include "pack.h"
#include "playview.h"
#include "renderer.h"

#ifndef EGL_OPENGL_ES3_BIT
#define EGL_OPENGL_ES3_BIT 0x40
#endif
#define LOG(...) __android_log_print(ANDROID_LOG_INFO, "forge", __VA_ARGS__)

using namespace forge;

// ---- archivos que llegan desde Java (hilo de Java -> hilo del juego)
static std::mutex gFileMx;
static std::deque<std::pair<std::string, std::vector<uint8_t>>> gFiles;

extern "C" JNIEXPORT void JNICALL Java_com_forge_maker_ForgeActivity_nativeOnFile(JNIEnv* env, jclass, jstring name,
                                                                                    jbyteArray data) {
    const char* n = env->GetStringUTFChars(name, nullptr);
    std::string nm = n ? n : "archivo";
    if (n) env->ReleaseStringUTFChars(name, n);
    jsize len = env->GetArrayLength(data);
    std::vector<uint8_t> bytes((size_t)len);
    if (len > 0) env->GetByteArrayRegion(data, 0, len, (jbyte*)bytes.data());
    std::lock_guard<std::mutex> lk(gFileMx);
    gFiles.emplace_back(std::move(nm), std::move(bytes));
}

// ---- texto escrito en el cuadro nativo (Java -> hilo del juego)
static std::mutex gTextMx;
static std::deque<std::pair<std::string, bool>> gTexts;

extern "C" JNIEXPORT void JNICALL Java_com_forge_maker_ForgeActivity_nativeOnText(JNIEnv* env, jclass, jstring text,
                                                                                    jboolean ok) {
    const char* n = text ? env->GetStringUTFChars(text, nullptr) : nullptr;
    std::string t = n ? n : "";
    if (n) env->ReleaseStringUTFChars(text, n);
    std::lock_guard<std::mutex> lk(gTextMx);
    gTexts.emplace_back(std::move(t), ok == JNI_TRUE);
}

struct App {
    android_app* a = nullptr;
    EGLDisplay dpy = EGL_NO_DISPLAY;
    EGLSurface surf = EGL_NO_SURFACE;
    EGLContext ctx = EGL_NO_CONTEXT;
    int w = 1, h = 1;
    bool ready = false, standalone = false, imguiOn = false, kbd = false;
    float scale = 2.f;
    Renderer rend;
    Audio audio;
    std::unique_ptr<Editor> editor;
    PlayView pv;  // modo independiente
    JNIEnv* env = nullptr;
};

static int64_t nowMs() {
    using namespace std::chrono;
    return duration_cast<milliseconds>(steady_clock::now().time_since_epoch()).count();
}

static bool readAsset(App& s, const char* name, std::vector<uint8_t>& out) {
    AAsset* as = AAssetManager_open(s.a->activity->assetManager, name, AASSET_MODE_BUFFER);
    if (!as) return false;
    const uint8_t* b = (const uint8_t*)AAsset_getBuffer(as);
    out.assign(b, b + AAsset_getLength(as));
    AAsset_close(as);
    return true;
}

static bool hasAsset(App& s, const char* name) {
    AAsset* as = AAssetManager_open(s.a->activity->assetManager, name, AASSET_MODE_UNKNOWN);
    if (!as) return false;
    AAsset_close(as);
    return true;
}

static bool initEGL(App& s) {
    s.dpy = eglGetDisplay(EGL_DEFAULT_DISPLAY);
    eglInitialize(s.dpy, nullptr, nullptr);
    // RGB888 + profundidad de 16 bits: menos memoria de video.
    const EGLint attr[] = {EGL_RENDERABLE_TYPE, EGL_OPENGL_ES3_BIT, EGL_SURFACE_TYPE, EGL_WINDOW_BIT,
                           EGL_RED_SIZE, 8, EGL_GREEN_SIZE, 8, EGL_BLUE_SIZE, 8, EGL_DEPTH_SIZE, 16, EGL_NONE};
    EGLConfig cfg;
    EGLint n = 0;
    if (!eglChooseConfig(s.dpy, attr, &cfg, 1, &n) || n < 1) return false;
    EGLint fmt;
    eglGetConfigAttrib(s.dpy, cfg, EGL_NATIVE_VISUAL_ID, &fmt);
    ANativeWindow_setBuffersGeometry(s.a->window, 0, 0, fmt);
    s.surf = eglCreateWindowSurface(s.dpy, cfg, s.a->window, nullptr);
    const EGLint ca[] = {EGL_CONTEXT_CLIENT_VERSION, 3, EGL_NONE};
    s.ctx = eglCreateContext(s.dpy, cfg, EGL_NO_CONTEXT, ca);
    if (s.surf == EGL_NO_SURFACE || s.ctx == EGL_NO_CONTEXT) return false;
    return eglMakeCurrent(s.dpy, s.surf, s.surf, s.ctx) == EGL_TRUE;
}

static void termEGL(App& s) {
    if (s.imguiOn) {
        ImGui_ImplOpenGL3_Shutdown();
        ImGui_ImplAndroid_Shutdown();
        s.imguiOn = false;
    }
    s.rend.shutdown();
    if (s.dpy != EGL_NO_DISPLAY) {
        eglMakeCurrent(s.dpy, EGL_NO_SURFACE, EGL_NO_SURFACE, EGL_NO_CONTEXT);
        if (s.ctx != EGL_NO_CONTEXT) eglDestroyContext(s.dpy, s.ctx);
        if (s.surf != EGL_NO_SURFACE) eglDestroySurface(s.dpy, s.surf);
        eglTerminate(s.dpy);
    }
    s.dpy = EGL_NO_DISPLAY; s.ctx = EGL_NO_CONTEXT; s.surf = EGL_NO_SURFACE;
}

// ---- llamadas a Java (puente de ForgeActivity)
static void callJavaArg(App& s, const char* method, const char* sig, const char* str, float num, int mode) {
    JavaVM* vm = s.a->activity->vm;
    JNIEnv* env = nullptr;
    if (vm->GetEnv((void**)&env, JNI_VERSION_1_6) != JNI_OK) {
        if (vm->AttachCurrentThread(&env, nullptr) != JNI_OK) return;
    }
    jobject obj = s.a->activity->clazz;
    jclass cls = env->GetObjectClass(obj);
    jmethodID m = env->GetMethodID(cls, method, sig);
    if (m) {
        if (mode == 0) { jstring j = env->NewStringUTF(str); env->CallVoidMethod(obj, m, j); env->DeleteLocalRef(j); }
        else if (mode == 1) env->CallVoidMethod(obj, m, (jfloat)num);
        else env->CallVoidMethod(obj, m, (jboolean)(num != 0.f));
    }
    if (env->ExceptionCheck()) env->ExceptionClear();
    env->DeleteLocalRef(cls);
}

static void callJava(App& s, const char* method, const char* sig, const char* a1 = nullptr, const char* a2 = nullptr) {
    JavaVM* vm = s.a->activity->vm;
    JNIEnv* env = nullptr;
    if (vm->GetEnv((void**)&env, JNI_VERSION_1_6) != JNI_OK) {
        if (vm->AttachCurrentThread(&env, nullptr) != JNI_OK) return;
    }
    jobject obj = s.a->activity->clazz;
    jclass cls = env->GetObjectClass(obj);
    jmethodID m = env->GetMethodID(cls, method, sig);
    if (m) {
        jstring j1 = a1 ? env->NewStringUTF(a1) : nullptr, j2 = a2 ? env->NewStringUTF(a2) : nullptr;
        if (a2) env->CallVoidMethod(obj, m, j1, j2);
        else env->CallVoidMethod(obj, m);
        if (j1) env->DeleteLocalRef(j1);
        if (j2) env->DeleteLocalRef(j2);
    }
    if (env->ExceptionCheck()) env->ExceptionClear();
    env->DeleteLocalRef(cls);
}

static int pollChar(App& s) {
    JavaVM* vm = s.a->activity->vm;
    JNIEnv* env = nullptr;
    if (vm->GetEnv((void**)&env, JNI_VERSION_1_6) != JNI_OK) return 0;
    jobject obj = s.a->activity->clazz;
    jclass cls = env->GetObjectClass(obj);
    jmethodID m = env->GetMethodID(cls, "pollUnicodeChar", "()I");
    int c = m ? env->CallIntMethod(obj, m) : 0;
    if (env->ExceptionCheck()) env->ExceptionClear();
    env->DeleteLocalRef(cls);
    return c;
}

static void setupImGui(App& s) {
    ImGuiIO& io = ImGui::GetIO();
    ImGui_ImplAndroid_Init(s.a->window);
    ImGui_ImplOpenGL3_Init("#version 300 es");
    s.imguiOn = true;
    (void)io;
}

static void startMode(App& s) {
    if (s.editor || s.pv.game.sc) return;  // ya iniciado (al recuperar la ventana solo se recrea GL)
    s.audio.init();
    int dpi = s.a->config ? AConfiguration_getDensity(s.a->config) : 0;
    if (dpi <= 0 || dpi > 1000) dpi = 320;
    s.scale = std::max(1.5f, std::min(4.f, dpi / 160.f));
    ImGuiIO& io = ImGui::GetIO();
    ImFontConfig fc;
    fc.SizePixels = 13.f * s.scale;
    io.Fonts->AddFontDefault(&fc);
    ImGui::StyleColorsDark();
    ImGui::GetStyle().ScaleAllSizes(s.scale * 0.85f);
    ImGui::GetStyle().WindowRounding = 6;

    std::vector<uint8_t> pk;
    if (hasAsset(s, "standalone") && readAsset(s, "game.pack", pk)) {
        s.standalone = true;
        Project p;
        Files files;
        std::string err;
        if (!packRead(pk.data(), pk.size(), files) || !loadProject(files, p, err)) {
            LOG("game.pack invalido: %s", err.c_str());
            loadDemo(p);
        }
        s.pv.audio = &s.audio;
        s.pv.onVibrate = [&s](float sec) { callJavaArg(s, "vibrate", "(F)V", nullptr, sec, 1); };
        s.pv.onSpeak = [&s](const std::string& t) { callJavaArg(s, "speak", "(Ljava/lang/String;)V", t.c_str(), 0, 0); };
        s.pv.onFlash = [&s](bool on) { callJavaArg(s, "flash", "(Z)V", nullptr, on ? 1.f : 0.f, 2); };
        s.pv.start(std::move(p));
        return;
    }
    EditorHost h;
    h.dataDir = s.a->activity->internalDataPath ? s.a->activity->internalDataPath : "/data/local/tmp";
    h.pickFile = [&s]() { callJava(s, "pickFile", "()V"); };
    h.saveOut = [&s](const std::string& name, const std::string& path) {
        callJava(s, "saveFile", "(Ljava/lang/String;Ljava/lang/String;)V", name.c_str(), path.c_str());
    };
    h.loadRuntime = [&s](std::vector<uint8_t>& out) { return readAsset(s, "forge_runtime.exe", out); };
    h.prompt = [&s](const std::string& title, const std::string& initial) {
        callJava(s, "promptText", "(Ljava/lang/String;Ljava/lang/String;)V", title.c_str(), initial.c_str());
    };
    h.vibrate = [&s](float sec) { callJavaArg(s, "vibrate", "(F)V", nullptr, sec, 1); };
    h.speak = [&s](const std::string& t) { callJavaArg(s, "speak", "(Ljava/lang/String;)V", t.c_str(), 0, 0); };
    h.flash = [&s](bool on) { callJavaArg(s, "flash", "(Z)V", nullptr, on ? 1.f : 0.f, 2); };
    s.editor.reset(new Editor(h));
    s.editor->init(&s.audio);
}

static void onCmd(android_app* a, int32_t cmd) {
    App* s = (App*)a->userData;
    switch (cmd) {
        case APP_CMD_INIT_WINDOW:
            if (a->window && initEGL(*s) && s->rend.init(1024)) {
                setupImGui(*s);
                startMode(*s);
                s->ready = true;
            } else if (a->window) {
                LOG("no se pudo iniciar OpenGL ES 3");
            }
            break;
        case APP_CMD_TERM_WINDOW:
            s->ready = false;
            termEGL(*s);
            break;
        case APP_CMD_PAUSE:
            if (s->editor && s->editor->dirty()) s->editor->saveProject();  // no perder trabajo
            break;
    }
}

static int32_t onInput(android_app* a, AInputEvent* e) {
    App* s = (App*)a->userData;
    if (!s->ready) return 0;
    if (AInputEvent_getType(e) == AINPUT_EVENT_TYPE_MOTION) {
        PlayControls& ctl = s->standalone ? s->pv.ctl : s->editor->controls();
        int32_t act = AMotionEvent_getAction(e);
        int32_t m = act & AMOTION_EVENT_ACTION_MASK;
        int idx = (act & AMOTION_EVENT_ACTION_POINTER_INDEX_MASK) >> AMOTION_EVENT_ACTION_POINTER_INDEX_SHIFT;
        int64_t t = nowMs();
        if (m == AMOTION_EVENT_ACTION_DOWN || m == AMOTION_EVENT_ACTION_POINTER_DOWN) {
            ctl.begin(AMotionEvent_getPointerId(e, idx), AMotionEvent_getX(e, idx), AMotionEvent_getY(e, idx), t);
        } else if (m == AMOTION_EVENT_ACTION_MOVE) {
            for (size_t i = 0; i < AMotionEvent_getPointerCount(e); i++)
                ctl.move(AMotionEvent_getPointerId(e, i), AMotionEvent_getX(e, i), AMotionEvent_getY(e, i));
        } else if (m == AMOTION_EVENT_ACTION_UP || m == AMOTION_EVENT_ACTION_POINTER_UP) {
            ctl.end(AMotionEvent_getPointerId(e, idx), t);
        } else if (m == AMOTION_EVENT_ACTION_CANCEL) {
            for (int i = 0; i < 10; i++) ctl.end(i, t, true);
        }
    }
    if (!s->standalone) ImGui_ImplAndroid_HandleInputEvent(e);  // el editor tambien recibe teclas
    return 1;
}

void android_main(android_app* a) {
    App s;
    s.a = a;
    a->userData = &s;
    a->onAppCmd = onCmd;
    a->onInputEvent = onInput;
    IMGUI_CHECKVERSION();
    ImGui::CreateContext();
    ImGui::GetIO().IniFilename = nullptr;
    auto prev = std::chrono::steady_clock::now();

    while (true) {
        int events;
        android_poll_source* src;
        while (ALooper_pollOnce(s.ready ? 0 : -1, nullptr, &events, (void**)&src) >= 0) {
            if (src) src->process(a, src);
            if (a->destroyRequested) {
                termEGL(s);
                s.editor.reset();
                s.audio.shutdown();
                ImGui::DestroyContext();
                return;
            }
        }
        if (!s.ready) continue;

        EGLint w = 1, h = 1;
        eglQuerySurface(s.dpy, s.surf, EGL_WIDTH, &w);
        eglQuerySurface(s.dpy, s.surf, EGL_HEIGHT, &h);
        s.w = w; s.h = h;
        auto now = std::chrono::steady_clock::now();
        float dt = std::chrono::duration<float>(now - prev).count();
        prev = now;
        if (dt > 0.1f) dt = 0.1f;

        ImGuiIO& io = ImGui::GetIO();
        if (s.editor) {
            // archivos elegidos en el selector
            for (;;) {
                std::pair<std::string, std::vector<uint8_t>> f;
                {
                    std::lock_guard<std::mutex> lk(gFileMx);
                    if (gFiles.empty()) break;
                    f = std::move(gFiles.front());
                    gFiles.pop_front();
                }
                s.editor->onFile(f.first, std::move(f.second));
            }
            for (;;) {
                std::pair<std::string, bool> t;
                {
                    std::lock_guard<std::mutex> lk(gTextMx);
                    if (gTexts.empty()) break;
                    t = std::move(gTexts.front());
                    gTexts.pop_front();
                }
                s.editor->onText(t.first, t.second);
            }
            for (int c; (c = pollChar(s)) != 0;) io.AddInputCharacter((unsigned)c);
        }

        ImGui_ImplOpenGL3_NewFrame();
        ImGui_ImplAndroid_NewFrame();
        ImGui::NewFrame();
        if (s.standalone) {
            s.pv.frame(&s.rend, w, h, dt);
        } else {
            s.editor->frame(&s.rend, w, h, dt);
            // teclado en pantalla solo mientras se escribe en un campo de texto
            if (io.WantTextInput != s.kbd) {
                s.kbd = io.WantTextInput;
                if (s.kbd) ANativeActivity_showSoftInput(a->activity, ANATIVEACTIVITY_SHOW_SOFT_INPUT_FORCED);
                else ANativeActivity_hideSoftInput(a->activity, 0);
            }
        }
        ImGui::Render();
        ImGui_ImplOpenGL3_RenderDrawData(ImGui::GetDrawData());
        eglSwapBuffers(s.dpy, s.surf);
    }
}
