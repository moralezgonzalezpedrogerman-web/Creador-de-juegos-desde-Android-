package com.forge.maker;

import android.app.NativeActivity;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.hardware.camera2.CameraManager;
import android.os.Build;
import android.os.Bundle;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.speech.tts.TextToSpeech;
import java.util.Locale;
import android.provider.OpenableColumns;
import android.view.KeyCharacterMap;
import android.view.KeyEvent;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.concurrent.ConcurrentLinkedQueue;

/**
 * Unico codigo Java de la app: el motor es C++ (NativeActivity). Esta clase solo hace de puente
 * para lo que Android solo ofrece por Java: el selector de archivos, guardar archivos y teclas de texto.
 */
public class ForgeActivity extends NativeActivity {
    private static final int REQ_PICK = 4101, REQ_SAVE = 4102;
    private static final long MAX_IMPORT = 96L * 1024 * 1024;
    private final ConcurrentLinkedQueue<Integer> chars = new ConcurrentLinkedQueue<>();
    private String pendingSavePath;

    private static native void nativeOnFile(String name, byte[] data);

    private TextToSpeech tts;
    private boolean ttsReady = false;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        try {
            tts = new TextToSpeech(this, status -> {
                if (status == TextToSpeech.SUCCESS) { ttsReady = true; tts.setLanguage(Locale.getDefault()); }
            });
        } catch (Throwable t) { tts = null; }
    }

    // ---- servicios del dispositivo para los bloques (vibrar, hablar, linterna)
    public void vibrate(final float seconds) {
        runOnUiThread(() -> {
            try {
                Vibrator v = (Vibrator) getSystemService(VIBRATOR_SERVICE);
                if (v == null) return;
                long ms = Math.max(1, Math.min(5000, (long) (seconds * 1000)));
                if (Build.VERSION.SDK_INT >= 26) v.vibrate(VibrationEffect.createOneShot(ms, VibrationEffect.DEFAULT_AMPLITUDE));
                else v.vibrate(ms);
            } catch (Throwable t) { }
        });
    }

    public void speak(final String text) {
        runOnUiThread(() -> {
            try { if (tts != null && ttsReady) tts.speak(text, TextToSpeech.QUEUE_ADD, null, "forge"); } catch (Throwable t) { }
        });
    }

    public void flash(final boolean on) {
        runOnUiThread(() -> {
            try {
                CameraManager cm = (CameraManager) getSystemService(CAMERA_SERVICE);
                String[] ids = cm.getCameraIdList();
                if (ids.length > 0) cm.setTorchMode(ids[0], on);
            } catch (Throwable t) { }
        });
    }

    // ---- llamados desde C++ (cualquier hilo)
    public void pickFile() {
        runOnUiThread(() -> {
            Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            i.addCategory(Intent.CATEGORY_OPENABLE);
            i.setType("*/*");
            startActivityForResult(i, REQ_PICK);
        });
    }

    public void saveFile(final String displayName, final String path) {
        runOnUiThread(() -> {
            pendingSavePath = path;
            Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
            i.addCategory(Intent.CATEGORY_OPENABLE);
            i.setType("application/octet-stream");
            i.putExtra(Intent.EXTRA_TITLE, displayName);
            startActivityForResult(i, REQ_SAVE);
        });
    }

    /** Siguiente caracter escrito (0 si no hay): lo usa ImGui para los campos de texto. */
    public int pollUnicodeChar() {
        Integer c = chars.poll();
        return c == null ? 0 : c;
    }

    @Override
    public boolean dispatchKeyEvent(KeyEvent e) {
        if (e.getAction() == KeyEvent.ACTION_DOWN) {
            int u = e.getUnicodeChar(e.getMetaState());
            if (u >= 32 && (u & KeyCharacterMap.COMBINING_ACCENT) == 0) chars.add(u);
        }
        return super.dispatchKeyEvent(e);
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (res != RESULT_OK || data == null || data.getData() == null) return;
        final Uri uri = data.getData();
        if (req == REQ_PICK) {
            new Thread(() -> {
                try {
                    String name = "archivo";
                    try (Cursor c = getContentResolver().query(uri, null, null, null, null)) {
                        if (c != null && c.moveToFirst()) {
                            int ix = c.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                            if (ix >= 0) name = c.getString(ix);
                        }
                    }
                    ByteArrayOutputStream bo = new ByteArrayOutputStream();
                    try (InputStream in = getContentResolver().openInputStream(uri)) {
                        byte[] buf = new byte[65536];
                        int n;
                        long total = 0;
                        while ((n = in.read(buf)) > 0) {
                            total += n;
                            if (total > MAX_IMPORT) return;
                            bo.write(buf, 0, n);
                        }
                    }
                    nativeOnFile(name, bo.toByteArray());
                } catch (Exception ex) {
                    // el editor simplemente no recibe el archivo
                }
            }).start();
        } else if (req == REQ_SAVE && pendingSavePath != null) {
            final String src = pendingSavePath;
            new Thread(() -> {
                try (InputStream in = new FileInputStream(new File(src));
                     OutputStream out = getContentResolver().openOutputStream(uri)) {
                    byte[] buf = new byte[65536];
                    int n;
                    while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
                } catch (Exception ex) {
                }
            }).start();
        }
    }
}
