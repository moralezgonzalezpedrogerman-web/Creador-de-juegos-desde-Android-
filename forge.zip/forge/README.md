# Forge

Creador de juegos para Android con motor propio en C++ (sin Unity/Godot).

- **Editor por páginas** (como Pocket Code): Proyecto → Escenas → Escena (Fondo + Actores y objetos) → Objeto con pestañas Scripts / Apariencias / Sonidos.
- **Bloques en español** (Eventos, Control, Movimiento, Sonido, Apariencia, Datos + extras 3D), se ordenan **arrastrando** el asa `=`; tocar el asa da ayuda, duplicar y eliminar.
- **Editor de fórmulas** con teclado de calculadora y listas Funciones / Objeto / Dispositivo / Lógica / Datos.
- Escenas **2D** (menús, juegos planos) y **3D** (niveles en primera persona), que pueden alternarse con "Iniciar escena".
- Exporta a APK (GitHub Actions) y a .exe (el .exe se arma dentro de la app).

## Compilar
Sube a tu repositorio solo `forge.zip` y `.github/workflows/build.yml`; el workflow descomprime y compila (pruebas, runtime de Windows y APK).

## Pruebas locales
`cmake -S tests -B build-tests && cmake --build build-tests && ctest --test-dir build-tests`

## Pendiente
Editor 3D de rejilla estilo FPS Creator, pintor de texturas, listas, lápiz, cámara y sensores en los bloques.
