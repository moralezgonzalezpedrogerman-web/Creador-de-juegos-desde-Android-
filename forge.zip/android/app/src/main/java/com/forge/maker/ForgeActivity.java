package com.forge.maker;

import android.app.NativeActivity;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.hardware.camera2.CameraManager;
import android.os.Build;
import android.os.Bundle;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.speech.tts.TextToSpeech;
import java.util.Locale;
import android.provider.OpenableColumns;
import android.view.KeyCharacterMap;
import android.view.KeyEvent;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.concurrent.ConcurrentLinkedQueue;

/**
 * Unico codigo Java de la app: el motor es C++ (NativeActivity). Esta clase solo hace de puente
 * para lo que Android solo ofrece por Java: el selector de archivos, guardar archivos y teclas de texto.
 */
public class ForgeActivity extends NativeActivity {
    private static final int REQ_PICK = 4101, REQ_SAVE = 4102;
    private static final long MAX_IMPORT = 1500L * 1024 * 1024;
    private final ConcurrentLinkedQueue<Integer> chars = new ConcurrentLinkedQueue<>();
    private String pendingSavePath;

    private static native void nativeOnFile(String name, byte[] data);
    private static native void nativeOnFilePath(String name, String path);  // path vacio = solo avisar
    private static native void nativeOnText(String text, boolean ok);

    // Sin esto, Android no encuentra los metodos nativos (la libreria la carga NativeActivity por su cuenta)
    // y la app se cerraba al elegir un archivo.
    static {
        try { System.loadLibrary("forge"); } catch (Throwable t) { }
    }

    private TextToSpeech tts;
    private boolean ttsReady = false;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setVolumeControlStream(android.media.AudioManager.STREAM_MUSIC);  // los botones de volumen suben/bajan la musica
        try {
            tts = new TextToSpeech(this, status -> {
                if (status == TextToSpeech.SUCCESS) { ttsReady = true; tts.setLanguage(Locale.getDefault()); }
            });
        } catch (Throwable t) { tts = null; }
    }

    // ---- video (lo usa el motor C++ por JNI)
    private VideoBridge video;
    private synchronized VideoBridge vb() { if (video == null) video = new VideoBridge(getCacheDir()); return video; }
    public boolean videoOpen(int id, byte[] data, String name) { return vb().open(id, data, name); }
    public void videoControl(int id, int cmd, float arg) { vb().control(id, cmd, arg); }
    public int[] videoInfo(int id) { return vb().info(id); }
    public byte[] videoFrame(int id) { return vb().frame(id); }
    public void videoClose(int id) { vb().close(id); }
    public void videoPauseAll() { vb().pauseAll(); }
    public void videoResumeAll() { vb().resumeAll(); }

    // ---- servicios del dispositivo para los bloques (vibrar, hablar, linterna)
    public void vibrate(final float seconds) {
        runOnUiThread(() -> {
            try {
                Vibrator v = (Vibrator) getSystemService(VIBRATOR_SERVICE);
                if (v == null) return;
                long ms = Math.max(1, Math.min(5000, (long) (seconds * 1000)));
                if (Build.VERSION.SDK_INT >= 26) v.vibrate(VibrationEffect.createOneShot(ms, VibrationEffect.DEFAULT_AMPLITUDE));
                else v.vibrate(ms);
            } catch (Throwable t) { }
        });
    }

    public void speak(final String text) {
        runOnUiThread(() -> {
            try { if (tts != null && ttsReady) tts.speak(text, TextToSpeech.QUEUE_ADD, null, "forge"); } catch (Throwable t) { }
        });
    }

    public void flash(final boolean on) {
        runOnUiThread(() -> {
            try {
                CameraManager cm = (CameraManager) getSystemService(CAMERA_SERVICE);
                String[] ids = cm.getCameraIdList();
                if (ids.length > 0) cm.setTorchMode(ids[0], on);
            } catch (Throwable t) { }
        });
    }

    // ---- cuadro de texto nativo (teclado del telefono): lo usan todos los campos de texto del editor
    public void promptText(final String title, final String initial) {
        runOnUiThread(() -> {
            try {
                final android.widget.EditText et = new android.widget.EditText(this);
                et.setSingleLine(true);
                et.setText(initial);
                et.setSelection(et.getText().length());
                et.setImeOptions(android.view.inputmethod.EditorInfo.IME_ACTION_DONE);
                final boolean[] done = {false};
                final android.app.AlertDialog d = new android.app.AlertDialog.Builder(this)
                    .setTitle(title)
                    .setView(et)
                    .setPositiveButton("Aceptar", (dlg, w) -> { done[0] = true; try { nativeOnText(et.getText().toString(), true); } catch (Throwable t) { } })
                    .setNegativeButton("Cancelar", (dlg, w) -> { })
                    .setOnDismissListener(dlg -> { if (!done[0]) { try { nativeOnText("", false); } catch (Throwable t) { } } })
                    .create();
                d.getWindow().setSoftInputMode(android.view.WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE);
                et.setOnEditorActionListener((v, a, ev) -> {
                    if (a == android.view.inputmethod.EditorInfo.IME_ACTION_DONE) {
                        done[0] = true;
                        try { nativeOnText(et.getText().toString(), true); } catch (Throwable t) { }
                        d.dismiss();
                        return true;
                    }
                    return false;
                });
                d.show();
                et.requestFocus();
            } catch (Throwable t) {
                try { nativeOnText("", false); } catch (Throwable t2) { }
            }
        });
    }

    // ---- crear el APK del juego dentro del telefono (ver ApkPatcher)
    private static volatile String apkStatus = "";

    /** Vacio mientras trabaja; "OK:ruta" o "ERROR:mensaje" al terminar. */
    public String buildApkStatus() { return apkStatus; }

    public void buildApk(final String packPath, final String label, final String appId, final String iconPath,
                         final String verName, final String outName, final int orient, final int verCode) {
        apkStatus = "";
        new Thread(() -> {
            try {
                String src = getApplicationInfo().sourceDir;
                File tpl = new File(src);
                if (!tpl.canRead()) throw new java.io.IOException("No se puede leer el APK instalado (la plantilla)");
                byte[] pack = readAll(new File(packPath));
                byte[] icon = (iconPath != null && iconPath.length() > 0) ? readAll(new File(iconPath)) : null;
                java.util.Map<String, byte[]> extra = new java.util.LinkedHashMap<>();
                extra.put("assets/game.pack", pack);
                extra.put("assets/standalone", new byte[]{'1'});
                byte[] keyB, certB;
                try (InputStream in = getAssets().open("apk_sign_key.pk8")) { keyB = readAll(in); }
                try (InputStream in = getAssets().open("apk_sign_cert.der")) { certB = readAll(in); }
                java.security.PrivateKey key = java.security.KeyFactory.getInstance("RSA")
                        .generatePrivate(new java.security.spec.PKCS8EncodedKeySpec(keyB));
                java.security.cert.X509Certificate cert = (java.security.cert.X509Certificate)
                        java.security.cert.CertificateFactory.getInstance("X.509").generateCertificate(new java.io.ByteArrayInputStream(certB));
                ApkPatcher.Config c = new ApkPatcher.Config();
                c.label = label; c.appId = appId; c.verName = verName; c.verCode = verCode; c.orient = orient;
                c.oldPackage = getPackageName();
                File dir = ApkProvider.exportDir(this);
                File out = new File(dir, outName);
                ApkPatcher.build(tpl, extra, icon, c, key, cert, out);
                String note = (icon != null && !ApkPatcher.lastIconReplaced) ? "|AVISO: no se encontro el icono en la plantilla; se dejo el de P-Maker" : "";
                apkStatus = "OK:" + out.getAbsolutePath() + note;
            } catch (Throwable t) {
                apkStatus = "ERROR:" + t.getClass().getSimpleName() + ": " + t.getMessage();
            }
        }).start();
    }

    private static byte[] readAll(File f) throws java.io.IOException {
        try (InputStream in = new FileInputStream(f)) { return readAll(in); }
    }

    private static byte[] readAll(InputStream in) throws java.io.IOException {
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        byte[] buf = new byte[65536];
        int n;
        while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
        return bo.toByteArray();
    }

    /** Abre el instalador de Android con el APK creado. */
    public void installApk(final String path) {
        runOnUiThread(() -> {
            try {
                if (Build.VERSION.SDK_INT >= 26 && !getPackageManager().canRequestPackageInstalls()) {
                    Intent s = new Intent(android.provider.Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:" + getPackageName()));
                    startActivity(s);  // el usuario permite instalar desde P-Maker y vuelve a pulsar "Instalar"
                    return;
                }
                Uri u = Uri.parse("content://" + getPackageName() + ".apkprovider/export/" + new File(path).getName());
                Intent i = new Intent(Intent.ACTION_VIEW);
                i.setDataAndType(u, "application/vnd.android.package-archive");
                i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(i);
            } catch (Throwable t) { }
        });
    }

    // ---- llamados desde C++ (cualquier hilo)
    public void pickFile() {
        runOnUiThread(() -> {
            Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            i.addCategory(Intent.CATEGORY_OPENABLE);
            i.setType("*/*");
            startActivityForResult(i, REQ_PICK);
        });
    }

    public void saveFile(final String displayName, final String path) {
        runOnUiThread(() -> {
            pendingSavePath = path;
            Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
            i.addCategory(Intent.CATEGORY_OPENABLE);
            i.setType("application/octet-stream");
            i.putExtra(Intent.EXTRA_TITLE, displayName);
            startActivityForResult(i, REQ_SAVE);
        });
    }

    /** Siguiente caracter escrito (0 si no hay): lo usa ImGui para los campos de texto. */
    public int pollUnicodeChar() {
        Integer c = chars.poll();
        return c == null ? 0 : c;
    }

    @Override
    public boolean dispatchKeyEvent(KeyEvent e) {
        if (e.getAction() == KeyEvent.ACTION_DOWN) {
            int u = e.getUnicodeChar(e.getMetaState());
            if (u >= 32 && (u & KeyCharacterMap.COMBINING_ACCENT) == 0) chars.add(u);
        }
        return super.dispatchKeyEvent(e);
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (res != RESULT_OK || data == null || data.getData() == null) return;
        final Uri uri = data.getData();
        if (req == REQ_PICK) {
            new Thread(() -> {
                try {
                    String name = "archivo";
                    try (Cursor c = getContentResolver().query(uri, null, null, null, null)) {
                        if (c != null && c.moveToFirst()) {
                            int ix = c.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                            if (ix >= 0) name = c.getString(ix);
                        }
                    }
                    nativeOnFilePath("\u0001START", "");
                    // se copia a un archivo temporal (sin cargarlo en la memoria de Java: sirve para archivos de cientos de MB)
                    File tmp = new File(getCacheDir(), "import.tmp");
                    try (InputStream in = getContentResolver().openInputStream(uri);
                         OutputStream out = new java.io.FileOutputStream(tmp)) {
                        byte[] buf = new byte[1 << 17];
                        int n;
                        long total = 0;
                        while ((n = in.read(buf)) > 0) {
                            total += n;
                            if (total > MAX_IMPORT) { nativeOnFilePath("\u0001FAIL", "El archivo es demasiado grande"); return; }
                            out.write(buf, 0, n);
                        }
                    }
                    nativeOnFilePath(name, tmp.getAbsolutePath());
                } catch (Throwable ex) {
                    nativeOnFilePath("\u0001FAIL", "No se pudo leer el archivo (" + ex.getClass().getSimpleName() + ")");
                }
            }).start();
        } else if (req == REQ_SAVE && pendingSavePath != null) {
            final String src = pendingSavePath;
            new Thread(() -> {
                try (InputStream in = new FileInputStream(new File(src));
                     OutputStream out = getContentResolver().openOutputStream(uri)) {
                    byte[] buf = new byte[65536];
                    int n;
                    while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
                } catch (Exception ex) {
                }
            }).start();
        }
    }
}
