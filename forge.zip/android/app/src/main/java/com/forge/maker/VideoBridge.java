package com.forge.maker;

import android.graphics.Bitmap;
import android.media.MediaMetadataRetriever;
import android.media.MediaPlayer;
import java.io.File;
import java.io.FileOutputStream;
import java.util.HashMap;

/**
 * Video para los objetos del juego. MediaPlayer pone el sonido y el reloj; los cuadros se sacan con
 * MediaMetadataRetriever (unos 10-15 por segundo, en baja resolucion) y el motor C++ los sube como textura.
 */
public class VideoBridge {
    static class Vid {
        MediaPlayer mp;
        MediaMetadataRetriever mmr;
        File file;
        int w, h, tw, th;
        volatile boolean playing, finished, alive = true, fresh, wasPlaying;
        volatile byte[] frame;
        volatile int fw, fh;
        volatile long seekReq = -1;
        Thread th_;
    }

    private final HashMap<Integer, Vid> vids = new HashMap<>();
    private final File cache;

    public VideoBridge(File cacheDir) { cache = cacheDir; }

    public synchronized boolean open(int id, byte[] data, String name) {
        close(id);
        try {
            String ext = name.contains(".") ? name.substring(name.lastIndexOf('.')) : ".mp4";
            final Vid v = new Vid();
            v.file = new File(cache, "vid" + id + ext);
            try (FileOutputStream o = new FileOutputStream(v.file)) { o.write(data); }
            v.mp = new MediaPlayer();
            v.mp.setDataSource(v.file.getAbsolutePath());
            v.mp.setLooping(false);
            v.mp.setOnCompletionListener(m -> { v.finished = true; v.playing = false; });
            v.mp.prepare();
            v.mmr = new MediaMetadataRetriever();
            v.mmr.setDataSource(v.file.getAbsolutePath());
            try {
                v.w = Integer.parseInt(v.mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH));
                v.h = Integer.parseInt(v.mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT));
            } catch (Throwable t) { v.w = 640; v.h = 360; }
            float k = Math.min(1f, 480f / Math.max(1, v.w));
            v.tw = Math.max(2, (int) (v.w * k)); v.th = Math.max(2, (int) (v.h * k));
            v.seekReq = 0;
            v.th_ = new Thread(() -> loop(v), "forge-video");
            v.th_.setDaemon(true);
            v.th_.start();
            vids.put(id, v);
            return true;
        } catch (Throwable t) {
            close(id);
            return false;
        }
    }

    private void loop(Vid v) {
        long lastPos = -1;
        while (v.alive) {
            try {
                long posMs;
                boolean need;
                if (v.seekReq >= 0) {
                    posMs = v.seekReq;
                    v.seekReq = -1;
                    need = true;
                    lastPos = -1;
                } else {
                    posMs = v.mp.getCurrentPosition();
                    need = v.playing && posMs != lastPos;
                }
                if (need) {
                    lastPos = posMs;
                    Bitmap b;
                    if (android.os.Build.VERSION.SDK_INT >= 27)
                        b = v.mmr.getScaledFrameAtTime(posMs * 1000L, MediaMetadataRetriever.OPTION_CLOSEST, v.tw, v.th);
                    else
                        b = v.mmr.getFrameAtTime(posMs * 1000L, MediaMetadataRetriever.OPTION_CLOSEST);
                    if (b != null) {
                        int w = b.getWidth(), h = b.getHeight();
                        int[] px = new int[w * h];
                        b.getPixels(px, 0, w, 0, 0, w, h);
                        byte[] out = new byte[w * h * 4];
                        for (int i = 0; i < px.length; i++) {
                            int c = px[i];
                            out[i * 4] = (byte) (c >> 16); out[i * 4 + 1] = (byte) (c >> 8); out[i * 4 + 2] = (byte) c; out[i * 4 + 3] = (byte) 255;
                        }
                        v.fw = w; v.fh = h; v.frame = out; v.fresh = true;
                    }
                }
                Thread.sleep(need ? 15 : 40);
            } catch (Throwable t) {
                try { Thread.sleep(50); } catch (InterruptedException e) { return; }
            }
        }
    }

    public synchronized void control(int id, int cmd, float arg) {
        Vid v = vids.get(id);
        if (v == null) return;
        try {
            if (cmd == 0) { v.finished = false; v.mp.start(); v.playing = true; }
            else if (cmd == 1) { v.mp.pause(); v.playing = false; }
            else if (cmd == 2) { v.mp.pause(); v.mp.seekTo(0); v.playing = false; v.finished = false; v.seekReq = 0; }
            else if (cmd == 3) { v.mp.seekTo((int) (arg * 1000f)); v.finished = false; v.seekReq = (long) (arg * 1000f); }
        } catch (Throwable t) { /* estado raro del reproductor: se ignora */ }
    }

    /** {ancho, alto, hay cuadro nuevo, termino} */
    public synchronized int[] info(int id) {
        Vid v = vids.get(id);
        if (v == null) return new int[] {0, 0, 0, 1};
        return new int[] {v.fw, v.fh, v.fresh ? 1 : 0, v.finished ? 1 : 0};
    }

    public synchronized byte[] frame(int id) {
        Vid v = vids.get(id);
        if (v == null) return null;
        v.fresh = false;
        return v.frame;
    }

    public synchronized void close(int id) {
        Vid v = vids.remove(id);
        if (v == null) return;
        v.alive = false;
        try { v.mp.release(); } catch (Throwable t) { }
        try { v.mmr.release(); } catch (Throwable t) { }
        try { v.file.delete(); } catch (Throwable t) { }
    }

    public synchronized void pauseAll() {
        for (Vid v : vids.values()) {
            v.wasPlaying = v.playing;
            if (v.playing) { try { v.mp.pause(); } catch (Throwable t) { } v.playing = false; }
        }
    }

    public synchronized void resumeAll() {
        for (Vid v : vids.values())
            if (v.wasPlaying) { try { v.mp.start(); } catch (Throwable t) { } v.playing = true; v.wasPlaying = false; }
    }
}
