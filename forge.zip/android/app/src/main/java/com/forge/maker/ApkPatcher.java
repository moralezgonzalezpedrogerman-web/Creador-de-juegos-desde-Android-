package com.forge.maker;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.PrivateKey;
import java.security.Signature;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.zip.CRC32;
import java.util.zip.Deflater;

/**
 * Convierte el APK instalado (plantilla) en el APK de un juego: cambia nombre, paquete, version y orientacion
 * (AndroidManifest binario + resources.arsc), anade game.pack, reescribe el zip alineado y lo firma (esquema v2).
 * No usa clases de Android: se puede probar en cualquier JVM.
 */
public final class ApkPatcher {
    private ApkPatcher() { }

    public static final class Config {
        public String label = "Juego";
        public String appId = "com.mijuego.app";
        public String verName = "1.0";
        public int verCode = 1;
        public int orient = 0;                       // 0 horizontal, 1 vertical, 2 automatica
        public String oldPackage = "com.forge.maker"; // paquete de la plantilla
    }

    // ------------------------------------------------------------------ utilidades
    private static ByteBuffer le(byte[] b) { return ByteBuffer.wrap(b).order(ByteOrder.LITTLE_ENDIAN); }
    private static int u16(byte[] b, int o) { return (b[o] & 0xff) | ((b[o + 1] & 0xff) << 8); }
    private static long u32(byte[] b, int o) { return (u16(b, o) | ((long) u16(b, o + 2) << 16)) & 0xffffffffL; }
    private static void p16(byte[] b, int o, int v) { b[o] = (byte) v; b[o + 1] = (byte) (v >> 8); }
    private static void p32(byte[] b, int o, long v) { p16(b, o, (int) v); p16(b, o + 2, (int) (v >> 16)); }

    // ------------------------------------------------------------------ AndroidManifest.xml binario
    private static final int RES_XML = 0x0003, RES_POOL = 0x0001, RES_MAP = 0x0180, XML_START_ELEMENT = 0x0102;
    private static final int ATTR_LABEL = 0x01010001, ATTR_AUTHORITIES = 0x01010018, ATTR_ORIENT = 0x0101001e,
            ATTR_VERCODE = 0x0101021b, ATTR_VERNAME = 0x0101021c;

    /** Cambia paquete, etiqueta, version y orientacion. Los textos nuevos se anaden al final del pool de strings. */
    public static byte[] patchManifest(byte[] in, Config c) throws IOException {
        if (in.length < 36 || u16(in, 0) != RES_XML) throw new IOException("AndroidManifest.xml no es binario");
        int ps = u16(in, 2);  // cabecera del archivo (8)
        if (u16(in, ps) != RES_POOL) throw new IOException("Falta el pool de strings del manifest");
        int poolSize = (int) u32(in, ps + 4);
        int count = (int) u32(in, ps + 8), styleCount = (int) u32(in, ps + 12);
        long flags = u32(in, ps + 16);
        int strStart = (int) u32(in, ps + 20);
        if (styleCount != 0) throw new IOException("Manifest con estilos: no soportado");
        boolean utf8 = (flags & (1 << 8)) != 0;
        int offBase = ps + u16(in, ps + 2);
        List<byte[]> raw = new ArrayList<>();
        List<String> txt = new ArrayList<>();
        for (int i = 0; i < count; i++) {
            int o = ps + strStart + (int) u32(in, offBase + 4 * i);
            int n = stringLen(in, o, utf8);
            byte[] r = new byte[n];
            System.arraycopy(in, o, r, 0, n);
            raw.add(r);
            txt.add(decode(in, o, utf8));
        }
        byte[] rest = new byte[in.length - (ps + poolSize)];
        System.arraycopy(in, ps + poolSize, rest, 0, rest.length);

        // mapa de recursos: indice de string -> id de atributo
        int[] resId = new int[count];
        int off = 0;
        while (off + 8 <= rest.length) {
            int type = u16(rest, off), size = (int) u32(rest, off + 4);
            if (size < 8) throw new IOException("Chunk invalido");
            if (type == RES_MAP) {
                int n = (size - u16(rest, off + 2)) / 4;
                for (int i = 0; i < n && i < count; i++) resId[i] = (int) u32(rest, off + u16(rest, off + 2) + 4 * i);
            }
            off += size;
        }

        List<String> add = new ArrayList<>();
        int newPkg = -1, newLabel = -1, newVerName = -1, newAuth = -1;
        String oldAuth = c.oldPackage + ".apkprovider";
        String curElem = "";
        boolean sawPkg = false, sawLabel = false;
        off = 0;
        while (off + 8 <= rest.length) {
            int type = u16(rest, off), size = (int) u32(rest, off + 4);
            if (type == XML_START_ELEMENT) {
                int nameIdx = (int) u32(rest, off + 20);
                curElem = nameIdx >= 0 && nameIdx < count ? txt.get(nameIdx) : "";
                int attrStart = off + 16 + u16(rest, off + 24), attrSize = u16(rest, off + 26), attrCount = u16(rest, off + 28);
                for (int a = 0; a < attrCount; a++) {
                    int ao = attrStart + a * attrSize;
                    long ns = u32(rest, ao);
                    int nm = (int) u32(rest, ao + 4);
                    int id = nm >= 0 && nm < count ? resId[nm] : 0;
                    String aname = nm >= 0 && nm < count ? txt.get(nm) : "";
                    int dtype = rest[ao + 15] & 0xff;
                    if (curElem.equals("manifest")) {
                        if (ns == 0xffffffffL && aname.equals("package")) {
                            if (newPkg < 0) { add.add(c.appId); newPkg = count + add.size() - 1; }
                            p32(rest, ao + 8, newPkg); rest[ao + 15] = 3; p32(rest, ao + 16, newPkg);
                            sawPkg = true;
                        } else if (id == ATTR_VERCODE) {
                            p32(rest, ao + 16, c.verCode); rest[ao + 15] = 0x10; p32(rest, ao + 8, 0xffffffffL);
                        } else if (id == ATTR_VERNAME) {
                            if (newVerName < 0) { add.add(c.verName); newVerName = count + add.size() - 1; }
                            p32(rest, ao + 8, newVerName); rest[ao + 15] = 3; p32(rest, ao + 16, newVerName);
                        }
                    } else if (curElem.equals("application") && id == ATTR_LABEL) {
                        if (newLabel < 0) { add.add(c.label); newLabel = count + add.size() - 1; }
                        p32(rest, ao + 8, newLabel); rest[ao + 15] = 3; p32(rest, ao + 16, newLabel);
                        sawLabel = true;
                    } else if (curElem.equals("activity") && id == ATTR_ORIENT) {
                        int v = c.orient == 1 ? 7 : c.orient == 2 ? 10 : 6;  // sensorPortrait / fullSensor / sensorLandscape
                        rest[ao + 15] = 0x10; p32(rest, ao + 16, v); p32(rest, ao + 8, 0xffffffffL);
                    } else if (curElem.equals("provider") && id == ATTR_AUTHORITIES && dtype == 3) {
                        int si = (int) u32(rest, ao + 8);
                        if (si >= 0 && si < count && txt.get(si).equals(oldAuth)) {
                            if (newAuth < 0) { add.add(c.appId + ".apkprovider"); newAuth = count + add.size() - 1; }
                            p32(rest, ao + 8, newAuth); p32(rest, ao + 16, newAuth);
                        }
                    }
                }
            }
            off += size;
        }
        if (!sawPkg) throw new IOException("El manifest de la plantilla no trae el paquete");
        if (!sawLabel) throw new IOException("El manifest de la plantilla no trae la etiqueta de la app");

        // pool nuevo: strings originales tal cual + los nuevos
        for (String s : add) raw.add(encode(s, utf8));
        int n = raw.size();
        int dataLen = 0;
        for (byte[] r : raw) dataLen += r.length;
        int pad = (4 - dataLen % 4) % 4;
        int newStrStart = 28 + 4 * n;
        int newPoolSize = newStrStart + dataLen + pad;
        byte[] pool = new byte[newPoolSize];
        p16(pool, 0, RES_POOL); p16(pool, 2, 28); p32(pool, 4, newPoolSize);
        p32(pool, 8, n); p32(pool, 12, 0);
        p32(pool, 16, flags & ~1L);  // ya no esta ordenado
        p32(pool, 20, newStrStart); p32(pool, 24, 0);
        int cur = 0;
        for (int i = 0; i < n; i++) {
            p32(pool, 28 + 4 * i, cur);
            System.arraycopy(raw.get(i), 0, pool, newStrStart + cur, raw.get(i).length);
            cur += raw.get(i).length;
        }
        byte[] out = new byte[ps + newPoolSize + rest.length];
        System.arraycopy(in, 0, out, 0, ps);
        System.arraycopy(pool, 0, out, ps, newPoolSize);
        System.arraycopy(rest, 0, out, ps + newPoolSize, rest.length);
        p32(out, 4, out.length);
        return out;
    }

    private static int stringLen(byte[] b, int o, boolean utf8) {
        if (utf8) {
            int p = o;
            int l = b[p] & 0xff; p += (l & 0x80) != 0 ? 2 : 1;  // caracteres
            int bl = b[p] & 0xff;
            if ((bl & 0x80) != 0) { bl = ((bl & 0x7f) << 8) | (b[p + 1] & 0xff); p += 2; } else p += 1;
            return (p - o) + bl + 1;
        }
        int l = u16(b, o), p = o + 2;
        if ((l & 0x8000) != 0) { l = ((l & 0x7fff) << 16) | u16(b, o + 2); p += 2; }
        return (p - o) + l * 2 + 2;
    }

    private static String decode(byte[] b, int o, boolean utf8) {
        if (utf8) {
            int p = o;
            int l = b[p] & 0xff; p += (l & 0x80) != 0 ? 2 : 1;
            int bl = b[p] & 0xff;
            if ((bl & 0x80) != 0) { bl = ((bl & 0x7f) << 8) | (b[p + 1] & 0xff); p += 2; } else p += 1;
            return new String(b, p, bl, StandardCharsets.UTF_8);
        }
        int l = u16(b, o), p = o + 2;
        if ((l & 0x8000) != 0) { l = ((l & 0x7fff) << 16) | u16(b, o + 2); p += 2; }
        return new String(b, p, l * 2, StandardCharsets.UTF_16LE);
    }

    private static byte[] encode(String s, boolean utf8) {
        ByteArrayOutputStream o = new ByteArrayOutputStream();
        if (utf8) {
            byte[] u = s.getBytes(StandardCharsets.UTF_8);
            int cl = s.length();
            if (cl > 0x7f) { o.write((cl >> 8) | 0x80); o.write(cl & 0xff); } else o.write(cl);
            if (u.length > 0x7f) { o.write((u.length >> 8) | 0x80); o.write(u.length & 0xff); } else o.write(u.length);
            o.write(u, 0, u.length);
            o.write(0);
        } else {
            int cl = s.length();
            if (cl > 0x7fff) { o.write(cl >> 16 | 0x80); o.write(cl >> 24); o.write(cl); o.write(cl >> 8); }
            else { o.write(cl); o.write(cl >> 8); }
            byte[] u = s.getBytes(StandardCharsets.UTF_16LE);
            o.write(u, 0, u.length);
            o.write(0); o.write(0);
        }
        return o.toByteArray();
    }

    // ------------------------------------------------------------------ resources.arsc
    /** Cambia el nombre de paquete guardado en los chunks de paquete (campo fijo de 128 caracteres UTF-16). */
    public static void patchArsc(byte[] a, Config c) throws IOException {
        if (a.length < 12 || u16(a, 0) != 0x0002) throw new IOException("resources.arsc invalido");
        if (c.appId.length() > 127) throw new IOException("Paquete demasiado largo");
        int off = u16(a, 2);
        boolean any = false;
        while (off + 8 <= a.length) {
            int type = u16(a, off), size = (int) u32(a, off + 4);
            if (size < 8) break;
            if (type == 0x0200 && off + 12 + 256 <= a.length) {
                byte[] nm = c.appId.getBytes(StandardCharsets.UTF_16LE);
                for (int i = 0; i < 256; i++) a[off + 12 + i] = i < nm.length ? nm[i] : 0;
                any = true;
            }
            off += size;
        }
        if (!any) throw new IOException("resources.arsc sin paquete");
    }

    // ------------------------------------------------------------------ zip (lectura cruda y escritura alineada)
    private static final class ZEntry {
        String name;
        int method, flags, time, date, versionMade = 0x0314;
        long crc, csize, usize, localOff, extAttr;
        byte[] data;        // contenido nuevo (null = copiar crudo del original)
        boolean raw() { return data == null; }
    }

    private static List<ZEntry> readCentral(RandomAccessFile f) throws IOException {
        long len = f.length();
        int max = (int) Math.min(len, 65557);
        byte[] tail = new byte[max];
        f.seek(len - max);
        f.readFully(tail);
        int e = -1;
        for (int i = max - 22; i >= 0; i--) if (u32(tail, i) == 0x06054b50L) { e = i; break; }
        if (e < 0) throw new IOException("No es un zip/APK valido");
        int n = u16(tail, e + 10);
        long cdSize = u32(tail, e + 12), cdOff = u32(tail, e + 16);
        if (cdOff == 0xffffffffL) throw new IOException("Zip64 no soportado");
        byte[] cd = new byte[(int) cdSize];
        f.seek(cdOff);
        f.readFully(cd);
        List<ZEntry> list = new ArrayList<>();
        int p = 0;
        for (int i = 0; i < n; i++) {
            if (u32(cd, p) != 0x02014b50L) throw new IOException("Directorio central dañado");
            ZEntry z = new ZEntry();
            z.versionMade = u16(cd, p + 4);
            z.flags = u16(cd, p + 8);
            z.method = u16(cd, p + 10);
            z.time = u16(cd, p + 12); z.date = u16(cd, p + 14);
            z.crc = u32(cd, p + 16); z.csize = u32(cd, p + 20); z.usize = u32(cd, p + 24);
            int nl = u16(cd, p + 28), el = u16(cd, p + 30), cl = u16(cd, p + 32);
            z.extAttr = u32(cd, p + 38);
            z.localOff = u32(cd, p + 42);
            z.name = new String(cd, p + 46, nl, StandardCharsets.UTF_8);
            list.add(z);
            p += 46 + nl + el + cl;
        }
        return list;
    }

    private static byte[] readEntry(RandomAccessFile f, ZEntry z) throws IOException {
        byte[] raw = readRaw(f, z);
        if (z.method == 0) return raw;
        java.util.zip.Inflater inf = new java.util.zip.Inflater(true);
        inf.setInput(raw);
        byte[] out = new byte[(int) z.usize];
        try {
            int n = 0;
            while (n < out.length && !inf.finished()) {
                int r = inf.inflate(out, n, out.length - n);
                if (r == 0 && (inf.needsInput() || inf.needsDictionary())) break;
                n += r;
            }
            if (n != out.length) throw new IOException("Entrada corrupta: " + z.name);
        } catch (java.util.zip.DataFormatException ex) {
            throw new IOException("Entrada corrupta: " + z.name);
        } finally { inf.end(); }
        return out;
    }

    private static byte[] readRaw(RandomAccessFile f, ZEntry z) throws IOException {
        byte[] lh = new byte[30];
        f.seek(z.localOff);
        f.readFully(lh);
        if (u32(lh, 0) != 0x04034b50L) throw new IOException("Cabecera local dañada: " + z.name);
        long dataOff = z.localOff + 30 + u16(lh, 26) + u16(lh, 28);
        byte[] raw = new byte[(int) z.csize];
        f.seek(dataOff);
        f.readFully(raw);
        return raw;
    }

    private static final class CountingOut {
        final RandomAccessFile f;
        long pos = 0;
        CountingOut(RandomAccessFile f) { this.f = f; }
        void write(byte[] b) throws IOException { f.write(b); pos += b.length; }
    }

    private static void writeEntry(CountingOut o, RandomAccessFile src, ZEntry z, List<byte[]> cdOut) throws IOException {
        byte[] stored;
        long crc = z.crc, csize = z.csize, usize = z.usize;
        int method = z.method;
        if (z.raw()) {
            stored = readRaw(src, z);
        } else {
            CRC32 cr = new CRC32();
            cr.update(z.data);
            crc = cr.getValue();
            usize = z.data.length;
            if (method == 0) stored = z.data;
            else {
                Deflater d = new Deflater(6, true);
                d.setInput(z.data); d.finish();
                ByteArrayOutputStream bo = new ByteArrayOutputStream();
                byte[] buf = new byte[65536];
                while (!d.finished()) { int n = d.deflate(buf); bo.write(buf, 0, n); }
                d.end();
                stored = bo.toByteArray();
            }
            csize = stored.length;
        }
        byte[] name = z.name.getBytes(StandardCharsets.UTF_8);
        int align = method != 0 ? 0 : (z.name.endsWith(".so") ? 4096 : 4);
        int pad = 0;
        if (align > 0) {
            long dataPos = o.pos + 30 + name.length;
            pad = (int) ((align - dataPos % align) % align);
            while (pad > 0 && pad < 6) pad += align;
        }
        byte[] extra = new byte[pad];
        if (pad > 0) { p16(extra, 0, 0xD935); p16(extra, 2, pad - 4); p16(extra, 4, align > 4096 ? 4096 : align); }
        int flags = z.flags & 0x0800;
        byte[] lh = new byte[30];
        p32(lh, 0, 0x04034b50L); p16(lh, 4, 20); p16(lh, 6, flags); p16(lh, 8, method);
        p16(lh, 10, z.time); p16(lh, 12, z.date);
        p32(lh, 14, crc); p32(lh, 18, csize); p32(lh, 22, usize);
        p16(lh, 26, name.length); p16(lh, 28, extra.length);
        long localOff = o.pos;
        o.write(lh); o.write(name); o.write(extra); o.write(stored);
        byte[] cd = new byte[46 + name.length];
        p32(cd, 0, 0x02014b50L); p16(cd, 4, 0x0314); p16(cd, 6, 20); p16(cd, 8, flags); p16(cd, 10, method);
        p16(cd, 12, z.time); p16(cd, 14, z.date);
        p32(cd, 16, crc); p32(cd, 20, csize); p32(cd, 24, usize);
        p16(cd, 28, name.length);
        p32(cd, 38, z.raw() ? z.extAttr : 0); p32(cd, 42, localOff);
        System.arraycopy(name, 0, cd, 46, name.length);
        cdOut.add(cd);
    }

    // ------------------------------------------------------------------ firma v2
    private static void put32(ByteArrayOutputStream o, long v) { o.write((int) v); o.write((int) (v >> 8)); o.write((int) (v >> 16)); o.write((int) (v >> 24)); }
    private static void put64(ByteArrayOutputStream o, long v) { put32(o, v & 0xffffffffL); put32(o, v >>> 32); }
    private static byte[] lp(byte[] b) { ByteArrayOutputStream o = new ByteArrayOutputStream(); put32(o, b.length); o.write(b, 0, b.length); return o.toByteArray(); }
    private static byte[] cat(byte[]... parts) { ByteArrayOutputStream o = new ByteArrayOutputStream(); for (byte[] p : parts) o.write(p, 0, p.length); return o.toByteArray(); }

    private static final int CHUNK = 1 << 20;

    private static int digestRange(RandomAccessFile f, long start, long end, MessageDigest md, ByteArrayOutputStream outDigests) throws IOException {
        int chunks = 0;
        byte[] buf = new byte[CHUNK];
        for (long p = start; p < end; p += CHUNK) {
            int n = (int) Math.min(CHUNK, end - p);
            f.seek(p);
            f.readFully(buf, 0, n);
            md.reset();
            md.update((byte) 0xa5);
            md.update(new byte[]{(byte) n, (byte) (n >> 8), (byte) (n >> 16), (byte) (n >> 24)});
            md.update(buf, 0, n);
            byte[] d = md.digest();
            outDigests.write(d, 0, d.length);
            chunks++;
        }
        return chunks;
    }

    private static void signV2(File unsigned, File out, long cdOff, long cdEnd, PrivateKey key, X509Certificate cert) throws Exception {
        try (RandomAccessFile f = new RandomAccessFile(unsigned, "r")) {
            long total = f.length();
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            ByteArrayOutputStream dg = new ByteArrayOutputStream();
            int chunks = digestRange(f, 0, cdOff, md, dg);
            chunks += digestRange(f, cdOff, cdEnd, md, dg);
            chunks += digestRange(f, cdEnd, total, md, dg);  // EOCD: su offset del directorio central ya apunta al inicio del bloque de firma
            md.reset();
            md.update((byte) 0x5a);
            md.update(new byte[]{(byte) chunks, (byte) (chunks >> 8), (byte) (chunks >> 16), (byte) (chunks >> 24)});
            md.update(dg.toByteArray());
            byte[] top = md.digest();

            byte[] digestItem = lp(cat(le32(0x0103), lp(top)));
            byte[] digests = lp(digestItem);
            byte[] certs = lp(lp(cert.getEncoded()));
            byte[] signedData = cat(digests, certs, lp(new byte[0]));  // digests y certs ya llevan su prefijo de longitud
            Signature sg = Signature.getInstance("SHA256withRSA");
            sg.initSign(key);
            sg.update(signedData);
            byte[] sig = sg.sign();
            byte[] sigs = lp(lp(cat(le32(0x0103), lp(sig))));
            byte[] signer = cat(lp(signedData), sigs, lp(cert.getPublicKey().getEncoded()));
            byte[] signers = lp(lp(signer));
            ByteArrayOutputStream pair = new ByteArrayOutputStream();
            put64(pair, 4 + signers.length);
            put32(pair, 0x7109871aL);
            pair.write(signers, 0, signers.length);
            byte[] pairs = pair.toByteArray();
            long blockSize = pairs.length + 8 + 16;
            ByteArrayOutputStream blk = new ByteArrayOutputStream();
            put64(blk, blockSize);
            blk.write(pairs, 0, pairs.length);
            put64(blk, blockSize);
            byte[] magic = "APK Sig Block 42".getBytes(StandardCharsets.US_ASCII);
            blk.write(magic, 0, magic.length);
            byte[] block = blk.toByteArray();

            try (RandomAccessFile o = new RandomAccessFile(out, "rw")) {
                o.setLength(0);
                copy(f, o, 0, cdOff);
                o.write(block);
                copy(f, o, cdOff, cdEnd);
                byte[] eocd = new byte[(int) (total - cdEnd)];
                f.seek(cdEnd);
                f.readFully(eocd);
                p32(eocd, 16, cdOff + block.length);
                o.write(eocd);
            }
        }
    }

    private static byte[] le32(long v) { ByteArrayOutputStream o = new ByteArrayOutputStream(); put32(o, v); return o.toByteArray(); }

    private static void copy(RandomAccessFile in, RandomAccessFile out, long from, long to) throws IOException {
        byte[] buf = new byte[1 << 16];
        in.seek(from);
        for (long p = from; p < to; ) {
            int n = (int) Math.min(buf.length, to - p);
            in.readFully(buf, 0, n);
            out.write(buf, 0, n);
            p += n;
        }
    }

    // ------------------------------------------------------------------ API principal
    /**
     * Crea el APK del juego.
     * @param template  APK instalado (plantilla)
     * @param extra     archivos nuevos dentro del APK (p.ej. "assets/game.pack", "assets/standalone")
     * @param iconPng   icono png (o null); reemplaza res/.../app_icon.png si existe en la plantilla
     */
    public static void build(File template, Map<String, byte[]> extra, byte[] iconPng, Config c,
                             PrivateKey key, X509Certificate cert, File out) throws Exception {
        if (!c.appId.matches("[a-z][a-z0-9_]*(\\.[a-z][a-z0-9_]*)+")) throw new IOException("Paquete invalido: " + c.appId);
        File tmp = new File(out.getPath() + ".tmp");
        try (RandomAccessFile src = new RandomAccessFile(template, "r");
             RandomAccessFile dst = new RandomAccessFile(tmp, "rw")) {
            dst.setLength(0);
            List<ZEntry> in = readCentral(src);
            Map<String, ZEntry> byName = new LinkedHashMap<>();
            for (ZEntry z : in) byName.put(z.name, z);
            ZEntry man = byName.get("AndroidManifest.xml");
            if (man == null) throw new IOException("La plantilla no tiene AndroidManifest.xml");
            ZEntry arsc = byName.get("resources.arsc");
            if (arsc == null) throw new IOException("La plantilla no tiene resources.arsc");

            Map<String, ZEntry> replace = new LinkedHashMap<>();
            ZEntry m2 = newEntry(man, patchManifest(readEntry(src, man), c), man.method);
            replace.put(man.name, m2);
            byte[] arscData = readEntry(src, arsc);
            patchArsc(arscData, c);
            replace.put(arsc.name, newEntry(arsc, arscData, 0));  // debe ir sin comprimir
            boolean iconDone = false;
            if (iconPng != null) {
                for (ZEntry z : in)
                    if (z.name.startsWith("res/") && z.name.endsWith("app_icon.png")) { replace.put(z.name, newEntry(z, iconPng, z.method)); iconDone = true; }
            }
            lastIconReplaced = iconDone;
            for (Map.Entry<String, byte[]> e : extra.entrySet()) {
                ZEntry z = new ZEntry();
                z.name = e.getKey(); z.data = e.getValue();
                z.method = e.getValue().length < 64 ? 0 : 8;
                z.time = 0; z.date = (1 << 5) | 1 | (46 << 9);  // 2026-01-01
                replace.put(z.name, z);
            }

            Set<String> skip = new HashSet<>();
            skip.add("assets/forge_runtime.exe");
            skip.add("assets/apk_sign_key.pk8");
            skip.add("assets/apk_sign_cert.der");
            CountingOut o = new CountingOut(dst);
            List<byte[]> cdList = new ArrayList<>();
            for (ZEntry z : in) {
                String n = z.name;
                if (n.endsWith("/") ) continue;
                if (n.startsWith("META-INF/") && (n.endsWith(".SF") || n.endsWith(".RSA") || n.endsWith(".DSA") || n.endsWith(".EC") || n.equals("META-INF/MANIFEST.MF"))) continue;
                if (skip.contains(n)) continue;
                ZEntry use = replace.containsKey(n) ? replace.remove(n) : z;
                writeEntry(o, src, use, cdList);
            }
            for (ZEntry z : replace.values()) writeEntry(o, src, z, cdList);  // los nuevos
            long cdOff = o.pos;
            for (byte[] cd : cdList) o.write(cd);
            long cdEnd = o.pos;
            byte[] eocd = new byte[22];
            p32(eocd, 0, 0x06054b50L);
            p16(eocd, 8, cdList.size()); p16(eocd, 10, cdList.size());
            p32(eocd, 12, cdEnd - cdOff); p32(eocd, 16, cdOff);
            o.write(eocd);
            dst.getFD().sync();
            dst.close();
            signV2(tmp, out, cdOff, cdEnd, key, cert);
        } finally {
            tmp.delete();
        }
    }

    /** true si el ultimo build encontro y cambio el icono. */
    public static volatile boolean lastIconReplaced = false;

    private static ZEntry newEntry(ZEntry like, byte[] data, int method) {
        ZEntry z = new ZEntry();
        z.name = like.name; z.data = data; z.method = method;
        z.time = like.time; z.date = like.date; z.flags = like.flags;
        return z;
    }
}
