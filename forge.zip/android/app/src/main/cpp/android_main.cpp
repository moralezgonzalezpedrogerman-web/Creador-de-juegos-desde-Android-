// Capa Android: NativeActivity + EGL/OpenGL ES 3 + ImGui. Dos modos:
//  - Editor (por defecto): la app Forge para crear juegos.
//  - Juego independiente: si el APK trae los assets "standalone" y "game.pack", solo ejecuta ese juego.
#include <EGL/egl.h>
#include <android/asset_manager.h>
#include <android/configuration.h>
#include <android/log.h>
#include <android_native_app_glue.h>
#include <jni.h>

#include <algorithm>
#include <cstdio>
#include <chrono>
#include <deque>
#include <memory>
#include <mutex>
#include <utility>

#include "audio.h"
#include "editor.h"
#include "imgui.h"
#include "imgui_impl_android.h"
#include "imgui_impl_opengl3.h"
#include "pack.h"
#include "video.h"
#include "playview.h"
#include "renderer.h"

#ifndef EGL_OPENGL_ES3_BIT
#define EGL_OPENGL_ES3_BIT 0x40
#endif
#define LOG(...) __android_log_print(ANDROID_LOG_INFO, "forge", __VA_ARGS__)

using namespace forge;

// ---- archivos que llegan desde Java (hilo de Java -> hilo del juego)
static std::mutex gFileMx;
static std::deque<std::pair<std::string, std::vector<uint8_t>>> gFiles;

extern "C" JNIEXPORT void JNICALL Java_com_forge_maker_ForgeActivity_nativeOnFile(JNIEnv* env, jclass, jstring name,
                                                                                    jbyteArray data) {
    const char* n = env->GetStringUTFChars(name, nullptr);
    std::string nm = n ? n : "archivo";
    if (n) env->ReleaseStringUTFChars(name, n);
    jsize len = env->GetArrayLength(data);
    std::vector<uint8_t> bytes((size_t)len);
    if (len > 0) env->GetByteArrayRegion(data, 0, len, (jbyte*)bytes.data());
    std::lock_guard<std::mutex> lk(gFileMx);
    gFiles.emplace_back(std::move(nm), std::move(bytes));
}

extern "C" JNIEXPORT void JNICALL Java_com_forge_maker_ForgeActivity_nativeOnFilePath(JNIEnv* env, jclass, jstring name, jstring path) {
    const char* n = env->GetStringUTFChars(name, nullptr);
    std::string nm = n ? n : "archivo";
    if (n) env->ReleaseStringUTFChars(name, n);
    const char* p = env->GetStringUTFChars(path, nullptr);
    std::string ps = p ? p : "";
    if (p) env->ReleaseStringUTFChars(path, p);
    std::vector<uint8_t> bytes;
    if (nm.size() && nm[0] == 1) {  // aviso (inicio / error): el texto del error viaja en 'path'
        bytes.assign(ps.begin(), ps.end());
    } else if (!ps.empty()) {
        FILE* f = fopen(ps.c_str(), "rb");
        if (!f) { nm = "\x01" "FAIL"; std::string m = "No se pudo abrir el archivo copiado"; bytes.assign(m.begin(), m.end()); }
        else {
            fseek(f, 0, SEEK_END);
            long long sz = (long long)ftell(f);
            fseek(f, 0, SEEK_SET);
            try {
                bytes.resize((size_t)sz);
                if (fread(bytes.data(), 1, (size_t)sz, f) != (size_t)sz) throw 1;
            } catch (...) {
                bytes.clear();
                nm = "\x01" "FAIL";
                std::string m = "No hay memoria suficiente para este archivo";
                bytes.assign(m.begin(), m.end());
            }
            fclose(f);
            remove(ps.c_str());
        }
    }
    std::lock_guard<std::mutex> lk(gFileMx);
    gFiles.emplace_back(std::move(nm), std::move(bytes));
}

// ---- texto escrito en el cuadro nativo (Java -> hilo del juego)
static std::mutex gTextMx;
static std::deque<std::pair<std::string, bool>> gTexts;

extern "C" JNIEXPORT void JNICALL Java_com_forge_maker_ForgeActivity_nativeOnText(JNIEnv* env, jclass, jstring text,
                                                                                    jboolean ok) {
    const char* n = text ? env->GetStringUTFChars(text, nullptr) : nullptr;
    std::string t = n ? n : "";
    if (n) env->ReleaseStringUTFChars(text, n);
    std::lock_guard<std::mutex> lk(gTextMx);
    gTexts.emplace_back(std::move(t), ok == JNI_TRUE);
}

struct App {
    android_app* a = nullptr;
    EGLDisplay dpy = EGL_NO_DISPLAY;
    EGLSurface surf = EGL_NO_SURFACE;
    EGLContext ctx = EGL_NO_CONTEXT;
    int w = 1, h = 1;
    bool ready = false, standalone = false, imguiOn = false, kbd = false;
    float scale = 2.f;
    Renderer rend;
    Audio audio;
    std::unique_ptr<Editor> editor;
    PlayView pv;  // modo independiente
    JNIEnv* env = nullptr;
};

static int64_t nowMs() {
    using namespace std::chrono;
    return duration_cast<milliseconds>(steady_clock::now().time_since_epoch()).count();
}

static bool readAsset(App& s, const char* name, std::vector<uint8_t>& out) {
    AAsset* as = AAssetManager_open(s.a->activity->assetManager, name, AASSET_MODE_BUFFER);
    if (!as) return false;
    const uint8_t* b = (const uint8_t*)AAsset_getBuffer(as);
    out.assign(b, b + AAsset_getLength(as));
    AAsset_close(as);
    return true;
}

static bool hasAsset(App& s, const char* name) {
    AAsset* as = AAssetManager_open(s.a->activity->assetManager, name, AASSET_MODE_UNKNOWN);
    if (!as) return false;
    AAsset_close(as);
    return true;
}

static bool initEGL(App& s) {
    s.dpy = eglGetDisplay(EGL_DEFAULT_DISPLAY);
    eglInitialize(s.dpy, nullptr, nullptr);
    // RGB888 + profundidad de 16 bits: menos memoria de video.
    const EGLint attr[] = {EGL_RENDERABLE_TYPE, EGL_OPENGL_ES3_BIT, EGL_SURFACE_TYPE, EGL_WINDOW_BIT,
                           EGL_RED_SIZE, 8, EGL_GREEN_SIZE, 8, EGL_BLUE_SIZE, 8, EGL_DEPTH_SIZE, 16, EGL_NONE};
    EGLConfig cfg;
    EGLint n = 0;
    if (!eglChooseConfig(s.dpy, attr, &cfg, 1, &n) || n < 1) return false;
    EGLint fmt;
    eglGetConfigAttrib(s.dpy, cfg, EGL_NATIVE_VISUAL_ID, &fmt);
    ANativeWindow_setBuffersGeometry(s.a->window, 0, 0, fmt);
    s.surf = eglCreateWindowSurface(s.dpy, cfg, s.a->window, nullptr);
    const EGLint ca[] = {EGL_CONTEXT_CLIENT_VERSION, 3, EGL_NONE};
    s.ctx = eglCreateContext(s.dpy, cfg, EGL_NO_CONTEXT, ca);
    if (s.surf == EGL_NO_SURFACE || s.ctx == EGL_NO_CONTEXT) return false;
    return eglMakeCurrent(s.dpy, s.surf, s.surf, s.ctx) == EGL_TRUE;
}

static void termEGL(App& s) {
    if (s.imguiOn) {
        ImGui_ImplOpenGL3_Shutdown();
        ImGui_ImplAndroid_Shutdown();
        s.imguiOn = false;
    }
    s.rend.shutdown();
    if (s.dpy != EGL_NO_DISPLAY) {
        eglMakeCurrent(s.dpy, EGL_NO_SURFACE, EGL_NO_SURFACE, EGL_NO_CONTEXT);
        if (s.ctx != EGL_NO_CONTEXT) eglDestroyContext(s.dpy, s.ctx);
        if (s.surf != EGL_NO_SURFACE) eglDestroySurface(s.dpy, s.surf);
        eglTerminate(s.dpy);
    }
    s.dpy = EGL_NO_DISPLAY; s.ctx = EGL_NO_CONTEXT; s.surf = EGL_NO_SURFACE;
}

// ---- llamadas a Java (puente de ForgeActivity)
static void callJavaArg(App& s, const char* method, const char* sig, const char* str, float num, int mode) {
    JavaVM* vm = s.a->activity->vm;
    JNIEnv* env = nullptr;
    if (vm->GetEnv((void**)&env, JNI_VERSION_1_6) != JNI_OK) {
        if (vm->AttachCurrentThread(&env, nullptr) != JNI_OK) return;
    }
    jobject obj = s.a->activity->clazz;
    jclass cls = env->GetObjectClass(obj);
    jmethodID m = env->GetMethodID(cls, method, sig);
    if (m) {
        if (mode == 0) { jstring j = env->NewStringUTF(str); env->CallVoidMethod(obj, m, j); env->DeleteLocalRef(j); }
        else if (mode == 1) env->CallVoidMethod(obj, m, (jfloat)num);
        else env->CallVoidMethod(obj, m, (jboolean)(num != 0.f));
    }
    if (env->ExceptionCheck()) env->ExceptionClear();
    env->DeleteLocalRef(cls);
}

// ---- video: puente al reproductor de Java
static JNIEnv* jenv(App& s) {
    JavaVM* vm = s.a->activity->vm;
    JNIEnv* env = nullptr;
    if (vm->GetEnv((void**)&env, JNI_VERSION_1_6) != JNI_OK && vm->AttachCurrentThread(&env, nullptr) != JNI_OK) return nullptr;
    return env;
}

static void installVideoApi(App& s) {
    VideoApi& api = forge::videoApi();
    api.open = [&s](int id, const std::string& name, const std::vector<uint8_t>& data) {
        JNIEnv* env = jenv(s);
        if (!env) return false;
        jobject obj = s.a->activity->clazz;
        jclass cls = env->GetObjectClass(obj);
        jmethodID m = env->GetMethodID(cls, "videoOpen", "(I[BLjava/lang/String;)Z");
        bool ok = false;
        if (m) {
            jbyteArray arr = env->NewByteArray((jsize)data.size());
            env->SetByteArrayRegion(arr, 0, (jsize)data.size(), (const jbyte*)data.data());
            jstring js = env->NewStringUTF(name.c_str());
            ok = env->CallBooleanMethod(obj, m, (jint)id, arr, js) == JNI_TRUE;
            env->DeleteLocalRef(arr);
            env->DeleteLocalRef(js);
        }
        if (env->ExceptionCheck()) { env->ExceptionClear(); ok = false; }
        env->DeleteLocalRef(cls);
        return ok;
    };
    api.control = [&s](int id, int cmd, float arg) {
        JNIEnv* env = jenv(s);
        if (!env) return;
        jobject obj = s.a->activity->clazz;
        jclass cls = env->GetObjectClass(obj);
        jmethodID m = env->GetMethodID(cls, "videoControl", "(IIF)V");
        if (m) env->CallVoidMethod(obj, m, (jint)id, (jint)cmd, (jfloat)arg);
        if (env->ExceptionCheck()) env->ExceptionClear();
        env->DeleteLocalRef(cls);
    };
    auto info = [&s](int id, int* out) {  // {w,h,fresh,finished}
        out[0] = out[1] = out[2] = 0; out[3] = 1;
        JNIEnv* env = jenv(s);
        if (!env) return;
        jobject obj = s.a->activity->clazz;
        jclass cls = env->GetObjectClass(obj);
        jmethodID m = env->GetMethodID(cls, "videoInfo", "(I)[I");
        if (m) {
            jintArray a = (jintArray)env->CallObjectMethod(obj, m, (jint)id);
            if (a && env->GetArrayLength(a) >= 4) env->GetIntArrayRegion(a, 0, 4, out);
            if (a) env->DeleteLocalRef(a);
        }
        if (env->ExceptionCheck()) env->ExceptionClear();
        env->DeleteLocalRef(cls);
    };
    api.finished = [info](int id) { int o[4]; info(id, o); return o[3] != 0; };
    api.frame = [&s, info](int id, int& w, int& h, std::vector<uint8_t>& px) {
        int o[4];
        info(id, o);
        if (!o[2] || o[0] <= 0 || o[1] <= 0) return false;
        JNIEnv* env = jenv(s);
        if (!env) return false;
        jobject obj = s.a->activity->clazz;
        jclass cls = env->GetObjectClass(obj);
        jmethodID m = env->GetMethodID(cls, "videoFrame", "(I)[B");
        bool ok = false;
        if (m) {
            jbyteArray a = (jbyteArray)env->CallObjectMethod(obj, m, (jint)id);
            if (a) {
                jsize n = env->GetArrayLength(a);
                if (n >= o[0] * o[1] * 4) {
                    px.resize((size_t)o[0] * o[1] * 4);
                    env->GetByteArrayRegion(a, 0, (jsize)px.size(), (jbyte*)px.data());
                    w = o[0]; h = o[1];
                    ok = true;
                }
                env->DeleteLocalRef(a);
            }
        }
        if (env->ExceptionCheck()) { env->ExceptionClear(); ok = false; }
        env->DeleteLocalRef(cls);
        return ok;
    };
    api.close = [&s](int id) { 
        JNIEnv* env = jenv(s);
        if (!env) return;
        jobject obj = s.a->activity->clazz;
        jclass cls = env->GetObjectClass(obj);
        jmethodID m = env->GetMethodID(cls, "videoClose", "(I)V");
        if (m) env->CallVoidMethod(obj, m, (jint)id);
        if (env->ExceptionCheck()) env->ExceptionClear();
        env->DeleteLocalRef(cls);
    };
    auto simple = [&s](const char* name) {
        JNIEnv* env = jenv(s);
        if (!env) return;
        jobject obj = s.a->activity->clazz;
        jclass cls = env->GetObjectClass(obj);
        jmethodID m = env->GetMethodID(cls, name, "()V");
        if (m) env->CallVoidMethod(obj, m);
        if (env->ExceptionCheck()) env->ExceptionClear();
        env->DeleteLocalRef(cls);
    };
    api.pauseAll = [simple]() { simple("videoPauseAll"); };
    api.resumeAll = [simple]() { simple("videoResumeAll"); };
}

static void callJava(App& s, const char* method, const char* sig, const char* a1 = nullptr, const char* a2 = nullptr) {
    JavaVM* vm = s.a->activity->vm;
    JNIEnv* env = nullptr;
    if (vm->GetEnv((void**)&env, JNI_VERSION_1_6) != JNI_OK) {
        if (vm->AttachCurrentThread(&env, nullptr) != JNI_OK) return;
    }
    jobject obj = s.a->activity->clazz;
    jclass cls = env->GetObjectClass(obj);
    jmethodID m = env->GetMethodID(cls, method, sig);
    if (m) {
        jstring j1 = a1 ? env->NewStringUTF(a1) : nullptr, j2 = a2 ? env->NewStringUTF(a2) : nullptr;
        if (a2) env->CallVoidMethod(obj, m, j1, j2);
        else env->CallVoidMethod(obj, m);
        if (j1) env->DeleteLocalRef(j1);
        if (j2) env->DeleteLocalRef(j2);
    }
    if (env->ExceptionCheck()) env->ExceptionClear();
    env->DeleteLocalRef(cls);
}

// Crear el APK del juego dentro del telefono (ForgeActivity.buildApk / buildApkStatus / installApk)
static void callBuildApk(App& s, const std::string& pack, const std::string& label, const std::string& appId, const std::string& icon,
                         const std::string& verName, const std::string& outName, int orient, int verCode) {
    JavaVM* vm = s.a->activity->vm;
    JNIEnv* env = nullptr;
    if (vm->GetEnv((void**)&env, JNI_VERSION_1_6) != JNI_OK) {
        if (vm->AttachCurrentThread(&env, nullptr) != JNI_OK) return;
    }
    jobject obj = s.a->activity->clazz;
    jclass cls = env->GetObjectClass(obj);
    jmethodID m = env->GetMethodID(cls, "buildApk",
                                   "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;II)V");
    if (m) {
        jstring a = env->NewStringUTF(pack.c_str()), b = env->NewStringUTF(label.c_str()), c = env->NewStringUTF(appId.c_str()),
                d = env->NewStringUTF(icon.c_str()), e = env->NewStringUTF(verName.c_str()), f = env->NewStringUTF(outName.c_str());
        env->CallVoidMethod(obj, m, a, b, c, d, e, f, (jint)orient, (jint)verCode);
        env->DeleteLocalRef(a); env->DeleteLocalRef(b); env->DeleteLocalRef(c);
        env->DeleteLocalRef(d); env->DeleteLocalRef(e); env->DeleteLocalRef(f);
    }
    if (env->ExceptionCheck()) env->ExceptionClear();
    env->DeleteLocalRef(cls);
}

static std::string callBuildApkStatus(App& s) {
    JavaVM* vm = s.a->activity->vm;
    JNIEnv* env = nullptr;
    if (vm->GetEnv((void**)&env, JNI_VERSION_1_6) != JNI_OK) {
        if (vm->AttachCurrentThread(&env, nullptr) != JNI_OK) return "ERROR:sin acceso a Java";
    }
    jobject obj = s.a->activity->clazz;
    jclass cls = env->GetObjectClass(obj);
    jmethodID m = env->GetMethodID(cls, "buildApkStatus", "()Ljava/lang/String;");
    std::string out;
    if (m) {
        jstring j = (jstring)env->CallObjectMethod(obj, m);
        if (j) {
            const char* c = env->GetStringUTFChars(j, nullptr);
            if (c) out = c;
            env->ReleaseStringUTFChars(j, c);
            env->DeleteLocalRef(j);
        }
    } else out = "ERROR:esta version no sabe crear APK";
    if (env->ExceptionCheck()) env->ExceptionClear();
    env->DeleteLocalRef(cls);
    return out;
}

static int pollChar(App& s) {
    JavaVM* vm = s.a->activity->vm;
    JNIEnv* env = nullptr;
    if (vm->GetEnv((void**)&env, JNI_VERSION_1_6) != JNI_OK) return 0;
    jobject obj = s.a->activity->clazz;
    jclass cls = env->GetObjectClass(obj);
    jmethodID m = env->GetMethodID(cls, "pollUnicodeChar", "()I");
    int c = m ? env->CallIntMethod(obj, m) : 0;
    if (env->ExceptionCheck()) env->ExceptionClear();
    env->DeleteLocalRef(cls);
    return c;
}

static void setupImGui(App& s) {
    ImGuiIO& io = ImGui::GetIO();
    ImGui_ImplAndroid_Init(s.a->window);
    ImGui_ImplOpenGL3_Init("#version 300 es");
    s.imguiOn = true;
    (void)io;
}

static void startMode(App& s) {
    if (s.editor || s.pv.game.sc) return;  // ya iniciado (al recuperar la ventana solo se recrea GL)
    s.audio.init();
    installVideoApi(s);
    int dpi = s.a->config ? AConfiguration_getDensity(s.a->config) : 0;
    if (dpi <= 0 || dpi > 1000) dpi = 320;
    s.scale = std::max(1.5f, std::min(4.f, dpi / 160.f));
    ImGuiIO& io = ImGui::GetIO();
    ImFontConfig fc;
    fc.SizePixels = 13.f * s.scale;
    io.Fonts->AddFontDefault(&fc);
    forge::applyTheme();
    ImGui::GetStyle().ScaleAllSizes(s.scale * 0.85f);

    std::vector<uint8_t> pk;
    if (hasAsset(s, "standalone") && readAsset(s, "game.pack", pk)) {
        s.standalone = true;
        Project p;
        Files files;
        std::string err;
        if (!packRead(pk.data(), pk.size(), files) || !loadProject(files, p, err)) {
            LOG("game.pack invalido: %s", err.c_str());
            loadDemo(p);
        }
        s.pv.audio = &s.audio;
        s.pv.onVibrate = [&s](float sec) { callJavaArg(s, "vibrate", "(F)V", nullptr, sec, 1); };
        s.pv.onSpeak = [&s](const std::string& t) { callJavaArg(s, "speak", "(Ljava/lang/String;)V", t.c_str(), 0, 0); };
        s.pv.onFlash = [&s](bool on) { callJavaArg(s, "flash", "(Z)V", nullptr, on ? 1.f : 0.f, 2); };
        s.pv.splash = true;
        s.pv.start(std::move(p));
        return;
    }
    EditorHost h;
    h.dataDir = s.a->activity->internalDataPath ? s.a->activity->internalDataPath : "/data/local/tmp";
    h.pickFile = [&s]() { callJava(s, "pickFile", "()V"); };
    h.saveOut = [&s](const std::string& name, const std::string& path) {
        callJava(s, "saveFile", "(Ljava/lang/String;Ljava/lang/String;)V", name.c_str(), path.c_str());
    };
    h.loadRuntime = [&s](std::vector<uint8_t>& out) { return readAsset(s, "forge_runtime.exe", out); };
    h.prompt = [&s](const std::string& title, const std::string& initial) {
        callJava(s, "promptText", "(Ljava/lang/String;Ljava/lang/String;)V", title.c_str(), initial.c_str());
    };
    h.buildApk = [&s](const std::string& pack, const std::string& label, const std::string& appId, const std::string& icon,
                      const std::string& verName, const std::string& outName, int orient, int verCode) {
        callBuildApk(s, pack, label, appId, icon, verName, outName, orient, verCode);
    };
    h.buildApkStatus = [&s]() { return callBuildApkStatus(s); };
    h.installApk = [&s](const std::string& path) { callJavaArg(s, "installApk", "(Ljava/lang/String;)V", path.c_str(), 0, 0); };
    h.vibrate = [&s](float sec) { callJavaArg(s, "vibrate", "(F)V", nullptr, sec, 1); };
    h.speak = [&s](const std::string& t) { callJavaArg(s, "speak", "(Ljava/lang/String;)V", t.c_str(), 0, 0); };
    h.flash = [&s](bool on) { callJavaArg(s, "flash", "(Z)V", nullptr, on ? 1.f : 0.f, 2); };
    s.editor.reset(new Editor(h));
    s.editor->init(&s.audio);
}

static void onCmd(android_app* a, int32_t cmd) {
    App* s = (App*)a->userData;
    switch (cmd) {
        case APP_CMD_INIT_WINDOW:
            if (a->window && initEGL(*s) && s->rend.init(1024)) {
                setupImGui(*s);
                startMode(*s);
                s->ready = true;
            } else if (a->window) {
                LOG("no se pudo iniciar OpenGL ES 3");
            }
            break;
        case APP_CMD_TERM_WINDOW:
            s->ready = false;
            termEGL(*s);
            break;
        case APP_CMD_PAUSE:
        case APP_CMD_STOP:
            if (cmd == APP_CMD_PAUSE && s->editor && s->editor->dirty()) s->editor->saveProject();  // no perder trabajo
            s->audio.pause();  // nada de musica con la app en segundo plano
            if (forge::videoApi().pauseAll) forge::videoApi().pauseAll();
            break;
        case APP_CMD_RESUME:
            s->audio.resume();
            if (forge::videoApi().resumeAll) forge::videoApi().resumeAll();
            break;
    }
}

static int32_t onInput(android_app* a, AInputEvent* e) {
    App* s = (App*)a->userData;
    if (AInputEvent_getType(e) == AINPUT_EVENT_TYPE_KEY) {  // los botones de volumen los maneja el telefono
        int32_t kc = AKeyEvent_getKeyCode(e);
        if (kc == AKEYCODE_VOLUME_UP || kc == AKEYCODE_VOLUME_DOWN || kc == AKEYCODE_VOLUME_MUTE) return 0;
    }
    if (!s->ready) return 0;
    if (AInputEvent_getType(e) == AINPUT_EVENT_TYPE_MOTION) {
        PlayControls& ctl = s->standalone ? s->pv.ctl : s->editor->controls();
        int32_t act = AMotionEvent_getAction(e);
        int32_t m = act & AMOTION_EVENT_ACTION_MASK;
        int idx = (act & AMOTION_EVENT_ACTION_POINTER_INDEX_MASK) >> AMOTION_EVENT_ACTION_POINTER_INDEX_SHIFT;
        int64_t t = nowMs();
        if (m == AMOTION_EVENT_ACTION_DOWN || m == AMOTION_EVENT_ACTION_POINTER_DOWN) {
            ctl.begin(AMotionEvent_getPointerId(e, idx), AMotionEvent_getX(e, idx), AMotionEvent_getY(e, idx), t);
        } else if (m == AMOTION_EVENT_ACTION_MOVE) {
            for (size_t i = 0; i < AMotionEvent_getPointerCount(e); i++)
                ctl.move(AMotionEvent_getPointerId(e, i), AMotionEvent_getX(e, i), AMotionEvent_getY(e, i));
        } else if (m == AMOTION_EVENT_ACTION_UP || m == AMOTION_EVENT_ACTION_POINTER_UP) {
            ctl.end(AMotionEvent_getPointerId(e, idx), t);
        } else if (m == AMOTION_EVENT_ACTION_CANCEL) {
            for (int i = 0; i < 10; i++) ctl.end(i, t, true);
        }
    }
    if (!s->standalone) ImGui_ImplAndroid_HandleInputEvent(e);  // el editor tambien recibe teclas
    return 1;
}

void android_main(android_app* a) {
    App s;
    s.a = a;
    a->userData = &s;
    a->onAppCmd = onCmd;
    a->onInputEvent = onInput;
    IMGUI_CHECKVERSION();
    ImGui::CreateContext();
    ImGui::GetIO().IniFilename = nullptr;
    auto prev = std::chrono::steady_clock::now();

    while (true) {
        int events;
        android_poll_source* src;
        while (ALooper_pollOnce(s.ready ? 0 : -1, nullptr, &events, (void**)&src) >= 0) {
            if (src) src->process(a, src);
            if (a->destroyRequested) {
                termEGL(s);
                s.editor.reset();
                s.audio.shutdown();
                ImGui::DestroyContext();
                return;
            }
        }
        if (!s.ready) continue;

        EGLint w = 1, h = 1;
        eglQuerySurface(s.dpy, s.surf, EGL_WIDTH, &w);
        eglQuerySurface(s.dpy, s.surf, EGL_HEIGHT, &h);
        s.w = w; s.h = h;
        auto now = std::chrono::steady_clock::now();
        float dt = std::chrono::duration<float>(now - prev).count();
        prev = now;
        if (dt > 0.1f) dt = 0.1f;

        ImGuiIO& io = ImGui::GetIO();
        if (s.editor) {
            // archivos elegidos en el selector
            for (;;) {
                std::pair<std::string, std::vector<uint8_t>> f;
                {
                    std::lock_guard<std::mutex> lk(gFileMx);
                    if (gFiles.empty()) break;
                    f = std::move(gFiles.front());
                    gFiles.pop_front();
                }
                s.editor->onFile(f.first, std::move(f.second));
            }
            for (;;) {
                std::pair<std::string, bool> t;
                {
                    std::lock_guard<std::mutex> lk(gTextMx);
                    if (gTexts.empty()) break;
                    t = std::move(gTexts.front());
                    gTexts.pop_front();
                }
                s.editor->onText(t.first, t.second);
            }
            for (int c; (c = pollChar(s)) != 0;) io.AddInputCharacter((unsigned)c);
        }

        ImGui_ImplOpenGL3_NewFrame();
        ImGui_ImplAndroid_NewFrame();
        ImGui::NewFrame();
        if (s.standalone) {
            s.pv.frame(&s.rend, w, h, dt);
        } else {
            s.editor->frame(&s.rend, w, h, dt);
            // teclado en pantalla solo mientras se escribe en un campo de texto
            if (io.WantTextInput != s.kbd) {
                s.kbd = io.WantTextInput;
                if (s.kbd) ANativeActivity_showSoftInput(a->activity, ANATIVEACTIVITY_SHOW_SOFT_INPUT_FORCED);
                else ANativeActivity_hideSoftInput(a->activity, 0);
            }
        }
        ImGui::Render();
        ImGui_ImplOpenGL3_RenderDrawData(ImGui::GetDrawData());
        eglSwapBuffers(s.dpy, s.surf);
    }
}
