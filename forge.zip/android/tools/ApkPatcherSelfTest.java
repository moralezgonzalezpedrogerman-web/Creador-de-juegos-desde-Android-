import com.forge.maker.ApkPatcher;

import java.io.*;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.security.*;
import java.security.cert.*;
import java.security.spec.PKCS8EncodedKeySpec;
import java.util.*;
import java.util.zip.*;

/** Prueba en JVM de ApkPatcher: APK sintetico -> parche -> firma v2 -> verificador independiente. */
public class ApkPatcherSelfTest {
    static String CERT;
    static int fails = 0;
    static void check(boolean ok, String what) { System.out.println((ok ? "ok    " : "FALLO ") + what); if (!ok) fails++; }

    // ---------- generador AXML independiente (UTF-8 o UTF-16)
    static class Axml {
        boolean utf8;
        List<String> strs = new ArrayList<>();
        ByteArrayOutputStream nodes = new ByteArrayOutputStream();
        List<Integer> ids = new ArrayList<>();
        Axml(boolean utf8) { this.utf8 = utf8; }
        int s(String x) { int i = strs.indexOf(x); if (i < 0) { strs.add(x); i = strs.size() - 1; } return i; }
        static void w16(ByteArrayOutputStream o, int v) { o.write(v); o.write(v >> 8); }
        static void w32(ByteArrayOutputStream o, long v) { w16(o, (int) v); w16(o, (int) (v >> 16)); }
        void attrName(String n, int id) { s(n); while (ids.size() < strs.size()) ids.add(0); ids.set(strs.indexOf(n), id); }
        void start(String elem, Object[][] attrs) {  // attr: {nsOrNull, name, type, value}
            ByteArrayOutputStream b = new ByteArrayOutputStream();
            w32(b, 0xffffffffL); w32(b, s(elem));
            w16(b, 20); w16(b, 20); w16(b, attrs.length); w16(b, 0); w16(b, 0); w16(b, 0);
            for (Object[] a : attrs) {
                w32(b, a[0] == null ? 0xffffffffL : s((String) a[0]));
                w32(b, s((String) a[1]));
                int t = (Integer) a[2];
                Object v = a[3];
                long data = t == 3 ? s((String) v) : (Integer) v;
                w32(b, t == 3 ? data : 0xffffffffL);
                w16(b, 8); b.write(0); b.write(t); w32(b, data);
            }
            byte[] body = b.toByteArray();
            w16(nodes, 0x0102); w16(nodes, 16); w32(nodes, 16 + body.length); w32(nodes, 1); w32(nodes, 0xffffffffL);
            nodes.write(body, 0, body.length);
        }
        void end(String elem) {
            w16(nodes, 0x0103); w16(nodes, 16); w32(nodes, 24); w32(nodes, 1); w32(nodes, 0xffffffffL);
            w32(nodes, 0xffffffffL); w32(nodes, s(elem));
        }
        byte[] build() {
            ByteArrayOutputStream data = new ByteArrayOutputStream();
            List<Integer> offs = new ArrayList<>();
            for (String x : strs) {
                offs.add(data.size());
                if (utf8) {
                    byte[] u = x.getBytes(StandardCharsets.UTF_8);
                    data.write(x.length()); data.write(u.length); data.write(u, 0, u.length); data.write(0);
                } else {
                    w16(data, x.length());
                    byte[] u = x.getBytes(StandardCharsets.UTF_16LE); data.write(u, 0, u.length); w16(data, 0);
                }
            }
            while (data.size() % 4 != 0) data.write(0);
            ByteArrayOutputStream pool = new ByteArrayOutputStream();
            int strStart = 28 + 4 * strs.size();
            w16(pool, 1); w16(pool, 28); w32(pool, strStart + data.size()); w32(pool, strs.size()); w32(pool, 0);
            w32(pool, utf8 ? 0x100 : 0); w32(pool, strStart); w32(pool, 0);
            for (int o : offs) w32(pool, o);
            byte[] d = data.toByteArray(); pool.write(d, 0, d.length);
            ByteArrayOutputStream map = new ByteArrayOutputStream();
            while (ids.size() < strs.size()) ids.add(0);
            int nmap = 0;
            for (int i = 0; i < strs.size(); i++) if (ids.get(i) != 0) nmap = i + 1;
            w16(map, 0x0180); w16(map, 8); w32(map, 8 + 4 * nmap);
            for (int i = 0; i < nmap; i++) w32(map, ids.get(i));
            byte[] p = pool.toByteArray(), m = map.toByteArray(), n = nodes.toByteArray();
            ByteArrayOutputStream all = new ByteArrayOutputStream();
            w16(all, 3); w16(all, 8); w32(all, 8 + p.length + m.length + n.length);
            all.write(p, 0, p.length); all.write(m, 0, m.length); all.write(n, 0, n.length);
            return all.toByteArray();
        }
    }

    static byte[] sampleManifest(boolean utf8) {
        Axml x = new Axml(utf8);
        String A = "http://schemas.android.com/apk/res/android";
        x.attrName("label", 0x01010001); x.attrName("name", 0x01010003); x.attrName("authorities", 0x01010018);
        x.attrName("screenOrientation", 0x0101001e); x.attrName("versionCode", 0x0101021b); x.attrName("versionName", 0x0101021c);
        x.start("manifest", new Object[][]{{A, "versionCode", 0x10, 2}, {A, "versionName", 3, "0.2"}, {null, "package", 3, "com.forge.maker"}});
        x.start("application", new Object[][]{{A, "label", 3, "P-Maker code333"}});
        x.start("activity", new Object[][]{{A, "name", 3, "com.forge.maker.ForgeActivity"}, {A, "screenOrientation", 0x10, 6}});
        x.end("activity");
        x.start("provider", new Object[][]{{A, "authorities", 3, "com.forge.maker.apkprovider"}});
        x.end("provider");
        x.end("application"); x.end("manifest");
        return x.build();
    }

    // ---------- lector AXML independiente: devuelve "elemento@atributo" -> valor
    static Map<String, String> parseAxml(byte[] b) {
        ByteBuffer bb = ByteBuffer.wrap(b).order(ByteOrder.LITTLE_ENDIAN);
        if (bb.getShort(0) != 3 || bb.getInt(4) != b.length) throw new RuntimeException("cabecera/size mal");
        int ps = 8;
        int count = bb.getInt(ps + 8); long flags = bb.getInt(ps + 16) & 0xffffffffL; int strStart = bb.getInt(ps + 20);
        int poolSize = bb.getInt(ps + 4);
        boolean utf8 = (flags & 0x100) != 0;
        String[] s = new String[count];
        for (int i = 0; i < count; i++) {
            int o = ps + strStart + bb.getInt(ps + 28 + 4 * i);
            if (utf8) {
                int p = o; int l = b[p] & 0xff; p += (l & 0x80) != 0 ? 2 : 1; int bl = b[p] & 0xff; p++;
                s[i] = new String(b, p, bl, StandardCharsets.UTF_8);
            } else {
                int l = bb.getShort(o) & 0xffff;
                s[i] = new String(b, o + 2, l * 2, StandardCharsets.UTF_16LE);
            }
        }
        Map<String, String> r = new LinkedHashMap<>();
        int off = ps + poolSize;
        String elem = "";
        while (off < b.length) {
            int type = bb.getShort(off) & 0xffff, size = bb.getInt(off + 4);
            if (type == 0x0102) {
                elem = s[bb.getInt(off + 20)];
                int n = bb.getShort(off + 28) & 0xffff, as = off + 16 + (bb.getShort(off + 24) & 0xffff), asz = bb.getShort(off + 26) & 0xffff;
                for (int i = 0; i < n; i++) {
                    int a = as + i * asz;
                    String nm = s[bb.getInt(a + 4)];
                    int t = b[a + 15] & 0xff, data = bb.getInt(a + 16);
                    r.put(elem + "@" + nm, t == 3 ? s[data] : "#" + data);
                    if (t == 3 && bb.getInt(a + 8) != data) throw new RuntimeException("raw != data en " + nm);
                }
            }
            if (size <= 0) throw new RuntimeException("chunk size 0");
            off += size;
        }
        return r;
    }

    static byte[] fakeArsc(String pkg) {
        ByteBuffer bb = ByteBuffer.allocate(12 + 288 + 8).order(ByteOrder.LITTLE_ENDIAN);
        bb.putShort((short) 2).putShort((short) 12).putInt(bb.capacity()).putInt(1);
        bb.putShort((short) 0x200).putShort((short) 288).putInt(288 + 8).putInt(0x7f);
        byte[] n = pkg.getBytes(StandardCharsets.UTF_16LE);
        bb.put(n);
        return bb.array();
    }

    // ---------- verificador v2 independiente
    static long u32(byte[] b, int o) { return ByteBuffer.wrap(b).order(ByteOrder.LITTLE_ENDIAN).getInt(o) & 0xffffffffL; }
    static byte[] lpRead(ByteBuffer b) { int n = b.getInt(); byte[] r = new byte[n]; b.get(r); return r; }

    static void verifyV2(File apk) throws Exception {
        byte[] all = Files.readAllBytes(apk.toPath());
        int e = -1;
        for (int i = all.length - 22; i >= 0; i--) if (u32(all, i) == 0x06054b50L) { e = i; break; }
        check(e == all.length - 22, "EOCD al final del archivo (sin comentario)");
        long cdOff = u32(all, e + 16), cdSize = u32(all, e + 12);
        check(cdOff + cdSize == e, "directorio central contiguo al EOCD");
        String magic = new String(all, (int) cdOff - 16, 16, StandardCharsets.US_ASCII);
        check(magic.equals("APK Sig Block 42"), "magia del bloque de firma justo antes del directorio central");
        long blkSize2 = ByteBuffer.wrap(all, (int) cdOff - 24, 8).order(ByteOrder.LITTLE_ENDIAN).getLong();
        long blkStart = cdOff - blkSize2 - 8;
        long blkSize1 = ByteBuffer.wrap(all, (int) blkStart, 8).order(ByteOrder.LITTLE_ENDIAN).getLong();
        check(blkSize1 == blkSize2, "tamanos del bloque coinciden");
        ByteBuffer pairs = ByteBuffer.wrap(all, (int) blkStart + 8, (int) blkSize1 - 24).order(ByteOrder.LITTLE_ENDIAN);
        byte[] v2 = null;
        while (pairs.hasRemaining()) {
            long len = pairs.getLong(); int id = pairs.getInt();
            byte[] val = new byte[(int) len - 4]; pairs.get(val);
            if (id == 0x7109871a) v2 = val;
        }
        check(v2 != null, "existe el par v2 (0x7109871a)");
        ByteBuffer signers = ByteBuffer.wrap(v2).order(ByteOrder.LITTLE_ENDIAN);
        signers.getInt();
        ByteBuffer signer = ByteBuffer.wrap(lpRead(signers)).order(ByteOrder.LITTLE_ENDIAN);
        byte[] signedData = lpRead(signer);
        ByteBuffer sigs = ByteBuffer.wrap(lpRead(signer)).order(ByteOrder.LITTLE_ENDIAN);
        byte[] pub = lpRead(signer);
        check(!signer.hasRemaining() && !signers.hasRemaining(), "estructura signer/signers sin bytes sobrantes");
        ByteBuffer sig1 = ByteBuffer.wrap(lpRead(sigs)).order(ByteOrder.LITTLE_ENDIAN);
        int algo = sig1.getInt(); byte[] sig = lpRead(sig1);
        check(algo == 0x0103, "algoritmo RSA-PKCS1-SHA256 (0x0103)");
        Signature sv = Signature.getInstance("SHA256withRSA");
        sv.initVerify(java.security.KeyFactory.getInstance("RSA").generatePublic(new java.security.spec.X509EncodedKeySpec(pub)));
        sv.update(signedData);
        check(sv.verify(sig), "la firma RSA verifica con la clave publica");
        ByteBuffer sd = ByteBuffer.wrap(signedData).order(ByteOrder.LITTLE_ENDIAN);
        ByteBuffer digs = ByteBuffer.wrap(lpRead(sd)).order(ByteOrder.LITTLE_ENDIAN);
        ByteBuffer certs = ByteBuffer.wrap(lpRead(sd)).order(ByteOrder.LITTLE_ENDIAN);
        byte[] certDer = lpRead(certs);
        check(Arrays.equals(certDer, java.nio.file.Files.readAllBytes(new File(CERT).toPath())), "certificado dentro de signed data");
        check(lpRead(sd).length == 0 && !sd.hasRemaining(), "atributos adicionales vacios y sin sobrantes");
        check(!digs.hasRemaining() || true, "");
        ByteBuffer d1 = ByteBuffer.wrap(lpRead(digs)).order(ByteOrder.LITTLE_ENDIAN);
        check(d1.getInt() == 0x0103, "digest con el mismo algoritmo");
        byte[] want = lpRead(d1);
        // recalcular: secciones [0,blkStart) , [cdOff, e) , EOCD con cdOff = blkStart
        byte[] eocd = Arrays.copyOfRange(all, e, all.length);
        ByteBuffer.wrap(eocd).order(ByteOrder.LITTLE_ENDIAN).putInt(16, (int) blkStart);
        MessageDigest md = MessageDigest.getInstance("SHA-256");
        ByteArrayOutputStream dg = new ByteArrayOutputStream();
        int chunks = 0;
        byte[][] secs = {Arrays.copyOfRange(all, 0, (int) blkStart), Arrays.copyOfRange(all, (int) cdOff, e), eocd};
        for (byte[] s : secs) {
            for (int p = 0; p < s.length; p += 1 << 20) {
                int n = Math.min(1 << 20, s.length - p);
                md.reset(); md.update((byte) 0xa5);
                md.update(ByteBuffer.allocate(4).order(ByteOrder.LITTLE_ENDIAN).putInt(n).array());
                md.update(s, p, n);
                dg.write(md.digest()); chunks++;
            }
        }
        md.reset(); md.update((byte) 0x5a);
        md.update(ByteBuffer.allocate(4).order(ByteOrder.LITTLE_ENDIAN).putInt(chunks).array());
        md.update(dg.toByteArray());
        check(Arrays.equals(md.digest(), want), "digest recalculado (" + chunks + " bloques de 1 MB) coincide con el firmado");
    }

    static void verifyZip(File apk, Map<String, byte[]> expectContent) throws Exception {
        // lectura con java.util.zip (comprueba CRC) + alineacion leyendo cabeceras locales
        try (ZipFile z = new ZipFile(apk)) {
            for (Enumeration<? extends ZipEntry> en = z.entries(); en.hasMoreElements(); ) {
                ZipEntry ze = en.nextElement();
                byte[] d = z.getInputStream(ze).readAllBytes();
                if (expectContent.containsKey(ze.getName())) check(Arrays.equals(d, expectContent.get(ze.getName())), "contenido de " + ze.getName());
            }
        }
        byte[] all = Files.readAllBytes(apk.toPath());
        int e = all.length - 22;
        long cdOff = u32(all, e + 16);
        // el CD esta desplazado por el bloque; localizar via el offset local de cada entrada
        int n = (int) (u32(all, e + 8) & 0xffff);
        int p = (int) cdOff;
        boolean alignOk = true, soOk = true;
        Set<String> names = new HashSet<>();
        for (int i = 0; i < n; i++) {
            int method = (int) (u32(all, p + 10) & 0xffff);
            int nl = (int) (u32(all, p + 28) & 0xffff), el = (int) (u32(all, p + 30) & 0xffff), cl = (int) (u32(all, p + 32) & 0xffff);
            long lo = u32(all, p + 42);
            String name = new String(all, p + 46, nl, StandardCharsets.UTF_8);
            names.add(name);
            long data = lo + 30 + (int) (u32(all, (int) lo + 26) & 0xffff) + (int) (u32(all, (int) lo + 28) & 0xffff);
            if (method == 0 && data % 4 != 0) alignOk = false;
            if (method == 0 && name.endsWith(".so") && data % 4096 != 0) soOk = false;
            if (u32(all, (int) lo) != 0x04034b50L) alignOk = false;
            p += 46 + nl + el + cl;
        }
        check(alignOk, "entradas stored alineadas a 4 bytes y cabeceras locales validas");
        check(soOk, "libs .so stored alineadas a 4096");
        check(names.stream().noneMatch(s -> s.startsWith("META-INF/") && (s.endsWith(".RSA") || s.endsWith(".SF"))), "sin firmas viejas");
    }

    public static void main(String[] a) throws Exception {
        CERT = a[0] + "/apk_sign_cert.der";
        byte[] keyB = Files.readAllBytes(new File(a[0] + "/apk_sign_key.pk8").toPath());
        PrivateKey key = KeyFactory.getInstance("RSA").generatePrivate(new PKCS8EncodedKeySpec(keyB));
        X509Certificate cert = (X509Certificate) CertificateFactory.getInstance("X.509").generateCertificate(new FileInputStream(a[0] + "/apk_sign_cert.der"));

        for (boolean utf8 : new boolean[]{true, false}) {
            System.out.println("--- manifest " + (utf8 ? "UTF-8" : "UTF-16"));
            File tpl = File.createTempFile("tpl", ".apk"), out = File.createTempFile("out", ".apk");
            byte[] big = new byte[3 * 1024 * 1024 + 123];  // para forzar varios bloques de 1 MB
            new Random(1).nextBytes(big);
            byte[] so = new byte[5000]; new Random(2).nextBytes(so);
            try (ZipOutputStream zo = new ZipOutputStream(new FileOutputStream(tpl))) {
                put(zo, "AndroidManifest.xml", sampleManifest(utf8), true);
                put(zo, "resources.arsc", fakeArsc("com.forge.maker"), false);
                put(zo, "classes.dex", "dex\n035".getBytes(), true);
                put(zo, "lib/arm64-v8a/libforge.so", so, false);
                put(zo, "assets/forge_runtime.exe", big, true);
                put(zo, "assets/apk_sign_key.pk8", keyB, true);
                put(zo, "res/drawable-nodpi/app_icon.png", "viejo".getBytes(), true);
                put(zo, "META-INF/CERT.RSA", "x".getBytes(), true);
                put(zo, "META-INF/CERT.SF", "x".getBytes(), true);
                put(zo, "META-INF/MANIFEST.MF", "x".getBytes(), true);
                put(zo, "assets/otro.bin", big, true);
            }
            ApkPatcher.Config c = new ApkPatcher.Config();
            c.label = "Mi Aventura ñ"; c.appId = "com.juan.aventura"; c.verName = "2.5"; c.verCode = 7; c.orient = 1;
            Map<String, byte[]> extra = new LinkedHashMap<>();
            byte[] pack = new byte[1500000]; new Random(3).nextBytes(pack);
            extra.put("assets/game.pack", pack); extra.put("assets/standalone", "1".getBytes());
            byte[] icon = "PNGNUEVO".getBytes();
            if (a.length > 1) {  // version C++ (tests/apkcli)
                File pf = File.createTempFile("pack", ".pack"), ic = File.createTempFile("icon", ".png");
                Files.write(pf.toPath(), pack); Files.write(ic.toPath(), icon);
                Process pr = new ProcessBuilder(a[1], tpl.getPath(), out.getPath(), pf.getPath(), ic.getPath(), a[0], c.label, c.appId, c.verName, "" + c.verCode, "" + c.orient)
                        .inheritIO().start();
                check(pr.waitFor() == 0, "apkcli (C++) termino bien");
            } else {
                ApkPatcher.build(tpl, extra, icon, c, key, cert, out);
                check(ApkPatcher.lastIconReplaced, "icono reemplazado");
            }

            Map<String, byte[]> expect = new HashMap<>();
            expect.put("assets/game.pack", pack); expect.put("assets/standalone", "1".getBytes());
            expect.put("res/drawable-nodpi/app_icon.png", icon); expect.put("classes.dex", "dex\n035".getBytes());
            expect.put("lib/arm64-v8a/libforge.so", so); expect.put("assets/otro.bin", big);
            verifyZip(out, expect);
            try (ZipFile z = new ZipFile(out)) {
                check(z.getEntry("assets/forge_runtime.exe") == null && z.getEntry("assets/apk_sign_key.pk8") == null, "se quitan el .exe y la clave");
                Map<String, String> m = parseAxml(z.getInputStream(z.getEntry("AndroidManifest.xml")).readAllBytes());
                check(m.get("manifest@package").equals("com.juan.aventura"), "package = " + m.get("manifest@package"));
                check(m.get("application@label").equals("Mi Aventura ñ"), "label = " + m.get("application@label"));
                check(m.get("manifest@versionName").equals("2.5") && m.get("manifest@versionCode").equals("#7"), "version " + m.get("manifest@versionName") + " / " + m.get("manifest@versionCode"));
                check(m.get("activity@screenOrientation").equals("#7"), "orientacion vertical (7)");
                check(m.get("activity@name").equals("com.forge.maker.ForgeActivity"), "clase de la actividad intacta");
                check(m.get("provider@authorities").equals("com.juan.aventura.apkprovider"), "autoridad del provider = " + m.get("provider@authorities"));
                byte[] ar = z.getInputStream(z.getEntry("resources.arsc")).readAllBytes();
                String pn = new String(ar, 12 + 12, 128, StandardCharsets.UTF_16LE);
                // el campo empieza en +12 del chunk de paquete, que empieza en +12 del archivo
                String pn2 = new String(Arrays.copyOfRange(ar, 24, 24 + 256), StandardCharsets.UTF_16LE).trim().replace("\u0000", "");
                check(pn2.equals("com.juan.aventura"), "resources.arsc paquete = " + pn2);
                ZipEntry ze = z.getEntry("resources.arsc");
                check(ze.getMethod() == 0, "resources.arsc sin comprimir");
            }
            verifyV2(out);
            tpl.delete(); out.delete();
        }
        System.out.println(fails == 0 ? "TODO OK" : ("FALLOS: " + fails));
        System.exit(fails == 0 ? 0 : 1);
    }

    static void put(ZipOutputStream zo, String name, byte[] d, boolean deflate) throws IOException {
        ZipEntry e = new ZipEntry(name);
        if (!deflate) {
            e.setMethod(ZipEntry.STORED); e.setSize(d.length); e.setCompressedSize(d.length);
            CRC32 c = new CRC32(); c.update(d); e.setCrc(c.getValue());
        }
        zo.putNextEntry(e); zo.write(d); zo.closeEntry();
    }
}
