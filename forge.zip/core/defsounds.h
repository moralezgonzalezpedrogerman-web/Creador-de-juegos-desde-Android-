#pragma once
#include <cstdint>
#include <string>
#include <vector>

namespace forge {

// Sonidos por defecto hechos por codigo (estilo juego militar): pasos, salto, disparo, recarga...
// Si el proyecto trae un audio con el mismo nombre, ese reemplaza al de por defecto.
const std::vector<std::string>& defaultSoundNames();               // sin extension: "paso", "disparo"...
std::vector<uint8_t> makeDefaultSound(const std::string& name);    // WAV 16 bits mono, vacio si no existe

}  // namespace forge
