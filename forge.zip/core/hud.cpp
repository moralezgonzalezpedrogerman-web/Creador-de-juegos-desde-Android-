#include "hud.h"
#include "renderer.h"
#include "imgui.h"
#include <cmath>
#include <cstdio>

namespace forge {

void drawCameraLayer(ImDrawList* dl, const Game& g, Renderer* r, int w, int h) {
    if (!g.sc) return;
    const Scene& S = *g.sc;
    float fs = ImGui::GetFontSize();
    for (auto& ov : S.overlays) {  // imagenes fijas
        if (ov.tex.empty() || !r) continue;
        unsigned id = r->textureId(g, ov.tex);
        if (!id) continue;
        float cx = ov.x * w, cy = ov.y * h, hw = ov.w * w * 0.5f, hh = ov.h * h * 0.5f;
        dl->AddImage((ImTextureID)(intptr_t)id, ImVec2(cx - hw, cy - hh), ImVec2(cx + hw, cy + hh), ImVec2(0, 1), ImVec2(1, 0),
                     IM_COL32(255, 255, 255, (int)(std::max(0.f, std::min(1.f, ov.alpha)) * 255)));
    }
    const ScreenFx& f = S.sfx;
    if (!f.any()) return;
    float t = (float)ImGui::GetTime();
    if (f.tint > 0)
        dl->AddRectFilled(ImVec2(0, 0), ImVec2((float)w, (float)h),
                          IM_COL32((int)(f.tintC[0] * 255), (int)(f.tintC[1] * 255), (int)(f.tintC[2] * 255), (int)(std::min(1.f, f.tint) * 90)));
    if (f.scan > 0) {  // lineas de barrido
        float step = std::max(3.f, h / 160.f);
        int a = (int)(std::min(1.f, f.scan) * 85);
        for (float y = std::fmod(t * 12.f, step); y < h; y += step) dl->AddRectFilled(ImVec2(0, y), ImVec2((float)w, y + step * 0.45f), IM_COL32(0, 0, 0, a));
    }
    if (f.track > 0) {  // banda de "tracking" que sube por la pantalla
        float y = h * (1.2f - std::fmod(t * 0.18f, 1.4f));
        float bh = h * 0.07f * f.track;
        dl->AddRectFilled(ImVec2(0, y), ImVec2((float)w, y + bh), IM_COL32(255, 255, 255, (int)(20 * std::min(1.f, f.track))));
        for (int i = 0; i < 3; i++) {
            float yy = y + bh * (0.2f + 0.3f * i), off = ((std::rand() % 100) / 100.f - 0.5f) * w * 0.05f * f.track;
            dl->AddRectFilled(ImVec2(off, yy), ImVec2(off + w * 0.6f, yy + 2.f), IM_COL32(255, 255, 255, 40));
        }
    }
    if (f.noise > 0) {  // grano
        int n = (int)(std::min(1.f, f.noise) * 260);
        for (int i = 0; i < n; i++) {
            float x = (float)(std::rand() % std::max(1, w)), y = (float)(std::rand() % std::max(1, h));
            int c = 120 + std::rand() % 135;
            dl->AddRectFilled(ImVec2(x, y), ImVec2(x + 2.f + std::rand() % 6, y + 1.5f), IM_COL32(c, c, c, 40));
        }
    }
    if (f.vignette > 0) {  // bordes oscuros
        float e = std::min(w, h) * 0.35f, a = std::min(1.f, f.vignette) * 200;
        ImU32 dark = IM_COL32(0, 0, 0, (int)a), clear = IM_COL32(0, 0, 0, 0);
        dl->AddRectFilledMultiColor(ImVec2(0, 0), ImVec2((float)w, e), dark, dark, clear, clear);
        dl->AddRectFilledMultiColor(ImVec2(0, h - e), ImVec2((float)w, (float)h), clear, clear, dark, dark);
        dl->AddRectFilledMultiColor(ImVec2(0, 0), ImVec2(e, (float)h), dark, clear, clear, dark);
        dl->AddRectFilledMultiColor(ImVec2(w - e, 0), ImVec2((float)w, (float)h), clear, dark, dark, clear);
    }
    if (f.rec) {  // visor de camara de video
        float m = fs * 1.6f, l = fs * 2.2f;
        ImU32 wh = IM_COL32(255, 255, 255, 220);
        float xs[2] = {m, w - m}, ys[2] = {m, h - m};
        for (int i = 0; i < 2; i++)
            for (int j = 0; j < 2; j++) {
                float dx = i ? -l : l, dy = j ? -l : l;
                dl->AddLine(ImVec2(xs[i], ys[j]), ImVec2(xs[i] + dx, ys[j]), wh, 3.f);
                dl->AddLine(ImVec2(xs[i], ys[j]), ImVec2(xs[i], ys[j] + dy), wh, 3.f);
            }
        if (std::fmod(t, 1.2f) < 0.7f) dl->AddCircleFilled(ImVec2(m + fs * 0.9f, m + fs * 1.6f), fs * 0.45f, IM_COL32(235, 40, 40, 255));
        int sec = (int)g.time;
        char buf[48];
        snprintf(buf, sizeof buf, "REC  %02d:%02d:%02d", sec / 3600, (sec / 60) % 60, sec % 60);
        dl->AddText(ImVec2(m + fs * 1.8f, m + fs * 1.05f), wh, buf);
        dl->AddText(ImVec2(m + fs * 0.4f, h - m - fs * 2.2f), wh, "PLAY ▶");
    }
}

void Hud::setup(const Project& p) {
    btns = p.hudDefault ? defaultHud() : p.hud;
    if (p.hudDefault) {  // v8: botones extra solo si el juego tiene varias armas o recarga
        if (!p.extraWeapons.empty()) {
            HudBtn n; n.label = "ARMA"; n.x = 0.88f; n.y = 0.38f; n.r = 0.07f; n.act = HudAct::NextWeapon;
            n.color[0] = 1.f; n.color[1] = 0.8f; n.color[2] = 0.2f;
            btns.push_back(n);
        }
        bool mag = p.weapon.magSize > 0;
        for (auto& w : p.extraWeapons) mag = mag || w.magSize > 0;
        if (mag) {
            HudBtn n; n.label = "RECARGAR"; n.x = 0.72f; n.y = 0.64f; n.r = 0.07f; n.act = HudAct::Reload;
            n.color[0] = 0.4f; n.color[1] = 1.f; n.color[2] = 0.5f;
            btns.push_back(n);
        }
    }
    st_.assign(btns.size(), St());
    joy = Joy();
}

bool Hud::down(int id, float px, float py, int w, int h, bool is3d) {
    if (!is3d) return false;
    for (size_t i = 0; i < btns.size(); i++) {
        const HudBtn& b = btns[i];
        if (b.act == HudAct::None) continue;
        float dx = px - b.x * w, dy = py - b.y * h, r = b.r * h;
        if (dx * dx + dy * dy <= r * r) {
            st_[i].ptr = id;
            st_[i].pressed = true;
            if (b.act == HudAct::Interact) st_[i].tapPending = true;
            return true;
        }
    }
    return false;
}

void Hud::up(int id) {
    for (auto& s : st_) if (s.ptr == id) s.ptr = -1;
}

void Hud::collect(Input& in) {
    for (size_t i = 0; i < btns.size() && i < st_.size(); i++) {
        if (st_[i].ptr >= 0) {
            if (btns[i].act == HudAct::Jump) in.jump = true;
            if (btns[i].act == HudAct::Shoot) in.shoot = true;
        }
        if (st_[i].pressed && btns[i].act == HudAct::NextWeapon) in.nextWeapon = true;
        if (st_[i].pressed && btns[i].act == HudAct::Reload) in.reload = true;
        if (st_[i].tapPending) { in.tap = true; st_[i].tapPending = false; }
        if (st_[i].pressed) { in.buttons.push_back(btns[i].label); st_[i].pressed = false; }
    }
}

static ImU32 col(float r, float g, float b, float a) {
    return IM_COL32((int)(r * 255), (int)(g * 255), (int)(b * 255), (int)(a * 255));
}

void Hud::draw(ImDrawList* dl, const Game& g, Renderer* rend, int w, int h, bool showButtons) {
    drawCameraLayer(dl, g, rend, w, h);
    if (!g.sc || !dl) return;
    bool is3d = g.sc->is3d;
    ImFont* font = ImGui::GetFont();
    float fs = ImGui::GetFontSize();

    // Arma en primera persona.
    if (is3d && g.curWeapon() && g.curWeapon()->enabled && g.camMode == kFirstPerson && g.curWeapon()->model.empty()) {
        const Weapon& wp = *g.curWeapon();
        float sh = wp.scale * h, cx = w * 0.62f + wp.ox * w, bottom = h + wp.oy * h + g.recoil * 0.04f * h;
        int tw = 1, th = 1;
        unsigned tid = rend ? rend->textureId(g, wp.tex, &tw, &th) : 0;
        float top;
        if (tid) {
            float sw = sh * (float)tw / (float)th;
            dl->AddImage((ImTextureID)(intptr_t)tid, ImVec2(cx - sw * 0.5f, bottom - sh), ImVec2(cx + sw * 0.5f, bottom),
                         ImVec2(0, 1), ImVec2(1, 0));
            top = bottom - sh;
        } else {  // arma basica dibujada
            float u = sh * 0.5f;
            dl->AddRectFilled(ImVec2(cx - 0.20f * u, bottom - 0.9f * u), ImVec2(cx + 0.20f * u, bottom), col(.18f, .18f, .2f, 1), 4.f);
            dl->AddRectFilled(ImVec2(cx - 0.34f * u, bottom - 1.35f * u), ImVec2(cx + 0.24f * u, bottom - 0.85f * u), col(.3f, .3f, .34f, 1), 4.f);
            dl->AddRectFilled(ImVec2(cx - 0.10f * u, bottom - 1.75f * u), ImVec2(cx + 0.04f * u, bottom - 1.30f * u), col(.22f, .22f, .26f, 1), 3.f);
            top = bottom - 1.75f * u;
        }
        if (g.flash > 0) dl->AddCircleFilled(ImVec2(cx, top), sh * 0.12f, col(1.f, .85f, .4f, .9f));
    }

    // Destello rojo al recibir dano.
    if (is3d && g.hurtFlash > 0)
        dl->AddRectFilled(ImVec2(0, 0), ImVec2((float)w, (float)h), col(1.f, 0.f, 0.f, std::min(0.45f, g.hurtFlash)));

    // Botones y joystick.
    if (showButtons && is3d) {
        for (size_t i = 0; i < btns.size(); i++) {
            const HudBtn& b = btns[i];
            bool pressed = i < st_.size() && st_[i].ptr >= 0;
            ImVec2 c(b.x * w, b.y * h);
            float r = b.r * h;
            dl->AddCircleFilled(c, r, col(b.color[0], b.color[1], b.color[2], pressed ? 0.65f : 0.30f), 40);
            dl->AddCircle(c, r, col(b.color[0], b.color[1], b.color[2], 0.9f), 40, 3.f);
            ImVec2 ts = font->CalcTextSizeA(fs, 1e9f, 0.f, b.label.c_str());
            dl->AddText(font, fs, ImVec2(c.x - ts.x * 0.5f, c.y - ts.y * 0.5f), IM_COL32(255, 255, 255, 230), b.label.c_str());
        }
        if (joy.active) {
            float R = w * 0.08f;
            dl->AddCircle(ImVec2(joy.ox, joy.oy), R, IM_COL32(255, 255, 255, 110), 40, 3.f);
            float dx = joy.x - joy.ox, dy = joy.y - joy.oy, l = std::sqrt(dx * dx + dy * dy);
            if (l > R) { dx *= R / l; dy *= R / l; }
            dl->AddCircleFilled(ImVec2(joy.ox + dx, joy.oy + dy), R * 0.4f, IM_COL32(255, 255, 255, 140), 24);
        }
    }

    // Variables visibles ("Mostrar la variable ... en X, Y"): coordenadas del escenario (alto 1000, origen al centro).
    {
        float sw = g.stageW(), sh = kView2DHeight;
        for (auto& v : g.shown) {
            Val val = g.vars.count(Game::vkey(v.first)) ? g.vars.at(Game::vkey(v.first)) : Val(0.0);
            std::string txt = val.txt();
            ImVec2 ts = font->CalcTextSizeA(fs, 1e9f, 0.f, txt.c_str());
            float px = (v.second.first / sw + 0.5f) * w, py = (0.5f - v.second.second / sh) * h;
            dl->AddRectFilled(ImVec2(px - ts.x * .5f - 8, py - ts.y * .5f - 3), ImVec2(px + ts.x * .5f + 8, py + ts.y * .5f + 3),
                              IM_COL32(0, 0, 0, 110), 4.f);
            dl->AddText(font, fs, ImVec2(px - ts.x * .5f, py - ts.y * .5f), IM_COL32(255, 255, 255, 240), txt.c_str());
        }
    }

    // Texto del bloque "decir".
    if (g.sayT > 0 && !g.say.empty()) {
        ImVec2 ts = font->CalcTextSizeA(fs * 1.2f, 1e9f, 0.f, g.say.c_str());
        float x = (w - ts.x) * 0.5f, y = h * 0.14f;
        dl->AddRectFilled(ImVec2(x - 14, y - 8), ImVec2(x + ts.x + 14, y + ts.y + 8), IM_COL32(0, 0, 0, 150), 8.f);
        dl->AddText(font, fs * 1.2f, ImVec2(x, y), IM_COL32(255, 255, 255, 255), g.say.c_str());
    }
}

}  // namespace forge
