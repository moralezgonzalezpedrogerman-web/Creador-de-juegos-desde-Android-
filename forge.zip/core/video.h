#pragma once
#include <cstdint>
#include <functional>
#include <string>
#include <vector>

namespace forge {

// Reproductor de video que pone cada plataforma (Android: MediaPlayer). Si no hay, los bloques de video no hacen nada.
struct VideoApi {
    std::function<bool(int id, const std::string& name, const std::vector<uint8_t>& data)> open;
    // cmd: 0 reproducir, 1 pausar, 2 detener, 3 ir al segundo 'arg'
    std::function<void(int id, int cmd, float arg)> control;
    std::function<bool(int id, int& w, int& h, std::vector<uint8_t>& rgba)> frame;  // true si hay un cuadro nuevo
    std::function<bool(int id)> finished;                                           // llego al final
    std::function<void(int id)> close;
    std::function<void()> pauseAll, resumeAll;                                      // app en segundo plano
    bool available() const { return (bool)open; }
};
VideoApi& videoApi();

}  // namespace forge
