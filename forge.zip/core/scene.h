#pragma once
#include "vec.h"
#include <cstdint>
#include <map>
#include <string>
#include <vector>

namespace forge {

enum class Kind { Cube, Floor, Wall, Item, Model, Light, Player };

// ---------------------------------------------------------------- bloques (como Pocket Code)
// Los bloques de un objeto son una lista PLANA. Un bloque de evento (sombrero) empieza un guion y termina
// en el siguiente evento. Los bucles y los "si" se cierran con bloques propios (Fin del bucle, Fin del si).
enum class Op : int {
    // Eventos
    WhenStart, WhenTap, WhenReceive, WhenCollide, WhenTrue, WhenShot, WhenNear,
    // Control
    Wait, BroadcastWait, Broadcast, Forever, Repeat, LoopEnd, Note, If, Else, EndIf, StartScene,
    // Movimiento
    PlaceAt, SetX, SetY, ChangeX, ChangeY, BounceEdge, Move, TurnLeft, TurnRight, PointDir, PointTowards,
    GlideTo, GoBack, GoFront, Vibrate,
    PhysDynamic, PhysStatic, PhysNone, SetForce, SpinLeft, SpinRight, SetGravity, SetMass, SetBounce, SetFriction,
    PlaceAt3, SetZ, ChangeZ,
    // Sonido
    StartSound, StopSounds, SetVolume, ChangeVolume, Speak, Music,
    // Apariencia
    NextLook, SetSize, ChangeSize, Show, Hide, SetTransp, ChangeTransp, SetBright, ChangeBright, ClearFx,
    SetLook, Flash, ChangeColor, Say, Destroy,
    // Datos
    SetVar, ChangeVar, ShowVar, HideVar,
    // Extras 3D (juego en primera persona)
    WhenInteract, SetSolid, TeleportPlayer, MoveToPlayer,
    // Juego (v3): sonido con espera, camara, combate, utilidades
    PlaySoundWait, SetCamera, WaitUntil, StopScript, ShootPlayer, HurtPlayer, SetSpeed, SetJump, PlayAnim, MoveRandom,
    CreateClone, DeleteClone, WhenCloneStart, BreakApart, GoToObject, MoveTowards, ShakeScreen, StopAll,
    SetFx, BurstFx, SetScreenFx,
    Count
};

enum class Cat { Eventos, Control, Movimiento, Sonido, Apariencia, Datos, Forge3D };

// Descripcion de un bloque para el editor y el archivo del proyecto.
// title: texto con huecos {0} {1} {2} (formulas) y {t} (texto: nombre de mensaje, objeto, sonido, variable...).
struct OpInfo {
    Op op;
    const char* key;    // nombre en el archivo
    Cat cat;
    const char* title;
    const char* help;
    const char* t;      // valores por defecto: texto y formulas
    const char* f0;
    const char* f1;
    const char* f2;
    int indent;         // +1 abre, -1 cierra, 0 normal; 2 = evento (sombrero)
};
const OpInfo& opInfo(Op op);
const OpInfo* opInfoByKey(const std::string& key);
const char* catName(Cat c);
bool isHat(Op op);

struct Block {
    Op op = Op::Wait;
    std::string t;       // texto (mensaje, nombre de objeto/sonido/variable/apariencia/escena)
    std::string f[3];    // formulas
};

enum class Phys { None, Dynamic, Static };

// ---------------------------------------------------------------- enemigos y monstruos
// Estados de animacion de un enemigo: 0 quieto, 1 caminar, 2 atacar, 3 recibir dano.
// "frames" son imagenes (sprites) o modelos .fmdl que se van alternando; los numeros son una animacion
// sencilla para modelos 3D (subir/bajar, balanceo, embestida, aplastar).
enum AnimId { kIdle = 0, kWalk = 1, kAttack = 2, kHurt = 3, kAnimCount = 4 };
struct AnimState {
    std::vector<std::string> frames;
    float fps = 6.f;
    float bob = 0.f, sway = 0.f, lunge = 0.f, squash = 0.f;
};
// Emisor de particulas (humo, fuego, chispas, nieve...). Medidas en metros (en 2D se multiplican por 100).
struct FxCfg {
    bool on = false;
    int kind = 0;                       // solo para recordar que preset se uso
    float rate = 20.f, life = 1.2f, size = 0.3f, speed = 1.5f, spread = 0.5f, gravity = 0.f, grow = 0.f, a0 = 0.8f;
    bool glow = false;                  // brillo (se suma a lo de atras)
    float c0[3] = {1, 1, 1}, c1[3] = {1, 1, 1};  // color al nacer -> color al morir
    std::string tex;                    // imagen propia (si no, un punto suave)
};
void fxPreset(FxCfg& f, int id);        // 0 humo, 1 fuego, 2 chispas, 3 nieve, 4 energia

// Capa de la camara: imagenes fijas en pantalla y efectos (VHS, camara de video...).
struct Overlay { std::string tex; float x = 0.5f, y = 0.5f, w = 0.3f, h = 0.3f, alpha = 1.f; };
struct ScreenFx {
    float scan = 0, noise = 0, vignette = 0, tint = 0, track = 0;
    float tintC[3] = {0, 0, 0};
    bool rec = false;
    bool any() const { return scan > 0 || noise > 0 || vignette > 0 || tint > 0 || track > 0 || rec; }
};
void sfxPreset(ScreenFx& f, int id);    // 0 ninguno, 1 VHS, 2 camara de video, 3 vision nocturna, 4 pelicula vieja

enum class AiType { None, Shooter, Melee };
struct AiCfg {
    AiType type = AiType::None;
    bool sprite = false;           // true = imagen plana que mira al jugador; false = modelo 3D / cubo
    float hp = 3.f, speed = 2.f, sight = 14.f, dmg = 1.f, rate = 1.2f, reach = 1.3f;
    std::string projTex, projModel;  // proyectil del enemigo (solo Shooter)
    float projSize = 0.25f, projSpeed = 12.f, projColor[3] = {1.f, 0.3f, 0.2f};
    AnimState anim[kAnimCount];
};

struct Obj {
    std::string name = "objeto";
    Kind kind = Kind::Cube;
    V3 pos, scale{1, 1, 1};
    float yaw = 0;      // direccion en grados (2D: 90 = derecha, 0 = arriba; 3D: 0 = hacia -Z)
    float color[3] = {1, 1, 1};
    std::string tex;    // asset png/jpg actual ("" = sin textura)
    std::string model;  // asset .fmdl (modelo 3D importado)
    bool solid = true, visible = true, alive = true, spin = false;
    std::vector<Block> blocks;          // guiones (lista plana)
    std::vector<std::string> looks;     // apariencias (assets de imagen)
    std::vector<std::string> sounds;    // sonidos (assets de audio)
    std::vector<std::string> localVars; // variables solo de este objeto
    Phys phys = Phys::None;
    float mass = 1.f, bounce = 0.5f, friction = 0.2f;
    float transp = 0.f, bright = 100.f, hue = 0.f;  // efectos: transparencia %, brillo %, color
    int layer = 0;                      // orden de dibujo en 2D
    bool bg = false;                    // es el "Fondo" de una escena 2D
    bool noColor = false;               // sin color: transparente (si tiene imagen, solo se ve la imagen)
    bool texTile = false;               // 3D: repetir la imagen cada metro (false = estirarla a toda la cara)
    FxCfg fx;                           // particulas que lanza este objeto
    AiCfg ai;                           // enemigo / monstruo (type None = objeto normal)
    bool clone = false;                 // solo en juego: este objeto es un clon (no se guarda)
};

struct Scene {
    std::string name = "main";
    bool is3d = true;
    V3 sunDir{-0.4f, -1.f, -0.3f};
    float sun[3] = {1.f, 0.95f, 0.85f};
    float skyTop[3] = {0.25f, 0.45f, 0.8f};
    float skyBot[3] = {0.75f, 0.85f, 0.95f};
    float ambient = 0.35f;
    float fog = 0.012f;
    V3 start{0, 0.05f, 0};
    V3 cam{0, 8.f, 10.f};   // camara fija (vista fija en tercera persona)
    std::vector<Overlay> overlays;  // imagenes fijas en pantalla
    ScreenFx sfx;                   // efectos de pantalla
    std::vector<Obj> objs;
};

// Botones tactiles en pantalla (escenas 3D).
enum class HudAct { None, Jump, Shoot, Interact };
struct HudBtn {
    std::string label = "OK";
    float x = 0.5f, y = 0.5f, r = 0.08f;  // centro (0..1) y radio (fraccion del alto)
    HudAct act = HudAct::None;
    float color[3] = {1, 1, 1};
};

// Arma en primera persona.
struct Weapon {
    bool enabled = true;
    std::string tex;      // sprite (asset png/jpg); vacio = arma basica dibujada
    float scale = 0.5f;   // alto del sprite (fraccion del alto de pantalla)
    float ox = 0, oy = 0; // desplazamiento (fraccion de pantalla)
    float rate = 0.25f;   // segundos entre disparos
    float range = 60.f;
    std::string model;      // arma 3D (asset .fmdl) en lugar del sprite
    float damage = 1.f;
    // proyectil visible
    std::string projTex, projModel;
    float projSize = 0.2f, projSpeed = 40.f, projColor[3] = {1.f, 0.85f, 0.3f};
    int projShape = 0;      // 0 esfera/bala (cubo pequeno), 1 imagen plana (sprite), 2 modelo
};

// Opciones al exportar el juego (APK / EXE).
struct ExportCfg {
    std::string appName;                 // nombre de la app en Android (si vacio, el del proyecto)
    std::string appId = "com.mijuego.app";  // paquete: com.tuempresa.tujuego
    std::string verName = "1.0";
    int verCode = 1;
    int orient = 0;                      // 0 horizontal, 1 vertical, 2 automatico
    std::string icon;                    // imagen png del proyecto para el icono
    std::string exeName;                 // nombre del archivo .exe (sin .exe)
    std::string winTitle;                // titulo de la ventana en Windows
    bool fullscreen = false;
    int winW = 1280, winH = 720;
};

enum CamMode { kFirstPerson = 0, kShoulder = 1, kFixed = 2 };
struct PlayerCfg {
    int cam = kFirstPerson;
    std::string model;      // cuerpo del jugador (visible en tercera persona)
    float speed = 4.5f, jump = 7.f;
};

using Files = std::map<std::string, std::vector<uint8_t>>;

struct Project {
    std::string name = "juego";
    std::vector<Scene> scenes;
    Files assets;  // texturas, sonidos, modelos
    bool hudDefault = true;       // true = botones por defecto (saltar y disparar)
    std::vector<HudBtn> hud;      // botones propios (si hudDefault == false; vacio = sin botones)
    Weapon weapon;
    PlayerCfg player;
    ExportCfg exportCfg;
    bool showVars = false;
    std::vector<std::string> globalVars;  // variables para todos los objetos y escenas
};

std::vector<HudBtn> defaultHud();

bool loadProject(const Files& files, Project& out, std::string& err);
std::string writeProject(const Project& p);  // genera project.forge
bool loadDemo(Project& out);

const char* kindName(Kind k);

// Garantiza que una escena 3D tenga su objeto "Jugador" (se puede mover y editar como cualquier objeto).
// Su centro esta 0.85 m sobre los pies; Scene::start se mantiene sincronizado.
void ensurePlayer(Scene& s);
int playerIndex(const Scene& s);

}  // namespace forge
