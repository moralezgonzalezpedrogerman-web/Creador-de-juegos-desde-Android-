#include "scene.h"

namespace forge {

static Block B(Op op, const char* t = "", const char* f0 = "", const char* f1 = "", const char* f2 = "") {
    Block b;
    b.op = op;
    b.t = t;
    b.f[0] = f0; b.f[1] = f1; b.f[2] = f2;
    return b;
}

static Obj mk(Kind k, const char* name, V3 pos, V3 scale, float r, float g, float bl, bool solid = true) {
    Obj o;
    o.kind = k;
    o.name = name;
    o.pos = pos;
    o.scale = scale;
    o.color[0] = r; o.color[1] = g; o.color[2] = bl;
    o.solid = solid;
    return o;
}

bool loadDemo(Project& out) {
    out = Project();
    out.name = "demo";
    out.globalVars = {"gemas", "puntos"};

    // Menu en 2D (como Pocket Code): fondo + boton
    Scene menu;
    menu.name = "Menu";
    menu.is3d = false;
    menu.skyTop[0] = .10f; menu.skyTop[1] = .12f; menu.skyTop[2] = .25f;
    menu.skyBot[0] = .20f; menu.skyBot[1] = .25f; menu.skyBot[2] = .45f;
    Obj bg = mk(Kind::Cube, "Fondo", {0, 0, 0}, {1, 1, 1}, .20f, .25f, .45f, false);
    bg.bg = true;
    bg.layer = -1000;
    menu.objs.push_back(bg);
    Obj btn = mk(Kind::Cube, "Boton", {0, 0, 0}, {420, 130, 10}, .95f, .55f, .15f, false);
    btn.yaw = 90;
    btn.blocks = {B(Op::WhenTap), B(Op::StartScene, "Nivel1")};
    menu.objs.push_back(btn);
    out.scenes.push_back(menu);

    // Nivel en 3D (como FPS Creator)
    Scene lv;
    lv.name = "Nivel1";
    lv.is3d = true;
    lv.start = {0, 0.05f, 6};
    Obj floor = mk(Kind::Floor, "Suelo", {0, -.1f, 0}, {40, .2f, 40}, .45f, .62f, .40f);
    floor.blocks = {B(Op::WhenStart), B(Op::SetVar, "gemas", "0"), B(Op::SetVar, "puntos", "0"),
                    B(Op::ShowVar, "gemas", "-420", "440"), B(Op::ShowVar, "puntos", "420", "440")};
    lv.objs.push_back(floor);
    lv.objs.push_back(mk(Kind::Wall, "Pared_fondo", {0, 1.5f, -10}, {12, 3, .5f}, .8f, .8f, .86f));
    lv.objs.push_back(mk(Kind::Wall, "Pared_izq", {-6, 1.5f, -5}, {.5f, 3, 10}, .8f, .8f, .86f));
    lv.objs.push_back(mk(Kind::Wall, "Pared_der", {6, 1.5f, -5}, {.5f, 3, 10}, .8f, .8f, .86f));

    Obj door = mk(Kind::Wall, "Puerta", {0, 1.2f, -4}, {3, 2.4f, .4f}, .55f, .35f, .2f);
    door.blocks = {B(Op::WhenTap), B(Op::StartSound, "puerta"), B(Op::Repeat, "", "24"), B(Op::ChangeY, "", "0.1"),
                   B(Op::Wait, "", "0.02"), B(Op::LoopEnd)};
    lv.objs.push_back(door);

    Obj gem = mk(Kind::Item, "Gema", {3, 1, -3}, {.5f, .5f, .5f}, 1.f, .8f, .1f, false);
    gem.spin = true;
    gem.blocks = {B(Op::WhenTap), B(Op::StartSound, "recoger"), B(Op::ChangeVar, "gemas", "1"),
                  B(Op::Say, "", "unir('Gemas: ', gemas)"), B(Op::Destroy)};
    lv.objs.push_back(gem);
    Obj gem2 = mk(Kind::Item, "Gema2", {-3, 1, -7}, {.5f, .5f, .5f}, .2f, .8f, 1.f, false);
    gem2.spin = true;
    gem2.blocks = gem.blocks;
    lv.objs.push_back(gem2);

    Obj lamp = mk(Kind::Light, "Lampara", {-4, 3, -6}, {14, 1, 1}, 1.f, .7f, .4f, false);
    lv.objs.push_back(lamp);

    Obj cube = mk(Kind::Cube, "Cubo_giratorio", {3, .6f, -6}, {1.2f, 1.2f, 1.2f}, .9f, .25f, .25f);
    cube.blocks = {B(Op::WhenStart), B(Op::Forever), B(Op::TurnRight, "", "2"), B(Op::LoopEnd)};
    lv.objs.push_back(cube);

    // Blanco: al dispararle suma un punto, se oculta y vuelve a aparecer
    Obj target = mk(Kind::Cube, "Blanco", {-3, 1, -8}, {1, 1, 1}, .9f, .1f, .1f);
    target.blocks = {B(Op::WhenShot), B(Op::ChangeVar, "puntos", "1"), B(Op::Hide), B(Op::Wait, "", "2"), B(Op::Show)};
    lv.objs.push_back(target);

    out.scenes.push_back(lv);
    return true;
}

}  // namespace forge
