#include "renderer.h"
#include <algorithm>
#include "model.h"
#include <cmath>
#include <cstring>
#include <functional>
#include <cstdlib>
#include <cstdio>

#define STB_IMAGE_IMPLEMENTATION
#define STBI_ONLY_PNG
#define STBI_ONLY_JPEG
#define STBI_NO_STDIO
#include "stb_image.h"

#ifdef FORGE_GLES
#define SHV "#version 300 es\nprecision highp float;\nprecision highp int;\nprecision highp sampler2D;\nprecision highp sampler2DShadow;\n"
#else
#define SHV "#version 330 core\n"
#endif

namespace forge {

// ---------------------------------------------------------------- shaders
static const char* kMainVS = SHV R"(
layout(location=0) in vec3 aPos;
layout(location=1) in vec3 aN;
layout(location=2) in vec2 aUV;
uniform mat4 uVP, uM, uLVP;
uniform int uUV1;
uniform float uTile, uTime, uSway;
out vec3 vN; out vec3 vWP; out vec2 vUV; out vec4 vLP;
void main(){
  vec4 wp = uM * vec4(aPos, 1.0);
  if (uSway > 0.0) {
    float k = 1.0 - aUV.y;
    k = k * k;
    wp.x += sin(uTime * 1.9 + wp.x * 0.9 + wp.z * 0.6) * uSway * k;
    wp.z += cos(uTime * 1.5 + wp.z * 0.8 + wp.x * 0.3) * uSway * 0.6 * k;
  }
  vWP = wp.xyz;
  vN = normalize(mat3(uM) * aN);
  if (uUV1 == 1) vUV = aUV;
  else {
    vec3 n = abs(vN);
    vec2 uv = (n.y > 0.5) ? wp.xz : ((n.x > 0.5) ? wp.zy : wp.xy);
    vUV = uv / uTile;
  }
  vLP = uLVP * wp;
  gl_Position = uVP * wp;
}
)";

static const char* kMainFS = SHV R"(
in vec3 vN; in vec3 vWP; in vec2 vUV; in vec4 vLP;
out vec4 oColor;
uniform sampler2D uTex;
uniform sampler2DShadow uSh;
uniform vec4 uColor;
uniform vec3 uSunDir, uSunCol, uSkyTop, uSkyBot, uCam;
uniform float uAmb, uFog, uTexel, uRefl, uTime, uGS, uShAmt;
uniform int uSpotOn, uCookieOn;
uniform vec3 uSpotPos, uSpotDir, uSpotCol;
uniform float uSpotCone, uSpotRange, uSpotTan;
uniform sampler2D uCookie;
uniform vec3 uTint, uFogCol, uColor2;
uniform int uUnlit, uNL, uShOn, uVeg, uRtx;
uniform vec4 uPL[4];
uniform vec3 uPC[4];
vec3 aces(vec3 x){ return clamp((x * (2.51 * x + 0.03)) / (x * (2.43 * x + 0.59) + 0.14), 0.0, 1.0); }
void main(){
  vec4 t;
  if (uVeg == 3) {   // pintura de suelo: la textura sigue al mundo y la pincelada tiene borde suave
    vec4 tx = texture(uTex, vWP.xz * uGS);
    float m = 1.0 - smoothstep(0.28, 0.5, length(vUV - 0.5));
    t = vec4(tx.rgb * uColor.rgb, tx.a * m);
    if (t.a < 0.01) discard;
  } else if (uVeg == 1) {
    vec4 tx = texture(uTex, vUV);
    t = vec4(tx.rgb * mix(uColor2, uColor.rgb, clamp(vUV.y, 0.0, 1.0)), tx.a);
    if (t.a < 0.45) discard;
    t.a = 1.0;
  } else {
    t = texture(uTex, vUV) * uColor;
    if (t.a < 0.08) discard;
  }
  if (uUnlit == 1) { oColor = t; return; }
  vec3 n = normalize(vN);
  if (uVeg == 2) {
    n = normalize(n + 0.05 * vec3(sin(vWP.x * 0.9 + uTime * 1.3) + sin(vWP.z * 1.7 - uTime * 0.9), 0.0,
                                  cos(vWP.z * 1.1 + uTime * 1.1) + cos(vWP.x * 1.9 + uTime * 0.7)));
  }
  float ndl = max(dot(n, -uSunDir), 0.0);
  vec3 p = vLP.xyz / vLP.w * 0.5 + 0.5;
  float sh = 1.0;
  if (uShOn == 1 && p.z <= 1.0 && p.x > 0.0 && p.x < 1.0 && p.y > 0.0 && p.y < 1.0) {
    float b = 0.0012;
    if (uRtx == 1) {  // sombras suaves: 9 muestras
      sh = 0.0;
      for (int i = -1; i <= 1; i++)
        for (int j = -1; j <= 1; j++)
          sh += texture(uSh, vec3(p.xy + uTexel * 1.7 * vec2(float(i), float(j)), p.z - b));
      sh /= 9.0;
    } else {
      sh = 0.25 * (texture(uSh, vec3(p.xy + uTexel * vec2(-0.5, -0.5), p.z - b))
                 + texture(uSh, vec3(p.xy + uTexel * vec2( 0.5, -0.5), p.z - b))
                 + texture(uSh, vec3(p.xy + uTexel * vec2(-0.5,  0.5), p.z - b))
                 + texture(uSh, vec3(p.xy + uTexel * vec2( 0.5,  0.5), p.z - b)));
    }
  }
  vec3 hemi = mix(uSkyBot * 0.5, uSkyTop, n.y * 0.5 + 0.5) * uAmb * 1.5;
  float shv = 1.0 - (1.0 - sh) * min(uShAmt, 1.0);                                   // sombras mas claras
  hemi *= 1.0 - clamp(uShAmt - 1.0, 0.0, 1.0) * (1.0 - sh) * 0.75;                   // sombras mas oscuras
  vec3 light = hemi + uSunCol * ndl * shv;
  if (uSpotOn == 1) {   // linterna
    vec3 d = vWP - uSpotPos;
    float dist = max(length(d), 0.05);
    vec3 L = d / dist;
    float cd = dot(L, uSpotDir);
    float cone = smoothstep(uSpotCone, mix(uSpotCone, 1.0, 0.45), cd);
    float at = clamp(1.0 - dist / uSpotRange, 0.0, 1.0);
    float pat = 1.0;
    if (uCookieOn == 1 && cd > 0.05) {
      vec3 rt = normalize(cross(uSpotDir, vec3(0.0, 1.0, 0.0)));
      vec3 up = cross(rt, uSpotDir);
      vec2 q = vec2(dot(d, rt), dot(d, up)) / (dot(d, uSpotDir) * uSpotTan);
      pat = (abs(q.x) < 1.0 && abs(q.y) < 1.0) ? texture(uCookie, q * 0.5 + 0.5).r : 0.0;
    }
    float nl = clamp(dot(n, -L), 0.0, 1.0) * 0.85 + 0.15;
    light += uSpotCol * nl * cone * at * at * pat * 1.6;
  }
  for (int i = 0; i < 4; i++) {
    if (i >= uNL) break;
    vec3 d = uPL[i].xyz - vWP;
    float dist = length(d);
    float at = clamp(1.0 - dist / uPL[i].w, 0.0, 1.0);
    light += uPC[i] * max(dot(n, d / max(dist, 0.001)), 0.0) * at * at * 1.5;
  }
  vec3 c = t.rgb * light * uTint;
  vec3 v = normalize(uCam - vWP);
  float fresnel = pow(1.0 - max(dot(n, v), 0.0), 3.0);
  if (uVeg == 2) {
    vec3 r = reflect(-v, n);
    vec3 env = mix(uSkyBot * 0.7, uSkyTop, clamp(r.y, 0.0, 1.0));
    env += uSunCol * pow(max(dot(r, -uSunDir), 0.0), 120.0) * 1.5;
    c = mix(c, env, clamp(0.28 + 0.62 * fresnel, 0.0, 0.92));
  } else if (uVeg == 0 && (uRefl > 0.0 || uRtx == 1)) {
    vec3 r = reflect(-v, n);
    float up = clamp(r.y * 0.5 + 0.5, 0.0, 1.0);
    vec3 env = mix(uSkyBot * 0.55, uSkyTop * 0.9, up * up);
    env *= mix(0.4, 1.0, smoothstep(-0.25, 0.25, r.y));          // abajo del horizonte: suelo oscuro
    env += uSunCol * pow(max(dot(r, -uSunDir), 0.0), 90.0) * 0.9;  // brillo pequeño del sol
    env *= mix(vec3(1.0), t.rgb * 1.5, 0.6);                      // el reflejo toma el color del material
    float amt = uRefl > 0.0 ? clamp((0.03 + 0.5 * fresnel) * uRefl, 0.0, 0.5) : 0.0;
    if (uRtx == 1) amt = max(amt, 0.04 + 0.22 * fresnel);
    c = mix(c, env, amt);
  }
  if (uRtx == 1 && uVeg == 0) {
    vec3 h = normalize(v - uSunDir);
    c += uSunCol * pow(max(dot(n, h), 0.0), 48.0) * 0.28 * sh;
    c *= mix(0.8, 1.0, n.y * 0.5 + 0.5);
    c = mix(c, aces(c * 1.12), 0.55);
  }
  float f = clamp(exp(-uFog * length(uCam - vWP)), 0.0, 1.0);
  oColor = vec4(mix(uFogCol, c, f), uVeg == 2 ? uColor.a : (uVeg == 3 ? t.a : t.a));
}
)";

static const char* kDepthVS = SHV R"(
layout(location=0) in vec3 aPos;
uniform mat4 uLVP, uM;
void main(){ gl_Position = uLVP * uM * vec4(aPos, 1.0); }
)";
static const char* kDepthFS = SHV R"(
void main(){}
)";

static const char* kSkyVS = SHV R"(
uniform vec3 uFwd, uRight, uUp;
uniform float uTX, uTY;
out vec3 vRay;
void main(){
  vec2 p = vec2(float((gl_VertexID << 1) & 2), float(gl_VertexID & 2)) * 2.0 - 1.0;
  vRay = uFwd + uRight * p.x * uTX + uUp * p.y * uTY;
  gl_Position = vec4(p, 0.0, 1.0);
}
)";
static const char* kSkyFS = SHV R"(
in vec3 vRay;
out vec4 oColor;
uniform vec3 uTop, uBot, uSunDir, uSunCol;
void main(){
  vec3 d = normalize(vRay);
  float t = clamp(d.y * 1.2 + 0.2, 0.0, 1.0);
  vec3 col = mix(uBot, uTop, pow(t, 0.7));
  float s = max(dot(d, -uSunDir), 0.0);
  col += uSunCol * (pow(s, 600.0) * 2.0 + pow(s, 8.0) * 0.12);
  oColor = vec4(col, 1.0);
}
)";

// ---------------------------------------------------------------- helpers
static GLuint compile(GLenum type, const char* src) {
    GLuint s = glCreateShader(type);
    glShaderSource(s, 1, &src, nullptr);
    glCompileShader(s);
    GLint ok = 0;
    glGetShaderiv(s, GL_COMPILE_STATUS, &ok);
    if (!ok) {
        char log[512];
        glGetShaderInfoLog(s, sizeof log, nullptr, log);
        fprintf(stderr, "shader: %s\n", log);
    }
    return s;
}

static bool build(GLuint& prog, const char* vs, const char* fs) {
    GLuint v = compile(GL_VERTEX_SHADER, vs), f = compile(GL_FRAGMENT_SHADER, fs);
    prog = glCreateProgram();
    glAttachShader(prog, v);
    glAttachShader(prog, f);
    glLinkProgram(prog);
    glDeleteShader(v);
    glDeleteShader(f);
    GLint ok = 0;
    glGetProgramiv(prog, GL_LINK_STATUS, &ok);
    if (!ok) {
        char log[512];
        glGetProgramInfoLog(prog, sizeof log, nullptr, log);
        fprintf(stderr, "link: %s\n", log);
    }
    return ok != 0;
}

GLint Renderer::Prog::u(const char* n) {
    auto it = loc.find(n);
    if (it != loc.end()) return it->second;
    GLint l = glGetUniformLocation(id, n);
    loc[n] = l;
    return l;
}

// Atributos de vertice: posicion, normal, uv (32 bytes) sobre el VBO enlazado.
void Renderer::setupAttribs() {
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 32, (const void*)0);
    glEnableVertexAttribArray(1);
    glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 32, (const void*)12);
    glEnableVertexAttribArray(2);
    glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, 32, (const void*)24);
}

// ---------------------------------------------------------------- init
bool Renderer::init(int shadowSize) {
    shadowSize_ = shadowSize;
    if (!build(main_.id, kMainVS, kMainFS) || !build(sky_.id, kSkyVS, kSkyFS) ||
        !build(depth_.id, kDepthVS, kDepthFS))
        return false;

    // Cubo unitario: 24 vertices + 36 indices de 16 bits.
    static const float F[6][9] = {  // n, u, v
        {1, 0, 0, 0, 0, -1, 0, 1, 0}, {-1, 0, 0, 0, 0, 1, 0, 1, 0}, {0, 1, 0, 1, 0, 0, 0, 0, -1},
        {0, -1, 0, 1, 0, 0, 0, 0, 1}, {0, 0, 1, 1, 0, 0, 0, 1, 0},  {0, 0, -1, -1, 0, 0, 0, 1, 0}};
    static const int S[4][2] = {{-1, -1}, {1, -1}, {1, 1}, {-1, 1}};
    float vtx[24 * 8];
    unsigned short idx[36];
    for (int f = 0; f < 6; f++) {
        const float* a = F[f];
        for (int k = 0; k < 4; k++) {
            float s = (float)S[k][0], t = (float)S[k][1];
            float* v = vtx + (f * 4 + k) * 8;
            for (int c = 0; c < 3; c++) v[c] = a[c] * 0.5f + (s * a[3 + c] + t * a[6 + c]) * 0.5f;
            v[3] = a[0]; v[4] = a[1]; v[5] = a[2];
            v[6] = (s + 1) * 0.5f; v[7] = (t + 1) * 0.5f;
        }
        unsigned short b = (unsigned short)(f * 4), *i = idx + f * 6;
        i[0] = b; i[1] = b + 1; i[2] = b + 2; i[3] = b; i[4] = b + 2; i[5] = b + 3;
    }
    glGenVertexArrays(1, &vao_);
    glBindVertexArray(vao_);
    glGenBuffers(1, &vbo_);
    glBindBuffer(GL_ARRAY_BUFFER, vbo_);
    glBufferData(GL_ARRAY_BUFFER, sizeof vtx, vtx, GL_STATIC_DRAW);
    glGenBuffers(1, &ibo_);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, ibo_);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof idx, idx, GL_STATIC_DRAW);
    setupAttribs();
    glGenVertexArrays(1, &vaoEmpty_);

    // Textura blanca 1x1.
    unsigned char px[4] = {255, 255, 255, 255};
    glGenTextures(1, &white_);
    glBindTexture(GL_TEXTURE_2D, white_);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, 1, 1, 0, GL_RGBA, GL_UNSIGNED_BYTE, px);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

    // Mapa de sombras de 16 bits (2 MB a 1024x1024).
    glGenTextures(1, &shadowTex_);
    glBindTexture(GL_TEXTURE_2D, shadowTex_);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_DEPTH_COMPONENT16, shadowSize_, shadowSize_, 0, GL_DEPTH_COMPONENT,
                 GL_UNSIGNED_SHORT, nullptr);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_COMPARE_MODE, GL_COMPARE_REF_TO_TEXTURE);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_COMPARE_FUNC, GL_LEQUAL);
    glGenFramebuffers(1, &fbo_);
    glBindFramebuffer(GL_FRAMEBUFFER, fbo_);
    glFramebufferTexture2D(GL_FRAMEBUFFER, GL_DEPTH_ATTACHMENT, GL_TEXTURE_2D, shadowTex_, 0);
    GLenum none = GL_NONE;
    glDrawBuffers(1, &none);
    glReadBuffer(GL_NONE);
    bool ok = glCheckFramebufferStatus(GL_FRAMEBUFFER) == GL_FRAMEBUFFER_COMPLETE;
    glBindFramebuffer(GL_FRAMEBUFFER, 0);
    return ok;
}

void Renderer::shutdown() {
    // Al perder el contexto GL (Android) los objetos ya no existen: solo olvidamos los ids.
    main_ = Prog(); sky_ = Prog(); depth_ = Prog();
    vao_ = vbo_ = ibo_ = vaoEmpty_ = fbo_ = shadowTex_ = white_ = 0;
    tex_.clear();
    models_.clear();
}

Renderer::TexInfo& Renderer::texture(const Game& g, const std::string& name) {
    static TexInfo none;
    if (name.empty()) { none.id = white_; return none; }
    auto it = tex_.find(name);
    if (it != tex_.end()) return it->second;
    TexInfo ti;
    ti.id = white_;
    auto a = g.proj.assets.find(name);
    if (a != g.proj.assets.end()) {
        int w, h, c;
        stbi_set_flip_vertically_on_load(1);
        unsigned char* d = stbi_load_from_memory(a->second.data(), (int)a->second.size(), &w, &h, &c, 4);
        if (d) {
            glGenTextures(1, &ti.id);
            glBindTexture(GL_TEXTURE_2D, ti.id);
            glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, w, h, 0, GL_RGBA, GL_UNSIGNED_BYTE, d);
            glGenerateMipmap(GL_TEXTURE_2D);
            glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
            glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
            glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
            glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
            ti.w = w; ti.h = h;
            stbi_image_free(d);  // la copia en RAM se libera: solo queda la de la GPU
        }
    }
    return tex_[name] = ti;
}

unsigned Renderer::uploadRGBA(const std::string& key, int w, int h, const uint8_t* px) {
    auto it = tex_.find(key);
    if (it != tex_.end()) return it->second.id;
    TexInfo ti;
    glGenTextures(1, &ti.id);
    glBindTexture(GL_TEXTURE_2D, ti.id);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, w, h, 0, GL_RGBA, GL_UNSIGNED_BYTE, px);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
    ti.w = w; ti.h = h;
    tex_[key] = ti;
    return ti.id;
}

unsigned Renderer::updateRGBA(const std::string& key, int w, int h, const uint8_t* px) {
    auto it = tex_.find(key);
    if (it == tex_.end()) return uploadRGBA(key, w, h, px);
    glBindTexture(GL_TEXTURE_2D, it->second.id);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, w, h, 0, GL_RGBA, GL_UNSIGNED_BYTE, px);
    it->second.w = w; it->second.h = h;
    return it->second.id;
}

unsigned Renderer::rawTexture(const std::string& key, int* w, int* h) const {
    auto it = tex_.find(key);
    if (it == tex_.end()) return 0;
    if (w) *w = it->second.w;
    if (h) *h = it->second.h;
    return it->second.id;
}

void Renderer::forget(const std::string& name) {
    auto it = tex_.find(name);
    if (it == tex_.end()) return;
    if (it->second.id && it->second.id != white_) glDeleteTextures(1, &it->second.id);
    tex_.erase(it);
}

unsigned Renderer::textureId(const Game& g, const std::string& name, int* w, int* h) {
    if (name.empty() || !g.proj.assets.count(name)) return 0;
    TexInfo& t = texture(g, name);
    if (t.id == white_) return 0;
    if (w) *w = t.w;
    if (h) *h = t.h;
    return t.id;
}

Renderer::ModelGL* Renderer::model(const Game& g, const std::string& name) {
    auto it = models_.find(name);
    if (it != models_.end()) return it->second.ok ? &it->second : nullptr;
    ModelGL& m = models_[name];
    auto a = g.proj.assets.find(name);
    ModelData md;
    if (a == g.proj.assets.end() || !modelRead(a->second.data(), a->second.size(), md)) return nullptr;
    glGenVertexArrays(1, &m.vao);
    glBindVertexArray(m.vao);
    glGenBuffers(1, &m.vbo);
    glBindBuffer(GL_ARRAY_BUFFER, m.vbo);
    glBufferData(GL_ARRAY_BUFFER, (GLsizeiptr)(md.v.size() * 4), md.v.data(), GL_STATIC_DRAW);
    glGenBuffers(1, &m.ibo);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, m.ibo);
    if (md.v.size() / 8 > 65535) {
        glBufferData(GL_ELEMENT_ARRAY_BUFFER, (GLsizeiptr)(md.idx.size() * 4), md.idx.data(), GL_STATIC_DRAW);
        m.itype = GL_UNSIGNED_INT;
    } else {
        std::vector<unsigned short> s(md.idx.begin(), md.idx.end());
        glBufferData(GL_ELEMENT_ARRAY_BUFFER, (GLsizeiptr)(s.size() * 2), s.data(), GL_STATIC_DRAW);
        m.itype = GL_UNSIGNED_SHORT;
    }
    setupAttribs();
    m.count = (int)md.idx.size();
    m.tex = md.tex;
    for (int i = 0; i < 3; i++) m.color[i] = md.color[i];
    m.ok = true;
    glBindVertexArray(vao_);
    return &m;
}

// Malla que cambia (terreno, modelos con esqueleto): se vuelve a subir solo si cambió su firma.
Renderer::ModelGL* Renderer::dynModel(const std::string& key, const std::vector<float>& v, const std::vector<uint32_t>& idx, unsigned long long sig) {
    ModelGL& m = models_[key];
    if (!m.vao) {
        glGenVertexArrays(1, &m.vao);
        glBindVertexArray(m.vao);
        glGenBuffers(1, &m.vbo);
        glBindBuffer(GL_ARRAY_BUFFER, m.vbo);
        glGenBuffers(1, &m.ibo);
        glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, m.ibo);
        m.sig = ~sig;
        m.itype = GL_UNSIGNED_INT;
    }
    if (m.sig != sig) {
        glBindVertexArray(m.vao);
        glBindBuffer(GL_ARRAY_BUFFER, m.vbo);
        glBufferData(GL_ARRAY_BUFFER, (GLsizeiptr)(v.size() * 4), v.data(), GL_DYNAMIC_DRAW);
        glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, m.ibo);
        glBufferData(GL_ELEMENT_ARRAY_BUFFER, (GLsizeiptr)(idx.size() * 4), idx.data(), GL_DYNAMIC_DRAW);
        setupAttribs();
        m.count = (int)idx.size();
        m.sig = sig;
        m.ok = true;
    }
    glBindVertexArray(vao_);
    return &m;
}

// Suelo deformable: rejilla de alturas en coordenadas relativas al objeto (la matriz solo lo traslada).
Renderer::ModelGL* Renderer::terrainMesh(const Game& g, int idx) {
    const Obj& o = g.sc->objs[idx];
    unsigned long long sig = (unsigned long long)o.terrVer * 1000003ULL;
    {
        float a[3] = {o.scale.x, o.scale.y, o.scale.z};
        unsigned u[3];
        std::memcpy(u, a, sizeof u);
        sig ^= ((unsigned long long)u[0] << 1) ^ ((unsigned long long)u[1] << 17) ^ ((unsigned long long)u[2] << 33);
        sig ^= std::hash<std::string>()(o.name + "|" + g.sc->name) << 3;
    }
    std::string key = "::terr:" + std::to_string(idx);
    auto it = models_.find(key);
    if (it != models_.end() && it->second.sig == sig) return &it->second;
    int n = o.tn;
    std::vector<float> v((size_t)n * n * 8);
    auto H = [&](int i, int j) { i = std::max(0, std::min(n - 1, i)); j = std::max(0, std::min(n - 1, j)); return o.heights[(size_t)j * n + i]; };
    float dx = o.scale.x / (n - 1), dz = o.scale.z / (n - 1);
    for (int j = 0; j < n; j++)
        for (int i = 0; i < n; i++) {
            float* q = &v[((size_t)j * n + i) * 8];
            q[0] = ((float)i / (n - 1) - 0.5f) * o.scale.x;
            q[1] = o.scale.y * 0.5f + H(i, j);
            q[2] = ((float)j / (n - 1) - 0.5f) * o.scale.z;
            float gx = (H(i + 1, j) - H(i - 1, j)) / (2 * dx), gz = (H(i, j + 1) - H(i, j - 1)) / (2 * dz);
            float l = std::sqrt(gx * gx + 1.f + gz * gz);
            q[3] = -gx / l; q[4] = 1.f / l; q[5] = -gz / l;
            q[6] = (float)i / (n - 1); q[7] = (float)j / (n - 1);
        }
    std::vector<uint32_t> id;
    id.reserve((size_t)(n - 1) * (n - 1) * 6);
    for (int j = 0; j < n - 1; j++)
        for (int i = 0; i < n - 1; i++) {
            uint32_t a = j * n + i, b = a + 1, c = a + n, d = c + 1;
            id.insert(id.end(), {a, c, b, b, c, d});
        }
    return dynModel(key, v, id, sig);
}

// Si el objeto tiene una animacion de esqueleto activa, devuelve el modelo ya deformado; si no, 'base'.
Renderer::ModelGL* Renderer::skinned(Game& g, int idx, const std::string& model, ModelGL* base) {
    if (!base || model.empty()) return base;
    const std::vector<float>* sv = nullptr;
    const std::vector<uint32_t>* si = nullptr;
    unsigned long long sg = 0;
    if (!g.skinVerts(idx, model, sv, si, sg)) return base;
    ModelGL* dm = dynModel("::skin:" + std::to_string(idx), *sv, *si, sg);
    dm->tex = base->tex;
    for (int k = 0; k < 3; k++) dm->color[k] = base->color[k];
    return dm;
}

void Renderer::box(Prog& p, V3 pos, V3 scale, float r, float g, float b, float a) {
    M4 m = modelMat(pos, 0, scale);
    glUniformMatrix4fv(p.u("uM"), 1, GL_FALSE, m.m);
    glUniform4f(p.u("uColor"), r, g, b, a);
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, white_);
    glBindVertexArray(vao_);
    glDrawElements(GL_TRIANGLES, 36, GL_UNSIGNED_SHORT, nullptr);
}

void Renderer::drawModelAt(Game& g, Prog& p, const std::string& model, const std::string& tex, V3 pos, float yawDeg, V3 scale,
                           float r, float gg, float b, float a) {
    ModelGL* md = forceMd_ ? forceMd_ : (model.empty() ? nullptr : this->model(g, model));
    forceMd_ = nullptr;
    M4 m = modelMat(pos, yawDeg, scale);
    glUniformMatrix4fv(p.u("uM"), 1, GL_FALSE, m.m);
    float c[3] = {r * (md ? md->color[0] : 1.f), gg * (md ? md->color[1] : 1.f), b * (md ? md->color[2] : 1.f)};
    glUniform4f(p.u("uColor"), c[0], c[1], c[2], a);
    glActiveTexture(GL_TEXTURE0);
    const std::string& tn = !tex.empty() ? tex : (md ? md->tex : tex);
    glBindTexture(GL_TEXTURE_2D, ovTex_ ? ovTex_ : texture(g, tn).id);
    glUniform1i(p.u("uUV1"), 1);
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, additive_ ? GL_ONE : GL_ONE_MINUS_SRC_ALPHA);
    glBindVertexArray(md ? md->vao : vao_);
    if (md) glDrawElements(GL_TRIANGLES, md->count, md->itype, nullptr);
    else glDrawElements(GL_TRIANGLES, 36, GL_UNSIGNED_SHORT, nullptr);
    glDisable(GL_BLEND);
    glBindVertexArray(vao_);
}

unsigned Renderer::softDot() {
    if (tex_.count("::softdot")) return tex_["::softdot"].id;
    const int N = 32;
    std::vector<uint8_t> px((size_t)N * N * 4);
    for (int y = 0; y < N; y++)
        for (int x = 0; x < N; x++) {
            float dx = (x + .5f) / N * 2.f - 1.f, dy = (y + .5f) / N * 2.f - 1.f;
            float d = std::sqrt(dx * dx + dy * dy), a = std::max(0.f, 1.f - d);
            a = a * a * (3.f - 2.f * a);
            uint8_t* o = &px[((size_t)y * N + x) * 4];
            o[0] = o[1] = o[2] = 255;
            o[3] = (uint8_t)(a * 255.f);
        }
    return uploadRGBA("::softdot", N, N, px.data());
}

// Particulas: puntos suaves (o la imagen elegida) que miran a la camara, con color que cambia y se desvanecen.
void Renderer::drawParticles(Game& g, Prog& p, bool is3) {
    if (g.parts.empty()) return;
    unsigned dot = softDot();
    for (int pass = 0; pass < 2; pass++) {  // primero las normales, luego las que brillan
        for (auto& q : g.parts) {
            if ((q.glow ? 1 : 0) != pass) continue;
            float t = 1.f - q.life / q.max;  // 0 recien nacida, 1 por morir
            float r = q.c0[0] + (q.c1[0] - q.c0[0]) * t, gg = q.c0[1] + (q.c1[1] - q.c0[1]) * t, b = q.c0[2] + (q.c1[2] - q.c0[2]) * t;
            float a = q.a0 * (1.f - t) * std::min(1.f, t * 12.f + 0.15f);
            float s = std::max(0.01f, q.size * (1.f + q.grow * t));
            additive_ = q.glow;
            ovTex_ = 0;
            if (!q.tex.empty()) {
                drawModelAt(g, p, "", q.tex, q.p, 0.f, V3{s, s, 0.02f}, r, gg, b, a);
                continue;
            }
            ovTex_ = dot;
            if (is3) {
                float yaw = std::atan2(camE_.x - q.p.x, camE_.z - q.p.z) / 0.0174532925f;
                drawModelAt(g, p, "", "", q.p, yaw, V3{s, s, 0.02f}, r, gg, b, a);
            } else {
                drawModelAt(g, p, "", "", q.p, 0.f, V3{s, s, 1.f}, r, gg, b, a);
            }
        }
    }
    ovTex_ = 0;
    additive_ = false;
}

// Imagen plana que siempre mira a la camara.
void Renderer::drawSprite(Game& g, Prog& p, const std::string& tex, V3 pos, float w, float h, float r, float gg, float b) {
    float yaw = std::atan2(camE_.x - pos.x, camE_.z - pos.z) / 0.0174532925f;
    drawModelAt(g, p, "", tex, pos, yaw, V3{w, h, 0.02f}, r, gg, b, 1.f);
}

// ---------------------------------------------------------------- vegetacion (pasto pintado)
static unsigned vegRnd(unsigned& st) { st = st * 1664525u + 1013904223u; return st >> 8; }
static float vegF(unsigned& st) { return (float)(vegRnd(st) & 0xFFFF) / 65535.f; }

// Texturas de pasto hechas por codigo (en gris: el color lo pone la capa).
unsigned Renderer::vegTexture(int style) {
    std::string key = "::veg" + std::to_string(style);
    if (tex_.count(key)) return tex_[key].id;
    const int N = 64;
    std::vector<uint8_t> px((size_t)N * N * 4, 0);
    unsigned st = 12345u + style * 77u;
    auto put = [&](int x, int y, float lum, float a) {
        if (x < 0 || y < 0 || x >= N || y >= N) return;
        uint8_t* o = &px[((size_t)y * N + x) * 4];
        float na = std::max((float)o[3] / 255.f, a);
        if (a >= (float)o[3] / 255.f) { o[0] = o[1] = o[2] = (uint8_t)std::max(0.f, std::min(255.f, lum * 255.f)); }
        o[3] = (uint8_t)(na * 255.f);
    };
    if (style == 2) {
        for (size_t i = 0; i < px.size(); i += 4) { px[i] = px[i + 1] = px[i + 2] = 255; px[i + 3] = 255; }
    } else {
        int blades = style == 1 ? 3 : 11;
        for (int b = 0; b < blades; b++) {
            float x0 = style == 1 ? 0.22f + 0.28f * b : 0.08f + 0.84f * vegF(st);
            float lean = style == 1 ? (b - 1) * 0.12f : (vegF(st) - 0.5f) * 0.38f;
            float hh = style == 1 ? (b == 1 ? 0.98f : 0.8f) : 0.45f + 0.55f * vegF(st);
            float var = 0.82f + 0.2f * vegF(st);
            float bw = style == 1 ? 0.085f : 0.03f + 0.02f * vegF(st);
            for (int y = 0; y < N; y++) {
                float v = (y + 0.5f) / N;
                if (v < 1.f - hh) continue;
                float t = (v - (1.f - hh)) / hh;                        // 0 punta, 1 base
                float cx = x0 + lean * (1.f - t) * (1.f - t) * 1.6f;     // la punta se dobla
                float hw = bw * std::pow(t, style == 1 ? 0.55f : 0.8f) + 0.004f;
                for (int x = 0; x < N; x++) {
                    float u = (x + 0.5f) / N, d = std::fabs(u - cx);
                    if (d > hw + 0.02f) continue;
                    float a = std::max(0.f, std::min(1.f, (hw - d) * N * 0.9f + 0.5f));
                    if (a <= 0.f) continue;
                    float lum = style == 1 ? ((hw - d) * N < 1.6f ? 0.42f : 0.97f) : (0.62f + 0.38f * (1.f - t)) * var * (d < hw * 0.18f ? 0.9f : 1.f);
                    put(x, y, lum, a);
                }
            }
        }
    }
    return uploadRGBA(key, N, N, px.data());
}

// ---------------------------------------------------------------- pintura de suelo
static float gHash(int x, int y, int seed) {
    unsigned h = (unsigned)(x * 374761393 + y * 668265263 + seed * 2147483647u);
    h = (h ^ (h >> 13)) * 1274126177u;
    return (float)((h ^ (h >> 16)) & 0xFFFF) / 65535.f;
}
// ruido de valor que se repite (para que la textura no tenga costuras)
static float gNoise(float x, float y, int period, int seed) {
    int xi = (int)std::floor(x), yi = (int)std::floor(y);
    float fx = x - xi, fy = y - yi;
    fx = fx * fx * (3 - 2 * fx); fy = fy * fy * (3 - 2 * fy);
    auto v = [&](int a, int b) { return gHash(((a % period) + period) % period, ((b % period) + period) % period, seed); };
    float a = v(xi, yi) + (v(xi + 1, yi) - v(xi, yi)) * fx, b = v(xi, yi + 1) + (v(xi + 1, yi + 1) - v(xi, yi + 1)) * fx;
    return a + (b - a) * fy;
}
static float gFbm(float u, float v, int base, int oct, int seed) {
    float a = 0.5f, sum = 0.f, nrm = 0.f;
    int per = base;
    for (int o = 0; o < oct; o++) { sum += a * gNoise(u * per, v * per, per, seed + o); nrm += a; a *= 0.5f; per *= 2; }
    return sum / nrm;
}

unsigned Renderer::groundTexture(int preset) {
    std::string key = "::gnd" + std::to_string(preset);
    if (tex_.count(key)) return tex_[key].id;
    const int N = 128;
    std::vector<uint8_t> px((size_t)N * N * 4);
    for (int y = 0; y < N; y++)
        for (int x = 0; x < N; x++) {
            float u = (float)x / N, v = (float)y / N, r, g, b;
            float n1 = gFbm(u, v, 4, 5, preset * 11), n2 = gFbm(u, v, 16, 3, preset * 11 + 5);
            switch (preset) {
                case 0: { float k = 0.78f + 0.22f * n1 + (n2 - 0.5f) * 0.12f; r = 0.86f * k; g = 0.74f * k; b = 0.50f * k; break; }   // arena
                case 1: { float k = 0.65f + 0.5f * n1; float st = gFbm(u * 2.f, v * 0.25f, 8, 3, 91); r = (0.20f + 0.18f * st) * k; g = (0.48f + 0.22f * st) * k; b = 0.12f * k; break; }  // pasto
                case 2: { float c = std::fabs(gFbm(u, v, 6, 4, 33) - 0.5f) * 2.f; float k = 0.42f + 0.3f * n1 - (c < 0.06f ? 0.18f : 0.f); r = k; g = k * 0.98f; b = k * 0.94f; break; }  // roca
                case 3: { float k = 0.92f + 0.08f * n2; r = k * 0.94f; g = k * 0.97f; b = k; break; }                                      // nieve
                default: { float k = 0.55f + 0.6f * n1; r = 0.42f * k; g = 0.29f * k; b = 0.18f * k; break; }                              // tierra
            }
            uint8_t* o = &px[((size_t)y * N + x) * 4];
            o[0] = (uint8_t)std::max(0.f, std::min(255.f, r * 255.f));
            o[1] = (uint8_t)std::max(0.f, std::min(255.f, g * 255.f));
            o[2] = (uint8_t)std::max(0.f, std::min(255.f, b * 255.f));
            o[3] = 255;
        }
    return uploadRGBA(key, N, N, px.data());
}

// Pinceladas de textura sobre el suelo: cuadritos suaves que siguen el relieve del terreno.
void Renderer::drawGround(Game& g, Prog& p) {
    const Scene& S = *g.sc;
    if (S.gnd.empty()) return;
    std::vector<const Obj*> terr;
    for (auto& o : S.objs) if (o.alive && o.kind == Kind::Floor && o.tn >= 2) terr.push_back(&o);
    glUniform1i(p.u("uVeg"), 3);
    glUniform1i(p.u("uUV1"), 1);
    glUniform1i(p.u("uUnlit"), 0);
    glUniform1f(p.u("uRefl"), 0.f);
    M4 id = modelMat(V3{0, 0, 0}, 0.f, V3{1, 1, 1});
    glUniformMatrix4fv(p.u("uM"), 1, GL_FALSE, id.m);
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    glDepthMask(GL_FALSE);
    glDisable(GL_CULL_FACE);
    glDepthFunc(GL_LEQUAL);
    for (size_t li = 0; li < S.gnd.size(); li++) {
        const GroundLayer& L = S.gnd[li];
        size_t n = L.pts.size() / 4;
        if (!n) continue;
        unsigned long long sig = (unsigned long long)L.ver * 1000003ULL ^ (n * 7919ULL) ^ ((unsigned long long)terr.size() << 40);
        sig ^= std::hash<std::string>()(S.name) << 3;
        std::string key = "::gnd:" + std::to_string(li);
        auto it = models_.find(key);
        ModelGL* md = nullptr;
        if (it != models_.end() && it->second.sig == sig) md = &it->second;
        else {
            std::vector<float> v;
            std::vector<uint32_t> idx;
            v.reserve(n * 16 * 8);
            idx.reserve(n * 54);
            const int C = 3;
            for (size_t i = 0; i < n; i++) {
                const float* P = &L.pts[i * 4];
                float sz = std::max(0.2f, P[3]);
                uint32_t base = (uint32_t)(v.size() / 8);
                for (int a = 0; a <= C; a++)
                    for (int b = 0; b <= C; b++) {
                        float fx = (float)a / C, fz = (float)b / C;
                        float x = P[0] + (fx - 0.5f) * 2.f * sz, z = P[2] + (fz - 0.5f) * 2.f * sz, y = P[1];
                        for (auto* o : terr) { float ty = terrainSurface(*o, x, z); if (ty > -1e8f) { y = ty; break; } }
                        v.insert(v.end(), {x, y + 0.025f + li * 0.004f, z, 0, 1, 0, fx, fz});
                    }
                for (int a = 0; a < C; a++)
                    for (int b = 0; b < C; b++) {
                        uint32_t i0 = base + a * (C + 1) + b, i1 = i0 + 1, i2 = i0 + (C + 1), i3 = i2 + 1;
                        idx.insert(idx.end(), {i0, i2, i1, i1, i2, i3});
                    }
            }
            md = dynModel(key, v, idx, sig);
        }
        glBindVertexArray(md->vao);
        float col[3] = {1.f, 1.f, 1.f};
        glUniform4f(p.u("uColor"), col[0], col[1], col[2], 1.f);
        glUniform1f(p.u("uGS"), L.scale);
        glActiveTexture(GL_TEXTURE0);
        glBindTexture(GL_TEXTURE_2D, L.preset == 5 ? texture(g, L.tex).id : groundTexture(L.preset));
        glDrawElements(GL_TRIANGLES, md->count, md->itype, nullptr);
    }
    glBindVertexArray(vao_);
    glDepthFunc(GL_LESS);
    glDepthMask(GL_TRUE);
    glDisable(GL_BLEND);
    glEnable(GL_CULL_FACE);
    glUniform1i(p.u("uVeg"), 0);
    glUniform1i(p.u("uUV1"), 0);
}

void Renderer::drawVeg(Game& g, Prog& p) {
    const Scene& S = *g.sc;
    if (S.veg.empty()) return;
    const int q = g.proj.quality;
    const float frac = q == 0 ? 0.35f : q == 1 ? 0.7f : 1.f;
    glDisable(GL_CULL_FACE);
    glUniform1i(p.u("uVeg"), 1);
    glUniform1i(p.u("uUV1"), 1);
    glUniform1i(p.u("uUnlit"), 0);
    glUniform1f(p.u("uRefl"), 0.f);
    M4 id = modelMat(V3{0, 0, 0}, 0.f, V3{1, 1, 1});
    glUniformMatrix4fv(p.u("uM"), 1, GL_FALSE, id.m);
    for (size_t li = 0; li < S.veg.size(); li++) {
        const VegLayer& L = S.veg[li];
        size_t n = L.pts.size() / 5;
        if (!n) continue;
        const int vpt = L.style == 2 ? 9 : (L.style == 0 ? 18 : 12);
        unsigned long long sig = (unsigned long long)L.ver * 1000003ULL ^ (n * 7919ULL) ^ ((unsigned long long)L.style << 40);
        { float a[2] = {L.h, L.w}; unsigned u[2]; std::memcpy(u, a, sizeof u); sig ^= ((unsigned long long)u[0] << 8) ^ ((unsigned long long)u[1] << 24); }
        sig ^= std::hash<std::string>()(S.name) << 5;
        std::string key = "::veg:" + std::to_string(li);
        auto it = models_.find(key);
        ModelGL* md = nullptr;
        if (it != models_.end() && it->second.sig == sig) md = &it->second;
        else {
            std::vector<float> v;
            v.reserve(n * vpt * 8);
            auto vert = [&](float x, float y, float z, float nx, float ny, float nz, float u, float w) {
                v.insert(v.end(), {x, y, z, nx, ny, nz, u, w});
            };
            for (size_t i = 0; i < n; i++) {
                const float* P = &L.pts[i * 5];
                float x = P[0], y = P[1], z = P[2], sz = std::max(0.1f, P[3]), rot = P[4] * 0.0174532925f;
                unsigned st = (unsigned)(i * 2654435761u) ^ 0x9e3779b9u;
                float hh = L.h * sz, hw = L.w * sz * 0.5f;
                if (L.style == 2) {  // lowpoly: tres hojas en triangulo
                    for (int b = 0; b < 3; b++) {
                        float a = rot + b * 2.0944f + vegF(st) * 0.5f;
                        float ca = std::cos(a), sa = std::sin(a), off = 0.10f * L.w * sz;
                        float bx = x + ca * off, bz = z + sa * off, wb = L.w * sz * 0.14f;
                        float tx = -sa * wb, tz = ca * wb;
                        float h2 = hh * (0.7f + 0.3f * vegF(st));
                        float px = bx + ca * 0.2f * h2, pz = bz + sa * 0.2f * h2;
                        V3 e1{2 * tx, 0, 2 * tz}, e2{px - (bx - tx), h2, pz - (bz - tz)};
                        V3 nn = cross(e1, e2);
                        float nl = std::sqrt(nn.x * nn.x + nn.y * nn.y + nn.z * nn.z);
                        if (nl > 1e-6f) nn = nn * (1.f / nl); else nn = V3{0, 1, 0};
                        if (nn.y < 0) nn = nn * -1.f;
                        vert(bx - tx, y, bz - tz, nn.x, nn.y, nn.z, 0.f, 1.f);
                        vert(bx + tx, y, bz + tz, nn.x, nn.y, nn.z, 1.f, 1.f);
                        vert(px, y + h2, pz, nn.x, nn.y, nn.z, 0.5f, 0.f);
                    }
                } else {
                    int cards = L.style == 0 ? 3 : 2;
                    for (int k = 0; k < cards; k++) {
                        float a = rot + k * (3.14159265f / cards);
                        float dx = std::cos(a) * hw, dz = std::sin(a) * hw;
                        float hv = hh * (0.85f + 0.3f * vegF(st));
                        // base izquierda, derecha, punta derecha, punta izquierda
                        vert(x - dx, y, z - dz, 0, 1, 0, 0.f, 1.f); vert(x + dx, y, z + dz, 0, 1, 0, 1.f, 1.f); vert(x + dx, y + hv, z + dz, 0, 1, 0, 1.f, 0.f);
                        vert(x - dx, y, z - dz, 0, 1, 0, 0.f, 1.f); vert(x + dx, y + hv, z + dz, 0, 1, 0, 1.f, 0.f); vert(x - dx, y + hv, z - dz, 0, 1, 0, 0.f, 0.f);
                    }
                }
            }
            std::vector<uint32_t> idx(v.size() / 8);
            for (size_t i = 0; i < idx.size(); i++) idx[i] = (uint32_t)i;
            md = dynModel(key, v, idx, sig);
        }
        glBindVertexArray(md->vao);
        glUniform4f(p.u("uColor"), L.col[0], L.col[1], L.col[2], 1.f);
        glUniform3f(p.u("uColor2"), L.col2[0], L.col2[1], L.col2[2]);
        glUniform1f(p.u("uSway"), L.sway * (L.style == 1 ? 0.34f : 0.2f) * L.h);
        glActiveTexture(GL_TEXTURE0);
        glBindTexture(GL_TEXTURE_2D, L.style == 3 ? texture(g, L.tex).id : vegTexture(L.style));
        size_t cnt = std::max<size_t>(1, (size_t)(n * frac)) * vpt;
        glDrawElements(GL_TRIANGLES, (GLsizei)std::min<size_t>(cnt, md->count), md->itype, nullptr);
    }
    glBindVertexArray(vao_);
    glUniform1f(p.u("uSway"), 0.f);
    glUniform1i(p.u("uVeg"), 0);
    glUniform1i(p.u("uUV1"), 0);
    glEnable(GL_CULL_FACE);
}

// Mar: un plano grande y translucido que sigue a la camara y refleja el cielo.
void Renderer::drawSea(Game& g, Prog& p) {
    const Scene& S = *g.sc;
    if (!S.sea) return;
    glUniform1i(p.u("uVeg"), 2);
    glUniform1i(p.u("uUV1"), 0);
    glUniform1i(p.u("uUnlit"), 0);
    glBindTexture(GL_TEXTURE_2D, white_);
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    box(p, V3{camE_.x, S.seaY - 0.01f, camE_.z}, V3{360.f, 0.02f, 360.f}, S.seaCol[0], S.seaCol[1], S.seaCol[2], std::max(0.1f, std::min(1.f, S.seaAlpha)));
    glDisable(GL_BLEND);
    glUniform1i(p.u("uVeg"), 0);
}

// Clima en el aire: lluvia, arena, nieve, niebla con particulas, personalizado. Estilo 0 = cajitas (clasico), 1 = realista.
void Renderer::drawAtmo(Game& g, Prog& p) {
    const Scene& S = *g.sc;
    if (S.atmo == 0 || (S.atmo == 1 && S.atmoStyle == 0)) return;
    float ac[3], aa;
    atmoDefaults(S.atmo, ac, aa);
    const float* col = S.atmo == 5 ? S.atmoCol : ac;
    const V3 e = camE_;
    const int qn = g.proj.quality == 0 ? 70 : g.proj.quality == 1 ? 180 : 360;
    int n = (int)(qn * (0.25f + std::min(S.atmoAmt, 3.f) * 1.5f));
    n = std::min(n, g.proj.quality == 0 ? 500 : 1400);
    const float t = g.time;
    const bool real = S.atmoStyle == 1;
    glUniform1i(p.u("uUnlit"), 1);
    glUniform1i(p.u("uUV1"), 1);
    if (!real) {
        glEnable(GL_BLEND);
        glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    }
    unsigned dot = real ? softDot() : 0;
    for (int i = 0; i < n; i++) {
        auto h = [&](int k) { float x = std::sin((float)(i * 12.9898f + k * 78.233f)) * 43758.5453f; return x - std::floor(x); };
        float x = e.x + (h(1) - 0.5f) * 36.f, z = e.z + (h(2) - 0.5f) * 36.f, y, sx = 0.05f, sy = 0.05f, a = 0.7f;
        if (!real) {
            if (S.atmo == 2) { y = e.y + 14.f - std::fmod(t * 20.f + h(3) * 28.f, 28.f); sx = 0.02f; sy = 0.7f; a = 0.45f; }
            else if (S.atmo == 3) { x = e.x + 18.f - std::fmod(t * 14.f + h(1) * 36.f, 36.f); y = e.y - 2.f + h(3) * 8.f; sx = 0.14f; sy = 0.03f; a = 0.6f; }
            else { y = e.y + 12.f - std::fmod(t * 1.6f + h(3) * 24.f, 24.f); x += std::sin(t + h(4) * 6.28f) * 0.6f; sx = sy = 0.07f; }
            box(p, V3{x, y, z}, V3{sx, sy, sx}, col[0], col[1], col[2], a);
            continue;
        }
        float cr = col[0], cg = col[1], cb = col[2];
        float depth = 0.6f + 0.4f * h(7);
        if (S.atmo == 2) {          // lluvia: rayas finas que caen rapido, las cercanas se ven mas claras
            float sp = 24.f + 14.f * h(5);
            y = e.y + 14.f - std::fmod(t * sp + h(3) * 28.f, 28.f);
            x += (14.f - (y - e.y)) * 0.12f;           // un poco de viento
            float len = 0.7f + 0.8f * h(6);
            sx = 0.018f + 0.01f * h(8); sy = len; a = 0.22f + 0.28f * depth;
            cr = cr * 0.8f + 0.2f; cg = cg * 0.8f + 0.2f; cb = cb * 0.8f + 0.22f;
        } else if (S.atmo == 3) {   // arena: rafagas horizontales y polvo fino
            float sp = 9.f + 12.f * h(5);
            x = e.x + 18.f - std::fmod(t * sp + h(1) * 36.f, 36.f);
            y = e.y - 2.5f + h(3) * 9.f + std::sin(t * 1.3f + h(4) * 6.28f) * 0.3f;
            z += std::sin(t * 0.7f + h(2) * 6.28f) * 0.8f;
            bool streak = h(9) < 0.4f;
            sx = streak ? 0.9f + 1.4f * h(6) : 0.05f + 0.07f * h(6); sy = streak ? 0.035f : sx; a = streak ? 0.10f + 0.1f * depth : 0.35f + 0.3f * depth;
        } else if (S.atmo == 4) {   // nieve: copos de distinto tamaño que flotan
            y = e.y + 12.f - std::fmod(t * (0.9f + 1.4f * h(5)) + h(3) * 24.f, 24.f);
            x += std::sin(t * (0.6f + h(4)) + h(4) * 6.28f) * 0.9f;
            z += std::cos(t * (0.5f + h(6)) + h(2) * 6.28f) * 0.7f;
            sx = sy = 0.035f + 0.1f * h(6) * h(6) + 0.02f; a = 0.5f + 0.45f * depth;
        } else if (S.atmo == 1) {   // niebla con particulas en el aire (polvo / ceniza flotando) y jirones bajos
            bool wisp = i % 9 == 0;
            if (wisp) {
                x = e.x + (h(1) - 0.5f) * 30.f + std::sin(t * 0.08f + h(4) * 6.28f) * 2.f; z = e.z + (h(2) - 0.5f) * 30.f;
                y = e.y - 1.2f + h(3) * 1.8f;
                sx = sy = 3.f + 4.f * h(6); a = 0.035f + 0.04f * h(8);
            } else {
                y = e.y + 7.f - std::fmod(t * (0.12f + 0.2f * h(5)) + h(3) * 14.f, 14.f);
                x += std::sin(t * 0.25f + h(4) * 6.28f) * 1.2f; z += std::cos(t * 0.2f + h(2) * 6.28f) * 1.2f;
                sx = sy = 0.03f + 0.09f * h(6) * h(6); a = 0.25f + 0.4f * depth;
            }
        } else {                    // personalizado: puntos suaves flotando
            y = e.y + 10.f - std::fmod(t * (0.8f + h(5)) + h(3) * 20.f, 20.f);
            x += std::sin(t * 0.7f + h(4) * 6.28f) * 0.6f;
            sx = sy = 0.05f + 0.08f * h(6); a = 0.4f + 0.4f * depth;
        }
        float yaw = std::atan2(e.x - x, e.z - z) / 0.0174532925f;
        ovTex_ = dot;
        drawModelAt(g, p, "", "", V3{x, y, z}, yaw, V3{sx, sy, 0.01f}, cr, cg, cb, std::min(1.f, a));
    }
    ovTex_ = 0;
    glDisable(GL_BLEND);
    glUniform1i(p.u("uUnlit"), 0);
    glUniform1i(p.u("uUV1"), 0);
}

// Cosas que se mueven y no son objetos de la escena: cuerpo del jugador y proyectiles.
void Renderer::drawDynamic(Game& g, Prog& p, const EditorView* ev) {
    const Scene& S = *g.sc;
    int pi = playerIndex(S);
    glUniform1i(p.u("uUnlit"), 0);
    if (!ev && g.camMode != kFirstPerson) {  // el jugador se ve en tercera persona
        V3 sc = pi >= 0 ? S.objs[pi].scale : V3{0.6f, 1.7f, 0.6f};
        float yawDeg = g.bodyYaw / 0.0174532925f;
        Game::ObjVis pv;
        if (pi >= 0) pv = g.vis(pi);
        V3 mid{g.pos.x, g.pos.y + sc.y * 0.5f + pv.bob, g.pos.z};
        const PlayerCfg& pcg = g.proj.player;
        V3 rgtB{std::cos(g.bodyYaw), 0, std::sin(g.bodyYaw)}, fwdB{std::sin(g.bodyYaw), 0, -std::cos(g.bodyYaw)};
        V3 midM = mid + rgtB * pcg.mox + V3{0, pcg.moy, 0} + fwdB * pcg.moz;
        bool hasAnim = pi >= 0 && (!pv.tex.empty() || !pv.model.empty() || pv.billboard);
        if (pv.billboard && !pv.tex.empty()) {  // imagen plana que mira a la camara
            drawSprite(g, p, pv.tex, mid, sc.x * 1.6f, sc.y, 1.f, 1.f, 1.f);
        } else if (hasAnim && !pv.model.empty()) {
            drawModelAt(g, p, pv.model, "", midM, yawDeg + pcg.myaw + pv.sway, sc * pcg.mscale, 1.f, 1.f, 1.f, 1.f);
        } else if (!g.proj.player.model.empty()) {
            if (pi >= 0) forceMd_ = skinned(g, pi, g.proj.player.model, model(g, g.proj.player.model));
            drawModelAt(g, p, g.proj.player.model, "", midM, yawDeg + pcg.myaw + pv.sway, V3{sc.x, sc.y * pv.squash, sc.z} * pcg.mscale, 1.f, 1.f, 1.f, 1.f);
        } else {  // muneco basico
            float H = sc.y;
            box(p, V3{g.pos.x, g.pos.y + H * 0.34f, g.pos.z}, V3{sc.x * 0.8f, H * 0.34f, sc.z * 0.5f}, 0.2f, 0.45f, 0.9f, 1.f);
            box(p, V3{g.pos.x, g.pos.y + H * 0.8f, g.pos.z}, V3{sc.x * 0.55f, H * 0.18f, sc.x * 0.55f}, 1.f, 0.8f, 0.65f, 1.f);
            box(p, V3{g.pos.x, g.pos.y + H * 0.12f, g.pos.z}, V3{sc.x * 0.6f, H * 0.24f, sc.z * 0.45f}, 0.2f, 0.2f, 0.35f, 1.f);
        }
    }
    if (!ev && g.camMode != kFirstPerson && g.curWeapon() && g.curWeapon()->enabled) {  // arma en la mano (tercera persona)
        const Weapon& wp = *g.curWeapon();
        float H = pi >= 0 ? S.objs[pi].scale.y : 1.7f;
        V3 rg{std::cos(g.bodyYaw), 0, std::sin(g.bodyYaw)}, fw{std::sin(g.bodyYaw), 0, -std::cos(g.bodyYaw)};
        float yawW = g.bodyYaw / 0.0174532925f;
        V3 hand = V3{g.pos.x, g.pos.y + H * 0.55f, g.pos.z} + rg * (0.28f * H * 0.6f) + fw * (0.32f * H * 0.6f);
        float sz = std::max(0.25f, wp.scale) * H * 0.55f;
        glUniform1i(p.u("uUnlit"), 0);
        if (!wp.model.empty()) drawModelAt(g, p, wp.model, "", hand, yawW, V3{sz, sz, sz}, 1.f, 1.f, 1.f, 1.f);
        else if (wp.type == 1) drawModelAt(g, p, "", "", hand + fw * 0.15f, yawW, V3{0.04f, 0.04f, sz * 0.9f}, 0.75f, 0.78f, 0.85f, 1.f);  // hoja
        else if (wp.type >= 2) drawModelAt(g, p, "", "", hand, yawW, V3{0.09f, 0.09f, 0.09f}, 0.25f, 0.3f, 0.2f, 1.f);
        else drawModelAt(g, p, "", "", hand, yawW, V3{0.05f, 0.07f, sz * 0.8f}, 0.12f, 0.12f, 0.14f, 1.f);
    }
    for (auto& d : g.debris) {  // pedazos de objetos rotos
        float a = std::min(1.f, d.life * 2.f);
        drawModelAt(g, p, "", d.tex, d.p, d.ang, V3{d.size, d.size, d.size}, d.col[0], d.col[1], d.col[2], a);
    }
    for (auto& pr : g.projs) {
        float s = pr.size;
        if (pr.shape == 2 && !pr.model.empty()) {
            float yaw = std::atan2(pr.v.x, -pr.v.z) / 0.0174532925f;
            drawModelAt(g, p, pr.model, "", pr.p, yaw, V3{s * 2.f, s * 2.f, s * 2.f}, 1.f, 1.f, 1.f, 1.f);
        } else if (pr.shape == 1 && !pr.tex.empty()) {
            drawSprite(g, p, pr.tex, pr.p, s * 2.f, s * 2.f, 1.f, 1.f, 1.f);
        } else {
            glUniform1i(p.u("uUnlit"), 1);
            box(p, pr.p, V3{s, s, s}, pr.col[0], pr.col[1], pr.col[2], 1.f);
            glUniform1i(p.u("uUnlit"), 0);
        }
    }
}

// Desplaza el tono de un color (0..200 como en Pocket Code = vuelta completa).
static void hueShift(float c[3], float amount) {
    if (amount == 0) return;
    float a = amount / 200.f * 6.2831853f, cs = std::cos(a), sn = std::sin(a);
    float r = c[0], g = c[1], b = c[2];
    // rotacion alrededor del eje gris
    c[0] = (.299f + .701f * cs + .168f * sn) * r + (.587f - .587f * cs + .330f * sn) * g + (.114f - .114f * cs - .497f * sn) * b;
    c[1] = (.299f - .299f * cs - .328f * sn) * r + (.587f + .413f * cs + .035f * sn) * g + (.114f - .114f * cs + .292f * sn) * b;
    c[2] = (.299f - .300f * cs + 1.25f * sn) * r + (.587f - .588f * cs - 1.05f * sn) * g + (.114f + .886f * cs - .203f * sn) * b;
    for (int i = 0; i < 3; i++) c[i] = std::max(0.f, std::min(1.f, c[i]));
}

void Renderer::drawObjs(Game& g, Prog& p, bool shadow) {
    const bool is3 = g.sc->is3d;
    std::vector<int> order;
    order.reserve(g.sc->objs.size());
    for (int i = 0; i < (int)g.sc->objs.size(); i++) order.push_back(i);
    if (!is3)  // 2D: el fondo primero y despues por capa
        std::stable_sort(order.begin(), order.end(), [&](int a, int b) {
            const Obj &x = g.sc->objs[a], &y = g.sc->objs[b];
            int lx = x.bg ? -2000000000 : x.layer, ly = y.bg ? -2000000000 : y.layer;
            return lx < ly;
        });
    for (int idx : order) {
        const Obj& o = g.sc->objs[idx];
        if (!o.alive || !o.visible) continue;
        if (o.kind == Kind::Light || o.kind == Kind::Player) continue;
        float alpha = 1.f - std::max(0.f, std::min(100.f, o.transp)) / 100.f;
        if (shadow && alpha < 0.5f) continue;
        if (o.noColor && o.tex.empty() && o.video.empty() && o.kind != Kind::Model && !(o.ai.type != AiType::None && is3)) continue;  // sin color y sin imagen: no se dibuja
        M4 m;
        Game::ObjVis vv;
        if (is3 && o.ai.type != AiType::None) vv = g.vis(idx);
        if (vv.billboard && shadow) continue;
        ModelGL* terr = (is3 && o.kind == Kind::Floor && o.tn >= 2 && o.heights.size() == (size_t)o.tn * o.tn) ? terrainMesh(g, idx) : nullptr;
        if (terr) {
            m = modelMat(o.pos, 0.f, V3{1, 1, 1});
        } else if (is3) {
            float yaw = o.yaw + (o.spin ? g.time * 90.f : 0.f);
            V3 pp = o.pos, sc3 = o.scale;
            if (vv.billboard) {
                yaw = std::atan2(camE_.x - o.pos.x, camE_.z - o.pos.z) / 0.0174532925f;
                sc3.z = 0.02f;
            } else {
                yaw += vv.sway;
                float a = o.yaw * 0.0174532925f;
                pp.x += std::sin(a) * vv.lunge; pp.z -= std::cos(a) * vv.lunge;
            }
            pp.y += vv.bob;
            sc3.y *= vv.squash;
            m = modelMat(pp, yaw, sc3);
        } else if (o.bg) {
            m = modelMatZ(V3{0, 0, 0}, 0.f, V3{g.stageW(), kView2DHeight, 1.f});
        } else {
            m = modelMatZ(o.pos, -(o.yaw - 90.f) + (o.spin ? -g.time * 90.f : 0.f), V3{o.scale.x, o.scale.y, 1.f});
        }
        glUniformMatrix4fv(p.u("uM"), 1, GL_FALSE, m.m);
        const std::string& mname = !vv.model.empty() ? vv.model : o.model;
        ModelGL* md = terr ? terr : (((o.kind == Kind::Model || !vv.model.empty()) && !mname.empty()) ? model(g, mname) : nullptr);
        if (md && !terr && is3 && !vv.billboard) md = skinned(g, idx, mname, md);
        glBindVertexArray(md ? md->vao : vao_);
        if (!shadow) {
            float col[3] = {o.color[0] * (md ? md->color[0] : 1.f), o.color[1] * (md ? md->color[1] : 1.f),
                            o.color[2] * (md ? md->color[2] : 1.f)};
            if (o.noColor || vv.billboard) col[0] = col[1] = col[2] = 1.f;  // sin color: la imagen se ve tal cual
            hueShift(col, o.hue);
            float br = o.bright / 100.f;
            glUniform4f(p.u("uColor"), col[0] * br, col[1] * br, col[2] * br, alpha);
            if (is3) glUniform1f(p.u("uRefl"), o.reflect ? 1.f : 0.f);
            glActiveTexture(GL_TEXTURE0);
            std::string vname;
            if (!o.video.empty() && !shadow) {
                int vw, vh;
                if (g.videoFrame(idx, vw, vh, vidPx_) && vw > 0 && vh > 0) updateRGBA("::vid" + std::to_string(idx), vw, vh, vidPx_.data());
                if (rawTexture("::vid" + std::to_string(idx))) vname = "::vid" + std::to_string(idx);
            }
            const std::string& tn = !vname.empty() ? vname : !vv.tex.empty() ? vv.tex : (!o.tex.empty() ? o.tex : (md ? md->tex : o.tex));
            glBindTexture(GL_TEXTURE_2D, texture(g, tn).id);
            glUniform1i(p.u("uUV1"), (!is3 || (md && !terr) || vv.billboard || !o.texTile) ? 1 : 0);  // 1 = la imagen se estira a cada cara
            if (is3 && (alpha < 1.f || !tn.empty() || vv.billboard)) { glEnable(GL_BLEND); glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA); }
        }
        if (md) glDrawElements(GL_TRIANGLES, md->count, md->itype, nullptr);
        else glDrawElements(GL_TRIANGLES, 36, GL_UNSIGNED_SHORT, nullptr);
        if (!shadow && is3 && (alpha < 1.f || !o.tex.empty() || md || vv.billboard)) glDisable(GL_BLEND);
    }
    glBindVertexArray(vao_);
}

void Renderer::render(Game& g, int w, int h, const EditorView* ev) {
    glDisable(GL_BLEND);
    glDisable(GL_SCISSOR_TEST);
    glViewport(0, 0, w, h);
    if (!g.sc) {
        glClearColor(0, 0, 0, 1);
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
        return;
    }
    if (g.sc->is3d) render3D(g, w, h, ev);
    else render2D(g, w, h, ev);
}

void Renderer::clear(int w, int h, float r, float g, float b) {
    glDisable(GL_BLEND);
    glDisable(GL_SCISSOR_TEST);
    glViewport(0, 0, w, h);
    glClearColor(r, g, b, 1.f);
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
}

void Renderer::render3D(Game& g, int w, int h, const EditorView* ev) {
    const Scene& S = *g.sc;
    V3 sd = norm(S.sunDir);
    V3 e = ev ? ev->eye : g.camEye, f = ev ? ev->fwd : g.camFwd;
    if (!ev && g.shakeT > 0) {  // temblor de camara
        float k = std::min(1.f, g.shakeT) * g.shakeAmp;
        e = e + V3{((float)std::rand() / RAND_MAX - .5f) * k, ((float)std::rand() / RAND_MAX - .5f) * k, ((float)std::rand() / RAND_MAX - .5f) * k};
    }
    camE_ = e;

    // 1) Mapa de sombras alrededor del jugador (o del punto que mira el editor).
    V3 c = ev ? ev->target : g.pos;
    V3 up = std::fabs(sd.y) < 0.99f ? V3{0, 1, 0} : V3{0, 0, 1};
    M4 lvp = mul(ortho(-24, 24, -24, 24, 1, 90), lookAt(c - sd * 40.f, c, up));
    glBindFramebuffer(GL_FRAMEBUFFER, fbo_);
    glViewport(0, 0, shadowSize_, shadowSize_);
    glClear(GL_DEPTH_BUFFER_BIT);
    glEnable(GL_DEPTH_TEST);
    glDisable(GL_CULL_FACE);
    glEnable(GL_POLYGON_OFFSET_FILL);
    glPolygonOffset(2.f, 4.f);
    glUseProgram(depth_.id);
    glUniformMatrix4fv(depth_.u("uLVP"), 1, GL_FALSE, lvp.m);
    if (g.proj.quality > 0) drawObjs(g, depth_, true);
    glDisable(GL_POLYGON_OFFSET_FILL);
    glBindFramebuffer(GL_FRAMEBUFFER, 0);

    // 2) Escena principal.
    glViewport(0, 0, w, h);
    glClearColor(S.skyBot[0], S.skyBot[1], S.skyBot[2], 1.f);
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    float aspect = h > 0 ? (float)w / (float)h : 1.f, fov = 1.2217f;
    V3 r = norm(cross(f, V3{0, 1, 0})), u = cross(r, f);
    V3 upv{0, 1, 0};
    if (!ev && std::fabs(g.camRollTotal) > 1e-4f) upv = V3{0, 1, 0} * std::cos(g.camRollTotal) + r * std::sin(g.camRollTotal);  // camara inclinada
    M4 vp = mul(perspective(fov, aspect, 0.1f, 200.f), lookAt(e, e + f, upv));

    glDisable(GL_DEPTH_TEST);
    glUseProgram(sky_.id);
    glUniform3f(sky_.u("uFwd"), f.x, f.y, f.z);
    glUniform3f(sky_.u("uRight"), r.x, r.y, r.z);
    glUniform3f(sky_.u("uUp"), u.x, u.y, u.z);
    float ty = std::tan(fov * 0.5f);
    glUniform1f(sky_.u("uTY"), ty);
    glUniform1f(sky_.u("uTX"), ty * aspect);
    glUniform3f(sky_.u("uTop"), S.skyTop[0], S.skyTop[1], S.skyTop[2]);
    float fc[3] = {S.skyBot[0], S.skyBot[1], S.skyBot[2]}, fogD = S.fog;
    atmoDensity_ = 0.f;
    if (S.fogMode == 1) { for (int q = 0; q < 3; q++) fc[q] = S.fogCol[q]; }
    if (S.atmo > 0) {
        float ac[3], aa;
        atmoDefaults(S.atmo, ac, aa);
        const float* col = S.atmo == 5 ? S.atmoCol : ac;
        float k = std::min(S.atmoAmt, 3.f);
        float add = (S.atmo == 1 ? 0.05f : S.atmo == 3 ? 0.07f : S.atmo == 5 ? 0.05f : 0.015f) * k;
        if (S.atmoStyle == 1 && S.atmo == 1) add *= 0.8f;
        fogD += add;
        if (!(S.atmo == 1 && S.fogMode == 1))  // la niebla con color propio no se mezcla con el color de la atmósfera
            for (int q = 0; q < 3; q++) fc[q] = fc[q] * 0.35f + col[q] * 0.65f;
        atmoDensity_ = k;
    }
    // el horizonte del cielo toma el color de la niebla para que no se vea un corte
    float hz = (S.fogMode == 1 || S.atmo > 0) ? std::min(1.f, 0.55f + fogD * 6.f) : 0.f;
    glUniform3f(sky_.u("uBot"), S.skyBot[0] + (fc[0] - S.skyBot[0]) * hz, S.skyBot[1] + (fc[1] - S.skyBot[1]) * hz, S.skyBot[2] + (fc[2] - S.skyBot[2]) * hz);
    glUniform3f(sky_.u("uSunDir"), sd.x, sd.y, sd.z);
    glUniform3f(sky_.u("uSunCol"), S.sun[0], S.sun[1], S.sun[2]);
    glBindVertexArray(vaoEmpty_);
    glDrawArrays(GL_TRIANGLES, 0, 3);

    glEnable(GL_DEPTH_TEST);
    glEnable(GL_CULL_FACE);
    glUseProgram(main_.id);
    glUniformMatrix4fv(main_.u("uVP"), 1, GL_FALSE, vp.m);
    glUniformMatrix4fv(main_.u("uLVP"), 1, GL_FALSE, lvp.m);
    glUniform1i(main_.u("uTex"), 0);
    glUniform1i(main_.u("uSh"), 1);
    glUniform1i(main_.u("uUV1"), 0);
    glUniform1i(main_.u("uUnlit"), 0);
    glUniform1f(main_.u("uTile"), 1.f);
    glUniform1f(main_.u("uTexel"), 1.f / (float)shadowSize_);
    glUniform3f(main_.u("uSunDir"), sd.x, sd.y, sd.z);
    glUniform3f(main_.u("uSunCol"), S.sun[0], S.sun[1], S.sun[2]);
    glUniform3f(main_.u("uSkyTop"), S.skyTop[0], S.skyTop[1], S.skyTop[2]);
    glUniform3f(main_.u("uSkyBot"), S.skyBot[0], S.skyBot[1], S.skyBot[2]);
    glUniform3f(main_.u("uCam"), e.x, e.y, e.z);
    glUniform1f(main_.u("uAmb"), S.ambient);
    {
        float tint[3];
        toneTint(S.tone, tint);
        glUniform3f(main_.u("uTint"), tint[0], tint[1], tint[2]);
        glUniform3f(main_.u("uFogCol"), fc[0], fc[1], fc[2]);
        glUniform1f(main_.u("uFog"), fogD);
        glUniform1f(main_.u("uRefl"), 0.f);
        glUniform1f(main_.u("uTime"), g.time);
        glUniform1f(main_.u("uSway"), 0.f);
        glUniform1i(main_.u("uVeg"), 0);
        glUniform1i(main_.u("uRtx"), g.proj.rtx ? 1 : 0);
        glUniform1f(main_.u("uShAmt"), S.shadowAmt);
        {   // linterna del jugador
            const PlayerCfg& pc = g.proj.player;
            bool on = !ev && g.flashOn_ && pc.flashlight;
            glUniform1i(main_.u("uSpotOn"), on ? 1 : 0);
            glUniform1i(main_.u("uCookieOn"), 0);
            if (on) {
                float flick = 1.f;
                if (pc.flashFlicker) flick = 0.75f + 0.25f * std::sin(g.time * 37.f) * std::sin(g.time * 11.f) + (std::sin(g.time * 3.1f) > 0.93f ? -0.6f : 0.f);
                float ang = std::max(5.f, std::min(70.f, pc.flashAngle)) * 0.0174533f;
                glUniform3f(main_.u("uSpotPos"), e.x, e.y, e.z);
                glUniform3f(main_.u("uSpotDir"), f.x, f.y, f.z);
                glUniform3f(main_.u("uSpotCol"), pc.flashCol[0] * pc.flashInt * flick, pc.flashCol[1] * pc.flashInt * flick, pc.flashCol[2] * pc.flashInt * flick);
                glUniform1f(main_.u("uSpotCone"), std::cos(ang));
                glUniform1f(main_.u("uSpotTan"), std::tan(ang));
                glUniform1f(main_.u("uSpotRange"), std::max(3.f, pc.flashRange));
                if (!pc.flashTex.empty()) {
                    glActiveTexture(GL_TEXTURE2);
                    glBindTexture(GL_TEXTURE_2D, texture(g, pc.flashTex).id);
                    glUniform1i(main_.u("uCookie"), 2);
                    glUniform1i(main_.u("uCookieOn"), 1);
                    glActiveTexture(GL_TEXTURE0);
                }
            }
        }
        glUniform1i(main_.u("uShOn"), g.proj.quality > 0 ? 1 : 0);
    }

    float pl[16] = {0}, pc[12] = {0};
    int nl = 0;
    for (auto& o : S.objs) {
        if (o.kind != Kind::Light || !o.alive || !o.visible || nl >= 4) continue;
        pl[nl * 4] = o.pos.x; pl[nl * 4 + 1] = o.pos.y; pl[nl * 4 + 2] = o.pos.z; pl[nl * 4 + 3] = o.scale.x;
        pc[nl * 3] = o.color[0]; pc[nl * 3 + 1] = o.color[1]; pc[nl * 3 + 2] = o.color[2];
        nl++;
    }
    glUniform4fv(main_.u("uPL"), 4, pl);
    glUniform3fv(main_.u("uPC"), 4, pc);
    glUniform1i(main_.u("uNL"), nl);

    glActiveTexture(GL_TEXTURE1);
    glBindTexture(GL_TEXTURE_2D, shadowTex_);
    drawObjs(g, main_, false);
    glActiveTexture(GL_TEXTURE0);
    drawDynamic(g, main_, ev);
    drawGround(g, main_);
    drawVeg(g, main_);
    drawSea(g, main_);
    drawParticles(g, main_, true);
    if (!ev && g.camMode == kFirstPerson && g.curWeapon() && g.curWeapon()->enabled && !g.curWeapon()->model.empty()) {
        // Arma 3D en la mano: se dibuja en el espacio de la camara, encima de todo.
        const Weapon& wp = *g.curWeapon();
        glClear(GL_DEPTH_BUFFER_BIT);
        M4 proj = perspective(fov, aspect, 0.05f, 10.f);
        glUniformMatrix4fv(main_.u("uVP"), 1, GL_FALSE, proj.m);
        glUniform3f(main_.u("uCam"), 0.f, 0.f, 0.f);
        glUniform1i(main_.u("uUnlit"), 1);
        float sz = wp.scale * 0.9f;
        V3 at{0.28f + wp.ox, -0.26f + wp.oy * 0.5f + g.recoil * 0.03f, -0.7f + g.recoil * 0.06f};
        drawModelAt(g, main_, wp.model, "", at, 8.f, V3{sz, sz, sz}, 1.f, 1.f, 1.f, 1.f);
        glUniform1i(main_.u("uUnlit"), 0);
    }

    drawAtmo(g, main_);

    if (ev) {
        // Marcadores del editor: luces, inicio del jugador y objeto seleccionado.
        glEnable(GL_BLEND);
        glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
        glUniform1i(main_.u("uUnlit"), 1);
        glUniform1i(main_.u("uUV1"), 1);
        for (auto& o : S.objs)
            if (o.kind == Kind::Light) box(main_, o.pos, V3{0.35f, 0.35f, 0.35f}, o.color[0], o.color[1], o.color[2], 1.f);
        for (auto& o : S.objs)  // objetos transparentes: se ven como un cristal tenue solo en el editor
            if (o.noColor && o.tex.empty() && o.alive && o.visible && o.kind != Kind::Light && o.kind != Kind::Model)
                box(main_, o.pos, o.scale, 0.8f, 0.9f, 1.f, 0.15f);
        box(main_, V3{S.start.x, S.start.y + 0.85f, S.start.z}, V3{0.6f, 1.7f, 0.6f}, 0.2f, 1.f, 0.3f, 0.5f);
        if (g.proj.player.cam == kFixed) box(main_, S.cam, V3{0.7f, 0.5f, 0.9f}, 0.3f, 0.6f, 1.f, 0.8f);
        if (ev->sel >= 0 && ev->sel < (int)S.objs.size()) {
            const Obj& o = S.objs[ev->sel];
            V3 sc = o.kind == Kind::Light ? V3{0.5f, 0.5f, 0.5f} : o.scale * 1.04f + V3{0.02f, 0.02f, 0.02f};
            box(main_, o.pos, sc, 1.f, 0.9f, 0.2f, 0.35f);
        }
        glDisable(GL_BLEND);
        glUniform1i(main_.u("uUnlit"), 0);
        glUniform1i(main_.u("uUV1"), 0);
    } else {
        // Mira central sin shaders extra: dos recortes con glClear.
        glEnable(GL_SCISSOR_TEST);
        glClearColor(1, 1, 1, 1);
        glScissor(w / 2 - 1, h / 2 - 8, 2, 16);
        glClear(GL_COLOR_BUFFER_BIT);
        glScissor(w / 2 - 8, h / 2 - 1, 16, 2);
        glClear(GL_COLOR_BUFFER_BIT);
        glDisable(GL_SCISSOR_TEST);
    }
}

void Renderer::render2D(Game& g, int w, int h, const EditorView* ev) {
    const Scene& S = *g.sc;
    glClearColor(S.skyBot[0], S.skyBot[1], S.skyBot[2], 1.f);
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    float aspect = h > 0 ? (float)w / (float)h : 1.f;
    float vh = ev ? ev->h2d : kView2DHeight, cx = ev ? ev->cx : 0.f, cy = ev ? ev->cy : 0.f;
    if (!ev && g.shakeT > 0) {
        float k = std::min(1.f, g.shakeT) * g.shakeAmp;
        cx += ((float)std::rand() / RAND_MAX - .5f) * k;
        cy += ((float)std::rand() / RAND_MAX - .5f) * k;
    }
    float hw = vh * 0.5f * aspect, hh = vh * 0.5f;
    M4 vp = ortho(cx - hw, cx + hw, cy - hh, cy + hh, -20, 20);

    glDisable(GL_DEPTH_TEST);
    glDisable(GL_CULL_FACE);
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    glUseProgram(main_.id);
    glUniformMatrix4fv(main_.u("uVP"), 1, GL_FALSE, vp.m);
    glUniform1i(main_.u("uTex"), 0);
    glUniform1i(main_.u("uSh"), 1);
    glUniform1i(main_.u("uUV1"), 1);
    glUniform1i(main_.u("uUnlit"), 1);
    glUniform3f(main_.u("uTint"), 1.f, 1.f, 1.f);
    glUniform1f(main_.u("uRefl"), 0.f);
    glUniform1i(main_.u("uShOn"), 0);
    glActiveTexture(GL_TEXTURE1);
    glBindTexture(GL_TEXTURE_2D, shadowTex_);
    drawObjs(g, main_, false);  // el orden de la lista = orden de capas
    for (auto& d : g.debris) box(main_, d.p, V3{d.size, d.size, 1.f}, d.col[0], d.col[1], d.col[2], std::min(1.f, d.life * 2.f));
    drawParticles(g, main_, false);
    if (ev)
        for (auto& o : S.objs)
            if (o.noColor && o.tex.empty() && o.alive && o.visible && !o.bg)
                box(main_, o.pos, V3{o.scale.x, o.scale.y, 1.f}, 0.8f, 0.9f, 1.f, 0.15f);
    if (ev && ev->sel >= 0 && ev->sel < (int)S.objs.size()) {
        const Obj& o = S.objs[ev->sel];
        box(main_, o.bg ? V3{0, 0, 0} : o.pos, o.bg ? V3{g.stageW(), kView2DHeight, 1.f} : V3{o.scale.x * 1.04f + 4.f, o.scale.y * 1.04f + 4.f, 1.f}, 1.f, 0.9f, 0.2f, 0.35f);
    }
    glActiveTexture(GL_TEXTURE0);
    glDisable(GL_BLEND);
}

}  // namespace forge
