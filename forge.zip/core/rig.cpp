#include "rig.h"
#include <algorithm>
#include <cmath>
#include <cstdlib>
#include <sstream>

namespace forge {

Quat qMul(Quat a, Quat b) {
    return {a.w * b.x + a.x * b.w + a.y * b.z - a.z * b.y, a.w * b.y - a.x * b.z + a.y * b.w + a.z * b.x,
            a.w * b.z + a.x * b.y - a.y * b.x + a.z * b.w, a.w * b.w - a.x * b.x - a.y * b.y - a.z * b.z};
}
Quat qNorm(Quat a) {
    float l = std::sqrt(a.x * a.x + a.y * a.y + a.z * a.z + a.w * a.w);
    if (l < 1e-9f) return Quat();
    return {a.x / l, a.y / l, a.z / l, a.w / l};
}
Quat qInv(Quat a) { return {-a.x, -a.y, -a.z, a.w}; }
Quat qSlerp(Quat a, Quat b, float t) {
    float d = a.x * b.x + a.y * b.y + a.z * b.z + a.w * b.w;
    if (d < 0) { b = {-b.x, -b.y, -b.z, -b.w}; d = -d; }
    if (d > 0.9995f) return qNorm({a.x + (b.x - a.x) * t, a.y + (b.y - a.y) * t, a.z + (b.z - a.z) * t, a.w + (b.w - a.w) * t});
    float th = std::acos(std::min(1.f, d)), s = std::sin(th);
    float wa = std::sin((1 - t) * th) / s, wb = std::sin(t * th) / s;
    return {a.x * wa + b.x * wb, a.y * wa + b.y * wb, a.z * wa + b.z * wb, a.w * wa + b.w * wb};
}
Quat qAxisAngle(V3 axis, float rad) {
    V3 n = norm(axis);
    float s = std::sin(rad * 0.5f);
    return {n.x * s, n.y * s, n.z * s, std::cos(rad * 0.5f)};
}
Quat qFromEulerDeg(float x, float y, float z) {
    const float k = 0.0174532925f;
    Quat qx = qAxisAngle({1, 0, 0}, x * k), qy = qAxisAngle({0, 1, 0}, y * k), qz = qAxisAngle({0, 0, 1}, z * k);
    return qNorm(qMul(qz, qMul(qy, qx)));
}
void qToEulerDeg(Quat q, float& x, float& y, float& z) {
    q = qNorm(q);
    float sinr = 2 * (q.w * q.x + q.y * q.z), cosr = 1 - 2 * (q.x * q.x + q.y * q.y);
    float sinp = 2 * (q.w * q.y - q.z * q.x);
    float siny = 2 * (q.w * q.z + q.x * q.y), cosy = 1 - 2 * (q.y * q.y + q.z * q.z);
    const float k = 57.2957795f;
    x = std::atan2(sinr, cosr) * k;
    y = (std::fabs(sinp) >= 1 ? std::copysign(1.5707963f, sinp) : std::asin(sinp)) * k;
    z = std::atan2(siny, cosy) * k;
}
V3 qRotate(Quat q, V3 v) {
    V3 u{q.x, q.y, q.z};
    V3 t = cross(u, v) * 2.f;
    return v + t * q.w + cross(u, t);
}

// ---------------------------------------------------------------- texto
static std::string enc(const std::string& s) {
    std::string o = s.empty() ? "-" : s;
    for (char& c : o) if (c == ' ' || c == '\t' || c == '\n') c = '\x1f';
    return o;
}
static std::string dec(const std::string& s) {
    if (s == "-") return "";
    std::string o = s;
    for (char& c : o) if (c == '\x1f') c = ' ';
    return o;
}

std::string rigWrite(const Rig& r) {
    std::ostringstream o;
    o.precision(5);
    o << "rig 1\nmodel " << enc(r.model) << "\nstiff " << r.stiff << "\n";
    for (auto& b : r.bones) o << "bone " << enc(b.name) << ' ' << b.parent << ' ' << b.head.x << ' ' << b.head.y << ' ' << b.head.z << '\n';
    for (auto& c : r.clips) {
        o << "clip " << enc(c.name) << ' ' << c.len << ' ' << (c.loop ? 1 : 0) << '\n';
        for (auto& k : c.keys) {
            o << "key " << k.t << ' ' << k.pose.root.x << ' ' << k.pose.root.y << ' ' << k.pose.root.z;
            for (size_t i = 0; i < r.bones.size(); i++) {
                Quat q = i < k.pose.rot.size() ? k.pose.rot[i] : Quat();
                o << ' ' << q.x << ' ' << q.y << ' ' << q.z << ' ' << q.w;
            }
            o << '\n';
        }
    }
    return o.str();
}

bool rigRead(const std::string& text, Rig& r) {
    r = Rig();
    std::istringstream in(text);
    std::string line;
    bool head = false;
    while (std::getline(in, line)) {
        std::istringstream ls(line);
        std::string k;
        if (!(ls >> k)) continue;
        if (k == "rig") head = true;
        else if (k == "model") { std::string m; ls >> m; r.model = dec(m); }
        else if (k == "stiff") ls >> r.stiff;
        else if (k == "bone") {
            RigBone b; std::string n;
            ls >> n >> b.parent >> b.head.x >> b.head.y >> b.head.z;
            b.name = dec(n);
            if (b.parent >= (int)r.bones.size()) b.parent = -1;
            r.bones.push_back(b);
        } else if (k == "clip") {
            RigClip c; std::string n; int lp = 1;
            ls >> n >> c.len >> lp;
            c.name = dec(n); c.loop = lp != 0;
            r.clips.push_back(c);
        } else if (k == "key" && !r.clips.empty()) {
            RigKey kk;
            ls >> kk.t >> kk.pose.root.x >> kk.pose.root.y >> kk.pose.root.z;
            for (size_t i = 0; i < r.bones.size(); i++) {
                Quat q;
                if (!(ls >> q.x >> q.y >> q.z >> q.w)) break;
                kk.pose.rot.push_back(qNorm(q));
            }
            kk.pose.rot.resize(r.bones.size());
            r.clips.back().keys.push_back(kk);
        }
    }
    for (auto& c : r.clips) std::stable_sort(c.keys.begin(), c.keys.end(), [](const RigKey& a, const RigKey& b) { return a.t < b.t; });
    return head;
}

// ---------------------------------------------------------------- poses
RigPose rigRestPose(const Rig& r) {
    RigPose p;
    p.rot.assign(r.bones.size(), Quat());
    return p;
}
int rigFindClip(const Rig& r, const std::string& name) {
    for (size_t i = 0; i < r.clips.size(); i++) if (r.clips[i].name == name) return (int)i;
    return -1;
}
int rigFindBone(const Rig& r, const std::string& name) {
    for (size_t i = 0; i < r.bones.size(); i++) if (r.bones[i].name == name) return (int)i;
    return -1;
}

RigPose rigSample(const Rig& r, const RigClip& c, float t) {
    if (c.keys.empty()) return rigRestPose(r);
    if (c.keys.size() == 1) { RigPose p = c.keys[0].pose; p.rot.resize(r.bones.size()); return p; }
    float len = std::max(0.01f, c.len);
    if (c.loop) { t = std::fmod(t, len); if (t < 0) t += len; }
    else t = std::max(0.f, std::min(len, t));
    // busca el par de poses que rodea a t (si es bucle, la ultima vuelve a la primera)
    const RigKey *a = &c.keys.back(), *b = &c.keys.front();
    float ta = a->t, tb = b->t + (c.loop ? len : 0.f);
    bool found = false;
    for (size_t i = 0; i + 1 < c.keys.size(); i++)
        if (t >= c.keys[i].t && t <= c.keys[i + 1].t) { a = &c.keys[i]; b = &c.keys[i + 1]; ta = a->t; tb = b->t; found = true; break; }
    if (!found) {
        if (t < c.keys.front().t) {
            if (c.loop) { a = &c.keys.back(); b = &c.keys.front(); ta = a->t - len; tb = b->t; }
            else { RigPose p = c.keys.front().pose; p.rot.resize(r.bones.size()); return p; }
        } else {
            if (c.loop) { a = &c.keys.back(); b = &c.keys.front(); ta = a->t; tb = b->t + len; }
            else { RigPose p = c.keys.back().pose; p.rot.resize(r.bones.size()); return p; }
        }
    }
    float f = tb > ta ? (t - ta) / (tb - ta) : 0.f;
    f = std::max(0.f, std::min(1.f, f));
    f = f * f * (3.f - 2.f * f);  // suave al arrancar y al frenar
    RigPose p;
    p.rot.resize(r.bones.size());
    for (size_t i = 0; i < r.bones.size(); i++) {
        Quat qa = i < a->pose.rot.size() ? a->pose.rot[i] : Quat(), qb = i < b->pose.rot.size() ? b->pose.rot[i] : Quat();
        p.rot[i] = qSlerp(qa, qb, f);
    }
    p.root = a->pose.root + (b->pose.root - a->pose.root) * f;
    return p;
}

// ---------------------------------------------------------------- piel
static V3 boneTail(const Rig& r, int i) {
    V3 sum{0, 0, 0};
    int n = 0;
    for (size_t k = 0; k < r.bones.size(); k++)
        if (r.bones[k].parent == i) { sum = sum + r.bones[k].head; n++; }
    if (n) return sum * (1.f / n);
    const RigBone& b = r.bones[i];
    if (b.parent >= 0) return b.head + (b.head - r.bones[b.parent].head) * 0.5f;
    return b.head + V3{0, 0.05f, 0};
}

void rigComputeWeights(const Rig& r, const std::vector<float>& v8, RigWeights& w) {
    size_t nv = v8.size() / 8, nb = r.bones.size();
    w.bi.assign(nv * 4, 0);
    w.bw.assign(nv * 4, 0.f);
    if (!nb) return;
    std::vector<V3> tail(nb);
    for (size_t i = 0; i < nb; i++) tail[i] = boneTail(r, (int)i);
    std::vector<std::pair<float, int>> d(nb);
    float pw = std::max(1.f, r.stiff);
    for (size_t v = 0; v < nv; v++) {
        V3 p{v8[v * 8], v8[v * 8 + 1], v8[v * 8 + 2]};
        for (size_t i = 0; i < nb; i++) {
            V3 a = r.bones[i].head, ab = tail[i] - a, ap = p - a;
            float l2 = dot(ab, ab), t = l2 > 1e-10f ? std::max(0.f, std::min(1.f, dot(ap, ab) / l2)) : 0.f;
            V3 q = a + ab * t;
            d[i] = {len(p - q), (int)i};
        }
        size_t k = std::min<size_t>(4, nb);
        std::partial_sort(d.begin(), d.begin() + k, d.end());
        float sum = 0;
        float ww[4] = {0, 0, 0, 0};
        for (size_t j = 0; j < k; j++) { ww[j] = 1.f / std::pow(d[j].first + 0.015f, pw); sum += ww[j]; }
        for (size_t j = 0; j < k; j++) { w.bi[v * 4 + j] = (uint8_t)d[j].second; w.bw[v * 4 + j] = ww[j] / sum; }
    }
}

static void rotMat(Quat q, float m[9]) {
    float x = q.x, y = q.y, z = q.z, ww = q.w;
    m[0] = 1 - 2 * (y * y + z * z); m[1] = 2 * (x * y - z * ww);     m[2] = 2 * (x * z + y * ww);
    m[3] = 2 * (x * y + z * ww);     m[4] = 1 - 2 * (x * x + z * z); m[5] = 2 * (y * z - x * ww);
    m[6] = 2 * (x * z - y * ww);     m[7] = 2 * (y * z + x * ww);     m[8] = 1 - 2 * (x * x + y * y);
}

void rigWorldRots(const Rig& r, const RigPose& p, std::vector<Quat>& out) {
    size_t nb = r.bones.size();
    out.assign(nb, Quat());
    for (size_t i = 0; i < nb; i++) {
        const RigBone& b = r.bones[i];
        Quat rl = i < p.rot.size() ? p.rot[i] : Quat();
        out[i] = (b.parent < 0 || b.parent >= (int)i) ? rl : qNorm(qMul(out[b.parent], rl));
    }
}

void rigJointPositions(const Rig& r, const RigPose& p, std::vector<V3>& out) {
    size_t nb = r.bones.size();
    out.assign(nb, V3());
    std::vector<Quat> rw(nb);
    for (size_t i = 0; i < nb; i++) {  // los padres siempre van antes que los hijos
        const RigBone& b = r.bones[i];
        Quat rl = i < p.rot.size() ? p.rot[i] : Quat();
        if (b.parent < 0 || b.parent >= (int)i) { rw[i] = rl; out[i] = b.head + p.root; }
        else {
            rw[i] = qNorm(qMul(rw[b.parent], rl));
            out[i] = out[b.parent] + qRotate(rw[b.parent], b.head - r.bones[b.parent].head);
        }
    }
}

void rigSkinMatrices(const Rig& r, const RigPose& p, std::vector<float>& mats) {
    size_t nb = r.bones.size();
    mats.assign(nb * 12, 0.f);
    std::vector<V3> pj;
    rigJointPositions(r, p, pj);
    std::vector<Quat> rw(nb);
    for (size_t i = 0; i < nb; i++) {
        const RigBone& b = r.bones[i];
        Quat rl = i < p.rot.size() ? p.rot[i] : Quat();
        rw[i] = (b.parent < 0 || b.parent >= (int)i) ? rl : qNorm(qMul(rw[b.parent], rl));
        float m[9];
        rotMat(rw[i], m);
        V3 t = pj[i] - qRotate(rw[i], b.head);
        float* o = &mats[i * 12];
        o[0] = m[0]; o[1] = m[1]; o[2] = m[2]; o[3] = t.x;
        o[4] = m[3]; o[5] = m[4]; o[6] = m[5]; o[7] = t.y;
        o[8] = m[6]; o[9] = m[7]; o[10] = m[8]; o[11] = t.z;
    }
}

void rigSkin(const std::vector<float>& rest, const RigWeights& w, const std::vector<float>& mats, std::vector<float>& out) {
    size_t nv = rest.size() / 8;
    out = rest;
    size_t nb = mats.size() / 12;
    for (size_t v = 0; v < nv; v++) {
        const float* s = &rest[v * 8];
        float px = 0, py = 0, pz = 0, nx = 0, ny = 0, nz = 0;
        for (int j = 0; j < 4; j++) {
            float wt = w.bw[v * 4 + j];
            if (wt <= 0.f) continue;
            size_t b = w.bi[v * 4 + j];
            if (b >= nb) continue;
            const float* m = &mats[b * 12];
            px += wt * (m[0] * s[0] + m[1] * s[1] + m[2] * s[2] + m[3]);
            py += wt * (m[4] * s[0] + m[5] * s[1] + m[6] * s[2] + m[7]);
            pz += wt * (m[8] * s[0] + m[9] * s[1] + m[10] * s[2] + m[11]);
            nx += wt * (m[0] * s[3] + m[1] * s[4] + m[2] * s[5]);
            ny += wt * (m[4] * s[3] + m[5] * s[4] + m[6] * s[5]);
            nz += wt * (m[8] * s[3] + m[9] * s[4] + m[10] * s[5]);
        }
        float* o = &out[v * 8];
        o[0] = px; o[1] = py; o[2] = pz;
        float l = std::sqrt(nx * nx + ny * ny + nz * nz);
        if (l > 1e-6f) { o[3] = nx / l; o[4] = ny / l; o[5] = nz / l; }
    }
}

}  // namespace forge
