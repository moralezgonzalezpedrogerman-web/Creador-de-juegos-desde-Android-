#include "video.h"
namespace forge {
VideoApi& videoApi() {
    static VideoApi a;
    return a;
}
}  // namespace forge
