#pragma once
// Motor de formulas (como el editor de formulas de Pocket Code).
// Numeros, textos entre comillas simples 'hola', variables ("nombre" o nombre), operadores
// + - * / ^ = != < <= > >= y o no, parentesis y funciones (sen, raiz cuadrada, unir, ...).
#include <string>
#include <vector>

namespace forge {

struct Val {
    double n = 0;
    std::string s;
    bool str = false;
    Val() {}
    Val(double v) : n(v) {}
    static Val text(const std::string& t) { Val v; v.s = t; v.str = true; return v; }
    double num() const;          // un texto se convierte si parece numero (si no, 0)
    std::string txt() const;     // un numero se escribe sin ceros de sobra
    bool truthy() const { return str ? !s.empty() : n != 0; }
};

// Lo que la formula no sabe resolver sola (variables, propiedades del objeto, sensores, 3D...)
// se pide al entorno. 'name' llega normalizado (minusculas, sin tildes). args vacio si no hay parentesis.
// Si la formula escribio la variable entre comillas dobles ("nombre"), name llega con una comilla doble al inicio.
class FormulaEnv {
public:
    virtual ~FormulaEnv() {}
    virtual bool lookup(const std::string& name, const std::vector<Val>& args, Val& out) = 0;
};

Val evalFormula(const std::string& src, FormulaEnv* env);  // nunca falla: si no es formula valida devuelve el texto tal cual
bool formulaValid(const std::string& src);
std::string normName(const std::string& s);  // minusculas sin tildes ("Posición X" -> "posicion x")

// Catalogo para el editor de formulas (grupo + texto tal como se inserta).
struct FuncDef { const char* group; const char* label; };
const std::vector<FuncDef>& formulaFunctions();

}  // namespace forge
