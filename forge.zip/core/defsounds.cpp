#include "defsounds.h"

#include <algorithm>
#include <cmath>
#include <cstring>

namespace forge {

namespace {
const int kRate = 22050;

struct Rng {
    uint32_t s = 2463534242u;
    float n() { s ^= s << 13; s ^= s >> 17; s ^= s << 5; return (float)(s & 0xFFFFFF) / 8388607.5f - 1.f; }
};

// filtro de un polo: pasa-bajos
struct Lp {
    float y = 0, a;
    explicit Lp(float cutoff) { a = 1.f - std::exp(-6.2831853f * cutoff / kRate); }
    float f(float x) { y += a * (x - y); return y; }
};

std::vector<uint8_t> wav(const std::vector<float>& s) {
    std::vector<uint8_t> o(44 + s.size() * 2);
    auto w32 = [&](size_t p, uint32_t v) { for (int i = 0; i < 4; i++) o[p + i] = (uint8_t)(v >> (8 * i)); };
    auto w16 = [&](size_t p, uint16_t v) { o[p] = (uint8_t)v; o[p + 1] = (uint8_t)(v >> 8); };
    memcpy(&o[0], "RIFF", 4); w32(4, (uint32_t)(36 + s.size() * 2)); memcpy(&o[8], "WAVEfmt ", 8);
    w32(16, 16); w16(20, 1); w16(22, 1); w32(24, kRate); w32(28, kRate * 2); w16(32, 2); w16(34, 16);
    memcpy(&o[36], "data", 4); w32(40, (uint32_t)(s.size() * 2));
    for (size_t i = 0; i < s.size(); i++) {
        float v = std::max(-1.f, std::min(1.f, s[i]));
        w16(44 + i * 2, (uint16_t)(int16_t)(v * 32000.f));
    }
    return o;
}

std::vector<float> blank(float sec) { return std::vector<float>((size_t)(sec * kRate), 0.f); }
float tt(size_t i) { return (float)i / kRate; }

// golpe seco de ruido filtrado en el instante t0
void thump(std::vector<float>& s, float t0, float freq, float decay, float amp) {
    for (size_t i = (size_t)(t0 * kRate); i < s.size(); i++) {
        float t = tt(i) - t0;
        s[i] += std::sin(6.2831853f * freq * t * (1.f - 0.3f * std::min(1.f, t * 8.f))) * std::exp(-t * decay) * amp;
    }
}
void noiseBurst(std::vector<float>& s, float t0, float cutoff, float decay, float amp, uint32_t seed) {
    Rng r; r.s ^= seed;
    Lp lp(cutoff);
    for (size_t i = (size_t)(t0 * kRate); i < s.size(); i++) {
        float t = tt(i) - t0;
        s[i] += lp.f(r.n()) * std::exp(-t * decay) * amp;
    }
}
void click(std::vector<float>& s, float t0, float freq, float decay, float amp) {  // chasquido metalico
    for (size_t i = (size_t)(t0 * kRate); i < s.size(); i++) {
        float t = tt(i) - t0;
        if (t > 0.08f) break;
        s[i] += (std::sin(6.2831853f * freq * t) + 0.5f * std::sin(6.2831853f * freq * 2.7f * t)) * std::exp(-t * decay) * amp;
    }
}

std::vector<float> shot(bool pistol) {
    auto s = blank(pistol ? 0.45f : 0.7f);
    noiseBurst(s, 0.f, 9000.f, pistol ? 70.f : 55.f, 0.9f, 1);        // chasquido
    noiseBurst(s, 0.f, 1800.f, pistol ? 22.f : 14.f, 0.7f, 2);        // cuerpo
    thump(s, 0.f, pistol ? 120.f : 70.f, pistol ? 22.f : 12.f, 0.9f);  // golpe grave
    noiseBurst(s, 0.02f, 700.f, pistol ? 8.f : 5.f, 0.22f, 3);        // eco del lugar
    return s;
}
}  // namespace

const std::vector<std::string>& defaultSoundNames() {
    static const std::vector<std::string> n = {"paso", "salto", "aterrizaje", "disparo", "pistola", "recarga", "golpe", "lanzar", "dano", "explosion", "linterna"};
    return n;
}

std::vector<uint8_t> makeDefaultSound(const std::string& name) {
    std::vector<float> s;
    if (name == "paso") {              // bota militar sobre grava
        s = blank(0.22f);
        thump(s, 0.f, 85.f, 38.f, 0.55f);
        noiseBurst(s, 0.f, 2500.f, 42.f, 0.5f, 11);
        noiseBurst(s, 0.045f, 5000.f, 60.f, 0.18f, 12);
    } else if (name == "salto") {      // tela y equipo
        s = blank(0.3f);
        noiseBurst(s, 0.f, 3200.f, 9.f, 0.28f, 21);
        thump(s, 0.02f, 140.f, 18.f, 0.25f);
    } else if (name == "aterrizaje") { // caida con peso
        s = blank(0.35f);
        thump(s, 0.f, 62.f, 20.f, 0.9f);
        noiseBurst(s, 0.f, 2200.f, 28.f, 0.5f, 31);
        click(s, 0.03f, 1700.f, 90.f, 0.12f);  // metal del equipo
    } else if (name == "disparo") {
        s = shot(false);
    } else if (name == "pistola") {
        s = shot(true);
    } else if (name == "recarga") {    // cargador fuera, dentro y cerrojo
        s = blank(1.2f);
        click(s, 0.10f, 1300.f, 60.f, 0.5f);
        noiseBurst(s, 0.10f, 4000.f, 50.f, 0.15f, 41);
        click(s, 0.55f, 2100.f, 55.f, 0.6f);
        thump(s, 0.55f, 180.f, 40.f, 0.3f);
        click(s, 0.90f, 900.f, 45.f, 0.7f);
        click(s, 0.97f, 2800.f, 80.f, 0.4f);
    } else if (name == "golpe") {      // tajo / golpe de arma
        s = blank(0.35f);
        Rng r; r.s ^= 51; Lp lp(1500.f); Lp lp2(300.f);
        for (size_t i = 0; i < s.size(); i++) {
            float t = tt(i), env = std::sin(std::min(1.f, t / 0.25f) * 3.14159f);
            float x = r.n();
            s[i] = (lp.f(x) - lp2.f(x)) * env * 0.9f * (1.f - t * 1.5f);
        }
        thump(s, 0.12f, 95.f, 25.f, 0.35f);
    } else if (name == "lanzar") {
        s = blank(0.35f);
        Rng r; r.s ^= 61; Lp lp(2200.f);
        for (size_t i = 0; i < s.size(); i++) { float t = tt(i); s[i] = lp.f(r.n()) * std::sin(std::min(1.f, t / 0.3f) * 3.14159f) * 0.5f; }
    } else if (name == "dano") {       // impacto en el cuerpo
        s = blank(0.4f);
        thump(s, 0.f, 80.f, 16.f, 0.85f);
        noiseBurst(s, 0.f, 1400.f, 22.f, 0.5f, 71);
    } else if (name == "explosion") {
        s = blank(1.6f);
        thump(s, 0.f, 48.f, 3.5f, 1.0f);
        noiseBurst(s, 0.f, 1600.f, 4.f, 0.9f, 81);
        noiseBurst(s, 0.f, 6000.f, 14.f, 0.5f, 82);
        noiseBurst(s, 0.15f, 500.f, 2.2f, 0.35f, 83);
    } else if (name == "linterna") {   // interruptor
        s = blank(0.12f);
        click(s, 0.f, 2400.f, 120.f, 0.5f);
        click(s, 0.035f, 1500.f, 150.f, 0.3f);
    } else return {};
    // fade corto para evitar clics al final
    size_t fade = std::min<size_t>(s.size() / 8, 200);
    for (size_t i = 0; i < fade; i++) s[s.size() - 1 - i] *= (float)i / fade;
    return wav(s);
}

}  // namespace forge
