#pragma once
#include "game.h"
#include "gl.h"
#include <string>
#include <unordered_map>

namespace forge {

// Vista del editor: camara orbital (3D) o vista plana (2D) y objeto seleccionado.
struct EditorView {
    V3 eye, fwd, target;
    int sel = -1;
    float cx = 0, cy = 0, h2d = kView2DHeight;
};

// Renderizador ligero: un cubo compartido para todos los objetos, modelos .fmdl,
// sombra direccional con un mapa de profundidad de 16 bits y cielo procedural.
class Renderer {
public:
    bool init(int shadowSize = 1024);
    void shutdown();  // libera todo lo de GL (tambien al perder el contexto en Android)
    void render(Game& g, int w, int h, const EditorView* ev = nullptr);
    void clear(int w, int h, float r, float g, float b);
    // Id de textura GL de un asset (0 si no existe) y sus dimensiones.
    unsigned textureId(const Game& g, const std::string& name, int* w = nullptr, int* h = nullptr);
    // Sube una imagen RGBA propia (miniaturas) con una clave; si ya existe devuelve la misma.
    unsigned uploadRGBA(const std::string& key, int w, int h, const uint8_t* px);
    unsigned updateRGBA(const std::string& key, int w, int h, const uint8_t* px);  // crea o reemplaza el contenido
    unsigned rawTexture(const std::string& key, int* w = nullptr, int* h = nullptr) const;  // textura subida con uploadRGBA
    bool hasTexture(const std::string& key) const { return tex_.count(key) > 0; }
    void forget(const std::string& name);  // olvida una textura (porque la imagen cambio)

private:
    struct Prog {
        GLuint id = 0;
        std::unordered_map<std::string, GLint> loc;
        GLint u(const char* n);
    };
    struct TexInfo { GLuint id = 0; int w = 1, h = 1; };
    struct ModelGL {
        GLuint vao = 0, vbo = 0, ibo = 0;
        int count = 0;
        GLenum itype = GL_UNSIGNED_SHORT;
        std::string tex;
        float color[3] = {1, 1, 1};
        bool ok = false;
        unsigned long long sig = 0;  // mallas dinámicas: firma de lo último que se subió
    };
    Prog main_, sky_, depth_;
    GLuint vao_ = 0, vbo_ = 0, ibo_ = 0, vaoEmpty_ = 0, fbo_ = 0, shadowTex_ = 0, white_ = 0;
    int shadowSize_ = 1024;
    float atmoDensity_ = 0.f;
    std::vector<uint8_t> vidPx_;
    std::unordered_map<std::string, TexInfo> tex_;
    std::unordered_map<std::string, ModelGL> models_;

    TexInfo& texture(const Game& g, const std::string& name);
    ModelGL* model(const Game& g, const std::string& name);
    ModelGL* dynModel(const std::string& key, const std::vector<float>& v, const std::vector<uint32_t>& idx, unsigned long long sig);
    ModelGL* skinned(Game& g, int idx, const std::string& model, ModelGL* base);
    ModelGL* forceMd_ = nullptr;
    ModelGL* terrainMesh(const Game& g, int idx);
    void setupAttribs();
    void drawObjs(Game& g, Prog& p, bool shadow);
    void box(Prog& p, V3 pos, V3 scale, float r, float g, float b, float a);
    void drawModelAt(Game& g, Prog& p, const std::string& model, const std::string& tex, V3 pos, float yawDeg, V3 scale, float r, float gg, float b, float a);
    void drawSprite(Game& g, Prog& p, const std::string& tex, V3 pos, float w, float h, float r, float gg, float b);
    void drawDynamic(Game& g, Prog& p, const EditorView* ev);
    V3 camE_{0, 0, 0};
    unsigned ovTex_ = 0;      // textura propia para el siguiente drawModelAt (particulas)
    bool additive_ = false;   // mezcla aditiva (brillo)
    unsigned softDot();
    void drawParticles(Game& g, Prog& p, bool is3);
    void render3D(Game& g, int w, int h, const EditorView* ev);
    void render2D(Game& g, int w, int h, const EditorView* ev);
};

}  // namespace forge
