#include "scene.h"
#include <cstdio>
#include <cstdlib>
#include <sstream>

namespace forge {

static std::vector<std::string> split(const std::string& l) {
    std::vector<std::string> t;
    std::istringstream ss(l);
    std::string w;
    while (ss >> w) t.push_back(w);
    return t;
}

const char* kindName(Kind k) {
    switch (k) {
        case Kind::Cube: return "cube";
        case Kind::Floor: return "floor";
        case Kind::Wall: return "wall";
        case Kind::Item: return "item";
        case Kind::Model: return "model";
        case Kind::Light: return "light";
        case Kind::Player: return "player";
    }
    return "cube";
}

static bool kindFromName(const std::string& s, Kind& k) {
    for (int i = 0; i <= (int)Kind::Player; i++)
        if (s == kindName((Kind)i)) { k = (Kind)i; return true; }
    return false;
}

static const char* actName(HudAct a) {
    switch (a) {
        case HudAct::None: return "none";
        case HudAct::Jump: return "jump";
        case HudAct::Shoot: return "shoot";
        case HudAct::Interact: return "interact";
    }
    return "none";
}

std::vector<HudBtn> defaultHud() {
    HudBtn s;
    s.label = "DISPARAR"; s.x = 0.88f; s.y = 0.68f; s.r = 0.12f; s.act = HudAct::Shoot;
    s.color[0] = 1.f; s.color[1] = 0.35f; s.color[2] = 0.3f;
    HudBtn j;
    j.label = "SALTAR"; j.x = 0.73f; j.y = 0.86f; j.r = 0.09f; j.act = HudAct::Jump;
    j.color[0] = 0.3f; j.color[1] = 0.7f; j.color[2] = 1.f;
    return {s, j};
}

// ---------------------------------------------------------------- tabla de bloques
// Nombres y descripciones tomados del PDF de bloques (Pocket Code).
#define H 2
static const OpInfo kOps[] = {
    // ---- Eventos
    {Op::WhenStart, "cuandoempieza", Cat::Eventos, "Cuando empieza el programa", "Ejecuta los bloques de código cuando el programa arranca.", "", "", "", "", H},
    {Op::WhenTap, "cuandopulse", Cat::Eventos, "Cuando pulse", "Ejecuta los bloques de código cuando se pulsa sobre el objeto.", "", "", "", "", H},
    {Op::WhenReceive, "cuandorecibo", Cat::Eventos, "Cuando recibo {t}", "Ejecuta los bloques de código cuando el objeto recibe un mensaje específico.", "mensaje1", "", "", "", H},
    {Op::WhenCollide, "cuandocolision", Cat::Eventos, "Cuando hay una colisión física con {t}", "Permite la ejecución de una secuencia de bloques cuando el objeto colisiona con otro objeto determinado.", "", "", "", "", H},
    {Op::WhenTrue, "cuandoverdadero", Cat::Eventos, "Cuando {0} se convierta en verdadero", "Ejecuta los bloques cuando la fórmula pasa de falsa a verdadera.", "", "1 = 2", "", "", H},
    {Op::WhenShot, "cuandodisparo", Cat::Forge3D, "Cuando reciba un disparo", "3D: se ejecuta cuando el jugador dispara a este objeto.", "", "", "", "", H},
    {Op::WhenInteract, "cuandointeractua", Cat::Forge3D, "Cuando se interactúe", "Se ejecuta al tocar el objeto o pulsar el botón de interactuar mirándolo de cerca (puertas, interruptores, carteles).", "", "", "", "", H},
    {Op::WhenNear, "cuandocerca", Cat::Forge3D, "Cuando el jugador se acerque", "3D: se ejecuta cuando el jugador entra en el radio del objeto.", "", "", "", "", H},
    // ---- Control
    {Op::Wait, "espera", Cat::Control, "Espera {0} segundos", "Espera un número específico de segundos y después continúa con la ejecución del siguiente bloque.", "", "1", "", "", 0},
    {Op::BroadcastWait, "enviayespera", Cat::Control, "Envía y espera {t}", "Envía un mensaje específico a todos los objetos y espera.", "mensaje1", "", "", "", 0},
    {Op::Broadcast, "difundir", Cat::Control, "Difundir mensaje {t}", "Envía un determinado mensaje a todos los objetos.", "mensaje1", "", "", "", 0},
    {Op::Forever, "parasiempre", Cat::Control, "Para siempre", "Ejecuta indefinidamente las instrucciones colocadas dentro del bloque.", "", "", "", "", 1},
    {Op::Repeat, "repetir", Cat::Control, "Repetir {0} veces", "Ejecuta un número específico de veces las instrucciones definidas dentro del bloque.", "", "10", "", "", 1},
    {Op::LoopEnd, "finbucle", Cat::Control, "Fin del bucle", "Define el fin del bucle (PARA SIEMPRE o REPETIR).", "", "", "", "", -1},
    {Op::Note, "nota", Cat::Control, "Nota {t}", "Con este bloque se pueden poner comentarios en el código sin cambiar la ejecución del programa.", "escribe aquí", "", "", "", 0},
    {Op::If, "si", Cat::Control, "Si {0} es verdadero entonces", "Si la condición es verdadera, ejecuta todos los bloques de instrucciones dentro de esta área. Si la condición es falsa ejecuta todos los bloques de lo contrario.", "", "1 = 1", "", "", 1},
    {Op::Else, "contrario", Cat::Control, "De lo contrario", "Define el área de instrucciones alternativas cuando la condición del bloque \"SI\" es falsa.", "", "", "", "", 3},
    {Op::EndIf, "finsi", Cat::Control, "Fin del si", "Siempre va con la condición si.", "", "", "", "", -1},
    {Op::StartScene, "iniciarescena", Cat::Control, "Iniciar escena {t}", "Cambia a otra escena del proyecto.", "", "", "", "", 0},
    // ---- Movimiento
    {Op::PlaceAt, "coloque", Cat::Movimiento, "Coloque en X: {0} Y: {1}", "Coloca el objeto en las coordenadas definidas en X e Y.", "", "0", "0", "", 0},
    {Op::SetX, "establecax", Cat::Movimiento, "Establezca X en: {0}", "Establece la coordenada X del objeto.", "", "0", "", "", 0},
    {Op::SetY, "establecay", Cat::Movimiento, "Establezca Y en: {0}", "Establece la coordenada Y del objeto.", "", "0", "", "", 0},
    {Op::ChangeX, "incrementax", Cat::Movimiento, "Incrementar X en: {0}", "Al valor actual de la coordenada X se suma el incremento especificado si es positivo o se resta si es negativo.", "", "10", "", "", 0},
    {Op::ChangeY, "incrementay", Cat::Movimiento, "Incrementar Y en: {0}", "Al valor actual de la coordenada Y se suma el incremento especificado si es positivo o se resta si es negativo.", "", "10", "", "", 0},
    {Op::BounceEdge, "rebotaborde", Cat::Movimiento, "Si en el borde, rebota", "Si el objeto toca el borde de la pantalla rebota contra él.", "", "", "", "", 0},
    {Op::Move, "mover", Cat::Movimiento, "Mover {0} pasos", "Mueve el objeto un número determinado de pasos (por ejemplo 10).", "", "10", "", "", 0},
    {Op::TurnLeft, "girarizq", Cat::Movimiento, "Girar a la izquierda: {0} ° (grados)", "Gira el objeto hacia la izquierda (en sentido opuesto a las agujas del reloj) un número específico de grados.", "", "15", "", "", 0},
    {Op::TurnRight, "girarder", Cat::Movimiento, "Girar a la derecha: {0} ° (grados)", "Gira el objeto hacia la derecha (en el sentido de las agujas del reloj) un número específico de grados.", "", "15", "", "", 0},
    {Op::PointDir, "apuntardir", Cat::Movimiento, "Apuntar en la dirección: {0} ° (grados)", "Establece la dirección del objeto (en grados).", "", "90", "", "", 0},
    {Op::PointTowards, "apuntarhacia", Cat::Movimiento, "Apuntar hacia {t}", "Apunta el objeto actual en la dirección de otro objeto.", "", "", "", "", 0},
    {Op::GlideTo, "deslizar", Cat::Movimiento, "Deslizar {0} segundos a X: {1} Y: {2}", "Desliza el objeto un número determinado de segundos hasta las coordenadas especificadas X e Y.", "", "1", "100", "100", 0},
    {Op::GoBack, "llevaratras", Cat::Movimiento, "Llevar atrás {0} capas", "Mueve el objeto un número específico de capas hacia el fondo (el objeto va pasando detrás de otros).", "", "1", "", "", 0},
    {Op::GoFront, "alfrente", Cat::Movimiento, "Ir al frente", "Mueve el objeto delante de todos los demás, a la capa más alta.", "", "", "", "", 0},
    {Op::Vibrate, "vibrar", Cat::Movimiento, "Vibrar por {0} segundos", "Usa la función de vibración del dispositivo por un dado número de segundos.", "", "1", "", "", 0},
    {Op::PhysDynamic, "fisicadinamica", Cat::Movimiento, "Establece el tipo de movimiento como: Rebotar con la gravedad", "Define un objeto físico que está afectado por la gravedad, colisiones, etc. Por ejemplo una pelota de ping-pong que choca y rebota con otros objetos que responden a la fuerza de la gravedad.", "", "", "", "", 0},
    {Op::PhysStatic, "fisicaestatica", Cat::Movimiento, "Establece el tipo de movimiento como: solo otros rebotan", "Define un objeto físico que no está afectado por la gravedad - por ejemplo un muro o el suelo - pero que permite a los objetos físicos chocar y rebotar contra él.", "", "", "", "", 0},
    {Op::PhysNone, "fisicanada", Cat::Movimiento, "Establece el tipo de movimiento como: No rebotar", "Define un objeto no físico que no está afectado por la gravedad y que no interacciona con los otros objetos físicos – por ejemplo el fondo - que no colisiona con otros objetos físicos.", "", "", "", "", 0},
    {Op::SetForce, "fuerza", Cat::Movimiento, "Establecer la intensidad de la fuerza en X: {0} Y: {1} pasos/segundos", "Establece la intensidad de la fuerza a lo largo de las componentes en los ejes X e Y. La trayectoria del objeto está determinada por la fuerza y la gravedad si el objeto es un objeto físico.", "", "0", "100", "", 0},
    {Op::SpinLeft, "giroizq", Cat::Movimiento, "Girar a la izquierda {0} grados/segundo", "Establece la velocidad de rotación hacia la izquierda (en sentido opuesto a las agujas del reloj) de un objeto en grados por segundo.", "", "15", "", "", 0},
    {Op::SpinRight, "giroder", Cat::Movimiento, "Girar a la derecha {0} grados/segundo", "Establece la velocidad de rotación hacia la derecha (en sentido de las agujas del reloj) de un objeto en grados por segundo.", "", "15", "", "", 0},
    {Op::SetGravity, "gravedad", Cat::Movimiento, "Establecer la gravedad para todos los objetos en X: {0} Y: {1} pasos/segundos²", "Cambia la dirección del campo gravitacional en las componentes X e Y en pasos por segundos al cuadrado. La aproximación del campo gravitacional de la tierra es X:0 Y:-10.", "", "0", "-10", "", 0},
    {Op::SetMass, "masa", Cat::Movimiento, "Establecer la masa a {0} kilogramos", "Determina la masa de un objeto. Los valores admitidos son 0 y superiores.", "", "1", "", "", 0},
    {Op::SetBounce, "rebote", Cat::Movimiento, "Ajustar el factor de rebote al {0} %", "Determina cuánta energía/velocidad de un objeto se pierde (o gana) tras colisionar con otro objeto físico. Si es 0 no rebota en absoluto.", "", "80", "", "", 0},
    {Op::SetFriction, "friccion", Cat::Movimiento, "Ajustar la fricción al {0} %", "Determina la rapidez/facilidad con la que un objeto puede deslizarse a lo largo de otro. Cuanto más alto, menos se deslizará.", "", "20", "", "", 0},
    {Op::PlaceAt3, "coloque3d", Cat::Forge3D, "Coloque en X: {0} Y: {1} Z: {2}", "3D: coloca el objeto en el espacio (Y es la altura).", "", "0", "0", "0", 0},
    {Op::SetZ, "establecaz", Cat::Forge3D, "Establezca Z en: {0}", "3D: establece la coordenada Z (profundidad).", "", "0", "", "", 0},
    {Op::ChangeZ, "incrementaz", Cat::Forge3D, "Incrementar Z en: {0}", "3D: suma al valor actual de Z.", "", "1", "", "", 0},
    // ---- Sonido
    {Op::StartSound, "iniciarsonido", Cat::Sonido, "Iniciar sonido {t}", "Empezar a reproducir el sonido especificado.", "", "", "", "", 0},
    {Op::StopSounds, "pararsonidos", Cat::Sonido, "Parar todos los sonidos", "Parar todos los sonidos que se están reproduciendo.", "", "", "", "", 0},
    {Op::SetVolume, "volumen", Cat::Sonido, "Ajustar el volumen a {0} %", "Ajustar el volumen de un sonido al porcentaje especificado.", "", "60", "", "", 0},
    {Op::ChangeVolume, "incvolumen", Cat::Sonido, "Incrementar el volumen en {0}", "Al valor actual del volumen del sonido se le incrementa el valor especificado.", "", "-10", "", "", 0},
    {Op::Speak, "hablar", Cat::Sonido, "Hablar {0}", "Hablar el texto escrito.", "", "Hola", "", "", 0},
    {Op::SetSolid, "establecesolido", Cat::Forge3D, "Establecer colisión a {0} (1 = choca, 0 = atraviesa)", "Activa o quita la colisión del objeto (por ejemplo, una puerta que se abre).", "", "0", "", "", 0},
    {Op::TeleportPlayer, "teletransportar", Cat::Forge3D, "Teletransportar al jugador a X: {0} Y: {1} Z: {2}", "3D: mueve al jugador a otra posición (Y es la altura).", "", "0", "0.05", "0", 0},
    {Op::MoveToPlayer, "moverhaciajugador", Cat::Forge3D, "Mover {0} pasos hacia el jugador", "3D: acerca el objeto al jugador (enemigos). Los pasos son metros por vuelta de bucle.", "", "0.05", "", "", 0},
    {Op::Music, "musica", Cat::Forge3D, "Música en bucle {t}", "Reproduce una música en bucle (pausa la anterior).", "", "", "", "", 0},
    // ---- Apariencia
    {Op::NextLook, "proximaapariencia", Cat::Apariencia, "Próxima apariencia", "Cambia la apariencia del objeto con la siguiente apariencia. Puedes cambiar el orden de las apariencias de un objeto.", "", "", "", "", 0},
    {Op::SetSize, "tamano", Cat::Apariencia, "Ajustar el tamaño en {0} %", "Establece el tamaño del objeto actual al valor especificado.", "", "100", "", "", 0},
    {Op::ChangeSize, "inctamano", Cat::Apariencia, "Incrementar el tamaño en {0} %", "Al tamaño actual del objeto se le incrementa el porcentaje especificado.", "", "10", "", "", 0},
    {Op::Show, "mostrar", Cat::Apariencia, "Mostrar", "Hacer el objeto visible en la pantalla.", "", "", "", "", 0},
    {Op::Hide, "ocultar", Cat::Apariencia, "Ocultar", "Hacer el objeto invisible.", "", "", "", "", 0},
    {Op::SetTransp, "transparencia", Cat::Apariencia, "Ajustar el nivel de transparencia en un {0} %", "Fijar el nivel de transparencia al valor especificado.", "", "50", "", "", 0},
    {Op::ChangeTransp, "inctransparencia", Cat::Apariencia, "Incrementar el nivel de transparencia en {0}", "Al valor actual de la transparencia del objeto se le incrementa el valor especificado.", "", "25", "", "", 0},
    {Op::SetBright, "brillo", Cat::Apariencia, "Ajustar el nivel de brillo en un {0} %", "Fijar el nivel de brillo al valor especificado.", "", "50", "", "", 0},
    {Op::ChangeBright, "incbrillo", Cat::Apariencia, "Incrementar el nivel de brillo en {0}", "Al valor actual del brillo del objeto se le incrementa el valor especificado.", "", "25", "", "", 0},
    {Op::ClearFx, "limpiarefectos", Cat::Apariencia, "Limpiar los efectos gráficos", "Borra cualquier efecto gráfico del objeto como el brillo y la transparencia.", "", "", "", "", 0},
    {Op::SetLook, "cambiarapariencia", Cat::Apariencia, "Cambiar apariencia a {t}", "Cambia el objeto con la apariencia especificada. Un objeto puede tener varias apariencias. Distintas apariencias de un mismo objeto se pueden usar para crear animaciones sencillas.", "", "", "", "", 0},
    {Op::Flash, "flash", Cat::Apariencia, "Encender el flash {0}", "Enciende el flash del dispositivo (1 = encender, 0 = apagar).", "", "1", "", "", 0},
    {Op::ChangeColor, "inccolor", Cat::Apariencia, "Incrementar el nivel de color en {0}", "Al valor actual del color del objeto se le incrementa el valor especificado.", "", "25", "", "", 0},
    {Op::Say, "decir", Cat::Forge3D, "Decir {0}", "Muestra un texto en pantalla unos segundos.", "", "Hola", "", "", 0},
    {Op::Destroy, "eliminar", Cat::Forge3D, "Eliminar este objeto", "Quita el objeto del juego (ya no se ve ni choca).", "", "", "", "", 0},
    // ---- Datos
    {Op::SetVar, "variable", Cat::Datos, "Establezca una variable {t} en: {0}", "Fijar la variable a un valor concreto.", "", "0", "", "", 0},
    {Op::ChangeVar, "incvariable", Cat::Datos, "Incrementar la variable {t} en: {0}", "Al valor actual de la variable se le incrementa el valor especificado.", "", "1", "", "", 0},
    {Op::ShowVar, "mostrarvariable", Cat::Datos, "Mostrar la variable {t} en X: {0} Y: {1}", "Muestra el valor de la variable en las coordenadas específicas X e Y de la escena.", "", "0", "0", "", 0},
    {Op::HideVar, "ocultarvariable", Cat::Datos, "Ocultar la variable {t}", "Oculta la variable, por lo tanto no es visible en la escena.", "", "", "", "", 0},
};
#undef H

const OpInfo& opInfo(Op op) {
    for (auto& i : kOps) if (i.op == op) return i;
    return kOps[0];
}

const OpInfo* opInfoByKey(const std::string& key) {
    for (auto& i : kOps) if (key == i.key) return &i;
    return nullptr;
}

const char* catName(Cat c) {
    switch (c) {
        case Cat::Eventos: return "Eventos";
        case Cat::Control: return "Control";
        case Cat::Movimiento: return "Movimiento";
        case Cat::Sonido: return "Sonido";
        case Cat::Apariencia: return "Apariencia";
        case Cat::Datos: return "Datos";
        case Cat::Forge3D: return "Extras 3D";
    }
    return "";
}

bool isHat(Op op) { return opInfo(op).indent == 2; }

static std::string esc(const std::string& s) {
    if (s.empty()) return "~";
    std::string o;
    for (char c : s) {
        if (c == '%') o += "%25";
        else if (c == ' ') o += "%20";
        else if (c == '\n') o += "%0A";
        else if (c == '\t') o += "%09";
        else if (c == '\r') continue;
        else o += c;
    }
    if (o == "~") return "%7E";
    return o;
}

static std::string unesc(const std::string& s) {
    if (s == "~") return "";
    std::string o;
    for (size_t i = 0; i < s.size(); i++) {
        if (s[i] == '%' && i + 2 < s.size() + 0 && i + 2 <= s.size() - 1 + 0) {
            std::string h = s.substr(i + 1, 2);
            o += (char)strtol(h.c_str(), nullptr, 16);
            i += 2;
        } else o += s[i];
    }
    return o;
}

static std::string unders(std::string s) {
    for (auto& c : s) if (c == '_') c = ' ';
    return s;
}

bool loadProject(const Files& files, Project& p, std::string& err) {
    auto it = files.find("project.forge");
    if (it == files.end()) { err = "falta project.forge"; return false; }

    std::vector<std::string> lines;
    {
        std::string text(it->second.begin(), it->second.end());
        std::istringstream ss(text);
        std::string l;
        while (std::getline(ss, l)) {
            if (!l.empty() && l.back() == '\r') l.pop_back();
            lines.push_back(l);
        }
    }
    size_t li = 0;
    p = Project();
    for (auto& f : files)
        if (f.first != "project.forge") p.assets[f.first] = f.second;

    while (li < lines.size()) {
        auto t = split(lines[li]);
        li++;
        if (t.empty() || t[0][0] == '#') continue;
        auto F = [&](size_t k) { return k < t.size() ? (float)atof(t[k].c_str()) : 0.f; };

        if (t[0] == "project") { if (t.size() > 1) p.name = t[1]; continue; }
        if (t[0] == "hud") {
            p.hudDefault = !(t.size() > 1 && (t[1] == "custom" || t[1] == "none"));
            continue;
        }
        if (t[0] == "button") {
            HudBtn b;
            b.label = t.size() > 1 ? unders(t[1]) : "OK";
            b.x = F(2); b.y = F(3); b.r = F(4);
            std::string a = t.size() > 5 ? t[5] : "none";
            b.act = a == "jump" ? HudAct::Jump : a == "shoot" ? HudAct::Shoot : a == "interact" ? HudAct::Interact : HudAct::None;
            for (int k = 0; k < 3; k++) b.color[k] = t.size() > (size_t)(6 + k) ? F(6 + k) : 1.f;
            p.hud.push_back(b);
            continue;
        }
        if (t[0] == "weapon") {
            Weapon& w = p.weapon;
            w.tex = (t.size() > 1 && t[1] != "-") ? t[1] : "";
            w.scale = F(2); w.ox = F(3); w.oy = F(4); w.rate = F(5); w.range = F(6);
            w.enabled = t.size() > 7 ? F(7) != 0 : true;
            if (w.scale <= 0) w.scale = 0.5f;
            if (w.rate <= 0) w.rate = 0.25f;
            if (w.range <= 0) w.range = 60.f;
            continue;
        }
        if (t[0] == "showvars") { p.showVars = F(1) != 0; continue; }
        if (t[0] == "gvar") { if (t.size() > 1) p.globalVars.push_back(unesc(t[1])); continue; }

        if (t[0] == "scene") {
            Scene s;
            s.name = t.size() > 1 ? t[1] : "escena";
            s.is3d = !(t.size() > 2 && t[2] == "2d");
            p.scenes.push_back(s);
            continue;
        }
        if (p.scenes.empty()) { err = "linea fuera de una escena: " + t[0]; return false; }
        Scene& s = p.scenes.back();

        if (t[0] == "sky") {
            for (int k = 0; k < 3; k++) { s.skyTop[k] = F(1 + k); s.skyBot[k] = F(4 + k); }
        } else if (t[0] == "sun") {
            s.sunDir = {F(1), F(2), F(3)};
            for (int k = 0; k < 3; k++) s.sun[k] = F(4 + k);
        } else if (t[0] == "env") {
            s.ambient = F(1); s.fog = F(2);
        } else if (t[0] == "start") {
            s.start = {F(1), F(2), F(3)};
        } else if (t[0] == "obj") {
            Obj o;
            if (t.size() < 3 || !kindFromName(t[1], o.kind)) { err = "objeto invalido"; return false; }
            o.name = t[2];
            o.pos = {F(3), F(4), F(5)};
            o.scale = {t.size() > 6 ? F(6) : 1.f, t.size() > 7 ? F(7) : 1.f, t.size() > 8 ? F(8) : 1.f};
            o.yaw = F(9);
            for (int k = 0; k < 3; k++) o.color[k] = t.size() > (size_t)(10 + k) ? F(10 + k) : 1.f;
            if (t.size() > 13 && t[13] != "-") o.tex = t[13];
            if (t.size() > 14) o.solid = F(14) != 0;
            if (t.size() > 15) o.visible = F(15) != 0;
            if (t.size() > 16) o.spin = F(16) != 0;
            if (t.size() > 17 && t[17] != "-") o.model = t[17];
            s.objs.push_back(o);
        } else if (t[0] == "bg") {
            if (s.objs.empty()) { err = "'bg' sin objeto"; return false; }
            s.objs.back().bg = true;
        } else if (t[0] == "fx") {
            if (s.objs.empty()) { err = "'fx' sin objeto"; return false; }
            Obj& o = s.objs.back();
            o.transp = F(1); o.bright = F(2); o.hue = F(3); o.layer = (int)F(4);
        } else if (t[0] == "ex") {
            if (s.objs.empty()) { err = "'ex' sin objeto"; return false; }
            Obj& o = s.objs.back();
            o.noColor = F(1) != 0; o.texTile = F(2) != 0;
        } else if (t[0] == "phys") {
            if (s.objs.empty()) { err = "'phys' sin objeto"; return false; }
            Obj& o = s.objs.back();
            o.phys = t.size() > 1 && t[1] == "dynamic" ? Phys::Dynamic : t.size() > 1 && t[1] == "static" ? Phys::Static : Phys::None;
            o.mass = F(2); o.bounce = F(3); o.friction = F(4);
        } else if (t[0] == "look" || t[0] == "snd" || t[0] == "lvar") {
            if (s.objs.empty()) { err = "'" + t[0] + "' sin objeto"; return false; }
            Obj& o = s.objs.back();
            std::string v = t.size() > 1 ? unesc(t[1]) : "";
            (t[0] == "look" ? o.looks : t[0] == "snd" ? o.sounds : o.localVars).push_back(v);
        } else if (t[0] == "blk") {
            if (s.objs.empty()) { err = "'blk' sin objeto"; return false; }
            const OpInfo* oi = t.size() > 1 ? opInfoByKey(t[1]) : nullptr;
            if (!oi) { err = "bloque desconocido: " + (t.size() > 1 ? t[1] : std::string()); return false; }
            Block b;
            b.op = oi->op;
            b.t = t.size() > 2 ? unesc(t[2]) : "";
            for (int k = 0; k < 3; k++) b.f[k] = t.size() > (size_t)(3 + k) ? unesc(t[3 + k]) : "";
            s.objs.back().blocks.push_back(std::move(b));
        } else {
            err = "instruccion desconocida: " + t[0];
            return false;
        }
    }
    if (p.scenes.empty()) { err = "el proyecto no tiene escenas"; return false; }
    return true;
}

// ---------------------------------------------------------------- escritura
static std::string fmt(float v) {
    char b[48];
    snprintf(b, sizeof b, "%g", (double)v);
    return b;
}

static std::string noSpace(std::string s) {
    if (s.empty()) return "-";
    for (auto& c : s) if (c == ' ' || c == '\t') c = '_';
    return s;
}

std::string writeProject(const Project& p) {
    std::ostringstream o;
    o << "project " << noSpace(p.name) << '\n';
    if (p.hudDefault) {
        o << "hud default\n";
    } else {
        o << "hud custom\n";
        for (auto& b : p.hud)
            o << "button " << noSpace(b.label) << ' ' << fmt(b.x) << ' ' << fmt(b.y) << ' ' << fmt(b.r) << ' '
              << actName(b.act) << ' ' << fmt(b.color[0]) << ' ' << fmt(b.color[1]) << ' ' << fmt(b.color[2]) << '\n';
    }
    o << "weapon " << noSpace(p.weapon.tex) << ' ' << fmt(p.weapon.scale) << ' ' << fmt(p.weapon.ox) << ' '
      << fmt(p.weapon.oy) << ' ' << fmt(p.weapon.rate) << ' ' << fmt(p.weapon.range) << ' '
      << (p.weapon.enabled ? 1 : 0) << '\n';
    o << "showvars " << (p.showVars ? 1 : 0) << '\n';
    for (auto& v : p.globalVars) o << "gvar " << esc(v) << '\n';

    for (auto& s : p.scenes) {
        o << "\nscene " << noSpace(s.name) << ' ' << (s.is3d ? "3d" : "2d") << '\n';
        o << "sky " << fmt(s.skyTop[0]) << ' ' << fmt(s.skyTop[1]) << ' ' << fmt(s.skyTop[2]) << ' '
          << fmt(s.skyBot[0]) << ' ' << fmt(s.skyBot[1]) << ' ' << fmt(s.skyBot[2]) << '\n';
        o << "sun " << fmt(s.sunDir.x) << ' ' << fmt(s.sunDir.y) << ' ' << fmt(s.sunDir.z) << ' '
          << fmt(s.sun[0]) << ' ' << fmt(s.sun[1]) << ' ' << fmt(s.sun[2]) << '\n';
        o << "env " << fmt(s.ambient) << ' ' << fmt(s.fog) << '\n';
        o << "start " << fmt(s.start.x) << ' ' << fmt(s.start.y) << ' ' << fmt(s.start.z) << '\n';
        for (auto& ob : s.objs) {
            o << "obj " << kindName(ob.kind) << ' ' << noSpace(ob.name) << ' '
              << fmt(ob.pos.x) << ' ' << fmt(ob.pos.y) << ' ' << fmt(ob.pos.z) << ' '
              << fmt(ob.scale.x) << ' ' << fmt(ob.scale.y) << ' ' << fmt(ob.scale.z) << ' ' << fmt(ob.yaw) << ' '
              << fmt(ob.color[0]) << ' ' << fmt(ob.color[1]) << ' ' << fmt(ob.color[2]) << ' '
              << noSpace(ob.tex) << ' ' << (ob.solid ? 1 : 0) << ' ' << (ob.visible ? 1 : 0) << ' '
              << (ob.spin ? 1 : 0) << ' ' << noSpace(ob.model) << '\n';
            if (ob.bg) o << "bg\n";
            o << "fx " << fmt(ob.transp) << ' ' << fmt(ob.bright) << ' ' << fmt(ob.hue) << ' ' << ob.layer << '\n';
            if (ob.noColor || ob.texTile) o << "ex " << (ob.noColor ? 1 : 0) << ' ' << (ob.texTile ? 1 : 0) << '\n';
            if (ob.phys != Phys::None)
                o << "phys " << (ob.phys == Phys::Dynamic ? "dynamic" : "static") << ' ' << fmt(ob.mass) << ' '
                  << fmt(ob.bounce) << ' ' << fmt(ob.friction) << '\n';
            for (auto& l : ob.looks) o << "look " << esc(l) << '\n';
            for (auto& l : ob.sounds) o << "snd " << esc(l) << '\n';
            for (auto& l : ob.localVars) o << "lvar " << esc(l) << '\n';
            for (auto& b : ob.blocks)
                o << "blk " << opInfo(b.op).key << ' ' << esc(b.t) << ' ' << esc(b.f[0]) << ' ' << esc(b.f[1]) << ' '
                  << esc(b.f[2]) << '\n';
        }
    }
    return o.str();
}

}  // namespace forge
