#include "game.h"
#include "model.h"
#include <algorithm>
#include <cmath>
#include <array>
#include <ctime>
#include <cstdlib>
#include <functional>
#include <map>

namespace forge {

static const float kRad = 3.14159265f / 180.f;

static bool solidKind(Kind k) {
    return k == Kind::Cube || k == Kind::Floor || k == Kind::Wall || k == Kind::Model;
}

bool Game::hasHat(const Obj& o, Op hat) const {
    for (auto& b : o.blocks) if (b.op == hat) return true;
    return false;
}

V3 Game::forward() const {
    return {std::sin(yaw) * std::cos(pitch), std::sin(pitch), -std::cos(yaw) * std::cos(pitch)};
}

// ---------------------------------------------------------------- carga
static void compileObj(const std::vector<Block>& B, std::vector<int>& match, std::vector<int>& hats) {
    int n = (int)B.size();
    match.assign(n, n);
    hats.clear();
    struct S { int idx; Op op; };
    std::vector<S> st;
    for (int i = 0; i < n; i++) {
        Op op = B[i].op;
        if (isHat(op)) { hats.push_back(i); st.clear(); continue; }
        if (op == Op::Forever || op == Op::Repeat || op == Op::If) st.push_back({i, op});
        else if (op == Op::Else) {
            if (!st.empty() && st.back().op == Op::If) { match[st.back().idx] = i; st.back() = {i, Op::Else}; }
        } else if (op == Op::EndIf) {
            if (!st.empty() && (st.back().op == Op::If || st.back().op == Op::Else)) { match[st.back().idx] = i; st.pop_back(); }
        } else if (op == Op::LoopEnd) {
            if (!st.empty() && (st.back().op == Op::Forever || st.back().op == Op::Repeat)) {
                match[st.back().idx] = i;
                match[i] = st.back().idx;
                st.pop_back();
            }
        }
    }
}

void Game::load(Project p) {
    proj = std::move(p);
    for (auto& sn : proj.scenes) ensurePlayer(sn);
    sc = nullptr;
    projs.clear();
    debris.clear();
    parts.clear();
    pendingClones_.clear();
    shakeT = 0;
    camMode = proj.player.cam;
    walkSpeed = proj.player.speed > 0 ? proj.player.speed : 4.5f;
    jumpPow = proj.player.jump > 0 ? proj.player.jump : 7.f;
    hurtFlash = 0;
    vars.clear();
    for (auto& g : proj.globalVars) {  // vida y municion empiezan llenas
        std::string k = normName(g);
        vars[k] = k == "vida" ? 100.0 : k == "municion" ? 30.0 : 0.0;
    }
    shown.clear();
    runners_.clear();
    shootCd = recoil = flash = 0;
    gravX_ = 0; gravY_ = -10;
    volume = 100;
    if (!proj.scenes.empty()) enterScene(proj.scenes[0].name);
}

void Game::bindScene(int idx) {
    if (idx < 0 || idx >= (int)proj.scenes.size()) { sc = nullptr; return; }
    sc = &proj.scenes[idx];
}

void Game::enterScene(const std::string& name) {
    Scene* found = nullptr;
    for (auto& s : proj.scenes) if (s.name == name) { found = &s; break; }
    if (!found) return;
    sc = found;
    runners_.clear();
    near_.assign(sc->objs.size(), 0);
    moving_.assign(sc->objs.size(), 0);
    last_.clear();
    for (auto& ob : sc->objs) last_.push_back(ob.pos);
    plMoving_ = plAir_ = false;
    base_.clear();
    cmp_.assign(sc->objs.size(), Compiled());
    st_.assign(sc->objs.size(), ObjState());
    for (size_t i = 0; i < sc->objs.size(); i++) {
        Obj& o = sc->objs[i];
        base_.push_back(o.scale);
        compileObj(o.blocks, cmp_[i].match, cmp_[i].hats);
        st_[i].hatState.assign(o.blocks.size(), 0);
        if (!o.looks.empty()) {
            auto it = std::find(o.looks.begin(), o.looks.end(), o.tex);
            st_[i].look = it == o.looks.end() ? 0 : (int)(it - o.looks.begin());
        }
    }
    pos = sc->start;
    yaw = 0;
    int pi = playerIndex(*sc);
    if (pi >= 0) {
        pos = {sc->objs[pi].pos.x, sc->objs[pi].pos.y - 0.85f, sc->objs[pi].pos.z};
        yaw = sc->objs[pi].yaw * kRad;
    }
    bodyYaw = yaw;
    projs.clear();
    debris.clear();
    parts.clear();
    pendingClones_.clear();
    vel = V3();
    pitch = 0;
    for (size_t i = 0; i < sc->objs.size(); i++) st_[i].hp = sc->objs[i].ai.hp;
    applyCam();
    for (size_t i = 0; i < sc->objs.size(); i++) fireHat((int)i, Op::WhenStart);
}

// ---------------------------------------------------------------- guiones
int Game::startScript(int obj, int hatIdx) {
    for (auto& r : runners_)
        if (r.obj == obj && r.hat == hatIdx && !r.done) {  // reinicia el guion
            r.pc = hatIdx + 1; r.loops.clear(); r.wait = 0; r.gT = 0; r.waitIds.clear();
            return r.id;
        }
    Runner r;
    r.id = nextId_++;
    r.obj = obj;
    r.hat = hatIdx;
    r.pc = hatIdx + 1;
    const auto& hats = cmp_[obj].hats;
    int total = (int)sc->objs[obj].blocks.size();
    r.end = total;
    for (int h : hats) if (h > hatIdx) { r.end = h; break; }
    runners_.push_back(std::move(r));
    return runners_.back().id;
}

void Game::fireHat(int obj, Op hat) {
    if (obj < 0 || obj >= (int)cmp_.size()) return;
    const auto& B = sc->objs[obj].blocks;
    for (int h : cmp_[obj].hats) if (B[h].op == hat) startScript(obj, h);
}

void Game::fireAll(Op hat) {
    if (!sc) return;
    for (size_t i = 0; i < sc->objs.size() && i < cmp_.size(); i++) fireHat((int)i, hat);
}

// Lanza los eventos que llevan un texto (boton, objeto que se mueve).
void Game::fireHatText(Op hat, const std::string& txt) {
    if (!sc) return;
    std::string k = normName(txt);
    for (size_t i = 0; i < sc->objs.size() && i < cmp_.size(); i++) {
        const auto& B = sc->objs[i].blocks;
        for (int h : cmp_[i].hats) if (B[h].op == hat && normName(B[h].t) == k) startScript((int)i, h);
    }
}

// Eventos nuevos: disparar, botones, movimiento de objetos y del jugador.
void Game::eventsV6(float dt, const Input& in) {
    (void)dt;
    for (auto& b : in.buttons) fireHatText(Op::WhenButton, b);
    int pi = playerIndex(*sc);
    // objetos que empiezan a moverse
    for (size_t i = 0; i < sc->objs.size() && i < last_.size() && i < moving_.size(); i++) {
        const Obj& o = sc->objs[i];
        V3 d = o.pos - last_[i];
        bool mv = o.alive && (std::fabs(d.x) + std::fabs(d.y) + std::fabs(d.z)) > (sc->is3d ? 0.004f : 0.3f);
        last_[i] = o.pos;
        if (mv && !moving_[i]) {
            if ((int)i != pi) {  // los que no tienen nombre: "este mismo objeto"
                const auto& B = o.blocks;
                for (int h : cmp_[i].hats) if (B[h].op == Op::WhenObjMoves && B[h].t.empty()) startScript((int)i, h);
            }
            for (size_t j = 0; j < sc->objs.size() && j < cmp_.size(); j++) {
                const auto& B = sc->objs[j].blocks;
                for (int h : cmp_[j].hats)
                    if (B[h].op == Op::WhenObjMoves && !B[h].t.empty() && normName(B[h].t) == normName(o.name)) startScript((int)j, h);
            }
        }
        moving_[i] = mv;
    }
    if (sc->is3d) {
        bool mv = std::fabs(vel.x) + std::fabs(vel.z) > 0.3f && ground;
        if (mv && !plMoving_) fireAll(Op::WhenPlayerMoves);
        plMoving_ = mv;
        bool air = !ground && vel.y > 0.5f;
        if (air && !plAir_) fireAll(Op::WhenPlayerJumps);
        plAir_ = air || (!ground && plAir_);
        if (ground) plAir_ = false;
    }
}

void Game::broadcast(const std::string& msg, std::vector<int>* ids) {
    for (size_t i = 0; i < sc->objs.size(); i++) {
        const auto& B = sc->objs[i].blocks;
        for (int h : cmp_[i].hats)
            if (B[h].op == Op::WhenReceive && B[h].t == msg) {
                int id = startScript((int)i, h);
                if (ids) ids->push_back(id);
            }
    }
}

int Game::findObj(const std::string& name) const {
    if (!sc) return -1;
    std::string k = normName(name);
    for (size_t i = 0; i < sc->objs.size(); i++) if (normName(sc->objs[i].name) == k) return (int)i;
    return -1;
}

// Rectangulo girado en el plano del suelo (3D: X,Z) o de la pantalla (2D: X,Y). (ax,ay) = eje local X girado.
struct Quad { float cx, cy, hx, hy, ax, ay; };
static Quad quadOf(const Obj& o, bool is3) {
    Quad q;
    q.cx = o.pos.x;
    q.hx = o.scale.x * .5f;
    if (is3) {
        float a = o.yaw * 0.0174532925f;
        q.cy = o.pos.z; q.hy = o.scale.z * .5f; q.ax = std::cos(a); q.ay = -std::sin(a);
    } else {
        float a = -(o.yaw - 90.f) * 0.0174532925f;
        q.cy = o.pos.y; q.hy = o.scale.y * .5f; q.ax = std::cos(a); q.ay = std::sin(a);
    }
    return q;
}
static bool quadsOverlap(const Quad& A, const Quad& B, float eps) {
    float ax[4][2] = {{A.ax, A.ay}, {-A.ay, A.ax}, {B.ax, B.ay}, {-B.ay, B.ax}};
    float dx = B.cx - A.cx, dy = B.cy - A.cy;
    for (auto& u : ax) {
        float rA = A.hx * std::fabs(u[0] * A.ax + u[1] * A.ay) + A.hy * std::fabs(-u[0] * A.ay + u[1] * A.ax);
        float rB = B.hx * std::fabs(u[0] * B.ax + u[1] * B.ay) + B.hy * std::fabs(-u[0] * B.ay + u[1] * B.ax);
        if (std::fabs(dx * u[0] + dy * u[1]) >= rA + rB - eps) return false;
    }
    return true;
}

bool Game::overlap(const Obj& a, const Obj& b) const {
    bool is3 = sc && sc->is3d;
    if (is3 && std::fabs(a.pos.y - b.pos.y) * 2 >= a.scale.y + b.scale.y) return false;
    return quadsOverlap(quadOf(a, is3), quadOf(b, is3), 0.f);  // la colision gira con el objeto
}

// ---------------------------------------------------------------- variables y formulas
Val Game::getVar(const std::string& name, int obj) {
    std::string k = vkey(name);
    if (obj >= 0 && obj < (int)st_.size()) {
        auto it = st_[obj].locals.find(k);
        if (it != st_[obj].locals.end()) return it->second;
    }
    auto it = vars.find(k);
    return it == vars.end() ? Val(0.0) : it->second;
}

void Game::setVar(const std::string& name, Val v, int obj) {
    std::string k = vkey(name);
    if (obj >= 0 && obj < (int)st_.size()) {
        for (auto& lv : sc->objs[obj].localVars)
            if (vkey(lv) == k) { st_[obj].locals[k] = v; return; }
    }
    vars[k] = v;
}

Val Game::eval(const std::string& f, int obj) {
    int prev = cur_;
    cur_ = obj;
    Val v = evalFormula(f, this);
    cur_ = prev;
    return v;
}

bool Game::lookup(const std::string& nameIn, const std::vector<Val>& a, Val& out) {
    bool quoted = !nameIn.empty() && nameIn[0] == '"';
    std::string n = quoted ? nameIn.substr(1) : nameIn;
    int o = cur_;
    Obj* ob = (sc && o >= 0 && o < (int)sc->objs.size()) ? &sc->objs[o] : nullptr;
    ObjState* os = (ob && o < (int)st_.size()) ? &st_[o] : nullptr;
    auto N = [&](size_t i) { return i < a.size() ? a[i].num() : 0.0; };
    auto S = [&](size_t i) { return i < a.size() ? a[i].txt() : std::string(); };

    if (quoted) {  // variable explicita
        out = getVar(n, o);
        return true;
    }
    bool is3 = sc && sc->is3d;
    float sw = stageW(), sh = kView2DHeight;
    auto touchX = [&](int i) { return (in_.touch[i].x - 0.5f) * sw; };
    auto touchY = [&](int i) { return (0.5f - in_.touch[i].y) * sh; };
    auto nthTouch = [&](int k) {  // k = 1..: indice del k-esimo dedo actual
        int c = 0;
        for (int i = 0; i < 10; i++) if (in_.touch[i].down && ++c == k) return i;
        return -1;
    };
    auto objByArg = [&](size_t i) { return findObj(S(i)); };
    auto objPos = [&](int idx, V3& p) {
        if (idx >= 0) { p = sc->objs[idx].pos; return true; }
        return false;
    };

    // --- propiedades del objeto
    if (ob) {
        if (n == "get_object_name") { out = Val::text(ob->name); return true; }
        if (n == "direccion" || n == "direccion de la mirada") { out = ob->yaw; return true; }
        if (n == "transparencia") { out = ob->transp; return true; }
        if (n == "brillo") { out = ob->bright; return true; }
        if (n == "color") { out = ob->hue; return true; }
        if (n == "numero_fondo") { out = os->look + 1; return true; }
        if (n == "nombre_fondo") { out = Val::text(os->look < (int)ob->looks.size() ? ob->looks[os->look] : ""); return true; }
        if (n == "numero de fondos") { out = (double)ob->looks.size(); return true; }
        if (n == "posicion x") { out = ob->pos.x; return true; }
        if (n == "posicion y") { out = ob->pos.y; return true; }
        if (n == "tamano") { out = os->sizePct; return true; }
        if (n == "width") { out = ob->scale.x; return true; }
        if (n == "height") { out = ob->scale.y; return true; }
        if (n == "capa") { out = ob->layer; return true; }
        if (n == "velocidad x") { out = os->vel.x; return true; }
        if (n == "velocidad y") { out = os->vel.y; return true; }
        if (n == "velocidad angular") { out = os->spin; return true; }
        if (n == "tocar_objeto" || n == "touches_object_by_name") {
            int j = objByArg(0);
            out = (j >= 0 && j != o && sc->objs[j].alive && sc->objs[j].visible && overlap(*ob, sc->objs[j])) ? 1 : 0;
            return true;
        }
        if (n == "tocar_bordes") {
            out = (!is3 && (std::fabs(ob->pos.x) + ob->scale.x * .5f > sw * .5f || std::fabs(ob->pos.y) + ob->scale.y * .5f > sh * .5f)) ? 1 : 0;
            return true;
        }
        if (n == "tocar_dedos") {
            bool hit = false;
            if (!is3)
                for (int i = 0; i < 10; i++)
                    if (in_.touch[i].down && std::fabs(touchX(i) - ob->pos.x) <= ob->scale.x * .5f &&
                        std::fabs(touchY(i) - ob->pos.y) <= ob->scale.y * .5f) hit = true;
            out = hit ? 1 : 0;
            return true;
        }
        if (n == "toca el color" || n == "color toca el color") { out = 0; return true; }
    }

    // --- dispositivo
    if (n == "volumen") { out = volume; return true; }
    if (n == "stage width") { out = sw; return true; }
    if (n == "stage height") { out = sh; return true; }
    if (n == "micro volume" || n == "micro frequency") { out = 0; return true; }
    if (n == "local server ip") { out = Val::text(""); return true; }
    if (n == "local server port") { out = 0; return true; }
    if (n == "battery percentage") { out = dev.battery; return true; }
    if (n == "connected to internet") { out = dev.online; return true; }
    if (n == "cpu architecture") { out = Val::text("arm64"); return true; }
    if (n == "fps") { out = fps_; return true; }
    if (n == "clipboard_text") { out = Val::text(dev.clipboard); return true; }
    if (n == "keyboard_height") { out = dev.keyboardH; return true; }
    if (n == "color a x y" || n == "color es igual a color con % tolerancia") { out = 0; return true; }
    if (n == "acceleracion x") { out = dev.accel[0]; return true; }
    if (n == "acceleracion y") { out = dev.accel[1]; return true; }
    if (n == "acceleracion_z") { out = dev.accel[2]; return true; }
    if (n == "inclinacion x") { out = std::atan2(dev.accel[0], dev.accel[2] == 0 ? 9.8f : dev.accel[2]) / kRad; return true; }
    if (n == "inclinacion y") { out = std::atan2(dev.accel[1], dev.accel[2] == 0 ? 9.8f : dev.accel[2]) / kRad; return true; }
    if (n == "direccion_compass") { out = dev.compass; return true; }
    if (n == "latitud") { out = dev.lat; return true; }
    if (n == "longitud") { out = dev.lon; return true; }
    if (n == "precision_localizacion") { out = dev.acc; return true; }
    if (n == "altitud") { out = dev.alt; return true; }
    if (n == "idioma del usuario") { out = Val::text(dev.lang); return true; }

    // --- toques
    if (n == "toque pantalla x" || n == "toque pantalla y" || n == "pantalla_tocada") {
        int i = a.empty() ? -1 : (int)N(0) - 1;
        if (a.empty()) { for (int k = 9; k >= 0; k--) if (in_.touch[k].down) { i = k; break; } }
        if (n == "pantalla_tocada") out = (i >= 0 && i < 10 && in_.touch[i].down) ? 1 : 0;
        else if (i < 0 || i > 9) out = 0;
        else out = n == "toque pantalla x" ? touchX(i) : touchY(i);
        return true;
    }
    if (n == "ultimo_indice_de_toque_pantalla") { int last = 0; for (int k = 0; k < 10; k++) if (in_.touch[k].down) last = k + 1; out = last; return true; }
    if (n == "numero de toques actuales") { int c = 0; for (auto& t : in_.touch) c += t.down; out = c; return true; }
    if (n == "indice del toque actual") { out = nthTouch((int)N(0)) + 1; return true; }

    // --- fecha y hora
    if (n == "cronometro") { out = time; return true; }
    if (n == "ano" || n == "mes" || n == "dia" || n == "dia de la semana" || n == "hora" || n == "minuto" || n == "segundo") {
        std::time_t t = std::time(nullptr);
        std::tm* tm = std::localtime(&t);
        out = n == "ano" ? tm->tm_year + 1900 : n == "mes" ? tm->tm_mon + 1 : n == "dia" ? tm->tm_mday
              : n == "dia de la semana" ? (tm->tm_wday == 0 ? 7 : tm->tm_wday) : n == "hora" ? tm->tm_hour
              : n == "minuto" ? tm->tm_min : tm->tm_sec;
        return true;
    }

    // --- 3D
    if (n == "distancia al jugador") {
        out = (sc && sc->is3d && ob) ? len(V3{ob->pos.x - pos.x, ob->pos.y - (pos.y + 0.85f), ob->pos.z - pos.z}) : 0.0;
        return true;
    }
    if (n == "delta-time") { out = 1.0 / std::max(1.f, fps_); return true; }
    if (n.compare(0, 3, "3d ") == 0 && a.size() >= 1) {
        std::string what = n.substr(3);
        if (what == "distance between") {
            V3 p, q;
            if (objPos(objByArg(0), p) && objPos(objByArg(1), q)) out = len(p - q); else out = 0;
            return true;
        }
        int j = objByArg(0);
        if (j < 0) { out = 0; return true; }
        const Obj& t = sc->objs[j];
        if (what == "position x") out = t.pos.x; else if (what == "position y") out = t.pos.y; else if (what == "position z") out = t.pos.z;
        else if (what == "rotation y") out = t.yaw; else if (what == "rotation x" || what == "rotation z") out = 0;
        else if (what == "scale x") out = t.scale.x; else if (what == "scale y") out = t.scale.y; else if (what == "scale z") out = t.scale.z;
        else if (what == "velocity x") out = st_[j].vel.x; else if (what == "velocity y") out = st_[j].vel.y; else if (what == "velocity z") out = st_[j].vel.z;
        else return false;
        return true;
    }
    if (n == "object touches object") {
        int i = objByArg(0), j = objByArg(1);
        out = (i >= 0 && j >= 0 && overlap(sc->objs[i], sc->objs[j])) ? 1 : 0;
        return true;
    }
    if (n.compare(0, 7, "camera ") == 0) {
        std::string w = n.substr(7);
        V3 e = is3 ? eye() : V3(), f = is3 ? forward() : V3();
        if (w == "position x") out = e.x; else if (w == "position y") out = e.y; else if (w == "position z") out = e.z;
        else if (w == "direction x") out = f.x; else if (w == "direction y") out = f.y; else if (w == "direction z") out = f.z;
        else if (w == "rotation x") out = pitch / kRad; else if (w == "rotation y") out = yaw / kRad; else if (w == "rotation z") out = 0;
        else return false;
        return true;
    }

    // --- variables sin comillas
    std::string k = vkey(n);
    if (a.empty()) {
        if (os && os->locals.count(k)) { out = os->locals[k]; return true; }
        auto it = vars.find(k);
        if (it != vars.end()) { out = it->second; return true; }
        if (ob) for (auto& lv : ob->localVars) if (vkey(lv) == k) { out = 0; return true; }
    }
    return false;
}

// ---------------------------------------------------------------- mundo 3D
// Colision que sigue la forma del modelo: se marcan las celdas de una rejilla 16x16x16 que tocan la malla y se
// juntan en cajas; donde el modelo esta vacio (huecos, puertas, techos abiertos) no hay colision.
const std::vector<Game::CBox>& Game::modelBoxes(const std::string& name) const {
    auto it = mcol_.find(name);
    if (it != mcol_.end()) return it->second;
    std::vector<CBox>& out = mcol_[name];
    auto a = proj.assets.find(name);
    ModelData md;
    if (a == proj.assets.end() || !modelRead(a->second.data(), a->second.size(), md)) return out;
    const int N = 64;
    std::vector<char> occ((size_t)N * N * N, 0);
    auto cell = [&](float v) { return std::max(0, std::min(N - 1, (int)std::floor((v + 0.5f) * N))); };
    const float cs = 1.f / N;
    for (size_t t = 0; t + 2 < md.idx.size(); t += 3) {
        const float* P[3] = {&md.v[md.idx[t] * 8], &md.v[md.idx[t + 1] * 8], &md.v[md.idx[t + 2] * 8]};
        float e = 0;
        for (int k = 0; k < 3; k++) {
            const float *p0 = P[k], *p1 = P[(k + 1) % 3];
            e = std::max(e, std::max(std::fabs(p0[0] - p1[0]), std::max(std::fabs(p0[1] - p1[1]), std::fabs(p0[2] - p1[2]))));
        }
        int n = std::max(1, std::min(96, (int)std::ceil(e / (cs * 0.5f))));
        for (int i = 0; i <= n; i++)
            for (int j = 0; i + j <= n; j++) {
                float u = (float)i / n, v = (float)j / n, w = 1.f - u - v;
                float x = P[0][0] * w + P[1][0] * u + P[2][0] * v, y = P[0][1] * w + P[1][1] * u + P[2][1] * v,
                      z = P[0][2] * w + P[1][2] * u + P[2][2] * v;
                occ[((size_t)cell(y) * N + cell(z)) * N + cell(x)] = 1;
            }
    }
    // Se juntan las celdas en cajas grandes (primero a lo largo de X, luego Z, luego Y): las casas huecas
    // quedan con paredes finas y el interior libre.
    struct R { int x0, x1, z0, z1, y0, y1; };
    std::vector<R> done;
    std::map<std::array<int, 4>, R> openY;
    for (int y = 0; y < N; y++) {
        std::vector<R> rowRects;
        std::vector<R> open;
        for (int z = 0; z < N; z++) {
            std::vector<R> next;
            int x = 0;
            while (x < N) {
                if (!occ[((size_t)y * N + z) * N + x]) { x++; continue; }
                int x1 = x;
                while (x1 < N && occ[((size_t)y * N + z) * N + x1]) x1++;
                bool ext = false;
                for (auto it = open.begin(); it != open.end(); ++it)
                    if (it->x0 == x && it->x1 == x1) { R r = *it; r.z1 = z + 1; next.push_back(r); open.erase(it); ext = true; break; }
                if (!ext) next.push_back({x, x1, z, z + 1, y, y + 1});
                x = x1;
            }
            for (auto& r : open) rowRects.push_back(r);
            open.swap(next);
        }
        for (auto& r : open) rowRects.push_back(r);
        std::map<std::array<int, 4>, R> nextY;
        for (auto& r : rowRects) {
            std::array<int, 4> k{r.x0, r.x1, r.z0, r.z1};
            auto it = openY.find(k);
            if (it != openY.end()) { R q = it->second; q.y1 = y + 1; nextY[k] = q; openY.erase(it); }
            else nextY[k] = r;
        }
        for (auto& kv : openY) done.push_back(kv.second);
        openY.swap(nextY);
    }
    for (auto& kv : openY) done.push_back(kv.second);
    for (auto& r : done)
        out.push_back({(r.x0 + r.x1) * 0.5f * cs - 0.5f, (r.y0 + r.y1) * 0.5f * cs - 0.5f, (r.z0 + r.z1) * 0.5f * cs - 0.5f,
                       (r.x1 - r.x0) * cs * 0.5f, (r.y1 - r.y0) * cs * 0.5f, (r.z1 - r.z0) * cs * 0.5f});
    return out;
}

bool Game::rayObj(const Obj& o, V3 e, V3 d, float& t) const {
    if (o.kind == Kind::Floor && o.tn >= 2) return rayTerrain(o, e, d, 400.f, t);
    float tb;
    if (!rayBoxYaw(e, d, o.pos, o.scale * .5f, o.yaw, tb)) return false;  // primero la caja entera
    if (o.kind != Kind::Model || o.model.empty()) { t = tb; return true; }
    const auto& boxes = modelBoxes(o.model);
    if (boxes.empty()) { t = tb; return true; }
    float a = o.yaw * 0.0174532925f, c = std::cos(a), s = std::sin(a);
    V3 oo{e.x - o.pos.x, e.y - o.pos.y, e.z - o.pos.z};
    V3 lo{(c * oo.x - s * oo.z) / o.scale.x, oo.y / o.scale.y, (s * oo.x + c * oo.z) / o.scale.z};
    V3 ld{(c * d.x - s * d.z) / o.scale.x, d.y / o.scale.y, (s * d.x + c * d.z) / o.scale.z};
    float best = 1e30f;
    for (auto& b : boxes) {
        float tt;
        if (rayBox(lo, ld, V3{b.cx, b.cy, b.cz}, V3{b.hx, b.hy, b.hz}, tt) && tt < best) best = tt;
    }
    if (best >= 1e29f) return false;
    t = best;
    return true;
}

bool Game::blocked(V3 p) const { return blockedBox(p, 0.3f, 1.7f, -1); }

float Game::groundAt(V3 p, float hw) const {
    float best = -1e9f;
    for (auto& o : sc->objs) {
        if (!o.alive || !o.visible || o.kind != Kind::Floor || o.tn < 2 || !o.solid) continue;
        static const float S[5][2] = {{0, 0}, {1, 1}, {1, -1}, {-1, 1}, {-1, -1}};
        for (auto& q : S) best = std::max(best, terrainSurface(o, p.x + q[0] * hw, p.z + q[1] * hw));
    }
    return best;
}

bool Game::blockedBox(V3 p, float hw, float h, int skip, float stepTol) const {
    const float eps = 1e-4f;
    for (int oi = 0; oi < (int)sc->objs.size(); oi++) {
        const Obj& o = sc->objs[oi];
        if (oi == skip || !o.alive || !o.visible || !o.solid || !solidKind(o.kind)) continue;
        if (o.kind == Kind::Floor && o.tn >= 2) {  // suelo deformable: bloquea lo que quede por debajo de la superficie
            float m = -1e9f;
            static const float S[5][2] = {{0, 0}, {1, 1}, {1, -1}, {-1, 1}, {-1, -1}};
            for (auto& q : S) m = std::max(m, terrainSurface(o, p.x + q[0] * hw, p.z + q[1] * hw));
            if (m > -1e8f && p.y < m - eps - stepTol && p.y + h > o.pos.y - o.scale.y * .5f + eps) return true;
            continue;
        }
        if (p.y + h <= o.pos.y - o.scale.y * .5f + eps || p.y >= o.pos.y + o.scale.y * .5f - eps) continue;
        Quad P{p.x, p.z, hw, hw, 1.f, 0.f};
        if (!quadsOverlap(P, quadOf(o, true), eps)) continue;
        if (o.kind == Kind::Model && !o.model.empty()) {  // la colision sigue la forma del modelo
            const auto& boxes = modelBoxes(o.model);
            if (!boxes.empty()) {
                float a = o.yaw * 0.0174532925f, c = std::cos(a), s = std::sin(a);
                bool hit = false;
                for (auto& b : boxes) {
                    float bx = b.cx * o.scale.x, bz = b.cz * o.scale.z;
                    float by = o.pos.y + b.cy * o.scale.y, hy = b.hy * o.scale.y;
                    if (p.y + h <= by - hy + eps || p.y >= by + hy - eps) continue;
                    Quad B{o.pos.x + c * bx + s * bz, o.pos.z - s * bx + c * bz, b.hx * o.scale.x, b.hz * o.scale.z, c, -s};
                    if (quadsOverlap(P, B, eps)) { hit = true; break; }
                }
                if (!hit) continue;
            }
        }
        return true;
    }
    return false;
}

void Game::tap3D() {
    V3 e = eye(), d = forward();
    float best = 4.f;
    int hit = -1;
    for (size_t i = 0; i < sc->objs.size(); i++) {
        auto& o = sc->objs[i];
        if (!o.alive || !o.visible) continue;
        if (!(hasHat(o, Op::WhenTap) || hasHat(o, Op::WhenInteract) || o.ai.type != AiType::None || (o.solid && solidKind(o.kind)))) continue;
        float t;
        if (rayObj(o, e, d, t) && t < best) { best = t; hit = (int)i; }
    }
    if (hit >= 0) { fireHat(hit, Op::WhenTap); fireHat(hit, Op::WhenInteract); }
}

void Game::damageObj(int i, float dmg) {
    Obj& o = sc->objs[i];
    ObjState& st = st_[i];
    if (o.ai.type != AiType::None && !st.dead) {
        st.hp -= dmg;
        st.hurtT = 0.35f;
        if (st.hp <= 0) {
            st.dead = true;
            st.deadT = 0;
            auto it = vars.find("puntos");
            if (it != vars.end()) it->second = Val(it->second.num() + (o.ai.type == AiType::Melee ? 25 : 10));
        }
    }
    fireHat(i, Op::WhenShot);
}

void Game::hurtPlayer(float d) {
    auto it = vars.find("vida");
    vars["vida"] = Val((it != vars.end() ? it->second.num() : 100.0) - d);
    hurtFlash = 0.35f;
    int pi = sc ? playerIndex(*sc) : -1;
    if (pi >= 0 && pi < (int)st_.size()) st_[pi].hurtT = 0.4f;
    fireAll(Op::WhenPlayerHurt);
    if (onVibrate) onVibrate(0.08f);
}

void Game::spawnProj(V3 from, V3 dir, int owner) {
    float l = len(dir);
    if (l < 1e-5f) return;
    dir = dir * (1.f / l);
    Proj p;
    p.p = from;
    p.owner = owner;
    if (owner < 0) {
        const Weapon& w = proj.weapon;
        p.v = dir * w.projSpeed;
        p.life = std::max(0.3f, w.range / std::max(1.f, w.projSpeed));
        p.size = w.projSize; p.dmg = w.damage; p.shape = w.projShape;
        p.tex = w.projTex; p.model = w.projModel;
        for (int k = 0; k < 3; k++) p.col[k] = w.projColor[k];
    } else {
        const AiCfg& a = sc->objs[owner].ai;
        p.v = dir * a.projSpeed;
        p.life = 5.f;
        p.size = a.projSize; p.dmg = a.dmg;
        p.tex = a.projTex; p.model = a.projModel;
        p.shape = !a.projModel.empty() ? 2 : !a.projTex.empty() ? 1 : 0;
        for (int k = 0; k < 3; k++) p.col[k] = a.projColor[k];
    }
    if (projs.size() < 256) projs.push_back(std::move(p));
}

void Game::shoot3D() {
    V3 d = forward();
    V3 e = camMode == 0 ? eye() : V3{pos.x, pos.y + 1.4f, pos.z};
    if (proj.weapon.projSpeed > 0.5f) {  // proyectil visible
        spawnProj(e + d * 0.5f, d, -1);
        return;
    }
    float best = proj.weapon.range;  // instantaneo
    int hit = -1;
    for (size_t i = 0; i < sc->objs.size(); i++) {
        auto& o = sc->objs[i];
        if (!o.alive || !o.visible) continue;
        if (!(hasHat(o, Op::WhenShot) || o.ai.type != AiType::None || (o.solid && solidKind(o.kind)))) continue;
        float t;
        if (rayObj(o, e, d, t) && t < best) { best = t; hit = (int)i; }
    }
    if (hit >= 0) damageObj(hit, proj.weapon.damage);
}

void Game::updateProjs(float dt) {
    for (size_t k = 0; k < projs.size();) {
        Proj& p = projs[k];
        V3 step = p.v * dt;
        float L = len(step);
        bool dead = false;
        if (L > 1e-6f) {
            V3 d = step * (1.f / L);
            float best = L;
            int hit = -1;
            bool hitPlayer = false;
            for (size_t i = 0; i < sc->objs.size(); i++) {
                const Obj& o = sc->objs[i];
                if ((int)i == p.owner || !o.alive || !o.visible || o.kind == Kind::Player || o.kind == Kind::Light) continue;
                bool wall = o.solid && solidKind(o.kind);
                bool target = p.owner < 0 && (hasHat(o, Op::WhenShot) || o.ai.type != AiType::None);
                if (o.ai.type != AiType::None && (st_[i].dead || p.owner >= 0)) { if (!wall) continue; }
                if (!wall && !target) continue;
                float t;
                if (rayObj(o, p.p, d, t) && t < best) { best = t; hit = (int)i; }
            }
            if (p.owner >= 0) {  // proyectil enemigo: toca al jugador
                V3 c{pos.x, pos.y + 0.9f, pos.z}, w = c - p.p;
                float proj_t = std::max(0.f, std::min(L, w.x * d.x + w.y * d.y + w.z * d.z));
                V3 q = p.p + d * proj_t, dq = c - q;
                float dist = std::sqrt(dq.x * dq.x + (dq.y * dq.y) * 0.25f + dq.z * dq.z);
                if (dist < 0.5f + p.size && proj_t <= best) { hitPlayer = true; best = proj_t; }
            }
            if (hitPlayer) { hurtPlayer(p.dmg); dead = true; }
            else if (hit >= 0) { damageObj(hit, p.dmg); dead = true; }
            else p.p = p.p + step;
        }
        p.life -= dt;
        if (p.life <= 0) dead = true;
        if (dead) projs.erase(projs.begin() + k);
        else k++;
    }
}

void Game::updateAI(float dt) {
    for (size_t i = 0; i < sc->objs.size(); i++) {
        Obj& o = sc->objs[i];
        AiCfg& a = o.ai;
        if (a.type == AiType::None || !o.alive) continue;
        ObjState& s = st_[i];
        s.animT += dt;
        s.hurtT = std::max(0.f, s.hurtT - dt);
        s.atkCd = std::max(0.f, s.atkCd - dt);
        s.atkT = std::max(0.f, s.atkT - dt);
        s.forceT = std::max(0.f, s.forceT - dt);
        if (s.dead) {
            s.deadT += dt;
            s.anim = kHurt;
            o.transp = std::min(100.f, s.deadT / 0.8f * 100.f);
            if (s.deadT > 0.8f) o.alive = false;
            continue;
        }
        float dx = pos.x - o.pos.x, dz = pos.z - o.pos.z, d = std::sqrt(dx * dx + dz * dz);
        bool sees = d < a.sight;
        int want = kIdle;
        if (sees) {
            o.yaw = std::atan2(dx, -dz) / kRad;
            float stopAt = a.type == AiType::Melee ? a.reach * 0.8f : 7.f;
            if (d > stopAt) {
                float stp = std::min(a.speed * dt, d - stopAt);
                float feet = o.pos.y - o.scale.y * .5f;
                float hw = 0.3f * std::max(o.scale.x, o.scale.z) + 0.1f;
                V3 np = {o.pos.x + dx / d * stp, feet, o.pos.z};
                if (!blockedBox(np, hw, o.scale.y, (int)i)) o.pos.x = np.x;
                np = {o.pos.x, feet, o.pos.z + dz / d * stp};
                if (!blockedBox(np, hw, o.scale.y, (int)i)) o.pos.z = np.z;
                want = kWalk;
            }
            if (s.atkCd <= 0) {
                if (a.type == AiType::Melee && d <= a.reach) {
                    hurtPlayer(a.dmg);
                    s.atkCd = a.rate; s.atkT = 0.35f;
                } else if (a.type == AiType::Shooter && d <= a.sight) {
                    V3 from{o.pos.x, o.pos.y + o.scale.y * 0.2f, o.pos.z};
                    spawnProj(from, V3{pos.x - from.x, pos.y + 1.2f - from.y, pos.z - from.z}, (int)i);
                    s.atkCd = a.rate; s.atkT = 0.35f;
                }
            }
        }
        if (s.forceT > 0) want = s.anim;
        else if (s.hurtT > 0) want = kHurt;
        else if (s.atkT > 0) want = kAttack;
        if (want != s.anim) { s.anim = want; s.animT = 0; }
    }
}

void Game::breakApart(int i, int n) {
    Obj& o = sc->objs[i];
    bool is3 = sc->is3d;
    int per = std::max(1, (int)std::ceil(std::cbrt((double)n)));
    float sz = is3 ? std::min(o.scale.x, std::min(o.scale.y, o.scale.z)) / per : std::min(o.scale.x, o.scale.y) / per;
    auto rnd = []() { return (float)std::rand() / (float)RAND_MAX; };
    for (int k = 0; k < n && debris.size() < 200; k++) {
        Debris d;
        d.is3 = is3;
        d.p = o.pos + V3{(rnd() - .5f) * o.scale.x * .8f, (rnd() - .5f) * o.scale.y * .8f, is3 ? (rnd() - .5f) * o.scale.z * .8f : 0.f};
        float sp = is3 ? 3.f : 300.f;
        d.v = V3{(rnd() - .5f) * sp, rnd() * sp * 0.9f, is3 ? (rnd() - .5f) * sp : 0.f};
        d.size = std::max(is3 ? 0.06f : 6.f, sz * (0.6f + rnd() * 0.5f));
        d.ground = o.pos.y - o.scale.y * .5f;
        d.life = 2.0f + rnd();
        d.spin = (rnd() - .5f) * 720.f;
        for (int c = 0; c < 3; c++) d.col[c] = o.color[c];
        d.tex = o.tex;
        debris.push_back(std::move(d));
    }
    o.alive = false;
}

void Game::emitParticles(int i, int n) {
    Obj& o = sc->objs[i];
    const FxCfg& f = o.fx;
    bool is3 = sc->is3d;
    float ps = is3 ? 1.f : 100.f;
    auto rnd = []() { return (float)std::rand() / (float)RAND_MAX; };
    for (int k = 0; k < n && parts.size() < 900; k++) {
        Part p;
        p.is3 = is3;
        p.p = o.pos;
        if (is3) p.p.y += o.scale.y * 0.4f;
        float sp = f.spread * ps;
        p.v = V3{(rnd() - .5f) * 2.f * sp, f.speed * ps * (0.7f + rnd() * 0.6f), is3 ? (rnd() - .5f) * 2.f * sp : 0.f};
        p.max = p.life = std::max(0.1f, f.life * (0.75f + rnd() * 0.5f));
        p.size = f.size * ps * (0.7f + rnd() * 0.6f);
        p.grow = f.grow; p.grav = f.gravity * ps; p.a0 = f.a0; p.glow = f.glow; p.tex = f.tex;
        for (int c = 0; c < 3; c++) { p.c0[c] = f.c0[c]; p.c1[c] = f.c1[c]; }
        parts.push_back(std::move(p));
    }
}

void Game::updateParts(float dt) {
    for (size_t i = 0; i < sc->objs.size() && i < st_.size(); i++) {
        Obj& o = sc->objs[i];
        if (!o.fx.on || !o.alive || !o.visible) continue;
        st_[i].fxAcc += o.fx.rate * dt;
        int n = (int)st_[i].fxAcc;
        st_[i].fxAcc -= n;
        if (n > 0) emitParticles((int)i, std::min(n, 20));
    }
    for (size_t k = 0; k < parts.size();) {
        Part& p = parts[k];
        p.life -= dt;
        p.v.y -= p.grav * dt;  // gravedad positiva = cae, negativa = sube
        p.p = p.p + p.v * dt;
        if (p.life <= 0) parts.erase(parts.begin() + k);
        else k++;
    }
}

void Game::updateDebris(float dt) {
    for (size_t k = 0; k < debris.size();) {
        Debris& d = debris[k];
        d.life -= dt;
        d.ang += d.spin * dt;
        if (d.is3) {
            d.v.y -= 20.f * dt;
            d.p = d.p + d.v * dt;
            if (d.p.y < d.ground + d.size * .5f) {
                d.p.y = d.ground + d.size * .5f;
                d.v.y = std::fabs(d.v.y) > 1.5f ? -d.v.y * 0.3f : 0.f;
                d.v.x *= 0.6f; d.v.z *= 0.6f; d.spin *= 0.5f;
            }
        } else {
            d.v.y += gravY_ * 100.f * dt;
            d.p = d.p + d.v * dt;
        }
        if (d.life <= 0) debris.erase(debris.begin() + k);
        else k++;
    }
}

Game::ObjVis Game::vis(int i) const {
    ObjVis v;
    if (!sc || i < 0 || i >= (int)sc->objs.size() || i >= (int)st_.size()) return v;
    const Obj& o = sc->objs[i];
    const ObjState& s = st_[i];
    if (o.ai.type == AiType::None && o.kind != Kind::Player) return v;
    v.billboard = o.ai.sprite;
    const AnimState& a = o.ai.anim[s.anim];
    if (!a.frames.empty()) {
        int k = (int)std::floor(s.animT * std::max(0.5f, a.fps)) % (int)a.frames.size();
        const std::string& f = a.frames[k];
        if (f.size() > 5 && f.substr(f.size() - 5) == ".fmdl") v.model = f;
        else v.tex = f;
    }
    float t = s.animT;
    v.bob = std::sin(t * 8.f) * a.bob;
    v.sway = std::sin(t * 6.f) * a.sway;
    v.lunge = std::sin(t * 10.f) * a.lunge;
    v.squash = 1.f + std::sin(t * 10.f) * a.squash * 0.2f;
    v.clip = a.clip;
    return v;
}

void Game::applyCam() {
    if (!sc) return;
    V3 head{pos.x, pos.y + 1.6f, pos.z};
    if (camMode == kShoulder) {
        V3 f = forward(), r{std::cos(yaw), 0, std::sin(yaw)};
        V3 want = head - f * 2.8f + r * 0.7f + V3{0, 0.3f, 0};
        V3 dir = want - head;
        float L = len(dir), best = L;
        V3 dn = dir * (1.f / L);
        for (auto& o : sc->objs) {
            if (!o.alive || !o.visible || !o.solid || !solidKind(o.kind)) continue;
            float t;
            if (rayObj(o, head, dn, t) && t < best) best = t;
        }
        camEye = head + dn * std::max(0.4f, std::min(L, best - 0.2f));
        camFwd = f;
    } else if (camMode == kFixed) {
        camEye = sc->cam;
        V3 tgt{pos.x, pos.y + 1.2f, pos.z};
        V3 d = tgt - camEye;
        camFwd = len(d) > 1e-4f ? norm(d) : V3{0, 0, -1};
    } else {
        camEye = head;
        camFwd = forward();
    }
}

void Game::tap2D(float x, float y) {
    float wx = (x - .5f) * stageW(), wy = (.5f - y) * kView2DHeight;
    int best = -1, bestLayer = -1000000;
    for (int i = 0; i < (int)sc->objs.size(); i++) {
        auto& o = sc->objs[i];
        if (!o.alive || !o.visible) continue;
        float ra = -(o.yaw - 90.f) * 0.0174532925f, cs = std::cos(ra), sn = std::sin(ra);
        float ddx = wx - o.pos.x, ddy = wy - o.pos.y;
        float lx = cs * ddx + sn * ddy, ly = -sn * ddx + cs * ddy;  // el toque se mide girado con el objeto
        if (!o.bg && !(std::fabs(lx) <= o.scale.x * .5f && std::fabs(ly) <= o.scale.y * .5f)) continue;
        int layer = o.bg ? -1000000 + 1 : o.layer;
        if (layer >= bestLayer && (hasHat(o, Op::WhenTap) || hasHat(o, Op::WhenInteract))) { best = i; bestLayer = layer; }
    }
    if (best >= 0) { fireHat(best, Op::WhenTap); fireHat(best, Op::WhenInteract); }
}

// ---------------------------------------------------------------- fisica sencilla
void Game::physics(float dt) {
    bool is3 = sc->is3d;
    float ps = is3 ? 1.f : 100.f;
    for (size_t i = 0; i < sc->objs.size(); i++) {
        Obj& o = sc->objs[i];
        ObjState& s = st_[i];
        if (!o.alive) continue;
        if (o.phys == Phys::Dynamic) {
            s.vel.x += gravX_ * ps * dt;
            s.vel.y += gravY_ * ps * dt;
            for (int axis = 0; axis < (is3 ? 3 : 2); axis++) {
                float* p = axis == 0 ? &o.pos.x : axis == 1 ? &o.pos.y : &o.pos.z;
                float* v = axis == 0 ? &s.vel.x : axis == 1 ? &s.vel.y : &s.vel.z;
                float old = *p;
                *p += *v * dt;
                for (size_t j = 0; j < sc->objs.size(); j++) {
                    if (j == i) continue;
                    const Obj& q = sc->objs[j];
                    bool solidWorld = is3 && q.solid && solidKind(q.kind);
                    if (!q.alive || !q.visible || (q.phys == Phys::None && !solidWorld)) continue;
                    if (!overlap(o, q)) continue;
                    *p = old;
                    float e = (o.bounce + q.bounce) * 0.5f;
                    *v = -*v * e;
                    if (std::fabs(*v) < 2.f * ps * 0.05f) *v = 0;
                    float fr = std::min(1.f, (o.friction + q.friction) * 0.5f) * dt * 10.f;
                    if (axis == 1) { s.vel.x *= (1.f - fr); s.vel.z *= (1.f - fr); }
                    else s.vel.y *= (1.f - fr);
                    break;
                }
            }
            if (!is3 && o.pos.y < -50000) o.alive = false;
        }
        if (s.spin != 0) o.yaw += s.spin * dt;
    }
}

void Game::checkConditions() {
    for (size_t i = 0; i < sc->objs.size(); i++) {
        Obj& o = sc->objs[i];
        if (!o.alive) continue;
        for (int h : cmp_[i].hats) {
            const Block& b = o.blocks[h];
            if (b.op == Op::WhenTrue) {
                bool now = eval(b.f[0], (int)i).truthy();
                if (now && !st_[i].hatState[h]) startScript((int)i, h);
                st_[i].hatState[h] = now;
            } else if (b.op == Op::WhenCollide) {
                bool now = false;
                std::string k = normName(b.t);
                if (sc->is3d && (k == "jugador" || k == "player")) {
                    V3 d = o.pos - V3{pos.x, pos.y + 0.85f, pos.z};
                    now = std::fabs(d.x) < o.scale.x * .5f + 0.3f && std::fabs(d.y) < o.scale.y * .5f + 0.85f &&
                          std::fabs(d.z) < o.scale.z * .5f + 0.3f;
                } else {
                    int j = findObj(b.t);
                    now = j >= 0 && j != (int)i && sc->objs[j].alive && sc->objs[j].visible && overlap(o, sc->objs[j]);
                }
                if (now && !st_[i].hatState[h]) startScript((int)i, h);
                st_[i].hatState[h] = now;
            }
        }
    }
}

// ---------------------------------------------------------------- bucle principal
void Game::update(float dt, const Input& in, float aspect) {
    if (aspect > 0.1f) aspect_ = aspect;
    in_ = in;
    if (!pending_.empty()) {
        std::string n = pending_;
        pending_.clear();
        enterScene(n);
    }
    if (!sc) return;
    dt = std::min(dt, 0.05f);
    if (dt > 0) fps_ = fps_ * 0.9f + (1.f / dt) * 0.1f;
    time += dt;
    if (sayT > 0) sayT -= dt;

    if (sc->is3d) {
        if (camMode != kFixed) {
            yaw += in.lookX;
            pitch = std::max(-1.5f, std::min(1.5f, pitch - in.lookY));
        } else {
            pitch = 0;
        }
        V3 f{std::sin(yaw), 0, -std::cos(yaw)}, r{std::cos(yaw), 0, std::sin(yaw)};
        if (camMode == kFixed) {  // se camina segun lo que ve la camara
            float fl = std::sqrt(camFwd.x * camFwd.x + camFwd.z * camFwd.z);
            if (fl > 1e-4f) { f = {camFwd.x / fl, 0, camFwd.z / fl}; r = {-f.z, 0, f.x}; }
        }
        V3 w = f * in.moveY + r * in.moveX;
        float l = len(w);
        if (l > 1) w = w * (1.f / l);
        if (camMode == kFixed && l > 0.1f) yaw = std::atan2(w.x, -w.z);
        bodyYaw = yaw;
        vel.x = w.x * walkSpeed;
        vel.z = w.z * walkSpeed;
        vel.y -= 20.f * dt;
        if (in.jump && ground) vel.y = jumpPow;

        V3 p = pos;
        p.x += vel.x * dt; if (blockedBox(p, 0.3f, 1.7f, -1, 0.55f)) p.x = pos.x;
        p.z += vel.z * dt; if (blockedBox(p, 0.3f, 1.7f, -1, 0.55f)) p.z = pos.z;
        {   // suelo deformable: sube y baja laderas suaves pegado al terreno
            float gy = groundAt(p, 0.2f);
            if (gy > -1e8f) {
                if (gy > p.y && gy - p.y <= 0.6f) { p.y = gy; if (vel.y < 0) vel.y = 0; }
                else if (ground && vel.y <= 0 && gy < p.y && p.y - gy <= 0.35f) p.y = gy;
            }
        }
        V3 q = p;
        q.y += vel.y * dt;
        ground = false;
        if (blocked(q)) { if (vel.y < 0) ground = true; vel.y = 0; }
        else p.y = q.y;
        pos = p;
        if (pos.y < -60) { pos = sc->start; vel = V3(); }
        hurtFlash = std::max(0.f, hurtFlash - dt);
        {   // animacion del jugador (quieto, caminar, atacar, recibir dano)
            int pi2 = playerIndex(*sc);
            if (pi2 >= 0 && pi2 < (int)st_.size()) {
                ObjState& ps = st_[pi2];
                ps.animT += dt;
                ps.atkT = std::max(0.f, ps.atkT - dt);
                ps.hurtT = std::max(0.f, ps.hurtT - dt);
                int want = ps.hurtT > 0 ? kHurt : ps.atkT > 0 ? kAttack : (std::fabs(vel.x) + std::fabs(vel.z) > 0.3f ? kWalk : kIdle);
                if (want != ps.anim) { ps.anim = want; ps.animT = 0; }
            }
        }
        updateAI(dt);
        updateProjs(dt);
        applyCam();

        for (size_t i = 0; i < sc->objs.size(); i++) {  // "Cuando el jugador se acerque"
            auto& o = sc->objs[i];
            if (!o.alive || !hasHat(o, Op::WhenNear)) continue;
            float dx = o.pos.x - pos.x, dz = o.pos.z - pos.z, dy = o.pos.y - (pos.y + 1.f);
            bool isNear = std::sqrt(dx * dx + dz * dz) < 1.2f + .5f * std::max(o.scale.x, o.scale.z) && std::fabs(dy) < 3.f;
            if (isNear && !near_[i]) fireHat((int)i, Op::WhenNear);
            near_[i] = isNear;
        }
        if (in.tap) tap3D();

        shootCd = std::max(0.f, shootCd - dt);
        recoil = std::max(0.f, recoil - dt * 6.f);
        flash = std::max(0.f, flash - dt);
        if (in.shoot && shootCd <= 0 && proj.weapon.enabled) {
            shootCd = proj.weapon.rate;
            recoil = 1.f;
            flash = 0.07f;
            if (onSound) onSound("disparo");
            shoot3D();
            fireAll(Op::WhenPlayerShoots);
            { int pi2 = playerIndex(*sc); if (pi2 >= 0 && pi2 < (int)st_.size()) st_[pi2].atkT = 0.3f; }
        }
    } else if (in.tap) {
        tap2D(in.tapX, in.tapY);
    }

    physics(dt);
    checkConditions();
    for (size_t i = 0; i < runners_.size(); i++) step(runners_[i], dt);
    runners_.erase(std::remove_if(runners_.begin(), runners_.end(), [](const Runner& r) { return r.done; }), runners_.end());
    eventsV6(dt, in);
    // Clones pedidos durante este cuadro (se crean aqui para no invalidar referencias a los objetos)
    for (int src : pendingClones_) {
        if (src < 0 || src >= (int)sc->objs.size() || sc->objs.size() >= 600) continue;
        Obj c = sc->objs[src];
        c.clone = true;
        c.alive = true;
        c.name += "_clon";
        ObjState ns = st_[src];
        sc->objs.push_back(std::move(c));
        int idx = (int)sc->objs.size() - 1;
        base_.push_back(base_[src]);
        near_.push_back(0);
        moving_.push_back(0);
        last_.push_back(sc->objs[idx].pos);
        cmp_.push_back(cmp_[src]);
        st_.push_back(std::move(ns));
        st_[idx].hatState.assign(sc->objs[idx].blocks.size(), 0);
        fireHat(idx, Op::WhenCloneStart);
    }
    pendingClones_.clear();
    updateDebris(dt);
    updateParts(dt);
    shakeT = std::max(0.f, shakeT - dt);
}

// ---------------------------------------------------------------- interprete de bloques
static float wrap360(float d) {
    d = std::fmod(d, 360.f);
    if (d > 180.f) d -= 360.f;
    if (d <= -180.f) d += 360.f;
    return d;
}

void Game::step(Runner& r, float dt) {
    Obj& o = sc->objs[r.obj];
    ObjState& s = st_[r.obj];
    const auto& B = o.blocks;
    const auto& M = cmp_[r.obj].match;
    int self = r.obj;

    if (!r.waitIds.empty()) {
        r.waitIds.erase(std::remove_if(r.waitIds.begin(), r.waitIds.end(), [&](int id) {
            for (auto& q : runners_) if (q.id == id && !q.done) return false;
            return true;
        }), r.waitIds.end());
        if (!r.waitIds.empty()) return;
    }
    if (r.gT > 0) {
        r.gE += dt;
        float t = std::min(1.f, r.gE / r.gT);
        o.pos = r.gFrom + (r.gTo - r.gFrom) * t;
        if (r.gE < r.gT) return;
        r.gT = 0;
    }
    if (r.wait > 0) {
        r.wait -= dt;
        if (r.wait > 0) return;
    }
    bool is3 = sc->is3d;
    int budget = 512;
    while (budget-- > 0) {
        if (r.pc >= r.end) { r.done = true; return; }
        int idx = r.pc;
        const Block& b = B[r.pc++];
        auto F = [&](int k) { return (float)num(b.f[k], self); };
        switch (b.op) {
            // eventos: nunca se ejecutan dentro de un guion
            case Op::WhenStart: case Op::WhenTap: case Op::WhenReceive: case Op::WhenCollide: case Op::WhenTrue:
            case Op::WhenShot: case Op::WhenNear: case Op::WhenInteract: case Op::WhenCloneStart:
            case Op::WhenPlayerShoots: case Op::WhenButton: case Op::WhenObjMoves: case Op::WhenPlayerMoves: case Op::WhenPlayerHurt: case Op::WhenPlayerJumps: break;

            // control
            case Op::Wait: r.wait = std::max(0.f, F(0)); if (r.wait > 0) return; break;
            case Op::Broadcast: broadcast(b.t, nullptr); break;
            case Op::BroadcastWait: {
                std::vector<int> ids;
                broadcast(b.t, &ids);
                r.waitIds = ids;
                if (!ids.empty()) return;
                break;
            }
            case Op::Forever: r.loops.push_back({idx, -1}); break;
            case Op::Repeat: {
                int n = (int)F(0);
                if (n <= 0) r.pc = M[idx] + 1;
                else r.loops.push_back({idx, n});
                break;
            }
            case Op::LoopEnd:
                if (!r.loops.empty()) {
                    Loop& l = r.loops.back();
                    if (l.remaining == -1 || --l.remaining > 0) { r.pc = l.start + 1; return; }
                    r.loops.pop_back();
                }
                break;
            case Op::Note: break;
            case Op::If:
                if (!eval(b.f[0], self).truthy()) r.pc = M[idx] + 1;
                break;
            case Op::Else: r.pc = M[idx] + 1; break;
            case Op::EndIf: break;
            case Op::StartScene: pending_ = b.t; r.done = true; return;

            // movimiento
            case Op::PlaceAt: o.pos.x = F(0); o.pos.y = F(1); break;
            case Op::SetX: o.pos.x = F(0); break;
            case Op::SetY: o.pos.y = F(0); break;
            case Op::ChangeX: o.pos.x += F(0); break;
            case Op::ChangeY: o.pos.y += F(0); break;
            case Op::PlaceAt3: o.pos = {F(0), F(1), F(2)}; break;
            case Op::SetZ: o.pos.z = F(0); break;
            case Op::ChangeZ: o.pos.z += F(0); break;
            case Op::Move: {
                float st = F(0), a = o.yaw * kRad;
                o.pos.x += st * std::sin(a);
                if (is3) o.pos.z -= st * std::cos(a); else o.pos.y += st * std::cos(a);
                break;
            }
            case Op::TurnLeft: o.yaw = wrap360(o.yaw - F(0)); break;
            case Op::TurnRight: o.yaw = wrap360(o.yaw + F(0)); break;
            case Op::PointDir: o.yaw = wrap360(F(0)); break;
            case Op::SetSolid: o.solid = F(0) != 0; break;
            case Op::TeleportPlayer: pos = {F(0), F(1), F(2)}; vel = V3(); break;
            case Op::MoveToPlayer: {
                V3 d{pos.x - o.pos.x, 0, pos.z - o.pos.z};
                float l = std::sqrt(d.x * d.x + d.z * d.z);
                if (l > 1e-4f) { float st = std::min(F(0), l); o.pos.x += d.x / l * st; o.pos.z += d.z / l * st; }
                break;
            }
            case Op::PointTowards: {
                std::string tk = normName(b.t);
                if (is3 && (tk == "jugador" || tk == "player")) {
                    o.yaw = std::atan2(pos.x - o.pos.x, -(pos.z - o.pos.z)) / kRad;
                    break;
                }
                int j = findObj(b.t);
                if (j >= 0) {
                    V3 d = sc->objs[j].pos - o.pos;
                    o.yaw = std::atan2(d.x, is3 ? -d.z : d.y) / kRad;
                }
                break;
            }
            case Op::BounceEdge:
                if (!is3) {
                    float hw = stageW() * .5f, hh = kView2DHeight * .5f;
                    if (o.pos.x + o.scale.x * .5f > hw) { o.pos.x = hw - o.scale.x * .5f; o.yaw = wrap360(-o.yaw); }
                    else if (o.pos.x - o.scale.x * .5f < -hw) { o.pos.x = -hw + o.scale.x * .5f; o.yaw = wrap360(-o.yaw); }
                    if (o.pos.y + o.scale.y * .5f > hh) { o.pos.y = hh - o.scale.y * .5f; o.yaw = wrap360(180.f - o.yaw); }
                    else if (o.pos.y - o.scale.y * .5f < -hh) { o.pos.y = -hh + o.scale.y * .5f; o.yaw = wrap360(180.f - o.yaw); }
                }
                break;
            case Op::GlideTo: {
                float secs = F(0);
                V3 to{F(1), F(2), o.pos.z};
                if (secs <= 0) o.pos = to;
                else { r.gFrom = o.pos; r.gTo = to; r.gT = secs; r.gE = 0; return; }
                break;
            }
            case Op::GoBack: o.layer -= (int)F(0); break;
            case Op::GoFront: {
                int mx = o.layer;
                for (auto& q : sc->objs) if (!q.bg) mx = std::max(mx, q.layer);
                o.layer = mx + 1;
                break;
            }
            case Op::Vibrate: if (onVibrate) onVibrate(F(0)); break;
            case Op::PhysDynamic: o.phys = Phys::Dynamic; break;
            case Op::PhysStatic: o.phys = Phys::Static; break;
            case Op::PhysNone: o.phys = Phys::None; s.vel = V3(); break;
            case Op::SetForce: s.vel.x = F(0); s.vel.y = F(1); break;
            case Op::SpinLeft: s.spin = -F(0); break;
            case Op::SpinRight: s.spin = F(0); break;
            case Op::SetGravity: gravX_ = F(0); gravY_ = F(1); break;
            case Op::SetMass: o.mass = std::max(0.f, F(0)); break;
            case Op::SetBounce: o.bounce = std::max(0.f, F(0) / 100.f); break;
            case Op::SetFriction: o.friction = std::max(0.f, F(0) / 100.f); break;

            // sonido
            case Op::StartSound: if (onSound) onSound(b.t); break;
            case Op::StopSounds: if (onStopSounds) onStopSounds(); if (onMusic) onMusic("", false); break;
            case Op::SetVolume: volume = std::max(0.f, std::min(100.f, F(0))); if (onVolume) onVolume(volume / 100.f); break;
            case Op::ChangeVolume: volume = std::max(0.f, std::min(100.f, volume + F(0))); if (onVolume) onVolume(volume / 100.f); break;
            case Op::Speak: {
                std::string t = eval(b.f[0], self).txt();
                say = t; sayT = 3.f;
                if (onSpeak) onSpeak(t);
                break;
            }
            case Op::Music: if (onMusic) onMusic(b.t, true); break;

            // apariencia
            case Op::NextLook:
                if (!o.looks.empty()) { s.look = (s.look + 1) % (int)o.looks.size(); o.tex = o.looks[s.look]; }
                break;
            case Op::SetLook: {
                auto it = std::find(o.looks.begin(), o.looks.end(), b.t);
                if (it != o.looks.end()) { s.look = (int)(it - o.looks.begin()); o.tex = *it; }
                break;
            }
            case Op::SetSize: s.sizePct = std::max(0.f, F(0)); o.scale = base_[self] * (s.sizePct / 100.f); break;
            case Op::ChangeSize: s.sizePct = std::max(0.f, s.sizePct + F(0)); o.scale = base_[self] * (s.sizePct / 100.f); break;
            case Op::Show: o.visible = true; break;
            case Op::Hide: o.visible = false; break;
            case Op::SetTransp: o.transp = std::max(0.f, std::min(100.f, F(0))); break;
            case Op::ChangeTransp: o.transp = std::max(0.f, std::min(100.f, o.transp + F(0))); break;
            case Op::SetBright: o.bright = std::max(0.f, F(0)); break;
            case Op::ChangeBright: o.bright = std::max(0.f, o.bright + F(0)); break;
            case Op::ClearFx: o.transp = 0; o.bright = 100; o.hue = 0; break;
            case Op::Flash: if (onFlash) onFlash(F(0) != 0); break;
            case Op::ChangeColor: o.hue = std::fmod(o.hue + F(0), 200.f); if (o.hue < 0) o.hue += 200.f; break;
            case Op::Say: say = eval(b.f[0], self).txt(); sayT = 3.f; break;
            case Op::Destroy: o.alive = false; break;

            // datos
            case Op::SetVar: setVar(b.t, eval(b.f[0], self), self); break;
            case Op::ChangeVar: setVar(b.t, Val(getVar(b.t, self).num() + num(b.f[0], self)), self); break;
            case Op::ShowVar: shown[b.t] = {F(0), F(1)}; break;
            case Op::HideVar: shown.erase(b.t); break;
            case Op::PlaySoundWait: {
                if (onSound) onSound(b.t);
                float len = soundLen ? soundLen(b.t) : 0.f;
                if (len > 0.f) { r.wait = len; return; }
                break;
            }
            case Op::SetCamera: {
                std::string k = normName(b.t);
                camMode = k.find("hombro") != std::string::npos ? kShoulder : k.find("fij") != std::string::npos ? kFixed : kFirstPerson;
                if (camMode != kFixed) yaw = bodyYaw;
                applyCam();
                break;
            }
            case Op::WaitUntil:
                if (!eval(b.f[0], self).truthy()) { r.pc = idx; return; }
                break;
            case Op::StopScript: r.done = true; return;
            case Op::ShootPlayer:
                if (is3) {
                    V3 from{o.pos.x, o.pos.y + o.scale.y * 0.2f, o.pos.z};
                    spawnProj(from, V3{pos.x - from.x, pos.y + 1.2f - from.y, pos.z - from.z}, self);
                }
                break;
            case Op::HurtPlayer: hurtPlayer(F(0)); break;
            case Op::SetSpeed: walkSpeed = std::max(0.f, F(0)); break;
            case Op::SetJump: jumpPow = std::max(0.f, F(0)); break;
            case Op::PlayAnim: {
                std::string k = normName(b.t);
                int a = (k.find("camin") != std::string::npos || k == "walk") ? kWalk
                      : (k.find("atac") != std::string::npos || k == "attack") ? kAttack
                      : (k.find("da") != std::string::npos || k == "hurt") ? kHurt : kIdle;
                s.anim = a; s.animT = 0; s.forceT = 1.0f;
                break;
            }
            case Op::MoveRandom: {
                float dist = F(0) * (float)std::rand() / (float)RAND_MAX, ang = 6.2831853f * (float)std::rand() / (float)RAND_MAX;
                o.pos.x += dist * std::cos(ang);
                if (is3) o.pos.z += dist * std::sin(ang); else o.pos.y += dist * std::sin(ang);
                break;
            }
            case Op::CreateClone: if (pendingClones_.size() < 8) pendingClones_.push_back(self); break;
            case Op::DeleteClone: if (o.clone) { o.alive = false; r.done = true; return; } break;
            case Op::BreakApart: breakApart(self, std::max(1, std::min(40, (int)F(0)))); r.done = true; return;
            case Op::PlayClip: s.clip = b.t; break;
            case Op::StopClip: s.clip.clear(); s.curClip.clear(); break;
            case Op::GoToPlayer: {
                V3 to = o.pos;
                if (is3) { to.x = pos.x; to.z = pos.z; }
                else {
                    int j = findObj("Jugador");
                    if (j >= 0) { to.x = sc->objs[j].pos.x; to.y = sc->objs[j].pos.y; }
                    else { to.x = (in_.tapX - 0.5f) * stageW(); to.y = (0.5f - in_.tapY) * kView2DHeight; }
                }
                float secs = F(0);
                if (secs <= 0) o.pos = to;
                else { r.gFrom = o.pos; r.gTo = to; r.gT = secs; r.gE = 0; return; }
                break;
            }
            case Op::GoToObject: {
                int j = findObj(b.t);
                if (j >= 0) { o.pos.x = sc->objs[j].pos.x; o.pos.y = sc->objs[j].pos.y; if (is3) o.pos.z = sc->objs[j].pos.z; }
                break;
            }
            case Op::MoveTowards: {
                int j = findObj(b.t);
                if (j < 0) break;
                V3 d = sc->objs[j].pos - o.pos;
                if (!is3) d.z = 0;
                float l = len(d);
                if (l > 1e-4f) { float st = std::min(F(0), l); o.pos = o.pos + d * (st / l); }
                break;
            }
            case Op::ShakeScreen: shakeT = std::max(shakeT, F(0)); shakeAmp = is3 ? 0.12f : 14.f; break;
            case Op::StopAll:
                for (auto& q : runners_) q.done = true;
                return;
            case Op::SetFx: o.fx.on = normName(b.t).find("apag") == std::string::npos; break;
            case Op::BurstFx: emitParticles(self, std::max(1, std::min(200, (int)F(0)))); break;
            case Op::SetScreenFx: {
                std::string k = normName(b.t);
                int id = k.find("vhs") != std::string::npos ? 1 : k.find("video") != std::string::npos ? 2
                       : k.find("noct") != std::string::npos ? 3 : k.find("vieja") != std::string::npos ? 4 : 0;
                sfxPreset(sc->sfx, id);
                break;
            }
            case Op::Count: break;
        }
    }
}

}  // namespace forge

namespace forge {

// Busca el esqueleto de un objeto: el que eligio, o el primero guardado que pertenezca a ese modelo.
Game::RigRT* Game::rigRT(int i, const std::string& model) {
    if (!sc || i < 0 || i >= (int)sc->objs.size() || model.empty()) return nullptr;
    const Obj& o = sc->objs[i];
    std::string rn = o.rig;
    if (rn.empty()) {
        for (auto& a : proj.assets) {
            const std::string& n = a.first;
            if (n.size() > 6 && n.compare(n.size() - 6, 6, ".fanim") == 0) {
                auto it = rigs_.find(n + "|" + model);
                if (it != rigs_.end() && it->second.ok) { rn = n; break; }
                Rig r;
                if (rigRead(std::string(a.second.begin(), a.second.end()), r) && r.model == model) { rn = n; break; }
            }
        }
    }
    if (rn.empty()) return nullptr;
    std::string key = rn + "|" + model;
    auto it = rigs_.find(key);
    if (it != rigs_.end()) return it->second.ok ? &it->second : nullptr;
    RigRT& rt = rigs_[key];
    auto ra = proj.assets.find(rn), ma = proj.assets.find(model);
    ModelData md;
    if (ra == proj.assets.end() || ma == proj.assets.end() || !rigRead(std::string(ra->second.begin(), ra->second.end()), rt.rig) ||
        rt.rig.bones.empty() || !modelRead(ma->second.data(), ma->second.size(), md))
        return nullptr;
    rt.model = model;
    rt.rest = md.v;
    rt.idx = md.idx;
    rigComputeWeights(rt.rig, rt.rest, rt.w);
    rt.ok = true;
    return &rt;
}

const Rig* Game::rigOf(int i, const std::string& model) const {
    RigRT* r = const_cast<Game*>(this)->rigRT(i, model);
    return r ? &r->rig : nullptr;
}

bool Game::skinVerts(int i, const std::string& model, const std::vector<float>*& verts, const std::vector<uint32_t>*& idx, unsigned long long& sig) {
    if (!sc || i < 0 || i >= (int)sc->objs.size() || i >= (int)st_.size() || model.empty()) return false;
    const Obj& o = sc->objs[i];
    ObjState& s = st_[i];
    std::string want = !s.clip.empty() ? s.clip : vis(i).clip;
    if (want.empty()) want = o.clip;
    if (want.empty()) return false;
    RigRT* rt = rigRT(i, model);
    if (!rt) return false;
    int ci = rigFindClip(rt->rig, want);
    if (ci < 0) return false;
    if (s.curClip != want) { s.curClip = want; s.clipStart = time; }
    RigPose p = rigSample(rt->rig, rt->rig.clips[ci], time - s.clipStart);
    std::vector<float> mats;
    rigSkinMatrices(rt->rig, p, mats);
    rigSkin(rt->rest, rt->w, mats, rt->out);
    verts = &rt->out;
    idx = &rt->idx;
    sig = (unsigned long long)(time * 90.f) * 2654435761ULL + (unsigned long long)i * 40503ULL + std::hash<std::string>()(want + model);
    return true;
}

}  // namespace forge
