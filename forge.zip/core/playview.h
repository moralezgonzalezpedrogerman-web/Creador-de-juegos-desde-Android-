#pragma once
#include "audio.h"
#include "controls.h"
#include "game.h"
#include "hud.h"
#include <functional>

namespace forge {

class Renderer;

// Un juego en marcha: logica + dibujo + botones + audio. Lo usan los runtimes y el modo "Jugar" del editor.
class PlayView {
public:
    Game game;
    Hud hud;
    PlayControls ctl;
    Audio* audio = nullptr;
    bool showButtons = true;
    bool splash = false;     // juegos exportados: muestra primero la pantalla de inicio
    float splashT = -1.f;    // >= 0 mientras se muestra
    // Servicios del dispositivo (la plataforma los rellena; pueden quedar vacios)
    std::function<void(float)> onVibrate;
    std::function<void(const std::string&)> onSpeak;
    std::function<void(bool)> onFlash;

    void start(Project p);
    // Requiere un frame de ImGui activo (el HUD se dibuja con ImGui). r puede ser null en pruebas.
    void frame(Renderer* r, int w, int h, float dt, const Input* direct = nullptr);
};

}  // namespace forge
