#pragma once
#include "vec.h"
#include <cstdint>
#include <string>
#include <vector>

namespace forge {

// Esqueleto sencillo para deformar modelos 3D: huesos (palos y puntos) + animaciones por poses.
// Las posiciones estan en el espacio normalizado del modelo (cubo unitario centrado en 0).
struct Quat { float x = 0, y = 0, z = 0, w = 1; };
Quat qMul(Quat a, Quat b);
Quat qNorm(Quat a);
Quat qInv(Quat a);
Quat qSlerp(Quat a, Quat b, float t);
Quat qAxisAngle(V3 axis, float rad);
Quat qFromEulerDeg(float x, float y, float z);
void qToEulerDeg(Quat q, float& x, float& y, float& z);
V3 qRotate(Quat q, V3 v);

struct RigBone {
    std::string name;
    int parent = -1;
    V3 head;                 // posicion en reposo (la "articulacion")
};
struct RigPose {
    std::vector<Quat> rot;   // giro de cada hueso respecto a su posicion de reposo
    V3 root;                 // desplazamiento de todo el cuerpo
};
struct RigKey { float t = 0; RigPose pose; };
struct RigClip {
    std::string name = "animacion";
    float len = 1.f;
    bool loop = true;
    std::vector<RigKey> keys;  // ordenadas por tiempo
};
struct Rig {
    std::string model;        // asset .fmdl al que pertenece
    float stiff = 3.f;        // que tan "duro" es el reparto de pesos (mas alto = juntas mas marcadas)
    std::vector<RigBone> bones;
    std::vector<RigClip> clips;
};

std::string rigWrite(const Rig& r);
bool rigRead(const std::string& text, Rig& r);

RigPose rigRestPose(const Rig& r);
RigPose rigSample(const Rig& r, const RigClip& c, float t);
int rigFindClip(const Rig& r, const std::string& name);
int rigFindBone(const Rig& r, const std::string& name);

// Pesos por hueso: 4 por vertice (indices y pesos), calculados por cercania a cada palo del esqueleto.
struct RigWeights {
    std::vector<uint8_t> bi;
    std::vector<float> bw;
};
void rigComputeWeights(const Rig& r, const std::vector<float>& verts8, RigWeights& w);
// Matrices de piel 3x4 (12 floats por hueso, por filas) para una pose.
void rigSkinMatrices(const Rig& r, const RigPose& p, std::vector<float>& mats);
// Deforma los vertices (8 floats: pos, normal, uv). 'out' queda del mismo tamano.
void rigSkin(const std::vector<float>& rest8, const RigWeights& w, const std::vector<float>& mats, std::vector<float>& out8);
// Giro mundial de cada hueso para una pose.
void rigWorldRots(const Rig& r, const RigPose& p, std::vector<Quat>& out);
// Posiciones de las articulaciones ya con la pose puesta (para dibujar el esqueleto).
void rigJointPositions(const Rig& r, const RigPose& p, std::vector<V3>& out);

}  // namespace forge
