#pragma once
#include "scene.h"
#include <memory>
#include <string>
#include <vector>

namespace forge {

// Audio con miniaudio: mp3, wav y flac. Los sonidos se leen desde los assets en memoria.
class Audio {
public:
    ~Audio() { shutdown(); }
    bool init(bool noDevice = false);  // noDevice: solo para pruebas
    void shutdown();
    void setAssets(const Files& f);    // (re)registra los archivos de audio
    void play(const std::string& name);   // efecto; admite el nombre sin extension
    void music(const std::string& name);  // en bucle
    void stopMusic();
    void pause();                         // app en segundo plano: calla todo
    void resume();
    void stopAll();                       // efectos y musica
    void setVolume(float v);              // 0..1, volumen general
    bool has(const std::string& name) const;
    float length(const std::string& name);  // duracion en segundos (0 si no se conoce)
    static bool isAudioFile(const std::string& name);

private:
    struct Impl;
    Impl* p_ = nullptr;
    std::vector<std::shared_ptr<std::vector<uint8_t>>> defData_;  // sonidos por defecto (deben vivir mientras suenan)
    std::string resolve(const std::string& name) const;
};

}  // namespace forge
