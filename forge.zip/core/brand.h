#pragma once
struct ImDrawList;

namespace forge {

class Renderer;

constexpr float kSplashSeconds = 2.8f;

// Imagenes de marca incrustadas: 0 logo, 1 pasillo, 2 bosque. Devuelve el id de textura GL (0 si no hay).
unsigned brandTexture(Renderer* r, int which, int* w = nullptr, int* h = nullptr);
// Pantalla de inicio (fondo blanco con el logo y el nombre). t = segundos desde que empezo.
void drawSplash(ImDrawList* dl, Renderer* r, int w, int h, float t);
// Fondo del menu de proyectos: imagen a pantalla completa con velo oscuro. which = 1 o 2.
void drawMenuBackdrop(ImDrawList* dl, Renderer* r, int w, int h, int which, float t);

}  // namespace forge
