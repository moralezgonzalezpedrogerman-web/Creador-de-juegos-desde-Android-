#include "playview.h"
#include "imgui.h"
#include "renderer.h"
#include "brand.h"

namespace forge {

void PlayView::start(Project p) {
    splashT = splash ? 0.f : -1.f;
    hud.setup(p);
    ctl.hud = &hud;
    ctl.reset();
    if (audio) {
        audio->stopMusic();
        audio->setAssets(p.assets);  // los buffers de los vectores sobreviven al mover el proyecto
        game.onSound = [this](const std::string& n) { audio->play(n); };
        game.onMusic = [this](const std::string& n, bool on) { if (on) audio->music(n); else audio->stopMusic(); };
        game.onStopSounds = [this]() { audio->stopAll(); };
        game.soundLen = [this](const std::string& n) { return audio->length(n); };
        game.onVolume = [this](float v) { audio->setVolume(v); };
        audio->setVolume(1.f);
    } else {
        game.onSound = nullptr;
        game.onMusic = nullptr;
        game.onStopSounds = nullptr;
        game.soundLen = nullptr;
        game.onVolume = nullptr;
    }
    game.onVibrate = onVibrate;
    game.onSpeak = onSpeak;
    game.onFlash = onFlash;
    game.load(std::move(p));
}

void PlayView::frame(Renderer* r, int w, int h, float dt, const Input* direct) {
    if (splashT >= 0.f) {  // pantalla de inicio: el juego espera a que termine
        splashT += dt;
        if (!r || splashT >= kSplashSeconds) splashT = -1.f;
        else {
            if (r) r->clear(w, h, 1.f, 1.f, 1.f);
            drawSplash(ImGui::GetForegroundDrawList(), r, w, h, splashT);
            ctl.reset();
            return;
        }
    }
    ctl.w = w;
    ctl.h = h;
    ctl.is3d = game.sc && game.sc->is3d;
    Input in = direct ? *direct : ctl.consume();
    float aspect = h > 0 ? (float)w / (float)h : 1.f;
    game.update(dt, in, aspect);
    if (r) r->render(game, w, h);
    hud.draw(ImGui::GetForegroundDrawList(), game, r, w, h, showButtons && !direct);
}

}  // namespace forge
