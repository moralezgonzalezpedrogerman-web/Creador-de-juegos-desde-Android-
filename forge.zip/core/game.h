#pragma once
#include "formula.h"
#include "scene.h"
#include <deque>
#include <functional>
#include <map>
#include <string>
#include <vector>

namespace forge {

constexpr float kView2DHeight = 1000.f;  // alto del escenario 2D en "pasos" (como Pocket Code)

struct TouchPt { bool down = false; float x = 0, y = 0; };  // x,y normalizados 0..1

struct Input {
    float moveX = 0, moveY = 0;      // -1..1 (adelante = +Y)
    float lookX = 0, lookY = 0;      // radianes a girar este frame
    bool jump = false;
    bool shoot = false;              // disparar (se mantiene)
    bool tap = false;                // toque/clic: interactuar
    float tapX = 0.5f, tapY = 0.5f;  // 0..1 en pantalla (escenas 2D)
    TouchPt touch[10];               // dedos actuales (para las formulas de toque)
};

// Datos del dispositivo que la plataforma puede rellenar (sensores).
struct DeviceInfo {
    float battery = 100, accel[3] = {0, 0, 0}, compass = 0;
    double lat = 0, lon = 0, alt = 0, acc = 0;
    int online = 1;
    std::string lang = "es", clipboard;
    float keyboardH = 0;
};

struct Loop { int start; int remaining; };
struct Runner {
    int id = 0, obj = 0, hat = 0, pc = 0, end = 0;
    std::vector<Loop> loops;
    float wait = 0;
    float gT = 0, gE = 0;          // deslizamiento: duracion y tiempo transcurrido
    V3 gFrom, gTo;
    std::vector<int> waitIds;      // "Envia y espera": guiones que faltan por terminar
    bool done = false;
};

class Game : public FormulaEnv {
public:
    Project proj;
    Scene* sc = nullptr;

    V3 pos, vel;
    float yaw = 0, pitch = 0;
    bool ground = false;
    float time = 0;

    // Arma
    float shootCd = 0, recoil = 0, flash = 0;

    std::map<std::string, Val> vars;                         // variables globales (clave normalizada)
    std::map<std::string, std::pair<float, float>> shown;    // variables visibles: nombre -> (x, y) en el escenario
    std::string say;     // texto de "Decir"
    float sayT = 0;
    float volume = 100;  // %
    DeviceInfo dev;

    std::function<void(const std::string&)> onSound;
    std::function<void(const std::string&, bool)> onMusic;  // (nombre, encender)
    std::function<void()> onStopSounds;
    std::function<void(float)> onVolume;    // 0..1
    std::function<void(const std::string&)> onSpeak;
    std::function<void(float)> onVibrate;   // segundos
    std::function<void(bool)> onFlash;

    void load(Project p);
    void enterScene(const std::string& name);
    void bindScene(int idx);  // solo apunta a la escena (editor), sin ejecutar guiones
    void update(float dt, const Input& in, float aspect);

    V3 eye() const { return {pos.x, pos.y + 1.6f, pos.z}; }
    V3 forward() const;
    float stageW() const { return kView2DHeight * aspect_; }

    // formulas
    Val eval(const std::string& f, int obj);
    double num(const std::string& f, int obj) { return eval(f, obj).num(); }
    bool lookup(const std::string& name, const std::vector<Val>& args, Val& out) override;
    static std::string vkey(const std::string& n) { return normName(n); }
    Val getVar(const std::string& name, int obj);
    void setVar(const std::string& name, Val v, int obj);
    bool hasHat(const Obj& o, Op hat) const;

private:
    struct Compiled { std::vector<int> match; std::vector<int> hats; };
    struct ObjState {
        float sizePct = 100, spin = 0;
        V3 vel;
        int look = 0;
        std::map<std::string, Val> locals;
        std::vector<char> hatState;  // ultimo estado de "se convierta en verdadero" / colision, por bloque
    };
    std::deque<Runner> runners_;  // deque: los guiones nuevos no invalidan referencias
    std::vector<Compiled> cmp_;
    std::vector<ObjState> st_;
    std::vector<char> near_;
    std::vector<V3> base_;
    std::string pending_;
    int cur_ = 0, nextId_ = 1;
    float aspect_ = 16.f / 9.f, gravX_ = 0, gravY_ = -10, fps_ = 60;
    Input in_;

    struct CBox { float cx, cy, cz, hx, hy, hz; };       // caja de colision en coordenadas del modelo (cubo unitario)
    mutable std::map<std::string, std::vector<CBox>> mcol_;
    const std::vector<CBox>& modelBoxes(const std::string& name) const;
    bool rayObj(const Obj& o, V3 e, V3 d, float& t) const;
    bool blocked(V3 p) const;
    int findObj(const std::string& name) const;
    bool overlap(const Obj& a, const Obj& b) const;
    void fireHat(int obj, Op hat);
    int startScript(int obj, int hatIdx);
    void broadcast(const std::string& msg, std::vector<int>* ids);
    void step(Runner& r, float dt);
    void physics(float dt);
    void checkConditions();
    void tap3D();
    void shoot3D();
    void tap2D(float x, float y);
};

}  // namespace forge
