#pragma once
#include "formula.h"
#include "scene.h"
#include "rig.h"
#include <deque>
#include <functional>
#include <map>
#include <string>
#include <vector>

namespace forge {

constexpr float kView2DHeight = 1000.f;  // alto del escenario 2D en "pasos" (como Pocket Code)

struct TouchPt { bool down = false; float x = 0, y = 0; };  // x,y normalizados 0..1

struct Input {
    float moveX = 0, moveY = 0;      // -1..1 (adelante = +Y)
    float lookX = 0, lookY = 0;      // radianes a girar este frame
    bool jump = false;
    bool shoot = false;              // disparar (se mantiene)
    bool reload = false, nextWeapon = false, flash = false;  // v8: recargar / cambiar de arma (un cuadro)
    bool tap = false;                // toque/clic: interactuar
    float tapX = 0.5f, tapY = 0.5f;  // 0..1 en pantalla (escenas 2D)
    TouchPt touch[10];               // dedos actuales (para las formulas de toque)
    std::vector<std::string> buttons;  // botones de pantalla presionados en este cuadro (por su texto)
};

// Datos del dispositivo que la plataforma puede rellenar (sensores).
struct DeviceInfo {
    float battery = 100, accel[3] = {0, 0, 0}, compass = 0;
    double lat = 0, lon = 0, alt = 0, acc = 0;
    int online = 1;
    std::string lang = "es", clipboard;
    float keyboardH = 0;
};

struct Loop { int start; int remaining; };
struct Runner {
    int id = 0, obj = 0, hat = 0, pc = 0, end = 0;
    std::vector<Loop> loops;
    float wait = 0;
    float gT = 0, gE = 0;          // deslizamiento: duracion y tiempo transcurrido
    V3 gFrom, gTo;
    std::vector<int> waitIds;      // "Envia y espera": guiones que faltan por terminar
    bool done = false;
};

class Game : public FormulaEnv {
public:
    Project proj;
    Scene* sc = nullptr;

    V3 pos, vel;
    float yaw = 0, pitch = 0;
    // v8: objetivo fijado
    bool targetOn_ = false;
    int target_ = -1, targetKind_ = 1;
    void aimAtTarget(float dt);
    // v8: video en objetos
    struct VidState { bool opened = false, started = false; int state = 0, loop = 0; std::string name; };
    std::vector<VidState> vid_;
    void videoCmd(int obj, int cmd, const std::string& asset, int times);   // 0 reproducir 1 pausar 2 reanudar 3 ciclo 4 N veces 5 reiniciar 6 detener
    void videoTick();
    bool videoFrame(int obj, int& w, int& h, std::vector<uint8_t>& px);
    // v8: armas (0 = principal, i>=1 = extras)
    std::vector<int> owned_, wMag_, wAmmo_;
    int curW_ = -1;
    float reloadT_ = 0.f, kick_ = 0.f;
    const Weapon& weaponAt(int i) const { return i <= 0 ? proj.weapon : proj.extraWeapons[i - 1]; }
    const Weapon* curWeapon() const { return curW_ >= 0 && curW_ <= (int)proj.extraWeapons.size() ? &weaponAt(curW_) : nullptr; }
    void initWeapons();
    void giveWeapon(const std::string& name);
    void cycleWeapon();
    void startReload();
    void weaponTick(float dt, const Input& in);
    bool ground = false;
    float time = 0;

    // Arma
    float shootCd = 0, recoil = 0, flash = 0;

    std::map<std::string, Val> vars;                         // variables globales (clave normalizada)
    std::map<std::string, std::pair<float, float>> shown;    // variables visibles: nombre -> (x, y) en el escenario
    std::string say;     // texto de "Decir"
    float sayT = 0;
    float volume = 100;  // %
    DeviceInfo dev;

    std::function<void(const std::string&)> onSound;
    std::function<void(const std::string&, bool)> onMusic;  // (nombre, encender)
    std::function<void()> onStopSounds;
    std::function<void(float)> onVolume;    // 0..1
    std::function<void(const std::string&)> onSpeak;
    std::function<void(float)> onVibrate;   // segundos
    std::function<void(bool)> onFlash;
    std::function<float(const std::string&)> soundLen;  // duracion (s) de un sonido, para "reproducir y esperar"

    // Camara y jugador
    int camMode = 0;                 // 0 primera persona, 1 al hombro, 2 fija en tercera persona
    V3 camEye, camFwd{0, 0, -1};
    float bodyYaw = 0;               // hacia donde mira el cuerpo del jugador (radianes)
    float walkSpeed = 4.5f, jumpPow = 7.f;
    float hurtFlash = 0;             // destello rojo al recibir dano

    // Proyectiles (del jugador y de los enemigos)
    struct Proj {
        V3 p, v;
        float life = 4.f, size = 0.2f, dmg = 1.f, col[3] = {1, 1, 1};
        int owner = -1;              // -1 = jugador; si no, indice del enemigo
        int shape = 0;
        std::string tex, model;
        float grav = 0.f, blast = 0.f;  // v8: arrojadiza (grav) y granada (blast > 0: explota al terminar su mecha)
        bool rest = false;
    };
    std::vector<Proj> projs;
    float camRoll = 0.f, camRollTarget = 0.f, camRollTotal = 0.f, bobPhase_ = 0.f, bobAmp_ = 0.f, bobRoll_ = 0.f, dt_ = 0.016f;  // v9: inclinacion y balanceo de camara (radianes)
    std::vector<char> keep_;           // v9: objetos 2D que no pueden salir de la pantalla
    bool keepAll_ = false;
    std::vector<std::string> keepExcept_;
    void keepTick();
    void snd(int slot);                 // v9: sonidos del juego (0 paso,1 salto,2 aterrizaje,3 disparo,4 recarga,5 golpe,6 daño,7 explosión)
    bool flashOn_ = false, worldFrozen_ = false, playerFrozen_ = false;  // v9
    float stepAcc_ = 0.f, lastVelY_ = 0.f;
    bool wasGround_ = true;
    void explode(const Proj& p);

    // Pedazos de objetos rotos (decorativos)
    struct Debris {
        V3 p, v;
        float size = 0.2f, life = 2.5f, ground = 0.f, spin = 0.f, ang = 0.f, col[3] = {1, 1, 1};
        std::string tex;
        bool is3 = true;
    };
    std::vector<Debris> debris;
    float shakeT = 0, shakeAmp = 0;

    // Particulas vivas
    struct Part {
        V3 p, v;
        float life = 1, max = 1, size = 0.3f, grow = 0, grav = 0, a0 = 1, c0[3], c1[3];
        bool glow = false, is3 = true;
        std::string tex;
    };
    std::vector<Part> parts;
    void emitParticles(int obj, int n);

    // Aspecto actual de un objeto (animacion de enemigos).
    struct ObjVis {
        std::string tex, model;      // vacios = los del objeto
        std::string clip;            // animacion de esqueleto del estado actual
        float bob = 0, sway = 0, lunge = 0, squash = 1;
        bool billboard = false;
    };
    ObjVis vis(int i) const;
    // Modelo con esqueleto: vertices ya deformados (nullptr si el objeto no tiene animacion de esqueleto).
    bool skinVerts(int i, const std::string& model, const std::vector<float>*& verts, const std::vector<uint32_t>*& idx, unsigned long long& sig);
    const Rig* rigOf(int i, const std::string& model) const;
    void clearRigCache() { rigs_.clear(); }
    void applyCam();
    void hurtPlayer(float d);

    void load(Project p);
    void enterScene(const std::string& name);
    void bindScene(int idx);  // solo apunta a la escena (editor), sin ejecutar guiones
    void update(float dt, const Input& in, float aspect);

    V3 eye() const { return {pos.x, pos.y + 1.6f, pos.z}; }
    V3 forward() const;
    float stageW() const { return kView2DHeight * aspect_; }

    // formulas
    Val eval(const std::string& f, int obj);
    double num(const std::string& f, int obj) { return eval(f, obj).num(); }
    bool lookup(const std::string& name, const std::vector<Val>& args, Val& out) override;
    static std::string vkey(const std::string& n) { return normName(n); }
    Val getVar(const std::string& name, int obj);
    void setVar(const std::string& name, Val v, int obj);
    bool hasHat(const Obj& o, Op hat) const;

private:
    struct Compiled { std::vector<int> match; std::vector<int> hats; };
    struct ObjState {
        float sizePct = 100, spin = 0;
        V3 vel;
        int look = 0;
        std::map<std::string, Val> locals;
        std::vector<char> hatState;  // ultimo estado de "se convierta en verdadero" / colision, por bloque
        // enemigos
        std::string clip, curClip;   // animacion de esqueleto pedida por bloques / la que se esta reproduciendo
        float clipStart = 0;
        float fxAcc = 0;
        int anim = 0;
        float animT = 0, hp = 3, atkCd = 0, atkT = 0, hurtT = 0, deadT = 0, forceT = 0;
        bool dead = false;
    };
    std::deque<Runner> runners_;  // deque: los guiones nuevos no invalidan referencias
    std::vector<Compiled> cmp_;
    std::vector<ObjState> st_;
    std::vector<char> near_;
    std::vector<V3> base_;
    std::string pending_;
    int cur_ = 0, nextId_ = 1;
    std::vector<int> pendingClones_;
    struct RigRT {
        Rig rig;
        bool ok = false;
        std::string model;
        std::vector<float> rest, out;
        std::vector<uint32_t> idx;
        RigWeights w;
    };
    std::map<std::string, RigRT> rigs_;    // clave: archivo de esqueleto + "|" + modelo
    RigRT* rigRT(int i, const std::string& model);
    std::vector<V3> last_;
    std::vector<char> moving_;
    bool plMoving_ = false, plAir_ = false;
    void fireHatText(Op hat, const std::string& txt);
    void fireAll(Op hat);
    void eventsV6(float dt, const Input& in);
    void breakApart(int i, int n);
    void updateDebris(float dt);
    void updateParts(float dt);
    float aspect_ = 16.f / 9.f, gravX_ = 0, gravY_ = -10, fps_ = 60;
    Input in_;

    struct CBox { float cx, cy, cz, hx, hy, hz; };       // caja de colision en coordenadas del modelo (cubo unitario)
    mutable std::map<std::string, std::vector<CBox>> mcol_;
    const std::vector<CBox>& modelBoxes(const std::string& name) const;
    bool rayObj(const Obj& o, V3 e, V3 d, float& t) const;
    bool blocked(V3 p) const;
    bool blockedBox(V3 feet, float hw, float h, int skip, float stepTol = 0.f) const;
    float groundAt(V3 p, float hw) const;  // mayor altura de suelo deformable bajo los pies (-1e9 si no hay)
    void updateAI(float dt);
    void updateProjs(float dt);
    void spawnProj(V3 from, V3 dir, int owner);
    void damageObj(int i, float dmg);
    int findObj(const std::string& name) const;
    bool overlap(const Obj& a, const Obj& b) const;
    void fireHat(int obj, Op hat);
    int startScript(int obj, int hatIdx);
    void broadcast(const std::string& msg, std::vector<int>* ids);
    void step(Runner& r, float dt);
    void physics(float dt);
    void checkConditions();
    void tap3D();
    void shoot3D();
    void tap2D(float x, float y);
};

}  // namespace forge
