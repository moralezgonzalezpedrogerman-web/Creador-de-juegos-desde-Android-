#include "brand.h"
#include "renderer.h"
#include "imgui.h"
#include "stb_image.h"
#include <algorithm>
#include <cmath>

namespace forge {

extern const unsigned char kLogo[], kBgHall[], kBgForest[];
extern const unsigned kLogoSize, kBgHallSize, kBgForestSize;

unsigned brandTexture(Renderer* r, int which, int* w, int* h) {
    if (!r) return 0;
    static const char* keys[3] = {"::brand_logo", "::brand_hall", "::brand_forest"};
    if (which < 0 || which > 2) return 0;
    if (!r->hasTexture(keys[which])) {
        const unsigned char* d = which == 0 ? kLogo : which == 1 ? kBgHall : kBgForest;
        unsigned n = which == 0 ? kLogoSize : which == 1 ? kBgHallSize : kBgForestSize;
        int iw = 0, ih = 0, c = 0;
        unsigned char* px = stbi_load_from_memory(d, (int)n, &iw, &ih, &c, 4);
        if (!px) return 0;
        r->uploadRGBA(keys[which], iw, ih, px);
        stbi_image_free(px);
    }
    return r->rawTexture(keys[which], w, h);
}

static float ease(float x) { x = std::max(0.f, std::min(1.f, x)); return x * x * (3.f - 2.f * x); }

void drawSplash(ImDrawList* dl, Renderer* r, int w, int h, float t) {
    if (!dl) return;
    float fadeIn = ease(t / 0.6f), fadeOut = 1.f - ease((t - (kSplashSeconds - 0.5f)) / 0.5f);
    float a = std::min(fadeIn, fadeOut);
    // fondo blanco con un degradado suave
    dl->AddRectFilledMultiColor(ImVec2(0, 0), ImVec2((float)w, (float)h), IM_COL32(255, 255, 255, 255), IM_COL32(255, 255, 255, 255),
                                IM_COL32(236, 240, 248, 255), IM_COL32(236, 240, 248, 255));
    float s = std::min(w, h) * 0.30f;
    float cx = w * 0.5f, cy = h * 0.43f - (1.f - fadeIn) * s * 0.08f;
    int alpha = (int)(a * 255);
    unsigned id = brandTexture(r, 0);
    if (id) {
        dl->AddRectFilled(ImVec2(cx - s * 0.5f + 4, cy - s * 0.5f + 8), ImVec2(cx + s * 0.5f + 4, cy + s * 0.5f + 8), IM_COL32(20, 30, 60, (int)(a * 40)), s * 0.12f);
        dl->AddImageRounded((ImTextureID)(intptr_t)id, ImVec2(cx - s * 0.5f, cy - s * 0.5f), ImVec2(cx + s * 0.5f, cy + s * 0.5f),
                            ImVec2(0, 0), ImVec2(1, 1), IM_COL32(255, 255, 255, alpha), s * 0.12f);
    }
    ImFont* f = ImGui::GetFont();
    float fs = std::max(ImGui::GetFontSize() * 1.6f, s * 0.17f);
    const char* title = "P-Maker code333";
    ImVec2 ts = f->CalcTextSizeA(fs, 1e9f, 0.f, title);
    dl->AddText(f, fs, ImVec2(cx - ts.x * 0.5f, cy + s * 0.5f + fs * 0.7f), IM_COL32(28, 36, 60, alpha), title);
    float fs2 = ImGui::GetFontSize();
    const char* sub = "Motor de juegos";
    ImVec2 ts2 = f->CalcTextSizeA(fs2, 1e9f, 0.f, sub);
    dl->AddText(f, fs2, ImVec2(cx - ts2.x * 0.5f, cy + s * 0.5f + fs * 0.7f + fs * 1.25f), IM_COL32(90, 100, 130, (int)(a * 200)), sub);
    // barra de carga fina
    float bw = std::min(w * 0.4f, s * 1.6f), by = h * 0.88f, p = std::min(1.f, t / (kSplashSeconds - 0.3f));
    dl->AddRectFilled(ImVec2(cx - bw * 0.5f, by), ImVec2(cx + bw * 0.5f, by + 4.f), IM_COL32(200, 208, 225, alpha), 2.f);
    dl->AddRectFilled(ImVec2(cx - bw * 0.5f, by), ImVec2(cx - bw * 0.5f + bw * p, by + 4.f), IM_COL32(30, 190, 170, alpha), 2.f);
}

void drawMenuBackdrop(ImDrawList* dl, Renderer* r, int w, int h, int which, float t) {
    if (!dl) return;
    dl->AddRectFilled(ImVec2(0, 0), ImVec2((float)w, (float)h), IM_COL32(8, 12, 18, 255));
    int iw = 1, ih = 1;
    unsigned id = brandTexture(r, which, &iw, &ih);
    if (id && iw > 0 && ih > 0) {  // cubrir la pantalla con un lento vaiven
        float sc = std::max((float)w / iw, (float)h / ih) * 1.08f;
        float dw = iw * sc, dh = ih * sc;
        float ox = (dw - w) * (0.5f + 0.5f * std::sin(t * 0.12f)), oy = (dh - h) * 0.5f;
        dl->AddImage((ImTextureID)(intptr_t)id, ImVec2(-ox, -oy), ImVec2(dw - ox, dh - oy), ImVec2(0, 0), ImVec2(1, 1));
    }
    dl->AddRectFilledMultiColor(ImVec2(0, 0), ImVec2((float)w, (float)h), IM_COL32(6, 10, 16, 150), IM_COL32(6, 10, 16, 110),
                                IM_COL32(6, 10, 16, 215), IM_COL32(6, 10, 16, 215));
}

}  // namespace forge
